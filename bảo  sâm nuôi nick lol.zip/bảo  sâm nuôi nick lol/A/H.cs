using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace A;

[CompilerGenerated]
internal sealed class H
{
	[StructLayout(LayoutKind.Explicit, Pack = 2, Size = 4)]
	internal struct m_6822
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 6)]
	internal struct m_6823
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 20)]
	internal struct B
	{
	}

	internal static readonly m_6822 A/* Not supported: data(2C 00 0A 00) */;

	internal static readonly m_6823 m_6818/* Not supported: data(20 00 0D 00 0A 00) */;

	internal static readonly long m_6819/* Not supported: data(5B 00 5D 00 22 00 20 00) */;

	internal static readonly B m_6820/* Not supported: data(01 00 00 00 02 00 00 00 04 00 00 00 08 00 00 00 10 00 00 00) */;

	internal static ReadOnlySpan<gm_6815> m_6821<gm_6814, gm_6815>(in gm_6814 buffer, int P_1)
	{
		return MemoryMarshal.CreateReadOnlySpan(in Unsafe.As<gm_6814, gm_6815>(ref Unsafe.AsRef(in buffer)), P_1);
	}

	internal static ref gm_6817 a<gm_6816, gm_6817>(ref gm_6816 P_0, int P_1)
	{
		return ref Unsafe.Add(ref Unsafe.As<gm_6816, gm_6817>(ref P_0), P_1);
	}
}
