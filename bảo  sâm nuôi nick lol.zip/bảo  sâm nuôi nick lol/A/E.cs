using System;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace A;

internal static class E
{
	public static void A(Popup P_0, object? sender)
	{
		A(P_0, sender, true);
	}

	public static void a(Popup P_0, object? sender)
	{
		A(P_0, sender, !P_0.IsOpen);
	}

	private static void A(Popup P_0, object? sender, bool P_2)
	{
		if (sender is UIElement uIElement && !A((DependencyObject?)(object)uIElement))
		{
			P_0.PlacementTarget = uIElement;
			P_0.Placement = PlacementMode.Bottom;
		}
		else
		{
			P_0.PlacementTarget = null;
			P_0.Placement = PlacementMode.MousePoint;
		}
		P_0.IsOpen = P_2;
	}

	private static bool A(DependencyObject? P_0)
	{
		while (P_0 != null)
		{
			if (P_0 is ContextMenu || P_0 is Popup || P_0 is MenuItem)
			{
				return true;
			}
			DependencyObject parent = LogicalTreeHelper.GetParent(P_0);
			if (parent == null && P_0 is Visual)
			{
				parent = VisualTreeHelper.GetParent(P_0);
			}
			P_0 = parent;
		}
		return false;
	}
}
internal sealed class e : JsonConverter<int>
{
	public override int Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
	{
		if (reader.TokenType == JsonTokenType.Number)
		{
			if (!reader.TryGetInt32(out var value))
			{
				return (int)Math.Round(reader.GetDouble());
			}
			return value;
		}
		if (reader.TokenType == JsonTokenType.String)
		{
			string s = reader.GetString() ?? "0";
			if (int.TryParse(s, out var result))
			{
				return result;
			}
			if (double.TryParse(s, CultureInfo.InvariantCulture, out var result2))
			{
				return (int)Math.Round(result2);
			}
		}
		throw new JsonException($"Không đọc được số nguyên từ giá trị JSON kiểu {reader.TokenType}.");
	}

	public override void Write(Utf8JsonWriter writer, int P_2862, JsonSerializerOptions options)
	{
		writer.WriteNumberValue(P_2862);
	}
}
