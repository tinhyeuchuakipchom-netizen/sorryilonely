using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using testTuongTacWPF;

namespace A;

internal static class G
{
	private const byte A = 27;

	private const uint m_5792 = 2u;

	[DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
	private static extern bool m_5793(nint P_0);

	[DllImport("user32.dll", EntryPoint = "keybd_event")]
	private static extern void m_5794(byte P_0, byte P_1, uint P_2, nuint P_3);

	public static void a(nint P_0)
	{
		if (P_0 == IntPtr.Zero)
		{
			return;
		}
		try
		{
			m_5793(P_0);
			Thread.Sleep(150);
			m_5794(27, 0, 0u, UIntPtr.Zero);
			Thread.Sleep(30);
			m_5794(27, 0, 2u, UIntPtr.Zero);
		}
		catch
		{
		}
	}
}
internal static class g
{
	[CompilerGenerated]
	private sealed class m_6069
	{
		public IBrowser A;

		internal void m_6070()
		{
			A(A);
		}
	}

	public static Proxy? A(string? P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return null;
		}
		ProxyParseResult proxyParseResult = ProxyParser.Parse(P_0);
		if (!proxyParseResult.IsValid)
		{
			throw new InvalidOperationException("Proxy không hợp lệ: " + proxyParseResult.Error);
		}
		string value = proxyParseResult.Scheme ?? "http";
		return new Proxy
		{
			Server = $"{value}://{proxyParseResult.Host}:{proxyParseResult.Port}",
			Username = proxyParseResult.User,
			Password = proxyParseResult.Pass
		};
	}

	public static CancellationTokenRegistration A(CancellationToken P_0, IBrowser P_1)
	{
		return P_0.Register(() =>
		{
			A(P_1);
		});
	}

	private static async Task A(IBrowser P_0)
	{
		try
		{
			await P_0.CloseAsync();
		}
		catch
		{
		}
	}
}
