using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace A;

[CompilerGenerated]
internal sealed class A<gp_0, gp_1, gp_2, gp_3>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_0 m_5;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_1 m_6;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_2 m_7;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_3 m_8;

	[SpecialName]
	public gp_0 m_9()
	{
		return m_5;
	}

	[SpecialName]
	public gp_1 a()
	{
		return m_6;
	}

	[SpecialName]
	public gp_2 B()
	{
		return m_7;
	}

	[SpecialName]
	public gp_3 b()
	{
		return m_8;
	}

	[DebuggerHidden]
	public A(gp_0 P_0, gp_1 P_1, gp_2 P_2, gp_3 P_3)
	{
		m_5 = P_0;
		m_6 = P_1;
		m_7 = P_2;
		m_8 = P_3;
	}

	[DebuggerHidden]
	public override bool Equals(object P_4)
	{
		A<gp_0, gp_1, gp_2, gp_3> a2 = P_4 as A<gp_0, gp_1, gp_2, gp_3>;
		if (this != a2)
		{
			if (a2 != null && EqualityComparer<gp_0>.Default.Equals(m_5, a2.m_5) && EqualityComparer<gp_1>.Default.Equals(m_6, a2.m_6) && EqualityComparer<gp_2>.Default.Equals(m_7, a2.m_7))
			{
				return EqualityComparer<gp_3>.Default.Equals(m_8, a2.m_8);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (((unchecked(-1377278836 * -1521134295) + EqualityComparer<gp_0>.Default.GetHashCode(m_5)) * -1521134295 + EqualityComparer<gp_1>.Default.GetHashCode(m_6)) * -1521134295 + EqualityComparer<gp_2>.Default.GetHashCode(m_7)) * -1521134295 + EqualityComparer<gp_3>.Default.GetHashCode(m_8);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[4];
		gp_0 val = m_5;
		array[0] = ((val != null) ? val.ToString() : null);
		gp_1 val2 = m_6;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		gp_2 val3 = m_7;
		array[2] = ((val3 != null) ? val3.ToString() : null);
		gp_3 val4 = m_8;
		array[3] = ((val4 != null) ? val4.ToString() : null);
		return string.Format(null, "{{ bizName = {0}, firstName = {1}, lastName = {2}, email = {3} }}", array);
	}
}
[CompilerGenerated]
internal sealed class a<gp_10, gp_11, gp_12, gp_13>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_10 A;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_11 m_15;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_12 m_16;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_13 m_17;

	[SpecialName]
	public gp_10 m_18()
	{
		return A;
	}

	[SpecialName]
	public gp_11 m_19()
	{
		return m_15;
	}

	[SpecialName]
	public gp_12 B()
	{
		return m_16;
	}

	[SpecialName]
	public gp_13 b()
	{
		return m_17;
	}

	[DebuggerHidden]
	public a(gp_10 P_0, gp_11 P_1, gp_12 P_2, gp_13 P_3)
	{
		A = P_0;
		m_15 = P_1;
		m_16 = P_2;
		m_17 = P_3;
	}

	[DebuggerHidden]
	public override bool Equals(object P_14)
	{
		a<gp_10, gp_11, gp_12, gp_13> a2 = P_14 as a<gp_10, gp_11, gp_12, gp_13>;
		if (this != a2)
		{
			if (a2 != null && EqualityComparer<gp_10>.Default.Equals(A, a2.A) && EqualityComparer<gp_11>.Default.Equals(m_15, a2.m_15) && EqualityComparer<gp_12>.Default.Equals(m_16, a2.m_16))
			{
				return EqualityComparer<gp_13>.Default.Equals(m_17, a2.m_17);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (((unchecked(59755437 * -1521134295) + EqualityComparer<gp_10>.Default.GetHashCode(A)) * -1521134295 + EqualityComparer<gp_11>.Default.GetHashCode(m_15)) * -1521134295 + EqualityComparer<gp_12>.Default.GetHashCode(m_16)) * -1521134295 + EqualityComparer<gp_13>.Default.GetHashCode(m_17);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[4];
		gp_10 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		gp_11 val2 = m_15;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		gp_12 val3 = m_16;
		array[2] = ((val3 != null) ? val3.ToString() : null);
		gp_13 val4 = m_17;
		array[3] = ((val4 != null) ? val4.ToString() : null);
		return string.Format(null, "{{ type = {0}, duration = {1}, x = {2}, y = {3} }}", array);
	}
}
