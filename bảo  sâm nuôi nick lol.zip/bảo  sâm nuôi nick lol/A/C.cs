using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace A;

[CompilerGenerated]
internal sealed class C<gp_30>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_30 A;

	[SpecialName]
	public gp_30 m_32()
	{
		return A;
	}

	[DebuggerHidden]
	public C(gp_30 P_0)
	{
		A = P_0;
	}

	[DebuggerHidden]
	public override bool Equals(object P_31)
	{
		C<gp_30> c2 = P_31 as C<gp_30>;
		if (this != c2)
		{
			if (c2 != null)
			{
				return EqualityComparer<gp_30>.Default.Equals(A, c2.A);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return unchecked(-418940205 * -1521134295) + EqualityComparer<gp_30>.Default.GetHashCode(A);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[1];
		gp_30 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		return string.Format(null, "{{ actions = {0} }}", array);
	}
}
[CompilerGenerated]
internal sealed class c<gp_33, gp_34, gp_35, gp_36>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_33 A;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_34 m_38;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_35 m_39;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_36 m_40;

	[SpecialName]
	public gp_33 m_41()
	{
		return A;
	}

	[SpecialName]
	public gp_34 a()
	{
		return m_38;
	}

	[SpecialName]
	public gp_35 B()
	{
		return m_39;
	}

	[SpecialName]
	public gp_36 b()
	{
		return m_40;
	}

	[DebuggerHidden]
	public c(gp_33 P_0, gp_34 P_1, gp_35 P_2, gp_36 P_3)
	{
		A = P_0;
		m_38 = P_1;
		m_39 = P_2;
		m_40 = P_3;
	}

	[DebuggerHidden]
	public override bool Equals(object P_37)
	{
		c<gp_33, gp_34, gp_35, gp_36> c2 = P_37 as c<gp_33, gp_34, gp_35, gp_36>;
		if (this != c2)
		{
			if (c2 != null && EqualityComparer<gp_33>.Default.Equals(A, c2.A) && EqualityComparer<gp_34>.Default.Equals(m_38, c2.m_38) && EqualityComparer<gp_35>.Default.Equals(m_39, c2.m_39))
			{
				return EqualityComparer<gp_36>.Default.Equals(m_40, c2.m_40);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (((unchecked(-500393386 * -1521134295) + EqualityComparer<gp_33>.Default.GetHashCode(A)) * -1521134295 + EqualityComparer<gp_34>.Default.GetHashCode(m_38)) * -1521134295 + EqualityComparer<gp_35>.Default.GetHashCode(m_39)) * -1521134295 + EqualityComparer<gp_36>.Default.GetHashCode(m_40);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[4];
		gp_33 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		gp_34 val2 = m_38;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		gp_35 val3 = m_39;
		array[2] = ((val3 != null) ? val3.ToString() : null);
		gp_36 val4 = m_40;
		array[3] = ((val4 != null) ? val4.ToString() : null);
		return string.Format(null, "{{ type = {0}, id = {1}, parameters = {2}, actions = {3} }}", array);
	}
}
