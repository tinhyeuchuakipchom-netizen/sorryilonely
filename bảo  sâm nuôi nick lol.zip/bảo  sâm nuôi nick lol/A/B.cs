using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace A;

[CompilerGenerated]
internal sealed class B<gp_20, gp_21>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_20 A;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_21 m_23;

	[SpecialName]
	public gp_20 m_24()
	{
		return A;
	}

	[SpecialName]
	public gp_21 a()
	{
		return m_23;
	}

	[DebuggerHidden]
	public B(gp_20 P_0, gp_21 P_1)
	{
		A = P_0;
		m_23 = P_1;
	}

	[DebuggerHidden]
	public override bool Equals(object P_22)
	{
		B<gp_20, gp_21> b2 = P_22 as B<gp_20, gp_21>;
		if (this != b2)
		{
			if (b2 != null && EqualityComparer<gp_20>.Default.Equals(A, b2.A))
			{
				return EqualityComparer<gp_21>.Default.Equals(m_23, b2.m_23);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (unchecked(-405607496 * -1521134295) + EqualityComparer<gp_20>.Default.GetHashCode(A)) * -1521134295 + EqualityComparer<gp_21>.Default.GetHashCode(m_23);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[2];
		gp_20 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		gp_21 val2 = m_23;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		return string.Format(null, "{{ type = {0}, button = {1} }}", array);
	}
}
[CompilerGenerated]
internal sealed class b<gp_25, gp_26>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_25 A;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_26 m_28;

	[SpecialName]
	public gp_25 m_29()
	{
		return A;
	}

	[SpecialName]
	public gp_26 a()
	{
		return m_28;
	}

	[DebuggerHidden]
	public b(gp_25 P_0, gp_26 P_1)
	{
		A = P_0;
		m_28 = P_1;
	}

	[DebuggerHidden]
	public override bool Equals(object P_27)
	{
		b<gp_25, gp_26> b2 = P_27 as b<gp_25, gp_26>;
		if (this != b2)
		{
			if (b2 != null && EqualityComparer<gp_25>.Default.Equals(A, b2.A))
			{
				return EqualityComparer<gp_26>.Default.Equals(m_28, b2.m_28);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (unchecked(1660203076 * -1521134295) + EqualityComparer<gp_25>.Default.GetHashCode(A)) * -1521134295 + EqualityComparer<gp_26>.Default.GetHashCode(m_28);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[2];
		gp_25 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		gp_26 val2 = m_28;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		return string.Format(null, "{{ type = {0}, duration = {1} }}", array);
	}
}
