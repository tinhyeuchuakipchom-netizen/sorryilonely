using System;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using testTuongTacWPF.Automation;

namespace A;

internal static class F
{
	public static async Task<OmoBrowserStartResult> A(IAntidetectBrowserClient P_0, IChromeEngineSettings P_1, IChromeAutomationAccount P_2)
	{
		if (string.IsNullOrWhiteSpace(P_2.BrowserProfileId))
		{
			IChromeAutomationAccount chromeAutomationAccount = P_2;
			chromeAutomationAccount.BrowserProfileId = await B(P_0, P_1, P_2);
		}
		try
		{
			return await P_0.StartProfileAsync(P_2.BrowserProfileId);
		}
		catch (BrowserProfileNotFoundException)
		{
			IChromeAutomationAccount chromeAutomationAccount = P_2;
			chromeAutomationAccount.BrowserProfileId = await B(P_0, P_1, P_2);
			return await P_0.StartProfileAsync(P_2.BrowserProfileId);
		}
		catch (Exception ex2) when (A(ex2))
		{
			await a(P_0, P_1, P_2);
			return await P_0.StartProfileAsync(P_2.BrowserProfileId);
		}
	}

	public static async Task<(OmoBrowserStartResult Start, IBrowser Browser)> A(IAntidetectBrowserClient P_0, IChromeEngineSettings P_1, IChromeAutomationAccount P_2, IPlaywright P_3, CancellationToken P_4)
	{
		return await A(P_0, P_1, P_2, P_3, await A(P_0, P_1, P_2), P_4);
	}

	public static async Task<(OmoBrowserStartResult Start, IBrowser Browser)> A(IAntidetectBrowserClient P_0, IChromeEngineSettings P_1, IChromeAutomationAccount P_2, IPlaywright P_3, OmoBrowserStartResult P_4, CancellationToken P_5)
	{
		try
		{
			return (Start: P_4, Browser: await ChromeLoginRunner.m_3644(P_3, A(P_4), P_5));
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2) when (A(ex2))
		{
			await a(P_0, P_1, P_2);
			OmoBrowserStartResult omoBrowserStartResult = await A(P_0, P_1, P_2);
			return (Start: omoBrowserStartResult, Browser: await ChromeLoginRunner.m_3644(P_3, A(omoBrowserStartResult), P_5));
		}
	}

	private static string A(OmoBrowserStartResult P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0.WebSocketDebuggingUrl))
		{
			return P_0.RemoteDebuggingAddress;
		}
		return P_0.WebSocketDebuggingUrl;
	}

	private static async Task a(IAntidetectBrowserClient P_0, IChromeEngineSettings P_1, IChromeAutomationAccount P_2)
	{
		string browserProfileId = P_2.BrowserProfileId;
		if (!string.IsNullOrWhiteSpace(browserProfileId))
		{
			await P_0.StopProfileAsync(browserProfileId);
			await P_0.DeleteProfileAsync(browserProfileId, hard: true);
		}
		if (P_2.ProfileChrome.StartsWith("BaoSamBrowser_", StringComparison.OrdinalIgnoreCase) || P_2.ProfileChrome.StartsWith("GPM_", StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(P_2.ProfileChrome))
		{
			P_2.ProfileChrome = $"BaoSamBrowser_{DateTime.Now:HHmmss}_{Random.Shared.Next(1000, 9999)}";
		}
		P_2.BrowserProfileId = await B(P_0, P_1, P_2);
	}

	private static async Task<string> B(IAntidetectBrowserClient P_0, IChromeEngineSettings P_1, IChromeAutomationAccount P_2)
	{
		return (await P_0.CreateProfileAsync(P_2.ProfileChrome, P_1.UseProxy ? P_2.Proxy : "", P_2.UserAgent)).ProfileId;
	}

	internal static bool A(Exception P_0)
	{
		for (Exception ex = P_0; ex != null; ex = ex.InnerException)
		{
			if (ex is HttpRequestException { StatusCode: var statusCode } ex2 && (statusCode == HttpStatusCode.InternalServerError || (ex2.Message != null && ex2.Message.Contains("500"))))
			{
				return true;
			}
			string text = ex.Message ?? "";
			if (text.Contains("500", StringComparison.Ordinal) || text.Contains("Internal Server Error", StringComparison.OrdinalIgnoreCase) || text.Contains("HTTP 500", StringComparison.OrdinalIgnoreCase) || text.Contains("does not indicate success", StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}
}
internal static class f
{
	public static string A(string P_0, string P_1, string P_2)
	{
		int num = P_0.IndexOf(P_1, StringComparison.Ordinal);
		if (num < 0)
		{
			return "";
		}
		num += P_1.Length;
		int num2 = P_0.IndexOf(P_2, num, StringComparison.Ordinal);
		if (num2 >= 0)
		{
			int num3 = num;
			return P_0.Substring(num3, num2 - num3);
		}
		return "";
	}

	public static string a(string P_0, string P_1, string P_2)
	{
		int num = P_0.IndexOf(P_1, StringComparison.Ordinal);
		if (num < 0)
		{
			return "";
		}
		int num2 = P_0.IndexOf(P_2, num + P_1.Length, StringComparison.Ordinal);
		if (num2 >= 0)
		{
			int num3 = num;
			return P_0.Substring(num3, num2 - num3);
		}
		return "";
	}

	public static string? A(string P_0)
	{
		Match match = Regex.Match(P_0, "\\b\\d{6}\\b");
		if (match.Success)
		{
			return match.Value;
		}
		Match match2 = Regex.Match(P_0, "\\b\\d{4,8}\\b");
		if (!match2.Success)
		{
			return null;
		}
		return match2.Value;
	}
}
