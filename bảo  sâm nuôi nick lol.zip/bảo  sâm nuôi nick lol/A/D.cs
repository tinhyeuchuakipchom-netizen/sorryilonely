using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace A;

[CompilerGenerated]
internal sealed class D<gp_42>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_42 A;

	[SpecialName]
	public gp_42 m_44()
	{
		return A;
	}

	[DebuggerHidden]
	public D(gp_42 P_0)
	{
		A = P_0;
	}

	[DebuggerHidden]
	public override bool Equals(object P_43)
	{
		D<gp_42> d2 = P_43 as D<gp_42>;
		if (this != d2)
		{
			if (d2 != null)
			{
				return EqualityComparer<gp_42>.Default.Equals(A, d2.A);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return unchecked(-1752678223 * -1521134295) + EqualityComparer<gp_42>.Default.GetHashCode(A);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[1];
		gp_42 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		return string.Format(null, "{{ pointerType = {0} }}", array);
	}
}
[CompilerGenerated]
internal sealed class d<gp_45>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly gp_45 A;

	[SpecialName]
	public gp_45 m_47()
	{
		return A;
	}

	[DebuggerHidden]
	public d(gp_45 P_0)
	{
		A = P_0;
	}

	[DebuggerHidden]
	public override bool Equals(object P_46)
	{
		d<gp_45> d2 = P_46 as d<gp_45>;
		if (this != d2)
		{
			if (d2 != null)
			{
				return EqualityComparer<gp_45>.Default.Equals(A, d2.A);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return unchecked(1521275937 * -1521134295) + EqualityComparer<gp_45>.Default.GetHashCode(A);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[1];
		gp_45 val = A;
		array[0] = ((val != null) ? val.ToString() : null);
		return string.Format(null, "{{ value = {0} }}", array);
	}
}
