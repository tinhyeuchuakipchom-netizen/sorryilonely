using System.Collections.Generic;
using System.Runtime.CompilerServices;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public sealed class AiVisionTestNickPlatform
{
	[CompilerGenerated]
	private readonly string A;

	[CompilerGenerated]
	private readonly IReadOnlyList<NickFolder> m_151;

	[CompilerGenerated]
	private readonly IReadOnlyList<AiVisionTestNickCandidate> m_152;

	public required string Label
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		init
		{
			A = value;
		}
	}

	public required IReadOnlyList<NickFolder> Folders
	{
		[CompilerGenerated]
		get
		{
			return m_151;
		}
		[CompilerGenerated]
		init
		{
			m_151 = value;
		}
	}

	public required IReadOnlyList<AiVisionTestNickCandidate> Nicks
	{
		[CompilerGenerated]
		get
		{
			return m_152;
		}
		[CompilerGenerated]
		init
		{
			m_152 = value;
		}
	}

	public string NickCountLabel => $"({Nicks.Count} nick)";
}
