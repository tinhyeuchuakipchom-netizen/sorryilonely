using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;

namespace testTuongTacWPF;

public partial class TextDetailWindow : Window, IComponentConnector
{
	private readonly object A;

	private readonly string m_2159;

	private readonly string? a;

	private bool m_2160;

	private bool m_2161;

	public TextDetailWindow(Window? owner, string title, object source, string propertyPath, string? detailPropertyPath = null)
	{
		InitializeComponent();
		if (owner != null)
		{
			Owner = owner;
		}
		A = source;
		m_2159 = propertyPath;
		a = detailPropertyPath;
		TitleText.Text = title;
		m_2164(propertyPath);
		if (!string.IsNullOrEmpty(detailPropertyPath) && m_2165(propertyPath) != m_2165(detailPropertyPath))
		{
			DetailButton.Visibility = Visibility.Visible;
		}
		m_2162();
	}

	private void m_2162()
	{
		if (DownloadBrowserButton != null)
		{
			string text = ContentTextBox.Text;
			bool flag = text.Contains("BaoSam Browser", StringComparison.OrdinalIgnoreCase) && (text.Contains("Không kết nối được", StringComparison.OrdinalIgnoreCase) || text.Contains("drive.google.com"));
			DownloadBrowserButton.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void m_2163(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://drive.google.com/file/d/1TEg_PjXtIsVrj1ORNUA2MNZclMnDw3vC/view?usp=drive_link",
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			MessageBox.Show("Không thể mở liên kết: " + ex.Message);
		}
	}

	private void m_2164(string P_0)
	{
		string text = m_2165(P_0);
		if (text.Contains("Không kết nối được") && text.Contains("BaoSam Browser") && !text.Contains("drive.google.com"))
		{
			((DependencyObject)ContentTextBox).ClearValue(TextBox.TextProperty);
			ContentTextBox.Text = text + "\n\nLink tải BaoSam Browser:\nhttps://drive.google.com/file/d/1TEg_PjXtIsVrj1ORNUA2MNZclMnDw3vC/view?usp=drive_link";
		}
		else
		{
			ContentTextBox.SetBinding(TextBox.TextProperty, new Binding(P_0)
			{
				Source = A,
				Mode = BindingMode.OneWay
			});
		}
		m_2162();
	}

	private string m_2165(string P_0)
	{
		return A.GetType().GetProperty(P_0)?.GetValue(A)?.ToString() ?? "";
	}

	private void m_2166(object P_0, RoutedEventArgs P_1)
	{
		if (a != null)
		{
			m_2160 = !m_2160;
			m_2164(m_2160 ? a : m_2159);
			DetailButton.Content = (m_2160 ? "Thu gọn" : "Chi tiết");
			m_2162();
		}
	}

	private void m_2167(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Clipboard.SetText(ContentTextBox.Text);
			CopyButton.Content = "Đã copy!";
		}
		catch
		{
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		Close();
	}
}
