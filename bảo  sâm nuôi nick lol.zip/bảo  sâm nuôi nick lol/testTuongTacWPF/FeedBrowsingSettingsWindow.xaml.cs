using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class FeedBrowsingSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private PostCreationSettings m_342 = new PostCreationSettings();

	private MessagingSettings m_343 = new MessagingSettings();

	private PageCreationSettings m_344 = new PageCreationSettings();

	private PageFarmingSettings m_345 = new PageFarmingSettings();

	private bool a;

	private FeedBrowsingSettingsWindow(FeedBrowsingSettings P_0)
	{
		InitializeComponent();
		m_342 = P_0.Post ?? new PostCreationSettings();
		m_343 = P_0.Messaging ?? new MessagingSettings();
		m_344 = P_0.PageCreation ?? new PageCreationSettings();
		m_345 = P_0.PageFarming ?? new PageFarmingSettings();
		AutoMessageCheckBox.IsChecked = P_0.AutoMessage;
		MessageChanceTextBox.Text = P_0.MessageChancePercent.ToString();
		AutoPostCheckBox.IsChecked = P_0.AutoPost;
		PostChanceTextBox.Text = P_0.PostChancePercent.ToString();
		AutoCreatePageCheckBox.IsChecked = P_0.AutoCreatePage;
		CreatePageChanceTextBox.Text = P_0.CreatePageChancePercent.ToString();
		AutoFarmPageCheckBox.IsChecked = P_0.AutoFarmPage;
		MinMinutesTextBox.Text = P_0.MinMinutes.ToString();
		MaxMinutesTextBox.Text = P_0.MaxMinutes.ToString();
		AutoLikeCheckBox.IsChecked = P_0.AutoLike;
		LikeChanceTextBox.Text = P_0.LikeChancePercent.ToString();
		AutoCommentCheckBox.IsChecked = P_0.AutoComment;
		CommentChanceTextBox.Text = P_0.CommentChancePercent.ToString();
		CommentTextsTextBox.Text = string.Join("\n", P_0.CommentTexts);
		WatchReelsCheckBox.IsChecked = P_0.WatchReels;
		ViewOtherProfilesCheckBox.IsChecked = P_0.ViewOtherProfiles;
		ViewOtherProfilesChanceTextBox.Text = P_0.ViewOtherProfilesChancePercent.ToString();
		ViewCommentsCheckBox.IsChecked = P_0.ViewComments;
		ViewCommentsChanceTextBox.Text = P_0.ViewCommentsChancePercent.ToString();
		AutoAddFriendCheckBox.IsChecked = P_0.AutoAddFriend;
		AddFriendChanceTextBox.Text = P_0.AddFriendChancePercent.ToString();
		FriendOptions.Load(P_0.FriendRequest);
		m_349();
	}

	private void m_346(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_347(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void m_348(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void D(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void d(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void E(object P_0, RoutedEventArgs P_1)
	{
		m_349();
	}

	private void e(object P_0, RoutedEventArgs P_1)
	{
		PostCreationSettings postCreationSettings = PostCreationSettingsWindow.Show(this, m_342);
		if (postCreationSettings != null)
		{
			m_342 = postCreationSettings;
		}
	}

	private void F(object P_0, RoutedEventArgs P_1)
	{
		MessagingSettings messagingSettings = MessagingSettingsWindow.Show(this, m_343);
		if (messagingSettings != null)
		{
			m_343 = messagingSettings;
		}
	}

	private void f(object P_0, RoutedEventArgs P_1)
	{
		PageCreationSettings pageCreationSettings = PageCreationSettingsWindow.Show(this, m_344);
		if (pageCreationSettings != null)
		{
			m_344 = pageCreationSettings;
		}
	}

	private void G(object P_0, RoutedEventArgs P_1)
	{
		PageFarmingSettings pageFarmingSettings = PageFarmingSettingsWindow.Show(this, m_345);
		if (pageFarmingSettings != null)
		{
			m_345 = pageFarmingSettings;
		}
	}

	private void m_349()
	{
		if (LikeChancePanel != null)
		{
			LikeChancePanel.Visibility = ((AutoLikeCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			CommentOptionsPanel.Visibility = ((AutoCommentCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			ViewOtherProfilesChancePanel.Visibility = ((ViewOtherProfilesCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			ViewCommentsChancePanel.Visibility = ((ViewCommentsCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			AddFriendPanel.Visibility = ((AutoAddFriendCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			FriendOptionsHost.Visibility = ((AutoAddFriendCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			PostOptionsPanel.Visibility = ((AutoPostCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			MessageOptionsPanel.Visibility = ((AutoMessageCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			CreatePageOptionsPanel.Visibility = ((AutoCreatePageCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			FarmPageOptionsPanel.Visibility = ((AutoFarmPageCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void g(object P_0, RoutedEventArgs P_1)
	{
		if (!m_350(out FeedBrowsingSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void H(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_350(out FeedBrowsingSettings P_0, out string P_1)
	{
		P_0 = new FeedBrowsingSettings();
		P_1 = "";
		if (!int.TryParse(MinMinutesTextBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "\"Từ\" (phút) phải là 1 số nguyên dương.";
			return false;
		}
		if (!int.TryParse(MaxMinutesTextBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "\"Đến\" (phút) phải là 1 số nguyên >= \"Từ\".";
			return false;
		}
		bool valueOrDefault = AutoLikeCheckBox.IsChecked == true;
		if (valueOrDefault && (!int.TryParse(LikeChanceTextBox.Text.Trim(), out var result3) || result3 < 0 || result3 > 100))
		{
			P_1 = "Tỉ lệ Like phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault2 = AutoCommentCheckBox.IsChecked == true;
		if (valueOrDefault2 && (!int.TryParse(CommentChanceTextBox.Text.Trim(), out var result4) || result4 < 0 || result4 > 100))
		{
			P_1 = "Tỉ lệ bình luận phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault3 = ViewOtherProfilesCheckBox.IsChecked == true;
		if (valueOrDefault3 && (!int.TryParse(ViewOtherProfilesChanceTextBox.Text.Trim(), out var result5) || result5 < 0 || result5 > 100))
		{
			P_1 = "Tỉ lệ ghé xem trang cá nhân phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault4 = ViewCommentsCheckBox.IsChecked == true;
		if (valueOrDefault4 && (!int.TryParse(ViewCommentsChanceTextBox.Text.Trim(), out var result6) || result6 < 0 || result6 > 100))
		{
			P_1 = "Tỉ lệ xem bình luận phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault5 = AutoAddFriendCheckBox.IsChecked == true;
		if (valueOrDefault5 && (!int.TryParse(AddFriendChanceTextBox.Text.Trim(), out var result7) || result7 < 0 || result7 > 100))
		{
			P_1 = "Tỉ lệ kết bạn phải là 1 số từ 0 đến 100.";
			return false;
		}
		FriendRequestSettings settings = new FriendRequestSettings();
		if (valueOrDefault5 && !FriendOptions.TryRead(out settings, out string error))
		{
			P_1 = error;
			return false;
		}
		P_0.MinMinutes = result;
		P_0.MaxMinutes = result2;
		P_0.AutoLike = valueOrDefault;
		P_0.LikeChancePercent = (valueOrDefault ? int.Parse(LikeChanceTextBox.Text.Trim()) : P_0.LikeChancePercent);
		P_0.AutoComment = valueOrDefault2;
		P_0.CommentChancePercent = (valueOrDefault2 ? int.Parse(CommentChanceTextBox.Text.Trim()) : P_0.CommentChancePercent);
		P_0.CommentTexts = CommentTextsTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		P_0.WatchReels = WatchReelsCheckBox.IsChecked == true;
		P_0.ViewOtherProfiles = valueOrDefault3;
		P_0.ViewOtherProfilesChancePercent = (valueOrDefault3 ? int.Parse(ViewOtherProfilesChanceTextBox.Text.Trim()) : P_0.ViewOtherProfilesChancePercent);
		P_0.ViewComments = valueOrDefault4;
		P_0.ViewCommentsChancePercent = (valueOrDefault4 ? int.Parse(ViewCommentsChanceTextBox.Text.Trim()) : P_0.ViewCommentsChancePercent);
		P_0.AutoAddFriend = valueOrDefault5;
		P_0.AddFriendChancePercent = (valueOrDefault5 ? int.Parse(AddFriendChanceTextBox.Text.Trim()) : P_0.AddFriendChancePercent);
		P_0.FriendRequest = (valueOrDefault5 ? settings : P_0.FriendRequest);
		bool valueOrDefault6 = AutoPostCheckBox.IsChecked == true;
		if (valueOrDefault6 && (!int.TryParse(PostChanceTextBox.Text.Trim(), out var result8) || result8 < 0 || result8 > 100))
		{
			P_1 = "Tỉ lệ đăng bài phải là 1 số từ 0 đến 100.";
			return false;
		}
		P_0.AutoPost = valueOrDefault6;
		P_0.PostChancePercent = (valueOrDefault6 ? int.Parse(PostChanceTextBox.Text.Trim()) : P_0.PostChancePercent);
		P_0.Post = m_342;
		bool valueOrDefault7 = AutoMessageCheckBox.IsChecked == true;
		if (valueOrDefault7 && (!int.TryParse(MessageChanceTextBox.Text.Trim(), out var result9) || result9 < 0 || result9 > 100))
		{
			P_1 = "Tỉ lệ nhắn tin phải là 1 số từ 0 đến 100.";
			return false;
		}
		P_0.AutoMessage = valueOrDefault7;
		P_0.MessageChancePercent = (valueOrDefault7 ? int.Parse(MessageChanceTextBox.Text.Trim()) : P_0.MessageChancePercent);
		P_0.Messaging = m_343;
		bool valueOrDefault8 = AutoCreatePageCheckBox.IsChecked == true;
		if (valueOrDefault8 && (!int.TryParse(CreatePageChanceTextBox.Text.Trim(), out var result10) || result10 < 0 || result10 > 100))
		{
			P_1 = "Tỉ lệ tạo Page phải là 1 số từ 0 đến 100.";
			return false;
		}
		P_0.AutoCreatePage = valueOrDefault8;
		P_0.CreatePageChancePercent = (valueOrDefault8 ? int.Parse(CreatePageChanceTextBox.Text.Trim()) : P_0.CreatePageChancePercent);
		P_0.PageCreation = m_344;
		P_0.AutoFarmPage = AutoFarmPageCheckBox.IsChecked == true;
		P_0.PageFarming = m_345;
		return true;
	}

	public static FeedBrowsingSettings? Show(Window? owner, FeedBrowsingSettings initial)
	{
		FeedBrowsingSettingsWindow feedBrowsingSettingsWindow = new FeedBrowsingSettingsWindow(initial);
		if (owner != null)
		{
			feedBrowsingSettingsWindow.Owner = owner;
		}
		feedBrowsingSettingsWindow.ShowDialog();
		if (!feedBrowsingSettingsWindow.A)
		{
			return null;
		}
		feedBrowsingSettingsWindow.m_350(out FeedBrowsingSettings result, out string _);
		return result;
	}
}
