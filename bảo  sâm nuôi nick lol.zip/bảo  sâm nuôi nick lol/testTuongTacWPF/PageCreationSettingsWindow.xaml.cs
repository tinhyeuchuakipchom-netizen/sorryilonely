using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class PageCreationSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private PageCreationSettingsWindow(PageCreationSettings P_0)
	{
		InitializeComponent();
		IncludeMiddleNameCheckBox.IsChecked = P_0.IncludeMiddleName;
		CustomNamesTextBox.Text = string.Join("\n", P_0.CustomNames);
		PickRandomlyCheckBox.IsChecked = P_0.PickCustomNameRandomly;
		PageCountTextBox.Text = ((P_0.PageCount > 0) ? P_0.PageCount.ToString() : "1");
		MinDelaySecondsTextBox.Text = ((P_0.MinDelaySeconds >= 0) ? P_0.MinDelaySeconds.ToString() : "10");
		MaxDelaySecondsTextBox.Text = ((P_0.MaxDelaySeconds >= 0) ? P_0.MaxDelaySeconds.ToString() : "30");
		ModeVietnameseRadio.IsChecked = P_0.NameMode == PageNameMode.RandomVietnamese;
		ModeEnglishRadio.IsChecked = P_0.NameMode == PageNameMode.RandomEnglish;
		ModeCustomRadio.IsChecked = P_0.NameMode == PageNameMode.CustomList;
		m_1672();
	}

	private void m_1670(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_1671(object P_0, RoutedEventArgs P_1)
	{
		m_1672();
	}

	private void m_1672()
	{
		if (VietnamesePanel != null)
		{
			VietnamesePanel.Visibility = ((ModeVietnameseRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			EnglishPanel.Visibility = ((ModeEnglishRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			CustomPanel.Visibility = ((ModeCustomRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void m_1673(object P_0, RoutedEventArgs P_1)
	{
		if (!m_1674(out PageCreationSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_1674(out PageCreationSettings P_0, out string P_1)
	{
		P_0 = new PageCreationSettings();
		P_1 = "";
		if (!int.TryParse(PageCountTextBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "Số lượng Page mỗi nick phải là số nguyên lớn hơn hoặc bằng 1.";
			return false;
		}
		if (!int.TryParse(MinDelaySecondsTextBox.Text.Trim(), out var result2) || result2 < 0)
		{
			P_1 = "Thời gian chờ tối thiểu (giây) không hợp lệ.";
			return false;
		}
		if (!int.TryParse(MaxDelaySecondsTextBox.Text.Trim(), out var result3) || result3 < result2)
		{
			P_1 = "Thời gian chờ tối đa phải lớn hơn hoặc bằng thời gian chờ tối thiểu.";
			return false;
		}
		PageNameMode pageNameMode = ((ModeEnglishRadio.IsChecked == true) ? PageNameMode.RandomEnglish : ((ModeCustomRadio.IsChecked == true) ? PageNameMode.CustomList : PageNameMode.RandomVietnamese));
		List<string> list = CustomNamesTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (pageNameMode == PageNameMode.CustomList && list.Count == 0)
		{
			P_1 = "Chưa nhập tên nào cho danh sách tự nạp.";
			return false;
		}
		P_0.PageCount = result;
		P_0.MinDelaySeconds = result2;
		P_0.MaxDelaySeconds = result3;
		P_0.NameMode = pageNameMode;
		P_0.IncludeMiddleName = IncludeMiddleNameCheckBox.IsChecked == true;
		P_0.CustomNames = list;
		P_0.PickCustomNameRandomly = PickRandomlyCheckBox.IsChecked == true;
		return true;
	}

	public static PageCreationSettings? Show(Window? owner, PageCreationSettings initial)
	{
		PageCreationSettingsWindow pageCreationSettingsWindow = new PageCreationSettingsWindow(initial);
		if (owner != null)
		{
			pageCreationSettingsWindow.Owner = owner;
		}
		pageCreationSettingsWindow.ShowDialog();
		if (!pageCreationSettingsWindow.A)
		{
			return null;
		}
		pageCreationSettingsWindow.m_1674(out PageCreationSettings result, out string _);
		return result;
	}
}
