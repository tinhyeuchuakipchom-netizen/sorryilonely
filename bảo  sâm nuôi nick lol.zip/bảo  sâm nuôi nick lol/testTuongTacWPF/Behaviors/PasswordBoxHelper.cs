using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace testTuongTacWPF.Behaviors;

public static class PasswordBoxHelper
{
	[CompilerGenerated]
	private static class m_2677
	{
		public static RoutedEventHandler A;
	}

	public static readonly DependencyProperty BoundPassword = DependencyProperty.RegisterAttached("BoundPassword", typeof(string), typeof(PasswordBoxHelper), new PropertyMetadata((object)"", (PropertyChangedCallback)m_2675));

	public static readonly DependencyProperty Attach = DependencyProperty.RegisterAttached("Attach", typeof(bool), typeof(PasswordBoxHelper), new PropertyMetadata((object)false, (PropertyChangedCallback)a));

	private static readonly DependencyProperty A = DependencyProperty.RegisterAttached("IsUpdating", typeof(bool), typeof(PasswordBoxHelper), new PropertyMetadata((object)false));

	public static void SetBoundPassword(DependencyObject dp, string P_2673)
	{
		dp.SetValue(BoundPassword, (object)P_2673);
	}

	public static string GetBoundPassword(DependencyObject dp)
	{
		return (string)dp.GetValue(BoundPassword);
	}

	public static void SetAttach(DependencyObject dp, bool P_2674)
	{
		dp.SetValue(Attach, (object)P_2674);
	}

	public static bool GetAttach(DependencyObject dp)
	{
		return (bool)dp.GetValue(Attach);
	}

	private static void m_2675(DependencyObject P_0, DependencyPropertyChangedEventArgs P_1)
	{
		if (P_0 is PasswordBox passwordBox)
		{
			passwordBox.PasswordChanged -= m_2676;
			if (!(bool)((DependencyObject)passwordBox).GetValue(A))
			{
				passwordBox.Password = (P_1.NewValue as string) ?? "";
			}
			passwordBox.PasswordChanged += m_2676;
		}
	}

	private static void a(DependencyObject P_0, DependencyPropertyChangedEventArgs P_1)
	{
		if (P_0 is PasswordBox passwordBox)
		{
			if ((bool)P_1.OldValue)
			{
				passwordBox.PasswordChanged -= m_2676;
			}
			if ((bool)P_1.NewValue)
			{
				passwordBox.PasswordChanged += m_2676;
			}
		}
	}

	private static void m_2676(object P_0, RoutedEventArgs P_1)
	{
		PasswordBox passwordBox = (PasswordBox)P_0;
		((DependencyObject)passwordBox).SetValue(A, (object)true);
		SetBoundPassword((DependencyObject)(object)passwordBox, passwordBox.Password);
		((DependencyObject)passwordBox).SetValue(A, (object)false);
	}

	static PasswordBoxHelper()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Expected Obj, but got Unknown
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Expected Obj, but got Unknown
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Expected Obj, but got Unknown
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Expected Obj, but got Unknown
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Expected Obj, but got Unknown
	}
}
