using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace testTuongTacWPF;

public partial class BulkUpdateWindow : Window, IComponentConnector
{
	private readonly HashSet<string> A;

	private readonly List<ComboBox> m_313 = new List<ComboBox>();

	private static readonly string[] m_314 = new string[17]
	{
		"Bỏ qua", "PASS", "2FA", "TOKEN", "COOKIE", "MAIL", "PASS MAIL", "MAIL KHÔI PHỤC", "PASS MAIL KHÔI PHỤC", "BẠN BÈ",
		"NHÓM", "GIỚI TÍNH", "PROXY", "GHI CHÚ", "TƯƠNG TÁC CUỐI", "TRẠNG THÁI", "PHONE"
	};

	private static readonly string[] a = new string[8] { "PASS", "TOKEN", "2FA", "Bỏ qua", "Bỏ qua", "Bỏ qua", "Bỏ qua", "Bỏ qua" };

	[CompilerGenerated]
	private readonly List<(string Uid, Dictionary<string, string> Fields)> m_315 = new List<(string, Dictionary<string, string>)>();

	private bool m_316;

	public List<(string Uid, Dictionary<string, string> Fields)> Entries
	{
		[CompilerGenerated]
		get
		{
			return m_315;
		}
	}

	public BulkUpdateWindow(IEnumerable<string> existingUids)
	{
		InitializeComponent();
		A = new HashSet<string>(existingUids);
		m_317();
	}

	private void m_317()
	{
		for (int i = 0; i < a.Length; i++)
		{
			StackPanel stackPanel = new StackPanel
			{
				Orientation = Orientation.Vertical,
				Margin = new Thickness(0.0, 0.0, 10.0, 8.0)
			};
			stackPanel.Children.Add(new TextBlock
			{
				Text = $"Vị trí {i + 2}",
				FontSize = 11.0,
				Foreground = (Brush)FindResource("BrushTextSecondary"),
				Margin = new Thickness(2.0, 0.0, 0.0, 2.0)
			});
			ComboBox comboBox = new ComboBox
			{
				Width = 130.0,
				ItemsSource = m_314,
				SelectedItem = a[i]
			};
			stackPanel.Children.Add(comboBox);
			m_313.Add(comboBox);
			FieldSlotsPanel.Children.Add(stackPanel);
		}
	}

	private void m_318(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_319(object P_0, RoutedEventArgs P_1)
	{
		WindowState = WindowState.Minimized;
	}

	private List<(string Uid, Dictionary<string, string> Fields)> m_320()
	{
		List<(string, Dictionary<string, string>)> list = new List<(string, Dictionary<string, string>)>();
		string[] array = EntriesTextBox.Text.Split('\n');
		for (int i = 0; i < array.Length; i++)
		{
			string text = array[i].Trim(new char[2] { '\r', ' ' });
			if (text.Length == 0)
			{
				continue;
			}
			string[] array2 = text.Split('|');
			string text2 = array2[0].Trim();
			if (text2.Length == 0)
			{
				continue;
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			for (int j = 1; j < array2.Length && j - 1 < m_313.Count; j++)
			{
				string text3 = (m_313[j - 1].SelectedItem as string) ?? "Bỏ qua";
				if (!(text3 == "Bỏ qua"))
				{
					dictionary[text3] = array2[j].Trim();
				}
			}
			if (dictionary.Count > 0)
			{
				list.Add((text2, dictionary));
			}
		}
		return list;
	}

	private void m_321(object P_0, TextChangedEventArgs P_1)
	{
		List<(string, Dictionary<string, string>)> list = m_320();
		int num = list.Count(((string Uid, Dictionary<string, string> Fields) entry) => A.Contains(entry.Uid));
		TotalCountText.Text = list.Count.ToString();
		MatchedCountText.Text = num.ToString();
		NotFoundCountText.Text = (list.Count - num).ToString();
	}

	private void m_322(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		List<(string, Dictionary<string, string>)> list = m_320();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa nhập dòng nào hợp lệ, hoặc chưa chọn trường nào cho các vị trí.", "Cập nhật hàng loạt", NotifyType.Warning);
			return;
		}
		Entries.Clear();
		Entries.AddRange(list);
		DialogResult = true;
		Close();
	}

	[CompilerGenerated]
	private bool m_324((string Uid, Dictionary<string, string> Fields) entry)
	{
		return A.Contains(entry.Uid);
	}
}
