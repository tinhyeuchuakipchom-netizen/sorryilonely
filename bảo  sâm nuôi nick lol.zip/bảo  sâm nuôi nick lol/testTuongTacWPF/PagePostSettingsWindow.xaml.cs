using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class PagePostSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private PostCreationSettings m_1686 = new PostCreationSettings();

	private bool a;

	private PagePostSettingsWindow(PagePostSettings P_0)
	{
		InitializeComponent();
		m_1686 = P_0.Post ?? new PostCreationSettings();
		PostsPerPageTextBox.Text = P_0.PostsPerPage.ToString();
		MaxPagesTextBox.Text = P_0.MaxPages.ToString();
		PageSwitchDelayTextBox.Text = P_0.PageSwitchDelaySeconds.ToString();
		TargetPageNamesTextBox.Text = string.Join("\n", P_0.TargetPageNames ?? new List<string>());
	}

	private void m_1687(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_1688(object P_0, RoutedEventArgs P_1)
	{
		PostCreationSettings postCreationSettings = PostCreationSettingsWindow.Show(this, m_1686);
		if (postCreationSettings != null)
		{
			m_1686 = postCreationSettings;
		}
	}

	private void m_1689(object P_0, RoutedEventArgs P_1)
	{
		if (!m_1690(out PagePostSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_1690(out PagePostSettings P_0, out string P_1)
	{
		P_0 = new PagePostSettings();
		P_1 = "";
		if (!int.TryParse(PostsPerPageTextBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "\"Số bài đăng / mỗi Page\" phải là số nguyên >= 1.";
			return false;
		}
		if (!int.TryParse(MaxPagesTextBox.Text.Trim(), out var result2) || result2 < 0)
		{
			P_1 = "\"Số Page tối đa\" phải là số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(PageSwitchDelayTextBox.Text.Trim(), out var result3) || result3 < 0)
		{
			P_1 = "\"Chờ chuyển Page\" phải là số nguyên >= 0.";
			return false;
		}
		P_0.PostsPerPage = result;
		P_0.MaxPages = result2;
		P_0.PageSwitchDelaySeconds = result3;
		P_0.TargetPageNames = TargetPageNamesTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		P_0.Post = m_1686;
		return true;
	}

	public static PagePostSettings? Show(Window? owner, PagePostSettings initial)
	{
		PagePostSettingsWindow pagePostSettingsWindow = new PagePostSettingsWindow(initial);
		if (owner != null)
		{
			pagePostSettingsWindow.Owner = owner;
		}
		pagePostSettingsWindow.ShowDialog();
		if (!pagePostSettingsWindow.A)
		{
			return null;
		}
		pagePostSettingsWindow.m_1690(out PagePostSettings result, out string _);
		return result;
	}
}
