using System.Windows;
using System.Windows.Media;

namespace testTuongTacWPF;

public static class NavIcon
{
	public static readonly DependencyProperty GlyphProperty = DependencyProperty.RegisterAttached("Glyph", typeof(string), typeof(NavIcon), new PropertyMetadata((object)""));

	public static readonly DependencyProperty AccentColorProperty = DependencyProperty.RegisterAttached("AccentColor", typeof(Brush), typeof(NavIcon), new PropertyMetadata((object)Brushes.Gray));

	public static readonly DependencyProperty LogoKeyProperty = DependencyProperty.RegisterAttached("LogoKey", typeof(string), typeof(NavIcon), new PropertyMetadata((object)""));

	public static void SetGlyph(DependencyObject element, string P_1667)
	{
		element.SetValue(GlyphProperty, (object)P_1667);
	}

	public static string GetGlyph(DependencyObject element)
	{
		return (string)element.GetValue(GlyphProperty);
	}

	public static void SetAccentColor(DependencyObject element, Brush P_1668)
	{
		element.SetValue(AccentColorProperty, (object)P_1668);
	}

	public static Brush GetAccentColor(DependencyObject element)
	{
		return (Brush)element.GetValue(AccentColorProperty);
	}

	public static void SetLogoKey(DependencyObject element, string P_1669)
	{
		element.SetValue(LogoKeyProperty, (object)P_1669);
	}

	public static string GetLogoKey(DependencyObject element)
	{
		return (string)element.GetValue(LogoKeyProperty);
	}

	static NavIcon()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected Obj, but got Unknown
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Expected Obj, but got Unknown
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Expected Obj, but got Unknown
	}
}
