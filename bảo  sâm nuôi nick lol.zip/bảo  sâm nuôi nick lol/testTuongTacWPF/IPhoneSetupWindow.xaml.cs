using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class IPhoneSetupWindow : Window, IComponentConnector
{
	private static readonly Brush A = new SolidColorBrush(Color.FromRgb(107, 114, 128));

	private static readonly Brush a = new SolidColorBrush(Color.FromRgb(74, 222, 128));

	private static readonly Brush B = new SolidColorBrush(Color.FromRgb(248, 113, 113));

	private static readonly Brush b = new SolidColorBrush(Color.FromRgb(251, 191, 36));

	private (int Width, int Height)? m_416;

	private bool m_417;

	public IPhoneSetupWindow()
	{
		InitializeComponent();
		Loaded += async delegate
		{
			await m_425();
		};
	}

	private void m_418(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.ChangedButton == MouseButton.Left)
		{
			DragMove();
		}
	}

	private void m_419(object P_0, RoutedEventArgs P_1)
	{
		Close();
	}

	private void m_420(string P_0)
	{
		LogText.Text = P_0;
	}

	private void m_421(object P_0, RoutedEventArgs P_1)
	{
		if (string.IsNullOrWhiteSpace(LogText.Text))
		{
			return;
		}
		try
		{
			Clipboard.SetText(LogText.Text);
		}
		catch
		{
		}
	}

	private async void m_422(object P_0, RoutedEventArgs P_1)
	{
		await m_425();
	}

	private void m_423(object P_0, RoutedEventArgs P_1)
	{
		KillIosButton.IsEnabled = false;
		try
		{
			var (num, num2) = IPhoneController.KillAllIosProcesses();
			if (num == 0 && num2 == 0)
			{
				m_420("Không có tiến trình ios.exe nào đang chạy - đang sạch, cứ bấm \"Khởi động WebDriverAgent\".");
				return;
			}
			string text = ((num2 > 0) ? ($"Đã diệt {num} tiến trình, còn {num2} tiến trình KHÔNG diệt được (Windows từ chối). " + "Nguyên nhân thường gặp: tiến trình đó do lần mở tool bằng \"Run as administrator\" tạo ra, phải mở lại tool bằng quyền admin mới dọn được (hoặc khởi động lại máy).") : $"Đã diệt {num} tiến trình ios.exe. Giờ bấm \"Khởi động WebDriverAgent\" để dựng lại kênh từ đầu.");
			m_420(text);
		}
		finally
		{
			KillIosButton.IsEnabled = true;
		}
	}

	private string? m_424()
	{
		return DeviceCombo.SelectedItem as string;
	}

	private async Task m_425()
	{
		CheckButton.IsEnabled = false;
		m_420("Đang kiểm tra...");
		try
		{
			if (IPhoneController.IsToolAvailable)
			{
				ToolDot.Fill = a;
				ToolStatusText.Text = "Công cụ ios.exe: đã sẵn sàng";
				List<string> list = await IPhoneController.ListDevicesAsync();
				string text = m_424();
				DeviceCombo.Items.Clear();
				foreach (string item in list)
				{
					DeviceCombo.Items.Add(item);
				}
				if (list.Count > 0)
				{
					if (text != null && list.Contains(text))
					{
						DeviceCombo.SelectedItem = text;
					}
					else
					{
						DeviceCombo.SelectedIndex = 0;
					}
				}
				if (list.Count > 0)
				{
					DeviceDot.Fill = a;
					DeviceStatusText.Text = $"Thiết bị: đã nhận {list.Count} máy ({string.Join(", ", list)})";
				}
				else
				{
					DeviceDot.Fill = B;
					DeviceStatusText.Text = "Thiết bị: chưa nhận iPhone nào - xem bước 1 và 4";
				}
				if (await IPhoneController.IsWdaReadyAsync())
				{
					WdaDot.Fill = a;
					WdaStatusText.Text = "WebDriverAgent: đang chạy tại " + IPhoneController.WdaBaseUrl;
					m_420("Sẵn sàng điều khiển iPhone.");
				}
				else if (list.Count > 0)
				{
					if (await IPhoneController.FindWdaBundleIdAsync(m_424()) != null)
					{
						WdaDot.Fill = b;
						WdaStatusText.Text = "WebDriverAgent: đã cài nhưng chưa chạy - bấm \"Khởi động WebDriverAgent\"";
						m_420("Nhớ mở khoá màn hình iPhone trước khi khởi động.");
					}
					else
					{
						WdaDot.Fill = B;
						WdaStatusText.Text = "WebDriverAgent: chưa cài trên máy này - xem bước 6";
						m_420("Làm theo PHẦN C để ký và cài WebDriverAgent.");
					}
				}
				else
				{
					WdaDot.Fill = A;
					WdaStatusText.Text = "WebDriverAgent: chưa kiểm tra được (chưa nhận thiết bị)";
					m_420("Cắm cáp và tin cậy máy tính trước đã.");
				}
			}
			else
			{
				ToolDot.Fill = B;
				ToolStatusText.Text = "Thiếu file " + IPhoneController.IosExePath + " - tải lại tool";
				m_420("Không tìm thấy ios.exe, các bước sau không chạy được.");
			}
		}
		catch (Exception ex)
		{
			m_420("Lỗi khi kiểm tra: " + ex.Message);
		}
		finally
		{
			CheckButton.IsEnabled = true;
		}
	}

	private async void C(object P_0, RoutedEventArgs P_1)
	{
		StartWdaButton.IsEnabled = false;
		CheckButton.IsEnabled = false;
		string text = null;
		string udid = m_424();
		try
		{
			_ = 2;
			try
			{
				m_420("Đang mở kênh liên lạc với iPhone (tunnel)...");
				IPhoneController.StartTunnel(udid);
				m_420("Đang đợi tunnel kết nối tới iPhone...");
				var (flag, text2) = await IPhoneController.WaitForTunnelAsync(15000, udid);
				if (!flag)
				{
					text = "Tunnel không kết nối được: " + (text2 ?? "(không rõ)") + "\nKiểm tra: cáp USB phải cắm, iPhone phải tin cậy máy tính, và iPhone phải chạy iOS 17+.";
					return;
				}
				if (IPhoneController.TunnelUsingUserspace)
				{
					m_420("Đã kết nối tunnel (chế độ userspace - ổn định hơn nếu có wintun.dll).");
				}
				m_420("Đang gắn Developer Disk Image (lần đầu cần mạng, có thể mất 1-2 phút)...");
				var (num, text3) = await IPhoneController.MountDeveloperImageAsync(udid);
				if (num != 0 && !text3.Contains("success mounting", StringComparison.OrdinalIgnoreCase) && !text3.Contains("already mounted", StringComparison.OrdinalIgnoreCase))
				{
					string text4 = (text3.Contains("unknown authority", StringComparison.OrdinalIgnoreCase) ? " → Nguyên nhân: chưa cài chứng chỉ Apple ở BƯỚC 2." : "");
					text = "Không gắn được Developer Disk Image." + text4 + " Log thật: " + text3.Trim();
					return;
				}
				m_420("Đang khởi động WebDriverAgent trên iPhone...");
				string item = (await IPhoneController.StartWdaAsync(udid)).Item2;
				text = item;
			}
			catch (Exception ex)
			{
				text = "Lỗi: " + ex.Message;
			}
		}
		finally
		{
			StartWdaButton.IsEnabled = true;
			CheckButton.IsEnabled = true;
			await m_425();
			if (text != null)
			{
				if (text.StartsWith("WebDriverAgent đã sẵn sàng", StringComparison.OrdinalIgnoreCase))
				{
					m_420(text);
				}
				else
				{
					try
					{
						Clipboard.SetText(text);
						m_420(text + "\n(Đã tự sao chép toàn bộ nội dung trên vào clipboard - dán thẳng được luôn.)");
					}
					catch
					{
						m_420(text);
					}
				}
			}
		}
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			string directoryName = Path.GetDirectoryName(IPhoneController.IosExePath);
			Process.Start(new ProcessStartInfo
			{
				FileName = directoryName,
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			m_420("Không mở được thư mục: " + ex.Message);
		}
	}

	private async void D(object P_0, RoutedEventArgs P_1)
	{
		ScreenshotTestButton.IsEnabled = false;
		TestResultText.Text = "Đang chụp màn hình...";
		try
		{
			byte[] array = await IPhoneController.ScreenshotAsync();
			if (array == null)
			{
				TestResultText.Text = "Không chụp được - kiểm tra WebDriverAgent đã chạy chưa (đèn phải xanh).";
				return;
			}
			using MemoryStream streamSource = new MemoryStream(array);
			BitmapImage bitmapImage = new BitmapImage();
			bitmapImage.BeginInit();
			bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
			bitmapImage.StreamSource = streamSource;
			bitmapImage.EndInit();
			((Freezable)bitmapImage).Freeze();
			PreviewImage.Source = bitmapImage;
			PreviewPlaceholderText.Visibility = Visibility.Collapsed;
			m_416 = await IPhoneController.GetScreenSizeAsync();
			TestResultText.Text = "Đã chụp xong - bấm thẳng vào ảnh để gửi 1 cú chạm thật tới đúng chỗ đó.";
		}
		catch (Exception ex)
		{
			TestResultText.Text = "Lỗi chụp màn hình: " + ex.Message;
		}
		finally
		{
			ScreenshotTestButton.IsEnabled = true;
		}
	}

	private async void m_426(object P_0, MouseButtonEventArgs P_1)
	{
		if (!(PreviewImage.Source is BitmapImage bitmapImage) || !m_416.HasValue)
		{
			TestResultText.Text = "Chưa có ảnh để bấm thử - chụp màn hình trước đã.";
			return;
		}
		Point position = P_1.GetPosition(PreviewImage);
		double actualWidth = PreviewImage.ActualWidth;
		double actualHeight = PreviewImage.ActualHeight;
		double num = (double)bitmapImage.PixelWidth / (double)bitmapImage.PixelHeight;
		double num2 = actualWidth / actualHeight;
		double num3;
		double num4;
		double num5;
		double num6;
		if (num > num2)
		{
			num3 = actualWidth;
			num4 = actualWidth / num;
			num5 = 0.0;
			num6 = (actualHeight - num4) / 2.0;
		}
		else
		{
			num4 = actualHeight;
			num3 = actualHeight * num;
			num5 = (actualWidth - num3) / 2.0;
			num6 = 0.0;
		}
		double num7 = (position.X - num5) / num3;
		double num8 = (position.Y - num6) / num4;
		bool flag = ((num7 < 0.0 || num7 > 1.0) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			bool flag3 = ((num8 < 0.0 || num8 > 1.0) ? true : false);
			flag2 = flag3;
		}
		if (flag2)
		{
			TestResultText.Text = "Bấm ngoài vùng ảnh, không tính.";
			return;
		}
		double num9 = num7 * (double)m_416.Value.Width;
		double num10 = num8 * (double)m_416.Value.Height;
		TestResultText.Text = $"Đang bấm tại ({num9:F0}, {num10:F0})...";
		bool flag4 = await IPhoneController.TapAsync(num9, num10);
		TestResultText.Text = (flag4 ? $"Đã gửi chạm tới ({num9:F0}, {num10:F0}) - xem trực tiếp trên màn hình iPhone, chụp lại để thấy kết quả." : "Gửi chạm thất bại - kiểm tra WebDriverAgent còn sống không.");
	}

	private async void d(object P_0, RoutedEventArgs P_1)
	{
		SwipeTestButton.IsEnabled = false;
		TestResultText.Text = "Đang vuốt thử...";
		try
		{
			(int, int) tuple = m_416 ?? (await IPhoneController.GetScreenSizeAsync()) ?? (375, 812);
			(int, int) tuple2 = tuple;
			int item = tuple2.Item1;
			int item2 = tuple2.Item2;
			double num = (double)item / 2.0;
			bool flag = await IPhoneController.SwipeAsync(num, (double)item2 * 0.75, num, (double)item2 * 0.25);
			TestResultText.Text = (flag ? "Đã gửi lệnh vuốt lên - nhìn màn hình iPhone để xác nhận." : "Gửi lệnh vuốt thất bại - kiểm tra WebDriverAgent còn sống không.");
		}
		finally
		{
			SwipeTestButton.IsEnabled = true;
		}
	}

	private void E(object P_0, RoutedEventArgs P_1)
	{
		m_427("https://sideloadly.io");
	}

	private void m_427(string P_0)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = P_0,
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			m_420("Không mở được liên kết: " + ex.Message);
		}
	}

	[CompilerGenerated]
	private async void e(object P_0, RoutedEventArgs P_1)
	{
		await m_425();
	}
}
