using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class LicenseHardwareCheckResult
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private bool a;

	[CompilerGenerated]
	private string m_2476 = "";

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool AccountBoundToOtherDevice
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return m_2476;
		}
		[CompilerGenerated]
		set
		{
			m_2476 = value;
		}
	}
}
