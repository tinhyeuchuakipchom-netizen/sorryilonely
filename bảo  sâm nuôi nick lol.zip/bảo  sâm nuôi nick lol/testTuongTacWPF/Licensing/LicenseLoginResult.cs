using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class LicenseLoginResult
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private bool a;

	[CompilerGenerated]
	private string m_2472 = "";

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool NeedsActivation
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return m_2472;
		}
		[CompilerGenerated]
		set
		{
			m_2472 = value;
		}
	}
}
