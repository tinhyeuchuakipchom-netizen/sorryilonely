using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class DesktopLicenseGuardResult
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private bool a;

	[CompilerGenerated]
	private string m_2443 = "";

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool Rejected
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return m_2443;
		}
		[CompilerGenerated]
		set
		{
			m_2443 = value;
		}
	}
}
