using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class JwksResponse
{
	[CompilerGenerated]
	private List<Jwk> A = new List<Jwk>();

	public List<Jwk> Keys
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
