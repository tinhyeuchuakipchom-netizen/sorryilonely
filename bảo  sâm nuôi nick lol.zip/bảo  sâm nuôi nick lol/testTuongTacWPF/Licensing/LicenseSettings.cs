using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Licensing;

public class LicenseSettings
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private bool m_2557;

	private static readonly string B = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "license_tuong_tac.json");

	public string Username
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Password
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool LoggedInBefore
	{
		[CompilerGenerated]
		get
		{
			return m_2557;
		}
		[CompilerGenerated]
		set
		{
			m_2557 = value;
		}
	}

	public static LicenseSettings Load()
	{
		try
		{
			if (!File.Exists(B))
			{
				return new LicenseSettings();
			}
			return JsonSerializer.Deserialize<LicenseSettings>(File.ReadAllText(B)) ?? new LicenseSettings();
		}
		catch
		{
			return new LicenseSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(B));
		File.WriteAllText(B, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
