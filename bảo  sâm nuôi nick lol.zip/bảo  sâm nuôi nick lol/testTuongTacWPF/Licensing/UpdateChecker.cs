using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace testTuongTacWPF.Licensing;

public static class UpdateChecker
{
	private const string A = "ver 11.10.49";

	private const string a = "https://tangbinhluan.com/updates/UPDATE_TOOL/toolfastfacebook/txtupdate.html";

	public static async Task CheckAndUpdateAsync()
	{
		string[] array = await m_2656();
		if (array != null && array.Length >= 2 && !array[0].Contains("ver 11.10.49"))
		{
			m_2657();
		}
	}

	private static async Task<string[]?> m_2656()
	{
		for (int i = 1; i <= 3; i++)
		{
			try
			{
				using HttpClient httpClient = new HttpClient
				{
					Timeout = TimeSpan.FromSeconds(8L)
				};
				httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
				string[] array = (await httpClient.GetStringAsync("https://tangbinhluan.com/updates/UPDATE_TOOL/toolfastfacebook/txtupdate.html")).Split('*')[1].Split('|');
				if (array.Length >= 2)
				{
					return array;
				}
			}
			catch
			{
			}
			if (i < 3)
			{
				await Task.Delay(1000);
			}
		}
		return null;
	}

	private static void m_2657()
	{
		string baseDirectory = AppContext.BaseDirectory;
		string text = Path.Combine(Path.GetTempPath(), $"FastBoxPhone_selfupdate_{Guid.NewGuid():N}");
		try
		{
			Directory.CreateDirectory(text);
			foreach (string item in Directory.EnumerateFiles(baseDirectory, "*", SearchOption.TopDirectoryOnly))
			{
				File.Copy(item, Path.Combine(text, Path.GetFileName(item)), overwrite: true);
			}
			string text2 = Path.Combine(text, "FastBoxPhone.exe");
			if (!File.Exists(text2))
			{
				CustomMessageBox.Show(null, "Có bản cập nhật mới nhưng không chuẩn bị được bản sao để cập nhật. Vui lòng tải lại tool.", "Cập nhật", NotifyType.Warning);
				return;
			}
			Process.Start(new ProcessStartInfo
			{
				FileName = text2,
				ArgumentList = { "--apply-update", baseDirectory },
				WorkingDirectory = text,
				UseShellExecute = false
			});
			Environment.Exit(0);
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(null, "Có bản cập nhật mới nhưng không chuẩn bị được cập nhật: " + ex.Message, "Cập nhật", NotifyType.Warning);
		}
	}
}
