using System;
using System.Collections.Generic;
using System.IO;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;

namespace testTuongTacWPF.Licensing;

public static class LicenseClient
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_2497
	{
		public static readonly m_2497 A = new m_2497();

		public static Func<int, char> m_2503;

		internal char m_2504(int P_0)
		{
			return "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[Random.Shared.Next("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".Length)];
		}
	}

	private const string A = "jwt/Toolregclone/login";

	private const string a = "jwt/Toolregclone/register";

	private const string B = "jwt/Toolregclone/checkocung";

	private const string b = "jwt/api/license/desktop-token";

	private const string C = "jwt/api/license/jwks";

	private const string c = "tangbinhluan.com";

	private const string D = "toolfastfacebook";

	private const string d = "toolfastfacebook";

	private const string E = "Tài khoản đã đăng kí với máy khác";

	private static readonly HttpClient m_2481 = m_2487();

	private static Dictionary<string, RsaSecurityKey> m_2482 = new Dictionary<string, RsaSecurityKey>();

	[CompilerGenerated]
	private static bool m_2483;

	[CompilerGenerated]
	private static bool m_2484;

	[CompilerGenerated]
	private static bool m_2485;

	[CompilerGenerated]
	private static bool m_2486;

	private static readonly string e = Path.Combine(AppContext.BaseDirectory, "dulieukhach", "ocung.txt");

	public static bool IsPhoneAiUnlocked
	{
		[CompilerGenerated]
		get
		{
			return m_2483;
		}
		[CompilerGenerated]
		private set
		{
			m_2483 = value;
		}
	}

	public static bool IsPhoneAiPaid
	{
		[CompilerGenerated]
		get
		{
			return m_2484;
		}
		[CompilerGenerated]
		private set
		{
			m_2484 = value;
		}
	}

	public static bool IsPhoneAiTrialActive
	{
		[CompilerGenerated]
		get
		{
			return m_2485;
		}
		[CompilerGenerated]
		private set
		{
			m_2485 = value;
		}
	}

	public static bool HasVerifiedLicense
	{
		[CompilerGenerated]
		get
		{
			return m_2486;
		}
		[CompilerGenerated]
		private set
		{
			m_2486 = value;
		}
	}

	private static HttpClient m_2487()
	{
		HttpClient httpClient = new HttpClient(new SocketsHttpHandler
		{
			PooledConnectionLifetime = TimeSpan.Zero
		});
		httpClient.BaseAddress = new Uri("https://tangbinhluan.com/");
		httpClient.DefaultRequestHeaders.Accept.Clear();
		httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
		httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
		return httpClient;
	}

	public static async Task<LicenseLoginResult> LoginAsync(string username, string password)
	{
		_ = 1;
		try
		{
			LicenseLoginRequest value = new LicenseLoginRequest
			{
				Username = username,
				Password = password
			};
			using StringContent content = new StringContent(JsonSerializer.Serialize(value), Encoding.UTF8, "application/json");
			using HttpResponseMessage httpResponseMessage = await m_2481.PostAsync("jwt/Toolregclone/login", content);
			LicenseLoginResponse licenseLoginResponse = JsonSerializer.Deserialize<LicenseLoginResponse>(await httpResponseMessage.Content.ReadAsStringAsync(), new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true
			});
			if (licenseLoginResponse == null)
			{
				return new LicenseLoginResult
				{
					Message = "Phản hồi từ máy chủ không hợp lệ."
				};
			}
			if (!httpResponseMessage.IsSuccessStatusCode || licenseLoginResponse.Status != "success")
			{
				return new LicenseLoginResult
				{
					Message = (string.IsNullOrWhiteSpace(licenseLoginResponse.Message) ? "Đăng nhập thất bại." : licenseLoginResponse.Message)
				};
			}
			if (licenseLoginResponse.Message.Contains("VUI LÒNG LIÊN HỆ ADMIN KÍCH HOẠT"))
			{
				return new LicenseLoginResult
				{
					NeedsActivation = true,
					Message = "Vui lòng liên hệ admin kích hoạt tài khoản trước."
				};
			}
			if (licenseLoginResponse.Message.Contains("Login successful"))
			{
				return new LicenseLoginResult
				{
					Success = true
				};
			}
			return new LicenseLoginResult
			{
				Message = "Đăng nhập thất bại."
			};
		}
		catch (Exception ex)
		{
			return new LicenseLoginResult
			{
				Message = "Lỗi đăng nhập: " + ex.Message
			};
		}
	}

	public static async Task<LicenseLoginResult> RegisterAsync(string username, string password, string lastName, string firstName)
	{
		_ = 1;
		try
		{
			LicenseRegisterRequest value = new LicenseRegisterRequest
			{
				TenDangNhapId = username,
				MatKhauPass = password,
				Ho = lastName,
				Ten = firstName
			};
			using StringContent content = new StringContent(JsonSerializer.Serialize(value), Encoding.UTF8, "application/json");
			using HttpResponseMessage httpResponseMessage = await m_2481.PostAsync("jwt/Toolregclone/register", content);
			LicenseLoginResponse licenseLoginResponse = JsonSerializer.Deserialize<LicenseLoginResponse>(await httpResponseMessage.Content.ReadAsStringAsync(), new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true
			});
			if (licenseLoginResponse == null)
			{
				return new LicenseLoginResult
				{
					Message = "Phản hồi từ máy chủ không hợp lệ."
				};
			}
			if (!httpResponseMessage.IsSuccessStatusCode || licenseLoginResponse.Status != "success")
			{
				return new LicenseLoginResult
				{
					Message = (string.IsNullOrWhiteSpace(licenseLoginResponse.Message) ? "Đăng ký thất bại." : licenseLoginResponse.Message)
				};
			}
			return new LicenseLoginResult
			{
				Success = true
			};
		}
		catch (Exception ex)
		{
			return new LicenseLoginResult
			{
				Message = "Lỗi đăng ký: " + ex.Message
			};
		}
	}

	public static async Task<LicenseHardwareCheckResult> CheckHardwareAsync(string username)
	{
		_ = 1;
		try
		{
			LicenseHardwareCheckRequest value = new LicenseHardwareCheckRequest
			{
				TenKhach = username,
				TenOcung = GetHardwareId()
			};
			using StringContent content = new StringContent(JsonSerializer.Serialize(value), Encoding.UTF8, "application/json");
			using HttpResponseMessage httpResponseMessage = await m_2481.PostAsync("jwt/Toolregclone/checkocung", content);
			LicenseLoginResponse licenseLoginResponse = JsonSerializer.Deserialize<LicenseLoginResponse>(await httpResponseMessage.Content.ReadAsStringAsync(), new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true
			});
			if (licenseLoginResponse == null)
			{
				return new LicenseHardwareCheckResult
				{
					Message = "Phản hồi từ máy chủ không hợp lệ."
				};
			}
			if (licenseLoginResponse.Status == "success")
			{
				return new LicenseHardwareCheckResult
				{
					Success = true
				};
			}
			string text = (string.IsNullOrWhiteSpace(licenseLoginResponse.Message) ? "Kiểm tra thiết bị thất bại." : licenseLoginResponse.Message);
			return new LicenseHardwareCheckResult
			{
				AccountBoundToOtherDevice = text.Contains("Tài khoản đã đăng kí với máy khác"),
				Message = text
			};
		}
		catch (Exception ex)
		{
			return new LicenseHardwareCheckResult
			{
				Message = "Lỗi kiểm tra thiết bị: " + ex.Message
			};
		}
	}

	public static async Task<DesktopTokenResult> RequestDesktopTokenAsync(string username, string password)
	{
		_ = 1;
		try
		{
			DesktopTokenRequest value = new DesktopTokenRequest
			{
				TenDangNhapId = username,
				MatKhauPass = password,
				HardwareId = GetHardwareId()
			};
			using StringContent content = new StringContent(JsonSerializer.Serialize(value), Encoding.UTF8, "application/json");
			using HttpResponseMessage httpResponseMessage = await m_2481.PostAsync("jwt/api/license/desktop-token", content);
			string json = await httpResponseMessage.Content.ReadAsStringAsync();
			DesktopTokenResponse desktopTokenResponse = null;
			try
			{
				desktopTokenResponse = JsonSerializer.Deserialize<DesktopTokenResponse>(json, new JsonSerializerOptions
				{
					PropertyNameCaseInsensitive = true
				});
			}
			catch
			{
			}
			if (desktopTokenResponse?.Status == "success" && !string.IsNullOrWhiteSpace(desktopTokenResponse.Token))
			{
				return new DesktopTokenResult
				{
					Token = desktopTokenResponse.Token
				};
			}
			string text = (string.IsNullOrWhiteSpace(desktopTokenResponse?.Message) ? "Máy chủ từ chối cấp quyền chạy." : desktopTokenResponse.Message);
			return new DesktopTokenResult
			{
				Rejected = m_2488(httpResponseMessage.StatusCode, text),
				Message = text
			};
		}
		catch (Exception ex)
		{
			return new DesktopTokenResult
			{
				Message = "Không kết nối được máy chủ license: " + ex.Message
			};
		}
	}

	private static bool m_2488(HttpStatusCode P_0, string P_1)
	{
		if ((P_0 == HttpStatusCode.Unauthorized || P_0 == HttpStatusCode.Forbidden) ? true : false)
		{
			return true;
		}
		if (P_0 == HttpStatusCode.BadRequest)
		{
			if (!P_1.Contains("SAI MẬT KHẨU", StringComparison.OrdinalIgnoreCase))
			{
				return P_1.Contains("Tài khoản đã đăng kí với máy khác", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
		return false;
	}

	public static async Task<bool> RefreshJwksCacheAsync()
	{
		_ = 1;
		try
		{
			using HttpResponseMessage httpResponseMessage = await m_2481.GetAsync("jwt/api/license/jwks");
			if (!httpResponseMessage.IsSuccessStatusCode)
			{
				return false;
			}
			JwksResponse jwksResponse = JsonSerializer.Deserialize<JwksResponse>(await httpResponseMessage.Content.ReadAsStringAsync(), new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true
			});
			if (jwksResponse?.Keys == null || jwksResponse.Keys.Count == 0)
			{
				return false;
			}
			Dictionary<string, RsaSecurityKey> dictionary = new Dictionary<string, RsaSecurityKey>();
			foreach (Jwk key in jwksResponse.Keys)
			{
				if (!string.IsNullOrWhiteSpace(key.Kid) && !string.IsNullOrWhiteSpace(key.N) && !string.IsNullOrWhiteSpace(key.E))
				{
					RSAParameters parameters = new RSAParameters
					{
						Modulus = m_2489(key.N),
						Exponent = m_2489(key.E)
					};
					RSA rSA = RSA.Create();
					rSA.ImportParameters(parameters);
					dictionary[key.Kid] = new RsaSecurityKey(rSA)
					{
						KeyId = key.Kid
					};
				}
			}
			if (dictionary.Count == 0)
			{
				return false;
			}
			m_2482 = dictionary;
			return true;
		}
		catch
		{
			return false;
		}
	}

	private static byte[] m_2489(string P_0)
	{
		string text = P_0.Replace('-', '+').Replace('_', '/');
		switch (text.Length % 4)
		{
		case 2:
			text += "==";
			break;
		case 3:
			text += "=";
			break;
		}
		return Convert.FromBase64String(text);
	}

	public static bool VerifyDesktopToken(string token, out string error)
	{
		error = "";
		try
		{
			JwtSecurityTokenHandler jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
			string kid = jwtSecurityTokenHandler.ReadJwtToken(token).Header.Kid;
			if (string.IsNullOrWhiteSpace(kid) || !m_2482.TryGetValue(kid, out RsaSecurityKey value))
			{
				error = "Không tìm thấy public key khớp (kid) trong cache - có thể server vừa xoay khoá.";
				return false;
			}
			TokenValidationParameters validationParameters = new TokenValidationParameters
			{
				ValidIssuer = "tangbinhluan.com",
				ValidAudience = "toolfastfacebook",
				IssuerSigningKey = value,
				ValidateIssuer = true,
				ValidateAudience = true,
				ValidateIssuerSigningKey = true,
				ValidateLifetime = true,
				ClockSkew = TimeSpan.FromSeconds(30L)
			};
			ClaimsPrincipal claimsPrincipal = jwtSecurityTokenHandler.ValidateToken(token, validationParameters, out var _);
			string[] array = (claimsPrincipal.FindFirst("scope")?.Value ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);
			IsPhoneAiTrialActive = claimsPrincipal.FindFirst("phoneAiTrial")?.Value == "1";
			IsPhoneAiPaid = array.Contains("toolfastfacebook");
			IsPhoneAiUnlocked = IsPhoneAiPaid || IsPhoneAiTrialActive;
			HasVerifiedLicense = true;
			return true;
		}
		catch (Exception ex)
		{
			error = "Verify token thất bại: " + ex.Message;
			return false;
		}
	}

	public static string GetHardwareId()
	{
		return m_2496(m_2490() ?? m_2491() ?? m_2492("SELECT SerialNumber FROM Win32_BaseBoard") ?? m_2492("SELECT SerialNumber FROM Win32_BIOS") ?? m_2493() ?? m_2494());
	}

	private static string? m_2490()
	{
		try
		{
			string text = Environment.GetFolderPath(Environment.SpecialFolder.System).Substring(0, 2);
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT DeviceID, DriveType FROM Win32_LogicalDisk WHERE DeviceID = '" + text + "' AND DriveType = 3");
			foreach (ManagementObject item in managementObjectSearcher.Get())
			{
				using ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher($"ASSOCIATORS OF {{Win32_LogicalDisk.DeviceID='{item["DeviceID"]}'}} WHERE AssocClass=Win32_LogicalDiskToPartition");
				foreach (ManagementObject item2 in managementObjectSearcher2.Get())
				{
					using ManagementObjectSearcher managementObjectSearcher3 = new ManagementObjectSearcher($"ASSOCIATORS OF {{Win32_DiskPartition.DeviceID='{item2["DeviceID"]}'}} WHERE AssocClass=Win32_DiskDriveToDiskPartition");
					foreach (ManagementObject item3 in managementObjectSearcher3.Get())
					{
						string text2 = item3["SerialNumber"]?.ToString()?.Trim();
						if (!string.IsNullOrEmpty(text2))
						{
							return text2;
						}
					}
				}
			}
			return null;
		}
		catch
		{
			return null;
		}
	}

	private static string? m_2491()
	{
		try
		{
			string text = Environment.GetFolderPath(Environment.SpecialFolder.System).Substring(0, 2);
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_LogicalDisk WHERE DeviceID = '" + text + "'");
			foreach (ManagementObject item in managementObjectSearcher.Get())
			{
				string text2 = item["DeviceID"].ToString();
				using ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + text2 + "'} WHERE AssocClass=Win32_LogicalDiskToPartition");
				foreach (ManagementObject item2 in managementObjectSearcher2.Get())
				{
					using ManagementObjectSearcher managementObjectSearcher3 = new ManagementObjectSearcher($"ASSOCIATORS OF {{Win32_DiskPartition.DeviceID='{item2["DeviceID"]}'}} WHERE AssocClass=Win32_DiskDriveToDiskPartition");
					foreach (ManagementObject item3 in managementObjectSearcher3.Get())
					{
						string text3 = item3["SerialNumber"]?.ToString()?.Trim();
						if (!string.IsNullOrEmpty(text3))
						{
							return text3;
						}
					}
				}
			}
			return null;
		}
		catch
		{
			return null;
		}
	}

	private static string? m_2492(string P_0)
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(P_0);
			foreach (ManagementObject item in managementObjectSearcher.Get())
			{
				string text = item["SerialNumber"]?.ToString()?.Trim();
				if (!string.IsNullOrEmpty(text) && text != "To be filled by O.E.M.")
				{
					return text;
				}
			}
			return null;
		}
		catch
		{
			return null;
		}
	}

	private static string? m_2493()
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
			foreach (ManagementObject item in managementObjectSearcher.Get())
			{
				string text = item["ProcessorId"]?.ToString()?.Trim();
				if (!string.IsNullOrEmpty(text))
				{
					return text;
				}
			}
			return null;
		}
		catch
		{
			return null;
		}
	}

	private static string m_2494()
	{
		try
		{
			if (File.Exists(e))
			{
				string[] array = File.ReadAllLines(e, Encoding.UTF8);
				if (array.Length != 0 && !string.IsNullOrWhiteSpace(array[0]))
				{
					return array[0].Trim();
				}
			}
			string text = m_2495(10);
			Directory.CreateDirectory(Path.GetDirectoryName(e));
			File.WriteAllText(e, text, Encoding.UTF8);
			return text;
		}
		catch
		{
			return Guid.NewGuid().ToString("N");
		}
	}

	private static string m_2495(int P_0)
	{
		return new string(Enumerable.Range(0, P_0).Select((Func<int, char>)delegate
		{
			return "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[Random.Shared.Next("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".Length)];
		}).ToArray());
	}

	private static string m_2496(string P_0)
	{
		return Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(P_0)));
	}
}
