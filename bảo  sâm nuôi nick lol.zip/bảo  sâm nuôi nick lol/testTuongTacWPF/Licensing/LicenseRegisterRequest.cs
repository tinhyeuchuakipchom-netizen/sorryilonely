using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Licensing;

public class LicenseRegisterRequest
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string C = "string";

	[JsonPropertyName("tendangnhap_id")]
	public string TenDangNhapId
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("matkhau_pass")]
	public string MatKhauPass
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	[JsonPropertyName("ho")]
	public string Ho
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	[JsonPropertyName("ten")]
	public string Ten
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	[JsonPropertyName("salthtml")]
	public string SaltHtml
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}
}
