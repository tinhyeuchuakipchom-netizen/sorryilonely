using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class DesktopTokenResult
{
	[CompilerGenerated]
	private string? A;

	[CompilerGenerated]
	private bool m_2480;

	[CompilerGenerated]
	private string a = "";

	public string? Token
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool Rejected
	{
		[CompilerGenerated]
		get
		{
			return m_2480;
		}
		[CompilerGenerated]
		set
		{
			m_2480 = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
