using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Licensing;

public static class DesktopLicenseGuard
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_2454
	{
		public static readonly m_2454 A = new m_2454();

		public static TimerCallback m_2456;

		internal async void m_2457(object? P_0)
		{
			DesktopLicenseGuardResult desktopLicenseGuardResult = await m_2453();
			if (!desktopLicenseGuardResult.Success && !IsCurrentlyLicensed)
			{
				m_2451?.Invoke(desktopLicenseGuardResult.Message);
			}
		}
	}

	private static readonly TimeSpan A = TimeSpan.FromMinutes(2L);

	private static readonly TimeSpan a = TimeSpan.FromMinutes(10L);

	private static string m_2446 = "";

	private static string m_2447 = "";

	private static DateTime m_2448 = DateTime.MinValue;

	private static Timer? m_2449;

	private static readonly SemaphoreSlim m_2450 = new SemaphoreSlim(1, 1);

	[CompilerGenerated]
	private static Action<string>? m_2451;

	public static bool IsCurrentlyLicensed
	{
		get
		{
			if (m_2448 != DateTime.MinValue)
			{
				return DateTime.UtcNow - m_2448 < a;
			}
			return false;
		}
	}

	public static event Action<string>? LicenseLost
	{
		[CompilerGenerated]
		add
		{
			Action<string> action = m_2451;
			Action<string> action2;
			do
			{
				action2 = action;
				Action<string> value2 = (Action<string>)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange(ref m_2451, value2, action2);
			}
			while ((object)action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action<string> action = m_2451;
			Action<string> action2;
			do
			{
				action2 = action;
				Action<string> value2 = (Action<string>)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange(ref m_2451, value2, action2);
			}
			while ((object)action != action2);
		}
	}

	public static async Task<DesktopLicenseGuardResult> InitializeAsync(string username, string password)
	{
		m_2446 = username;
		m_2447 = password;
		DesktopLicenseGuardResult desktopLicenseGuardResult = await m_2453();
		if (desktopLicenseGuardResult.Success)
		{
			m_2452();
		}
		return desktopLicenseGuardResult;
	}

	public static void Stop()
	{
		m_2449?.Dispose();
		m_2449 = null;
		m_2448 = DateTime.MinValue;
	}

	private static void m_2452()
	{
		m_2449?.Dispose();
		m_2449 = new Timer(async delegate
		{
			DesktopLicenseGuardResult desktopLicenseGuardResult = await m_2453();
			if (!desktopLicenseGuardResult.Success && !IsCurrentlyLicensed)
			{
				m_2451?.Invoke(desktopLicenseGuardResult.Message);
			}
		}, null, A, A);
	}

	private static async Task<DesktopLicenseGuardResult> m_2453()
	{
		await m_2450.WaitAsync();
		try
		{
			DesktopTokenResult desktopTokenResult = await LicenseClient.RequestDesktopTokenAsync(m_2446, m_2447);
			if (desktopTokenResult.Token == null)
			{
				if (desktopTokenResult.Rejected)
				{
					m_2448 = DateTime.MinValue;
				}
				return new DesktopLicenseGuardResult
				{
					Rejected = desktopTokenResult.Rejected,
					Message = desktopTokenResult.Message
				};
			}
			string token = desktopTokenResult.Token;
			if (!LicenseClient.VerifyDesktopToken(token, out string error))
			{
				if (await LicenseClient.RefreshJwksCacheAsync() && LicenseClient.VerifyDesktopToken(token, out error))
				{
					m_2448 = DateTime.UtcNow;
					return new DesktopLicenseGuardResult
					{
						Success = true
					};
				}
				return new DesktopLicenseGuardResult
				{
					Message = error
				};
			}
			m_2448 = DateTime.UtcNow;
			return new DesktopLicenseGuardResult
			{
				Success = true
			};
		}
		catch (Exception ex)
		{
			return new DesktopLicenseGuardResult
			{
				Message = "Lỗi xác thực license: " + ex.Message
			};
		}
		finally
		{
			m_2450.Release();
		}
	}
}
