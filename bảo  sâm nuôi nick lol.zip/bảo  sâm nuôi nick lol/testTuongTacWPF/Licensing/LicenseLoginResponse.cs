using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class LicenseLoginResponse
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	public string Status
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
