using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class Jwk
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	public string Kid
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string N
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string E
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}
}
