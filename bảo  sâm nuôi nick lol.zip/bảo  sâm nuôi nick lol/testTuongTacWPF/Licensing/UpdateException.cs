using System;

namespace testTuongTacWPF.Licensing;

public class UpdateException : Exception
{
	public UpdateException(string message)
		: base(message)
	{
	}

	public UpdateException(string message, Exception inner)
		: base(message, inner)
	{
	}
}
