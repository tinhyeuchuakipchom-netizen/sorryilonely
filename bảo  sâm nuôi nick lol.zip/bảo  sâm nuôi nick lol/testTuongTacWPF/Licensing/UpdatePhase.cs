namespace testTuongTacWPF.Licensing;

public enum UpdatePhase
{
	CheckingVersion,
	Downloading,
	Verifying,
	Installing,
	RelaunchingApp,
	Done
}
