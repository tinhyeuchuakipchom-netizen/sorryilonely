using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Licensing;

public static class SelfUpdateService
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_2586
	{
		public static readonly m_2586 A = new m_2586();

		public static Predicate<ManifestEntry> m_2592;

		public static Predicate<ManifestEntry> a;

		internal bool m_2593(ManifestEntry P_0)
		{
			return !m_2572(P_0.Path);
		}

		internal bool m_2594(ManifestEntry P_0)
		{
			return m_2572(P_0.Path);
		}
	}

	[CompilerGenerated]
	private sealed class m_2587
	{
		public Func<Task> A;

		internal async Task<bool> m_2595()
		{
			await A();
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_2588
	{
		public Process A;

		internal bool m_2600()
		{
			return A.WaitForExit(3000);
		}
	}

	[CompilerGenerated]
	private sealed class m_2589
	{
		public string A;

		internal bool m_2601(string P_0)
		{
			return A.StartsWith(P_0, StringComparison.OrdinalIgnoreCase);
		}
	}

	[CompilerGenerated]
	private sealed class m_2590
	{
		public CancellationToken A;

		internal Task<List<ManifestEntry>> m_2602()
		{
			return m_2578(A);
		}
	}

	[CompilerGenerated]
	private sealed class m_2591
	{
		public string A;

		public string a;

		public IProgress<UpdateProgress> m_2603;

		public CancellationToken m_2604;

		internal Task m_2605()
		{
			return m_2581(A, a, m_2603, m_2604);
		}
	}

	private const string A = "FastBoxPhone.exe";

	private const string a = "https://tangbinhluan.com/updates/UPDATE_TOOL/toolfastfacebook/full";

	private const int m_2568 = 5;

	private static readonly int[] m_2569 = new int[5] { 1, 2, 4, 8, 16 };

	private static readonly string[] m_2570 = new string[4] { "dulieu/", "setup/", "runtimes/", ".playwright/" };

	private static readonly HttpClient m_2571 = m_2573();

	private static bool m_2572(string P_0)
	{
		return Array.Exists(m_2570, (string value) => P_0.StartsWith(value, StringComparison.OrdinalIgnoreCase));
	}

	private static HttpClient m_2573()
	{
		return new HttpClient
		{
			Timeout = TimeSpan.FromMinutes(5L),
			DefaultRequestVersion = HttpVersion.Version11,
			DefaultVersionPolicy = HttpVersionPolicy.RequestVersionExact,
			DefaultRequestHeaders = { { "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FastBoxPhoneSelfUpdate" } }
		};
	}

	public static async Task RunAsync(string installDir, IProgress<UpdateProgress> progress, CancellationToken cancellationToken)
	{
		b(installDir);
		progress.Report(new UpdateProgress
		{
			Phase = UpdatePhase.CheckingVersion,
			Message = "Đang tải danh sách file mới nhất..."
		});
		List<ManifestEntry> list = await m_2576(() => m_2578(cancellationToken), progress, "Đang tải danh sách file mới nhất...", cancellationToken);
		progress.Report(new UpdateProgress
		{
			Phase = UpdatePhase.Verifying,
			Message = "Đang so sánh với bản hiện tại..."
		});
		List<ManifestEntry> list2 = m_2579(list, installDir);
		if (list2.Count == 0)
		{
			progress.Report(new UpdateProgress
			{
				Phase = UpdatePhase.Done,
				Message = "Đã là bản mới nhất."
			});
			B(installDir);
			return;
		}
		List<ManifestEntry> list3 = list2.FindAll((ManifestEntry P_0) => !m_2572(P_0.Path));
		List<ManifestEntry> list4 = list2.FindAll((ManifestEntry P_0) => m_2572(P_0.Path));
		string text = Path.Combine(Path.GetTempPath(), $"FastBoxPhone_update_{Guid.NewGuid():N}");
		try
		{
			if (list3.Count > 0)
			{
				await m_2574("light.zip", list3, text, progress, cancellationToken);
			}
			if (list4.Count > 0)
			{
				await m_2574("heavy.zip", list4, text, progress, cancellationToken);
			}
			progress.Report(new UpdateProgress
			{
				Phase = UpdatePhase.Installing,
				Message = "Đang cài đặt..."
			});
			await m_2583(cancellationToken);
			m_2584(text, installDir, list2);
			progress.Report(new UpdateProgress
			{
				Phase = UpdatePhase.RelaunchingApp,
				Message = "Hoàn tất! Đang mở lại ứng dụng..."
			});
			B(installDir);
			progress.Report(new UpdateProgress
			{
				Phase = UpdatePhase.Done,
				Message = "Hoàn tất."
			});
		}
		finally
		{
			c(text);
		}
	}

	private static async Task m_2574(string P_0, List<ManifestEntry> P_1, string P_2, IProgress<UpdateProgress> P_3, CancellationToken P_4)
	{
		string a2 = Path.Combine(Path.GetTempPath(), $"FastBoxPhone_update_{Guid.NewGuid():N}.zip");
		try
		{
			await m_2575(() => m_2581(P_0, a2, P_3, P_4), P_3, "Đang tải " + P_0 + "...", P_4);
			P_3.Report(new UpdateProgress
			{
				Phase = UpdatePhase.Verifying,
				Message = "Đang giải nén và xác minh..."
			});
			m_2582(a2, P_2, P_1);
		}
		finally
		{
			C(a2);
		}
	}

	private static Task m_2575(Func<Task> P_0, IProgress<UpdateProgress> P_1, string P_2, CancellationToken P_3)
	{
		return m_2576(async () =>
		{
			await P_0();
			return true;
		}, P_1, P_2, P_3);
	}

	private static async Task<gm_2567> m_2576<gm_2567>(Func<Task<gm_2567>> P_0, IProgress<UpdateProgress> P_1, string P_2, CancellationToken P_3)
	{
		Exception ex = null;
		for (int i = 1; i <= 5; i++)
		{
			P_3.ThrowIfCancellationRequested();
			try
			{
				return await P_0();
			}
			catch (OperationCanceledException)
			{
				throw;
			}
			catch (Exception ex3)
			{
				ex = ex3;
				if (i != 5)
				{
					int num = m_2569[Math.Min(i - 1, m_2569.Length - 1)];
					P_1.Report(new UpdateProgress
					{
						Phase = UpdatePhase.CheckingVersion,
						Message = $"{P_2} (lỗi, thử lại sau {num}s - lần {i}/{5})"
					});
					await Task.Delay(TimeSpan.FromSeconds(num), P_3);
					continue;
				}
			}
			break;
		}
		throw new UpdateException($"Thử {5} lần vẫn không được: {ex?.Message}", ex);
	}

	private static string m_2577(string P_0)
	{
		return P_0 + (P_0.Contains('?') ? "&" : "?") + "_=" + DateTime.UtcNow.Ticks;
	}

	private static async Task<List<ManifestEntry>> m_2578(CancellationToken P_0)
	{
		List<ManifestEntry> list = JsonSerializer.Deserialize<List<ManifestEntry>>(await m_2571.GetStringAsync(m_2577("https://tangbinhluan.com/updates/UPDATE_TOOL/toolfastfacebook/full/manifest.json"), P_0));
		if (list == null || list.Count == 0)
		{
			throw new UpdateException("Không đọc được danh sách file cập nhật từ máy chủ.");
		}
		return list;
	}

	private static List<ManifestEntry> m_2579(List<ManifestEntry> P_0, string P_1)
	{
		List<ManifestEntry> list = new List<ManifestEntry>();
		foreach (ManifestEntry item in P_0)
		{
			if (m_2580(Path.Combine(P_1, item.Path.Replace('/', Path.DirectorySeparatorChar)), item))
			{
				list.Add(item);
			}
		}
		return list;
	}

	private static bool m_2580(string P_0, ManifestEntry P_1)
	{
		FileInfo fileInfo = new FileInfo(P_0);
		if (!fileInfo.Exists)
		{
			return true;
		}
		if (fileInfo.Length != P_1.Size)
		{
			return true;
		}
		using SHA256 sHA = SHA256.Create();
		using FileStream inputStream = File.OpenRead(P_0);
		return !string.Equals(Convert.ToHexString(sHA.ComputeHash(inputStream)), P_1.Sha256, StringComparison.OrdinalIgnoreCase);
	}

	private static async Task m_2581(string P_0, string P_1, IProgress<UpdateProgress> P_2, CancellationToken P_3)
	{
		_ = 5;
		try
		{
			using HttpResponseMessage httpResponseMessage = await m_2571.GetAsync(m_2577("https://tangbinhluan.com/updates/UPDATE_TOOL/toolfastfacebook/full/" + P_0), HttpCompletionOption.ResponseHeadersRead, P_3);
			if (!httpResponseMessage.IsSuccessStatusCode)
			{
				throw new UpdateException($"Máy chủ trả về {(int)httpResponseMessage.StatusCode} {httpResponseMessage.StatusCode} khi tải bản cập nhật.");
			}
			long? contentLength = httpResponseMessage.Content.Headers.ContentLength;
			await using Stream stream = await httpResponseMessage.Content.ReadAsStreamAsync(P_3);
			await using FileStream fileStream = File.Create(P_1);
			byte[] array = new byte[81920];
			long num = 0L;
			while (true)
			{
				int num3;
				int num2 = (num3 = await stream.ReadAsync(array, P_3));
				if (num3 <= 0)
				{
					break;
				}
				await fileStream.WriteAsync(array.AsMemory(0, num2), P_3);
				num += num2;
				double? num4 = (contentLength.HasValue ? new double?(Math.Round((double)num * 100.0 / (double)contentLength.Value, 1)) : ((double?)null));
				P_2.Report(new UpdateProgress
				{
					Phase = UpdatePhase.Downloading,
					Message = (num4.HasValue ? $"Đang tải xuống... {num4:0}%" : $"Đang tải xuống... {num / 1024 / 1024}MB"),
					PercentComplete = num4
				});
			}
		}
		catch
		{
			C(P_1);
			throw;
		}
	}

	private static void m_2582(string P_0, string P_1, List<ManifestEntry> P_2)
	{
		Directory.CreateDirectory(P_1);
		ZipFile.ExtractToDirectory(P_0, P_1, overwriteFiles: true);
		foreach (ManifestEntry item in P_2)
		{
			string path = Path.Combine(P_1, item.Path.Replace('/', Path.DirectorySeparatorChar));
			if (!File.Exists(path))
			{
				throw new UpdateException("Bản cập nhật thiếu file " + item.Path + ".");
			}
			using SHA256 sHA = SHA256.Create();
			using FileStream inputStream = File.OpenRead(path);
			if (!string.Equals(Convert.ToHexString(sHA.ComputeHash(inputStream)), item.Sha256, StringComparison.OrdinalIgnoreCase))
			{
				throw new UpdateException("File " + item.Path + " trong bản cập nhật bị lỗi (checksum không khớp).");
			}
		}
	}

	private static async Task m_2583(CancellationToken P_0)
	{
		int processId = Environment.ProcessId;
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension("FastBoxPhone.exe");
		Process[] processesByName = Process.GetProcessesByName(fileNameWithoutExtension);
		foreach (Process A in processesByName)
		{
			if (A.Id == processId)
			{
				continue;
			}
			try
			{
				if (A.CloseMainWindow())
				{
					await Task.Run(() => A.WaitForExit(3000), P_0);
				}
				if (!A.HasExited)
				{
					A.Kill();
				}
			}
			catch
			{
			}
		}
	}

	private static void m_2584(string P_0, string P_1, List<ManifestEntry> P_2)
	{
		foreach (ManifestEntry item in P_2)
		{
			string path = item.Path.Replace('/', Path.DirectorySeparatorChar);
			string text = Path.Combine(P_0, path);
			string text2 = Path.Combine(P_1, path);
			string directoryName = Path.GetDirectoryName(text2);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			m_2585(text, text2);
		}
	}

	private static void m_2585(string P_0, string P_1)
	{
		try
		{
			File.Copy(P_0, P_1, overwrite: true);
		}
		catch (IOException)
		{
			if (File.Exists(P_1))
			{
				string destFileName = P_1 + $".old_{Guid.NewGuid():N}";
				File.Move(P_1, destFileName);
			}
			File.Copy(P_0, P_1, overwrite: true);
		}
	}

	private static void B(string P_0)
	{
		string text = Path.Combine(P_0, "FastBoxPhone.exe");
		if (!File.Exists(text))
		{
			return;
		}
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = text,
				WorkingDirectory = P_0,
				UseShellExecute = true
			});
		}
		catch
		{
		}
	}

	private static void b(string P_0)
	{
		try
		{
			foreach (string item in Directory.EnumerateFiles(P_0, "*.old_*", SearchOption.AllDirectories))
			{
				C(item);
			}
		}
		catch
		{
		}
	}

	private static void C(string P_0)
	{
		try
		{
			if (File.Exists(P_0))
			{
				File.Delete(P_0);
			}
		}
		catch
		{
		}
	}

	private static void c(string P_0)
	{
		try
		{
			if (Directory.Exists(P_0))
			{
				Directory.Delete(P_0, recursive: true);
			}
		}
		catch
		{
		}
	}
}
