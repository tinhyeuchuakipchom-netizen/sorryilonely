using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Licensing;

public class ManifestEntry
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private long m_2566;

	[JsonPropertyName("path")]
	public string Path
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("sha256")]
	public string Sha256
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	[JsonPropertyName("size")]
	public long Size
	{
		[CompilerGenerated]
		get
		{
			return m_2566;
		}
		[CompilerGenerated]
		set
		{
			m_2566 = value;
		}
	}
}
