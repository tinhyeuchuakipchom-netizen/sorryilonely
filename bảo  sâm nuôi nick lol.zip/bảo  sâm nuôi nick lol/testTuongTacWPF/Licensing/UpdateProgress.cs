using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Licensing;

public class UpdateProgress
{
	[CompilerGenerated]
	private UpdatePhase A;

	[CompilerGenerated]
	private string m_2561 = "";

	[CompilerGenerated]
	private double? m_2562;

	public UpdatePhase Phase
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return m_2561;
		}
		[CompilerGenerated]
		set
		{
			m_2561 = value;
		}
	}

	public double? PercentComplete
	{
		[CompilerGenerated]
		get
		{
			return m_2562;
		}
		[CompilerGenerated]
		set
		{
			m_2562 = value;
		}
	}
}
