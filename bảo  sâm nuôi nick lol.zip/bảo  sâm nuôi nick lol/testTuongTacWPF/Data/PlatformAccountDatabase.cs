using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Data;

public class PlatformAccountDatabase
{
	public const string DefaultFolderName = "Mặc định";

	private static readonly string A = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");

	private static readonly string a = Path.Combine(A, "facebook_accounts.db");

	private static readonly string B = "Data Source=" + a;

	private readonly string b;

	private readonly string C;

	public PlatformAccountDatabase(string platformKey)
	{
		b = platformKey + "Accounts";
		C = platformKey + "Folders";
	}

	private void m_2668(SqliteConnection P_0, string P_1, string P_2, string P_3)
	{
		using (SqliteCommand sqliteCommand = P_0.CreateCommand())
		{
			sqliteCommand.CommandText = "PRAGMA table_info(" + P_1 + ")";
			using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
			while (sqliteDataReader.Read())
			{
				if (string.Equals(sqliteDataReader.GetString(1), P_2, StringComparison.OrdinalIgnoreCase))
				{
					return;
				}
			}
		}
		using SqliteCommand sqliteCommand2 = P_0.CreateCommand();
		sqliteCommand2.CommandText = $"ALTER TABLE {P_1} ADD COLUMN {P_2} {P_3}";
		sqliteCommand2.ExecuteNonQuery();
	}

	public void EnsureCreated()
	{
		Directory.CreateDirectory(A);
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using (SqliteCommand sqliteCommand = sqliteConnection.CreateCommand())
		{
			sqliteCommand.CommandText = $"\r\n                    CREATE TABLE IF NOT EXISTS {C} (\r\n                        Id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n                        Name TEXT NOT NULL,\r\n                        IsSystem INTEGER NOT NULL DEFAULT 0\r\n                    );\r\n\r\n                    CREATE TABLE IF NOT EXISTS {b} (\r\n                        Id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n                        Idx INTEGER NOT NULL,\r\n                        FolderId INTEGER NOT NULL DEFAULT 0,\r\n                        PhoneName TEXT NOT NULL DEFAULT '',\r\n                        ScriptId INTEGER NOT NULL DEFAULT 0,\r\n                        ScriptName TEXT NOT NULL DEFAULT '',\r\n                        Uid TEXT NOT NULL DEFAULT '',\r\n                        Pass TEXT NOT NULL DEFAULT '',\r\n                        TwoFA TEXT NOT NULL DEFAULT '',\r\n                        Token TEXT NOT NULL DEFAULT '',\r\n                        Cookie TEXT NOT NULL DEFAULT '',\r\n                        Mail TEXT NOT NULL DEFAULT '',\r\n                        PassMail TEXT NOT NULL DEFAULT '',\r\n                        MailKhoiPhuc TEXT NOT NULL DEFAULT '',\r\n                        ProfileChrome TEXT NOT NULL DEFAULT '',\r\n                        TenProfile TEXT NOT NULL DEFAULT '',\r\n                        UserAgent TEXT NOT NULL DEFAULT '',\r\n                        Proxy TEXT NOT NULL DEFAULT '',\r\n                        GhiChu TEXT NOT NULL DEFAULT '',\r\n                        TrangThai TEXT NOT NULL DEFAULT '',\r\n                        TinhTrang TEXT NOT NULL DEFAULT '',\r\n                        BrowserProfileId TEXT NOT NULL DEFAULT ''\r\n                    );";
			sqliteCommand.ExecuteNonQuery();
		}
		m_2668(sqliteConnection, b, "UserAgent", "TEXT NOT NULL DEFAULT ''");
		m_2668(sqliteConnection, b, "TikTokInteractionSettingsJson", "TEXT NOT NULL DEFAULT ''");
		int num;
		using (SqliteCommand sqliteCommand2 = sqliteConnection.CreateCommand())
		{
			sqliteCommand2.CommandText = "SELECT Id FROM " + C + " WHERE IsSystem = 1 ORDER BY Id LIMIT 1";
			object obj = sqliteCommand2.ExecuteScalar();
			if (obj != null)
			{
				num = Convert.ToInt32(obj);
			}
			else
			{
				using SqliteCommand sqliteCommand3 = sqliteConnection.CreateCommand();
				sqliteCommand3.CommandText = "INSERT INTO " + C + " (Name, IsSystem) VALUES (@Name, 1); SELECT last_insert_rowid();";
				sqliteCommand3.Parameters.AddWithValue("@Name", "Mặc định");
				num = Convert.ToInt32(sqliteCommand3.ExecuteScalar());
			}
		}
		using (SqliteCommand sqliteCommand4 = sqliteConnection.CreateCommand())
		{
			sqliteCommand4.CommandText = "UPDATE " + b + " SET FolderId = @DefaultId WHERE FolderId = 0";
			sqliteCommand4.Parameters.AddWithValue("@DefaultId", num);
			sqliteCommand4.ExecuteNonQuery();
		}
		using SqliteCommand sqliteCommand5 = sqliteConnection.CreateCommand();
		sqliteCommand5.CommandText = "UPDATE " + C + " SET Name = @Name WHERE Id = @DefaultId";
		sqliteCommand5.Parameters.AddWithValue("@Name", "Mặc định");
		sqliteCommand5.Parameters.AddWithValue("@DefaultId", num);
		sqliteCommand5.ExecuteNonQuery();
	}

	public void DropTables()
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = $"DROP TABLE IF EXISTS {b}; DROP TABLE IF EXISTS {C};";
		sqliteCommand.ExecuteNonQuery();
	}

	public List<NickFolder> LoadFolders()
	{
		List<NickFolder> list = new List<NickFolder>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "SELECT Id, Name, IsSystem FROM " + C + " ORDER BY IsSystem DESC, Id";
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			list.Add(new NickFolder
			{
				Id = sqliteDataReader.GetInt32(0),
				Name = sqliteDataReader.GetString(1),
				IsSystem = (sqliteDataReader.GetInt32(2) != 0)
			});
		}
		return list;
	}

	public NickFolder CreateFolder(string name)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "INSERT INTO " + C + " (Name, IsSystem) VALUES (@Name, 0); SELECT last_insert_rowid();";
		sqliteCommand.Parameters.AddWithValue("@Name", name);
		int id = Convert.ToInt32(sqliteCommand.ExecuteScalar());
		return new NickFolder
		{
			Id = id,
			Name = name,
			IsSystem = false
		};
	}

	public void RenameFolder(int id, string newName)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "UPDATE " + C + " SET Name = @Name WHERE Id = @Id AND IsSystem = 0";
		sqliteCommand.Parameters.AddWithValue("@Name", newName);
		sqliteCommand.Parameters.AddWithValue("@Id", id);
		sqliteCommand.ExecuteNonQuery();
	}

	public void DeleteFolder(int id)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "DELETE FROM " + C + " WHERE Id = @Id AND IsSystem = 0";
		sqliteCommand.Parameters.AddWithValue("@Id", id);
		sqliteCommand.ExecuteNonQuery();
	}

	public List<PlatformAccountRow> LoadAll()
	{
		List<PlatformAccountRow> list = new List<PlatformAccountRow>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "\r\n                SELECT Idx, FolderId, PhoneName, ScriptId, ScriptName, Uid, Pass, TwoFA, Token, Cookie, Mail, PassMail,\r\n                       MailKhoiPhuc, ProfileChrome, TenProfile, UserAgent, Proxy, GhiChu, TrangThai, TinhTrang, BrowserProfileId,\r\n                       TikTokInteractionSettingsJson\r\n                FROM " + b + "\r\n                ORDER BY Id";
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			list.Add(new PlatformAccountRow
			{
				Index = sqliteDataReader.GetInt32(0),
				FolderId = sqliteDataReader.GetInt32(1),
				PhoneName = sqliteDataReader.GetString(2),
				ScriptId = sqliteDataReader.GetInt32(3),
				ScriptName = sqliteDataReader.GetString(4),
				Uid = sqliteDataReader.GetString(5),
				Pass = sqliteDataReader.GetString(6),
				TwoFA = sqliteDataReader.GetString(7),
				Token = sqliteDataReader.GetString(8),
				Cookie = sqliteDataReader.GetString(9),
				Mail = sqliteDataReader.GetString(10),
				PassMail = sqliteDataReader.GetString(11),
				MailKhoiPhuc = sqliteDataReader.GetString(12),
				ProfileChrome = sqliteDataReader.GetString(13),
				TenProfile = sqliteDataReader.GetString(14),
				UserAgent = sqliteDataReader.GetString(15),
				Proxy = sqliteDataReader.GetString(16),
				GhiChu = sqliteDataReader.GetString(17),
				TrangThai = sqliteDataReader.GetString(18),
				TinhTrang = sqliteDataReader.GetString(19),
				BrowserProfileId = sqliteDataReader.GetString(20),
				TikTokInteractionSettingsJson = sqliteDataReader.GetString(21)
			});
		}
		return list;
	}

	public void SaveAll(IEnumerable<PlatformAccountRow> rows)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteTransaction sqliteTransaction = sqliteConnection.BeginTransaction();
		using (SqliteCommand sqliteCommand = sqliteConnection.CreateCommand())
		{
			sqliteCommand.Transaction = sqliteTransaction;
			sqliteCommand.CommandText = "DELETE FROM " + b;
			sqliteCommand.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand2 = sqliteConnection.CreateCommand())
		{
			sqliteCommand2.Transaction = sqliteTransaction;
			sqliteCommand2.CommandText = "\r\n                    INSERT INTO " + b + "\r\n                    (Idx, FolderId, PhoneName, ScriptId, ScriptName, Uid, Pass, TwoFA, Token, Cookie, Mail, PassMail,\r\n                     MailKhoiPhuc, ProfileChrome, TenProfile, UserAgent, Proxy, GhiChu, TrangThai, TinhTrang, BrowserProfileId,\r\n                     TikTokInteractionSettingsJson)\r\n                    VALUES\r\n                    (@Idx, @FolderId, @PhoneName, @ScriptId, @ScriptName, @Uid, @Pass, @TwoFA, @Token, @Cookie, @Mail, @PassMail,\r\n                     @MailKhoiPhuc, @ProfileChrome, @TenProfile, @UserAgent, @Proxy, @GhiChu, @TrangThai, @TinhTrang, @BrowserProfileId,\r\n                     @TikTokInteractionSettingsJson)";
			sqliteCommand2.Parameters.Add("@Idx", SqliteType.Integer);
			sqliteCommand2.Parameters.Add("@FolderId", SqliteType.Integer);
			sqliteCommand2.Parameters.Add("@PhoneName", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@ScriptId", SqliteType.Integer);
			sqliteCommand2.Parameters.Add("@ScriptName", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Uid", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Pass", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TwoFA", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Token", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Cookie", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Mail", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PassMail", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@MailKhoiPhuc", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@ProfileChrome", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TenProfile", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@UserAgent", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Proxy", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@GhiChu", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TrangThai", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TinhTrang", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@BrowserProfileId", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TikTokInteractionSettingsJson", SqliteType.Text);
			foreach (PlatformAccountRow row in rows)
			{
				sqliteCommand2.Parameters["@Idx"].Value = row.Index;
				sqliteCommand2.Parameters["@FolderId"].Value = row.FolderId;
				sqliteCommand2.Parameters["@PhoneName"].Value = row.PhoneName;
				sqliteCommand2.Parameters["@ScriptId"].Value = row.ScriptId;
				sqliteCommand2.Parameters["@ScriptName"].Value = row.ScriptName;
				sqliteCommand2.Parameters["@Uid"].Value = row.Uid;
				sqliteCommand2.Parameters["@Pass"].Value = row.Pass;
				sqliteCommand2.Parameters["@TwoFA"].Value = row.TwoFA;
				sqliteCommand2.Parameters["@Token"].Value = row.Token;
				sqliteCommand2.Parameters["@Cookie"].Value = row.Cookie;
				sqliteCommand2.Parameters["@Mail"].Value = row.Mail;
				sqliteCommand2.Parameters["@PassMail"].Value = row.PassMail;
				sqliteCommand2.Parameters["@MailKhoiPhuc"].Value = row.MailKhoiPhuc;
				sqliteCommand2.Parameters["@ProfileChrome"].Value = row.ProfileChrome;
				sqliteCommand2.Parameters["@TenProfile"].Value = row.TenProfile;
				sqliteCommand2.Parameters["@UserAgent"].Value = row.UserAgent;
				sqliteCommand2.Parameters["@Proxy"].Value = row.Proxy;
				sqliteCommand2.Parameters["@GhiChu"].Value = row.GhiChu;
				sqliteCommand2.Parameters["@TrangThai"].Value = row.TrangThai;
				sqliteCommand2.Parameters["@TinhTrang"].Value = row.TinhTrang;
				sqliteCommand2.Parameters["@BrowserProfileId"].Value = row.BrowserProfileId;
				sqliteCommand2.Parameters["@TikTokInteractionSettingsJson"].Value = row.TikTokInteractionSettingsJson;
				sqliteCommand2.ExecuteNonQuery();
			}
		}
		sqliteTransaction.Commit();
	}
}
