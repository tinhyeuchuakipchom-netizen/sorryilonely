using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Data;

public static class FacebookAccountDatabase
{
	public const string DefaultFolderName = "Mặc định";

	private static readonly string A = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");

	private static readonly string a = Path.Combine(A, "facebook_accounts.db");

	private static readonly string B = "Data Source=" + a;

	private static readonly (string Platform, string Category, string Name)[] m_2666 = new (string, string, string)[51]
	{
		("Phone", "Chăm sóc tài khoản", "Lướt tin nuôi theo đề xuất"),
		("Phone", "Chăm sóc tài khoản", "Lướt xem Reels"),
		("Phone", "Chăm sóc tài khoản", "Đăng nhập và Nghỉ ngơi"),
		("Phone", "Chăm sóc tài khoản", "Đọc thông báo"),
		("Phone", "Chăm sóc tài khoản", "Up avatar và ảnh bìa"),
		("Phone", "Chăm sóc tài khoản", "Đổi tên tài khoản"),
		("Phone", "Chăm sóc tài khoản", "Đăng story"),
		("Phone", "Chăm sóc tài khoản", "Phê duyệt thành viên group"),
		("Phone", "Chăm sóc tài khoản", "Từ chối bài viết group"),
		("Phone", "Chăm sóc tài khoản", "Mời bạn bè vào group"),
		("Phone", "Tương tác nhóm", "Tham gia nhóm"),
		("Phone", "Tương tác nhóm", "Bình luận bài viết lên nhóm"),
		("Phone", "Tương tác nhóm", "Đăng bài viết lên nhóm"),
		("Phone", "Tương tác nhóm", "Đăng bài lên tường"),
		("Phone", "Tương tác nhóm", "Nhắn tin người đăng bài trên nhóm"),
		("Phone", "Tương tác nhóm", "Nhắn tin cho người bình luận nhóm"),
		("Phone", "Tương tác nhóm", "Nhắn tin cho UID chỉ định"),
		("Phone", "Tương tác nhóm", "Comment và like comment"),
		("Phone", "Tương tác nhóm", "Report bài viết hoặc tài khoản"),
		("Phone", "Tương tác nhóm", "Chia sẻ bài viết vào nhóm"),
		("Phone", "Kết bạn / tương tác", "Kết bạn theo từ khoá"),
		("Phone", "Kết bạn / tương tác", "Kết bạn theo gợi ý"),
		("Phone", "Kết bạn / tương tác", "Kết bạn theo UID"),
		("Phone", "Kết bạn / tương tác", "Huỷ lời mời kết bạn"),
		("Phone", "Kết bạn / tương tác", "Xác nhận kết bạn"),
		("Phone", "Kết bạn / tương tác", "Buff like và Buff follow"),
		("Phone", "Kết bạn / tương tác", "Cập nhật thông tin"),
		("Phone", "Kết bạn / tương tác", "Xem livestream và bình luận"),
		("Phone", "Kết bạn / tương tác", "Mời bạn bè like Fanpage"),
		("Phone", "Kết bạn / tương tác", "Check-in địa điểm"),
		("Phone", "Bài viết / Page", "Share bài viết"),
		("Phone", "Bài viết / Page", "Mời bạn bè vào nhóm"),
		("Phone", "Bài viết / Page", "Rời nhóm"),
		("Phone", "Bài viết / Page", "Tạo Page mới"),
		("Phone", "Bài viết / Page", "Đánh giá và review page"),
		("Phone", "Bài viết / Page", "Bật chế độ chuyên nghiệp"),
		("Phone", "Bài viết / Page", "Đổi mật khẩu"),
		("Phone", "Bài viết / Page", "Gắn thẻ bạn bè trong bài viết"),
		("Phone", "Bài viết / Page", "Xóa/Ẩn bài viết cũ"),
		("Phone", "Bài viết / Page", "Bật chế độ hẹn hò"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền Like TBL"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền Comment"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền Share bài viết"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền Follow"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền Tham gia nhóm"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền Review Fanpage"),
		("Phone", "Kiếm tiền / khác", "Kiếm tiền ALL job"),
		("Phone", "Kiếm tiền / khác", "Tạo BM business"),
		("Phone", "Kiếm tiền / khác", "Tạo tài khoản intagram"),
		("Phone", "Kiếm tiền / khác", "Nuôi nick web"),
		("Chrome", "Chăm sóc tài khoản", "Đăng nhập và giữ phiên")
	};

	private static void m_2667(SqliteConnection P_0, string P_1, string P_2, string P_3)
	{
		using (SqliteCommand sqliteCommand = P_0.CreateCommand())
		{
			sqliteCommand.CommandText = "PRAGMA table_info(" + P_1 + ")";
			using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
			while (sqliteDataReader.Read())
			{
				if (string.Equals(sqliteDataReader.GetString(1), P_2, StringComparison.OrdinalIgnoreCase))
				{
					return;
				}
			}
		}
		using SqliteCommand sqliteCommand2 = P_0.CreateCommand();
		sqliteCommand2.CommandText = $"ALTER TABLE {P_1} ADD COLUMN {P_2} {P_3}";
		sqliteCommand2.ExecuteNonQuery();
	}

	public static void EnsureCreated()
	{
		Directory.CreateDirectory(A);
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using (SqliteCommand sqliteCommand = sqliteConnection.CreateCommand())
		{
			sqliteCommand.CommandText = "\n                    CREATE TABLE IF NOT EXISTS NickFolders (\n                        Id INTEGER PRIMARY KEY AUTOINCREMENT,\n                        Name TEXT NOT NULL,\n                        IsSystem INTEGER NOT NULL DEFAULT 0\n                    );\n\n                    CREATE TABLE IF NOT EXISTS Actions (\n                        Id INTEGER PRIMARY KEY AUTOINCREMENT,\n                        Name TEXT NOT NULL,\n                        Category TEXT NOT NULL DEFAULT '',\n                        Platform TEXT NOT NULL DEFAULT 'Phone'\n                    );\n\n                    CREATE TABLE IF NOT EXISTS ScriptFolders (\n                        Id INTEGER PRIMARY KEY AUTOINCREMENT,\n                        Name TEXT NOT NULL,\n                        Platform TEXT NOT NULL DEFAULT 'Phone',\n                        IsSystem INTEGER NOT NULL DEFAULT 0\n                    );\n\n                    CREATE TABLE IF NOT EXISTS ScriptFolderActions (\n                        ScriptFolderId INTEGER NOT NULL,\n                        ActionId INTEGER NOT NULL,\n                        PRIMARY KEY (ScriptFolderId, ActionId)\n                    );\n\n                    CREATE TABLE IF NOT EXISTS FacebookAccounts (\n                        Id INTEGER PRIMARY KEY AUTOINCREMENT,\n                        Idx INTEGER NOT NULL,\n                        FolderId INTEGER NOT NULL DEFAULT 0,\n                        PhoneName TEXT NOT NULL DEFAULT '',\n                        ScriptId INTEGER NOT NULL DEFAULT 0,\n                        ScriptName TEXT NOT NULL DEFAULT '',\n                        Uid TEXT NOT NULL DEFAULT '',\n                        Pass TEXT NOT NULL DEFAULT '',\n                        TwoFA TEXT NOT NULL DEFAULT '',\n                        Token TEXT NOT NULL DEFAULT '',\n                        Cookie TEXT NOT NULL DEFAULT '',\n                        Mail TEXT NOT NULL DEFAULT '',\n                        PassMail TEXT NOT NULL DEFAULT '',\n                        MailKhoiPhuc TEXT NOT NULL DEFAULT '',\n                        PassMailKhoiPhuc TEXT NOT NULL DEFAULT '',\n                        BanBe TEXT NOT NULL DEFAULT '',\n                        Nhom TEXT NOT NULL DEFAULT '',\n                        GioiTinh TEXT NOT NULL DEFAULT '',\n                        Avatar TEXT NOT NULL DEFAULT '',\n                        ProfileChrome TEXT NOT NULL DEFAULT '',\n                        TenProfile TEXT NOT NULL DEFAULT '',\n                        UserAgent TEXT NOT NULL DEFAULT '',\n                        Proxy TEXT NOT NULL DEFAULT '',\n                        TepCu TEXT NOT NULL DEFAULT '',\n                        GhiChu TEXT NOT NULL DEFAULT '',\n                        TuongTacCuoi TEXT NOT NULL DEFAULT '',\n                        TrangThai TEXT NOT NULL DEFAULT '',\n                        TinhTrang TEXT NOT NULL DEFAULT '',\n                        BrowserProfileId TEXT NOT NULL DEFAULT '',\n                        HoTen TEXT NOT NULL DEFAULT ''\n                    );";
			sqliteCommand.ExecuteNonQuery();
		}
		m_2667(sqliteConnection, "FacebookAccounts", "FolderId", "INTEGER NOT NULL DEFAULT 0");
		m_2667(sqliteConnection, "FacebookAccounts", "PhoneName", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "ScriptId", "INTEGER NOT NULL DEFAULT 0");
		m_2667(sqliteConnection, "FacebookAccounts", "ScriptName", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "TinhTrang", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "HoTen", "TEXT NOT NULL DEFAULT ''");
		try
		{
			using SqliteCommand sqliteCommand2 = sqliteConnection.CreateCommand();
			sqliteCommand2.CommandText = "ALTER TABLE FacebookAccounts RENAME COLUMN GpmProfileId TO BrowserProfileId";
			sqliteCommand2.ExecuteNonQuery();
		}
		catch
		{
		}
		m_2667(sqliteConnection, "FacebookAccounts", "BrowserProfileId", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "FeedBrowsingSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "GroupSpamSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "GroupSpamCommentedPostsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "PostBoostSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "PostBoostDoneActionsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "FriendRequestSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "FriendRequestSentJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "PageCreationSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "PostCreationSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "PagePostSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "MessagingSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "MessagingSentJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "FacebookAccounts", "BmCreationSettingsJson", "TEXT NOT NULL DEFAULT ''");
		m_2667(sqliteConnection, "Actions", "Platform", "TEXT NOT NULL DEFAULT 'Phone'");
		m_2667(sqliteConnection, "ScriptFolders", "Platform", "TEXT NOT NULL DEFAULT 'Phone'");
		m_2667(sqliteConnection, "ScriptFolders", "AiVisionFlowJson", "TEXT NOT NULL DEFAULT '[]'");
		m_2667(sqliteConnection, "ScriptFolders", "ChuDe", "TEXT NOT NULL DEFAULT 'Facebook'");
		m_2667(sqliteConnection, "ScriptFolders", "IsSystem", "INTEGER NOT NULL DEFAULT 0");
		using (SqliteCommand sqliteCommand3 = sqliteConnection.CreateCommand())
		{
			sqliteCommand3.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand3.Parameters.AddWithValue("@Name", "Đăng nhập");
			sqliteCommand3.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand4 = sqliteConnection.CreateCommand())
		{
			sqliteCommand4.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand4.Parameters.AddWithValue("@Name", "Tạo Page");
			sqliteCommand4.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand5 = sqliteConnection.CreateCommand())
		{
			sqliteCommand5.CommandText = "UPDATE ScriptFolders SET Name = @NewName WHERE Name = @OldName AND IsSystem = 1";
			sqliteCommand5.Parameters.AddWithValue("@NewName", "Nuôi nick");
			sqliteCommand5.Parameters.AddWithValue("@OldName", "Lướt bảng tin");
			sqliteCommand5.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand6 = sqliteConnection.CreateCommand())
		{
			sqliteCommand6.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand6.Parameters.AddWithValue("@Name", "Nuôi nick");
			sqliteCommand6.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand7 = sqliteConnection.CreateCommand())
		{
			sqliteCommand7.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand7.Parameters.AddWithValue("@Name", "Spam nhóm");
			sqliteCommand7.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand8 = sqliteConnection.CreateCommand())
		{
			sqliteCommand8.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand8.Parameters.AddWithValue("@Name", "Nuôi bài viết");
			sqliteCommand8.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand9 = sqliteConnection.CreateCommand())
		{
			sqliteCommand9.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand9.Parameters.AddWithValue("@Name", "Kết bạn");
			sqliteCommand9.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand10 = sqliteConnection.CreateCommand())
		{
			sqliteCommand10.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand10.Parameters.AddWithValue("@Name", "Nhắn tin");
			sqliteCommand10.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand11 = sqliteConnection.CreateCommand())
		{
			sqliteCommand11.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand11.Parameters.AddWithValue("@Name", "Đăng bài viết");
			sqliteCommand11.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand12 = sqliteConnection.CreateCommand())
		{
			sqliteCommand12.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand12.Parameters.AddWithValue("@Name", "Đăng bài trên page");
			sqliteCommand12.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand13 = sqliteConnection.CreateCommand())
		{
			sqliteCommand13.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, IsSystem)\n                    SELECT @Name, 'Chrome', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name)";
			sqliteCommand13.Parameters.AddWithValue("@Name", "Tạo BM");
			sqliteCommand13.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand14 = sqliteConnection.CreateCommand())
		{
			sqliteCommand14.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, ChuDe, IsSystem)\n                    SELECT 'Đăng nhập', 'Phone', 'TikTok', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = 'Đăng nhập' AND ChuDe = 'TikTok' AND Platform = 'Phone')";
			sqliteCommand14.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand15 = sqliteConnection.CreateCommand())
		{
			sqliteCommand15.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, ChuDe, IsSystem)\n                    SELECT 'Tương tác', 'Phone', 'TikTok', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = 'Tương tác' AND ChuDe = 'TikTok' AND Platform = 'Phone')";
			sqliteCommand15.ExecuteNonQuery();
		}
		string[] array = new string[5] { "Thả tim", "Bình luận", "Follow (Sub)", "Chia sẻ", "Cập nhật Avatar" };
		foreach (string value in array)
		{
			using SqliteCommand sqliteCommand16 = sqliteConnection.CreateCommand();
			sqliteCommand16.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, ChuDe, IsSystem)\n                    SELECT @Name, 'Phone', 'TikTok', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name AND ChuDe = 'TikTok' AND Platform = 'Phone')";
			sqliteCommand16.Parameters.AddWithValue("@Name", value);
			sqliteCommand16.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand17 = sqliteConnection.CreateCommand())
		{
			sqliteCommand17.CommandText = "\n                    DELETE FROM ScriptFolders \n                    WHERE ChuDe = 'Facebook' \n                      AND (Platform = 'Phone' OR Platform = 'Android' OR Platform = 'iPhone' OR Platform = 'iOS')\n                      AND Name NOT IN ('Đăng nhập', 'Tạo Page', 'Đăng bài viết', 'Nuôi bài viết', 'Spam nhóm', 'Kết bạn')\n                      AND IsSystem = 1;\n                    DELETE FROM ScriptFolders\n                    WHERE ChuDe = 'Facebook'\n                      AND (Platform = 'iPhone' OR Platform = 'iOS')\n                      AND IsSystem = 1;";
			sqliteCommand17.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand18 = sqliteConnection.CreateCommand())
		{
			sqliteCommand18.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, ChuDe, IsSystem)\n                    SELECT 'Đăng nhập', 'Phone', 'Facebook', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = 'Đăng nhập' AND ChuDe = 'Facebook' AND (Platform = 'Phone' OR Platform = 'Android'))";
			sqliteCommand18.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand19 = sqliteConnection.CreateCommand())
		{
			sqliteCommand19.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, ChuDe, IsSystem)\n                    SELECT 'Tạo Page', 'Phone', 'Facebook', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = 'Tạo Page' AND ChuDe = 'Facebook' AND (Platform = 'Phone' OR Platform = 'Android'))";
			sqliteCommand19.ExecuteNonQuery();
		}
		array = new string[4] { "Đăng bài viết", "Nuôi bài viết", "Spam nhóm", "Kết bạn" };
		foreach (string value2 in array)
		{
			using SqliteCommand sqliteCommand20 = sqliteConnection.CreateCommand();
			sqliteCommand20.CommandText = "\n                    INSERT INTO ScriptFolders (Name, Platform, ChuDe, IsSystem)\n                    SELECT @Name, 'Phone', 'Facebook', 1\n                    WHERE NOT EXISTS (SELECT 1 FROM ScriptFolders WHERE Name = @Name AND ChuDe = 'Facebook' AND (Platform = 'Phone' OR Platform = 'Android'))";
			sqliteCommand20.Parameters.AddWithValue("@Name", value2);
			sqliteCommand20.ExecuteNonQuery();
		}
		int num;
		using (SqliteCommand sqliteCommand21 = sqliteConnection.CreateCommand())
		{
			sqliteCommand21.CommandText = "SELECT Id FROM NickFolders WHERE IsSystem = 1 ORDER BY Id LIMIT 1";
			object obj2 = sqliteCommand21.ExecuteScalar();
			if (obj2 != null)
			{
				num = Convert.ToInt32(obj2);
			}
			else
			{
				using SqliteCommand sqliteCommand22 = sqliteConnection.CreateCommand();
				sqliteCommand22.CommandText = "INSERT INTO NickFolders (Name, IsSystem) VALUES (@Name, 1); SELECT last_insert_rowid();";
				sqliteCommand22.Parameters.AddWithValue("@Name", "Mặc định");
				num = Convert.ToInt32(sqliteCommand22.ExecuteScalar());
			}
		}
		using (SqliteCommand sqliteCommand23 = sqliteConnection.CreateCommand())
		{
			sqliteCommand23.CommandText = "UPDATE FacebookAccounts SET FolderId = @DefaultId WHERE FolderId = 0";
			sqliteCommand23.Parameters.AddWithValue("@DefaultId", num);
			sqliteCommand23.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand24 = sqliteConnection.CreateCommand())
		{
			sqliteCommand24.CommandText = "UPDATE NickFolders SET Name = @Name WHERE Id = @DefaultId";
			sqliteCommand24.Parameters.AddWithValue("@Name", "Mặc định");
			sqliteCommand24.Parameters.AddWithValue("@DefaultId", num);
			sqliteCommand24.ExecuteNonQuery();
		}
		using SqliteTransaction sqliteTransaction = sqliteConnection.BeginTransaction();
		using SqliteCommand sqliteCommand25 = sqliteConnection.CreateCommand();
		sqliteCommand25.Transaction = sqliteTransaction;
		sqliteCommand25.CommandText = "\n                    INSERT INTO Actions (Name, Category, Platform)\n                    SELECT @Name, @Category, @Platform\n                    WHERE NOT EXISTS (SELECT 1 FROM Actions WHERE Name = @Name AND Platform = @Platform)";
		sqliteCommand25.Parameters.Add("@Name", SqliteType.Text);
		sqliteCommand25.Parameters.Add("@Category", SqliteType.Text);
		sqliteCommand25.Parameters.Add("@Platform", SqliteType.Text);
		(string, string, string)[] array2 = m_2666;
		for (int i = 0; i < array2.Length; i++)
		{
			var (value3, value4, value5) = array2[i];
			sqliteCommand25.Parameters["@Name"].Value = value5;
			sqliteCommand25.Parameters["@Category"].Value = value4;
			sqliteCommand25.Parameters["@Platform"].Value = value3;
			sqliteCommand25.ExecuteNonQuery();
		}
		sqliteTransaction.Commit();
	}

	public static List<NickFolder> LoadFolders()
	{
		List<NickFolder> list = new List<NickFolder>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "SELECT Id, Name, IsSystem FROM NickFolders ORDER BY IsSystem DESC, Id";
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			list.Add(new NickFolder
			{
				Id = sqliteDataReader.GetInt32(0),
				Name = sqliteDataReader.GetString(1),
				IsSystem = (sqliteDataReader.GetInt32(2) != 0)
			});
		}
		return list;
	}

	public static NickFolder CreateFolder(string name)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "INSERT INTO NickFolders (Name, IsSystem) VALUES (@Name, 0); SELECT last_insert_rowid();";
		sqliteCommand.Parameters.AddWithValue("@Name", name);
		int id = Convert.ToInt32(sqliteCommand.ExecuteScalar());
		return new NickFolder
		{
			Id = id,
			Name = name,
			IsSystem = false
		};
	}

	public static void RenameFolder(int id, string newName)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "UPDATE NickFolders SET Name = @Name WHERE Id = @Id AND IsSystem = 0";
		sqliteCommand.Parameters.AddWithValue("@Name", newName);
		sqliteCommand.Parameters.AddWithValue("@Id", id);
		sqliteCommand.ExecuteNonQuery();
	}

	public static void DeleteFolder(int id)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "DELETE FROM NickFolders WHERE Id = @Id AND IsSystem = 0";
		sqliteCommand.Parameters.AddWithValue("@Id", id);
		sqliteCommand.ExecuteNonQuery();
	}

	public static List<InteractionAction> LoadActions()
	{
		List<InteractionAction> list = new List<InteractionAction>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "SELECT Id, Name, Category, Platform FROM Actions ORDER BY Id";
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			list.Add(new InteractionAction
			{
				Id = sqliteDataReader.GetInt32(0),
				Name = sqliteDataReader.GetString(1),
				Category = sqliteDataReader.GetString(2),
				Platform = sqliteDataReader.GetString(3)
			});
		}
		return list;
	}

	public static List<ScriptItem> LoadScriptFolders()
	{
		List<ScriptItem> list = new List<ScriptItem>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "SELECT Id, Name, Platform, AiVisionFlowJson, IsSystem, ChuDe FROM ScriptFolders ORDER BY Id";
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			list.Add(new ScriptItem
			{
				Id = sqliteDataReader.GetInt32(0),
				Name = sqliteDataReader.GetString(1),
				Platform = sqliteDataReader.GetString(2),
				AiVisionFlowJson = sqliteDataReader.GetString(3),
				IsSystem = (sqliteDataReader.GetInt32(4) != 0),
				ChuDe = (sqliteDataReader.IsDBNull(5) ? "Facebook" : sqliteDataReader.GetString(5))
			});
		}
		return list;
	}

	public static void SaveScriptFolderAiVisionFlow(int folderId, string flowJson)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "UPDATE ScriptFolders SET AiVisionFlowJson = @Json WHERE Id = @Id";
		sqliteCommand.Parameters.AddWithValue("@Json", flowJson);
		sqliteCommand.Parameters.AddWithValue("@Id", folderId);
		sqliteCommand.ExecuteNonQuery();
	}

	public static ScriptItem CreateScriptFolder(string name, string platform, string chuDe = "Facebook")
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "INSERT INTO ScriptFolders (Name, Platform, ChuDe) VALUES (@Name, @Platform, @ChuDe); SELECT last_insert_rowid();";
		sqliteCommand.Parameters.AddWithValue("@Name", name);
		sqliteCommand.Parameters.AddWithValue("@Platform", platform);
		sqliteCommand.Parameters.AddWithValue("@ChuDe", chuDe);
		int id = Convert.ToInt32(sqliteCommand.ExecuteScalar());
		return new ScriptItem
		{
			Id = id,
			Name = name,
			Platform = platform,
			ChuDe = chuDe
		};
	}

	public static void RenameScriptFolder(int id, string newName)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "UPDATE ScriptFolders SET Name = @Name WHERE Id = @Id AND IsSystem = 0";
		sqliteCommand.Parameters.AddWithValue("@Name", newName);
		sqliteCommand.Parameters.AddWithValue("@Id", id);
		sqliteCommand.ExecuteNonQuery();
	}

	public static void DeleteScriptFolder(int id)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteTransaction sqliteTransaction = sqliteConnection.BeginTransaction();
		using (SqliteCommand sqliteCommand = sqliteConnection.CreateCommand())
		{
			sqliteCommand.Transaction = sqliteTransaction;
			sqliteCommand.CommandText = "DELETE FROM ScriptFolderActions WHERE ScriptFolderId = @Id";
			sqliteCommand.Parameters.AddWithValue("@Id", id);
			sqliteCommand.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand2 = sqliteConnection.CreateCommand())
		{
			sqliteCommand2.Transaction = sqliteTransaction;
			sqliteCommand2.CommandText = "DELETE FROM ScriptFolders WHERE Id = @Id AND IsSystem = 0";
			sqliteCommand2.Parameters.AddWithValue("@Id", id);
			sqliteCommand2.ExecuteNonQuery();
		}
		sqliteTransaction.Commit();
	}

	public static HashSet<int> LoadActionIdsForFolder(int folderId)
	{
		HashSet<int> hashSet = new HashSet<int>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "SELECT ActionId FROM ScriptFolderActions WHERE ScriptFolderId = @FolderId";
		sqliteCommand.Parameters.AddWithValue("@FolderId", folderId);
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			hashSet.Add(sqliteDataReader.GetInt32(0));
		}
		return hashSet;
	}

	public static void SetActionInFolder(int folderId, int actionId, bool included)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		if (included)
		{
			sqliteCommand.CommandText = "INSERT OR IGNORE INTO ScriptFolderActions (ScriptFolderId, ActionId) VALUES (@FolderId, @ActionId)";
		}
		else
		{
			sqliteCommand.CommandText = "DELETE FROM ScriptFolderActions WHERE ScriptFolderId = @FolderId AND ActionId = @ActionId";
		}
		sqliteCommand.Parameters.AddWithValue("@FolderId", folderId);
		sqliteCommand.Parameters.AddWithValue("@ActionId", actionId);
		sqliteCommand.ExecuteNonQuery();
	}

	public static List<FacebookAccountRow> LoadAll()
	{
		List<FacebookAccountRow> list = new List<FacebookAccountRow>();
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteCommand sqliteCommand = sqliteConnection.CreateCommand();
		sqliteCommand.CommandText = "\n                SELECT Idx, FolderId, PhoneName, ScriptId, ScriptName, Uid, Pass, TwoFA, Token, Cookie, Mail, PassMail,\n                       MailKhoiPhuc, PassMailKhoiPhuc, BanBe, Nhom, GioiTinh, Avatar, ProfileChrome, TenProfile,\n                       UserAgent, Proxy, TepCu, GhiChu, TuongTacCuoi, TrangThai, TinhTrang, BrowserProfileId, HoTen,\n                       FeedBrowsingSettingsJson, GroupSpamSettingsJson, GroupSpamCommentedPostsJson,\n                       PostBoostSettingsJson, PostBoostDoneActionsJson,\n                        FriendRequestSettingsJson, FriendRequestSentJson, PageCreationSettingsJson,\n                        PostCreationSettingsJson, PagePostSettingsJson, MessagingSettingsJson, MessagingSentJson,\n                        BmCreationSettingsJson\n                FROM FacebookAccounts\n                ORDER BY Id";
		using SqliteDataReader sqliteDataReader = sqliteCommand.ExecuteReader();
		while (sqliteDataReader.Read())
		{
			list.Add(new FacebookAccountRow
			{
				Index = sqliteDataReader.GetInt32(0),
				FolderId = sqliteDataReader.GetInt32(1),
				PhoneName = sqliteDataReader.GetString(2),
				ScriptId = sqliteDataReader.GetInt32(3),
				ScriptName = sqliteDataReader.GetString(4),
				Uid = sqliteDataReader.GetString(5),
				Pass = sqliteDataReader.GetString(6),
				TwoFA = sqliteDataReader.GetString(7),
				Token = sqliteDataReader.GetString(8),
				Cookie = sqliteDataReader.GetString(9),
				Mail = sqliteDataReader.GetString(10),
				PassMail = sqliteDataReader.GetString(11),
				MailKhoiPhuc = sqliteDataReader.GetString(12),
				PassMailKhoiPhuc = sqliteDataReader.GetString(13),
				BanBe = sqliteDataReader.GetString(14),
				Nhom = sqliteDataReader.GetString(15),
				GioiTinh = sqliteDataReader.GetString(16),
				Avatar = sqliteDataReader.GetString(17),
				ProfileChrome = sqliteDataReader.GetString(18),
				TenProfile = sqliteDataReader.GetString(19),
				UserAgent = sqliteDataReader.GetString(20),
				Proxy = sqliteDataReader.GetString(21),
				TepCu = sqliteDataReader.GetString(22),
				GhiChu = sqliteDataReader.GetString(23),
				TuongTacCuoi = sqliteDataReader.GetString(24),
				TrangThai = sqliteDataReader.GetString(25),
				TinhTrang = sqliteDataReader.GetString(26),
				BrowserProfileId = sqliteDataReader.GetString(27),
				HoTen = sqliteDataReader.GetString(28),
				FeedBrowsingSettingsJson = sqliteDataReader.GetString(29),
				GroupSpamSettingsJson = sqliteDataReader.GetString(30),
				GroupSpamCommentedPostsJson = sqliteDataReader.GetString(31),
				PostBoostSettingsJson = sqliteDataReader.GetString(32),
				PostBoostDoneActionsJson = sqliteDataReader.GetString(33),
				FriendRequestSettingsJson = sqliteDataReader.GetString(34),
				FriendRequestSentJson = sqliteDataReader.GetString(35),
				PageCreationSettingsJson = sqliteDataReader.GetString(36),
				PostCreationSettingsJson = sqliteDataReader.GetString(37),
				PagePostSettingsJson = sqliteDataReader.GetString(38),
				MessagingSettingsJson = sqliteDataReader.GetString(39),
				MessagingSentJson = sqliteDataReader.GetString(40),
				BmCreationSettingsJson = sqliteDataReader.GetString(41)
			});
		}
		return list;
	}

	public static void SaveAll(IEnumerable<FacebookAccountRow> rows)
	{
		using SqliteConnection sqliteConnection = new SqliteConnection(B);
		sqliteConnection.Open();
		using SqliteTransaction sqliteTransaction = sqliteConnection.BeginTransaction();
		using (SqliteCommand sqliteCommand = sqliteConnection.CreateCommand())
		{
			sqliteCommand.Transaction = sqliteTransaction;
			sqliteCommand.CommandText = "DELETE FROM FacebookAccounts";
			sqliteCommand.ExecuteNonQuery();
		}
		using (SqliteCommand sqliteCommand2 = sqliteConnection.CreateCommand())
		{
			sqliteCommand2.Transaction = sqliteTransaction;
			sqliteCommand2.CommandText = "\n                    INSERT INTO FacebookAccounts\n                    (Idx, FolderId, PhoneName, ScriptId, ScriptName, Uid, Pass, TwoFA, Token, Cookie, Mail, PassMail,\n                     MailKhoiPhuc, PassMailKhoiPhuc, BanBe, Nhom, GioiTinh, Avatar, ProfileChrome, TenProfile,\n                     UserAgent, Proxy, TepCu, GhiChu, TuongTacCuoi, TrangThai, TinhTrang, BrowserProfileId, HoTen,\n                     FeedBrowsingSettingsJson, GroupSpamSettingsJson, GroupSpamCommentedPostsJson,\n                     PostBoostSettingsJson, PostBoostDoneActionsJson,\n                     FriendRequestSettingsJson, FriendRequestSentJson, PageCreationSettingsJson,\n                     PostCreationSettingsJson, PagePostSettingsJson, MessagingSettingsJson, MessagingSentJson,\n                     BmCreationSettingsJson)\n                    VALUES\n                    (@Idx, @FolderId, @PhoneName, @ScriptId, @ScriptName, @Uid, @Pass, @TwoFA, @Token, @Cookie, @Mail, @PassMail,\n                     @MailKhoiPhuc, @PassMailKhoiPhuc, @BanBe, @Nhom, @GioiTinh, @Avatar, @ProfileChrome, @TenProfile,\n                     @UserAgent, @Proxy, @TepCu, @GhiChu, @TuongTacCuoi, @TrangThai, @TinhTrang, @BrowserProfileId, @HoTen,\n                     @FeedBrowsingSettingsJson, @GroupSpamSettingsJson, @GroupSpamCommentedPostsJson,\n                     @PostBoostSettingsJson, @PostBoostDoneActionsJson,\n                     @FriendRequestSettingsJson, @FriendRequestSentJson, @PageCreationSettingsJson,\n                     @PostCreationSettingsJson, @PagePostSettingsJson, @MessagingSettingsJson, @MessagingSentJson,\n                     @BmCreationSettingsJson)";
			sqliteCommand2.Parameters.Add("@Idx", SqliteType.Integer);
			sqliteCommand2.Parameters.Add("@FolderId", SqliteType.Integer);
			sqliteCommand2.Parameters.Add("@PhoneName", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@ScriptId", SqliteType.Integer);
			sqliteCommand2.Parameters.Add("@ScriptName", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Uid", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Pass", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TwoFA", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Token", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Cookie", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Mail", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PassMail", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@MailKhoiPhuc", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PassMailKhoiPhuc", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@BanBe", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Nhom", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@GioiTinh", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Avatar", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@ProfileChrome", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TenProfile", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@UserAgent", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@Proxy", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TepCu", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@GhiChu", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TuongTacCuoi", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TrangThai", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@TinhTrang", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@BrowserProfileId", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@HoTen", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@FeedBrowsingSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@GroupSpamSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@GroupSpamCommentedPostsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PostBoostSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PostBoostDoneActionsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@FriendRequestSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@FriendRequestSentJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PageCreationSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PostCreationSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@PagePostSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@MessagingSettingsJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@MessagingSentJson", SqliteType.Text);
			sqliteCommand2.Parameters.Add("@BmCreationSettingsJson", SqliteType.Text);
			foreach (FacebookAccountRow row in rows)
			{
				sqliteCommand2.Parameters["@Idx"].Value = row.Index;
				sqliteCommand2.Parameters["@FolderId"].Value = row.FolderId;
				sqliteCommand2.Parameters["@PhoneName"].Value = row.PhoneName;
				sqliteCommand2.Parameters["@ScriptId"].Value = row.ScriptId;
				sqliteCommand2.Parameters["@ScriptName"].Value = row.ScriptName;
				sqliteCommand2.Parameters["@Uid"].Value = row.Uid;
				sqliteCommand2.Parameters["@Pass"].Value = row.Pass;
				sqliteCommand2.Parameters["@TwoFA"].Value = row.TwoFA;
				sqliteCommand2.Parameters["@Token"].Value = row.Token;
				sqliteCommand2.Parameters["@Cookie"].Value = row.Cookie;
				sqliteCommand2.Parameters["@Mail"].Value = row.Mail;
				sqliteCommand2.Parameters["@PassMail"].Value = row.PassMail;
				sqliteCommand2.Parameters["@MailKhoiPhuc"].Value = row.MailKhoiPhuc;
				sqliteCommand2.Parameters["@PassMailKhoiPhuc"].Value = row.PassMailKhoiPhuc;
				sqliteCommand2.Parameters["@BanBe"].Value = row.BanBe;
				sqliteCommand2.Parameters["@Nhom"].Value = row.Nhom;
				sqliteCommand2.Parameters["@GioiTinh"].Value = row.GioiTinh;
				sqliteCommand2.Parameters["@Avatar"].Value = row.Avatar;
				sqliteCommand2.Parameters["@ProfileChrome"].Value = row.ProfileChrome;
				sqliteCommand2.Parameters["@TenProfile"].Value = row.TenProfile;
				sqliteCommand2.Parameters["@UserAgent"].Value = row.UserAgent;
				sqliteCommand2.Parameters["@Proxy"].Value = row.Proxy;
				sqliteCommand2.Parameters["@TepCu"].Value = row.TepCu;
				sqliteCommand2.Parameters["@GhiChu"].Value = row.GhiChu;
				sqliteCommand2.Parameters["@TuongTacCuoi"].Value = row.TuongTacCuoi;
				sqliteCommand2.Parameters["@TrangThai"].Value = row.TrangThai;
				sqliteCommand2.Parameters["@TinhTrang"].Value = row.TinhTrang;
				sqliteCommand2.Parameters["@BrowserProfileId"].Value = row.BrowserProfileId;
				sqliteCommand2.Parameters["@HoTen"].Value = row.HoTen;
				sqliteCommand2.Parameters["@FeedBrowsingSettingsJson"].Value = row.FeedBrowsingSettingsJson;
				sqliteCommand2.Parameters["@GroupSpamSettingsJson"].Value = row.GroupSpamSettingsJson;
				sqliteCommand2.Parameters["@GroupSpamCommentedPostsJson"].Value = row.GroupSpamCommentedPostsJson;
				sqliteCommand2.Parameters["@PostBoostSettingsJson"].Value = row.PostBoostSettingsJson;
				sqliteCommand2.Parameters["@PostBoostDoneActionsJson"].Value = row.PostBoostDoneActionsJson;
				sqliteCommand2.Parameters["@FriendRequestSettingsJson"].Value = row.FriendRequestSettingsJson;
				sqliteCommand2.Parameters["@FriendRequestSentJson"].Value = row.FriendRequestSentJson;
				sqliteCommand2.Parameters["@PageCreationSettingsJson"].Value = row.PageCreationSettingsJson;
				sqliteCommand2.Parameters["@PostCreationSettingsJson"].Value = row.PostCreationSettingsJson;
				sqliteCommand2.Parameters["@PagePostSettingsJson"].Value = row.PagePostSettingsJson;
				sqliteCommand2.Parameters["@MessagingSettingsJson"].Value = row.MessagingSettingsJson;
				sqliteCommand2.Parameters["@MessagingSentJson"].Value = row.MessagingSentJson;
				sqliteCommand2.Parameters["@BmCreationSettingsJson"].Value = row.BmCreationSettingsJson;
				sqliteCommand2.ExecuteNonQuery();
			}
		}
		sqliteTransaction.Commit();
	}
}
