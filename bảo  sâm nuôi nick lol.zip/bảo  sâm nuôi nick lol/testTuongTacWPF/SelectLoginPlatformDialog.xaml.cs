using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class SelectLoginPlatformDialog : Window, IComponentConnector
{
	[CompilerGenerated]
	private sealed class m_2148
	{
		public string A;

		public SelectLoginPlatformDialog m_2151;

		internal void m_2152(object P_0, RoutedEventArgs P_1)
		{
			m_2151.m_2139(A);
		}
	}

	[CompilerGenerated]
	private readonly List<string> A = new List<string>();

	private List<string> a = new List<string>();

	private List<string> B = new List<string>();

	private bool m_2132 = true;

	private bool m_2133;

	private bool m_2134;

	public string SelectedPlatform
	{
		get
		{
			if (PlatformPhoneRadio.IsChecked != true)
			{
				return "Chrome";
			}
			return "Phone";
		}
	}

	public string SelectedPackageType
	{
		get
		{
			if (AppLiteRadio.IsChecked != true)
			{
				return "Katana";
			}
			return "Lite";
		}
	}

	public bool UpdateNickPlatform => UpdatePlatformCheckBox.IsChecked == true;

	public List<string> SelectedPhones
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
	}

	public SelectLoginPlatformDialog(int selectedCount = 1, Window? owner = null)
	{
		InitializeComponent();
		if (owner != null)
		{
			Owner = owner;
		}
		if (selectedCount > 1)
		{
			PromptTextBlock.Text = $"Chọn nền tảng bạn muốn dùng để đăng nhập cho {selectedCount} tài khoản đã chọn:";
		}
		else
		{
			PromptTextBlock.Text = "Chọn nền tảng bạn muốn dùng để đăng nhập tài khoản:";
		}
		try
		{
			CreateRunThreadsSettings createRunThreadsSettings = CreateRunThreadsSettings.Load("Reg Nick Facebook");
			if (createRunThreadsSettings.PhoneNames != null && createRunThreadsSettings.PhoneNames.Count > 0)
			{
				B = createRunThreadsSettings.PhoneNames.ToList();
			}
			if (string.Equals(createRunThreadsSettings.Platform, "Phone", StringComparison.OrdinalIgnoreCase))
			{
				PlatformPhoneRadio.IsChecked = true;
				AndroidAppSelectionPanel.Visibility = Visibility.Visible;
			}
			else
			{
				PlatformChromeRadio.IsChecked = true;
				AndroidAppSelectionPanel.Visibility = Visibility.Collapsed;
			}
			if (string.Equals(createRunThreadsSettings.AndroidPackageType, "Lite", StringComparison.OrdinalIgnoreCase))
			{
				AppLiteRadio.IsChecked = true;
			}
			else
			{
				AppKatanaRadio.IsChecked = true;
			}
		}
		catch
		{
			PlatformChromeRadio.IsChecked = true;
			AndroidAppSelectionPanel.Visibility = Visibility.Collapsed;
		}
		if (PlatformPhoneRadio.IsChecked == true)
		{
			m_2136();
		}
	}

	private void m_2135(object P_0, RoutedEventArgs P_1)
	{
		if (AndroidAppSelectionPanel != null)
		{
			bool valueOrDefault = PlatformPhoneRadio.IsChecked == true;
			AndroidAppSelectionPanel.Visibility = ((!valueOrDefault) ? Visibility.Collapsed : Visibility.Visible);
			if (valueOrDefault && a.Count == 0 && !m_2133)
			{
				m_2136();
			}
		}
	}

	private async Task m_2136(bool P_0 = false)
	{
		if (m_2133)
		{
			return;
		}
		m_2133 = true;
		try
		{
			if (RefreshDevicesButton != null)
			{
				RefreshDevicesButton.IsEnabled = false;
			}
			if (RefreshDevicesText != null)
			{
				RefreshDevicesText.Text = "Đang tìm...";
			}
			if (DeviceCountText != null)
			{
				DeviceCountText.Text = "Đang quét...";
			}
			a = (await AdbController.ListDevicesAsync()) ?? new List<string>();
			SelectedPhones.RemoveAll((string item) => !a.Contains(item));
			if (m_2132)
			{
				m_2132 = false;
				List<string> list = a.Where((string item) => B.Contains(item)).ToList();
				if (list.Count > 0)
				{
					SelectedPhones.AddRange(list);
				}
				else if (a.Count > 0)
				{
					SelectedPhones.AddRange(a);
				}
			}
			else if (SelectedPhones.Count == 0 && a.Count > 0)
			{
				SelectedPhones.AddRange(a);
			}
			m_2137();
		}
		catch
		{
			if (DeviceCountText != null)
			{
				DeviceCountText.Text = "Lỗi quét";
			}
		}
		finally
		{
			m_2133 = false;
			if (RefreshDevicesButton != null)
			{
				RefreshDevicesButton.IsEnabled = true;
			}
			if (RefreshDevicesText != null)
			{
				RefreshDevicesText.Text = "Tìm lại phone";
			}
		}
	}

	private void m_2137()
	{
		if (DeviceListPanel == null)
		{
			return;
		}
		DeviceListPanel.Children.Clear();
		if (a.Count == 0)
		{
			DeviceListPanel.Children.Add(new TextBlock
			{
				Text = "Không tìm thấy phone Android nào đang kết nối.\nVui lòng cắm cáp USB hoặc mở giả lập rồi bấm \"Tìm lại phone\".",
				Foreground = (Brush)FindResource("BrushTextMuted"),
				FontSize = 11.5,
				TextWrapping = TextWrapping.Wrap,
				Margin = new Thickness(4.0, 4.0, 4.0, 4.0),
				LineHeight = 16.0
			});
			if (SelectAllDevicesCheckBox != null)
			{
				SelectAllDevicesCheckBox.IsChecked = false;
			}
			if (DeviceCountText != null)
			{
				DeviceCountText.Text = "0 phone";
			}
			return;
		}
		foreach (string item in a)
		{
			string A = item;
			bool flag = SelectedPhones.Contains(A);
			Border border = new Border
			{
				Tag = A,
				Background = (flag ? ((Brush)FindResource("BrushHover")) : ((Brush)FindResource("BrushCard"))),
				BorderBrush = (flag ? ((Brush)FindResource("BrushAccent")) : ((Brush)FindResource("BrushBorderLight"))),
				BorderThickness = new Thickness(flag ? 1.5 : 1.0),
				CornerRadius = new CornerRadius(6.0),
				Padding = new Thickness(8.0, 6.0, 8.0, 6.0),
				Margin = new Thickness(0.0, 2.0, 0.0, 2.0),
				Cursor = Cursors.Hand
			};
			border.MouseLeftButtonDown += m_2138;
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = GridLength.Auto
			});
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(1.0, GridUnitType.Star)
			});
			CheckBox checkBox = new CheckBox
			{
				IsChecked = flag,
				VerticalAlignment = VerticalAlignment.Center,
				Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
			};
			checkBox.Click += delegate
			{
				m_2139(A);
			};
			StackPanel stackPanel = new StackPanel
			{
				Orientation = Orientation.Horizontal,
				VerticalAlignment = VerticalAlignment.Center
			};
			Grid.SetColumn(stackPanel, 1);
			TextBlock element = new TextBlock
			{
				Text = "\ue8ea",
				FontFamily = (FontFamily)FindResource("IconFont"),
				FontSize = 13.0,
				Foreground = new SolidColorBrush(Color.FromRgb(61, 220, 132)),
				VerticalAlignment = VerticalAlignment.Center,
				Margin = new Thickness(0.0, 0.0, 6.0, 0.0)
			};
			TextBlock element2 = new TextBlock
			{
				Text = A,
				FontSize = 12.0,
				FontWeight = FontWeights.SemiBold,
				Foreground = (Brush)FindResource("BrushTextPrimary"),
				VerticalAlignment = VerticalAlignment.Center,
				TextTrimming = TextTrimming.CharacterEllipsis
			};
			stackPanel.Children.Add(element);
			stackPanel.Children.Add(element2);
			grid.Children.Add(checkBox);
			grid.Children.Add(stackPanel);
			border.Child = grid;
			DeviceListPanel.Children.Add(border);
		}
		m_2140();
	}

	private void m_2138(object P_0, MouseButtonEventArgs P_1)
	{
		if (!(P_1.OriginalSource is CheckBox) && P_0 is FrameworkElement { Tag: string tag })
		{
			m_2139(tag);
		}
	}

	private void m_2139(string P_0)
	{
		if (SelectedPhones.Contains(P_0))
		{
			SelectedPhones.Remove(P_0);
		}
		else
		{
			SelectedPhones.Add(P_0);
		}
		m_2140();
	}

	private void m_2140()
	{
		if (DeviceListPanel == null)
		{
			return;
		}
		foreach (UIElement child in DeviceListPanel.Children)
		{
			if (!(child is Border { Tag: string tag } border))
			{
				continue;
			}
			bool flag = SelectedPhones.Contains(tag);
			border.BorderBrush = (flag ? ((Brush)FindResource("BrushAccent")) : ((Brush)FindResource("BrushBorderLight")));
			border.BorderThickness = new Thickness(flag ? 1.5 : 1.0);
			border.Background = (flag ? ((Brush)FindResource("BrushHover")) : ((Brush)FindResource("BrushCard")));
			if (!(border.Child is Grid grid))
			{
				continue;
			}
			foreach (UIElement child2 in grid.Children)
			{
				if (child2 is CheckBox checkBox)
				{
					checkBox.IsChecked = flag;
					break;
				}
			}
		}
		if (SelectAllDevicesCheckBox != null)
		{
			SelectAllDevicesCheckBox.IsChecked = a.Count > 0 && SelectedPhones.Count == a.Count;
		}
		if (DeviceCountText != null)
		{
			DeviceCountText.Text = ((a.Count == 0) ? "0 phone" : $"Đã chọn {SelectedPhones.Count}/{a.Count} phone");
		}
	}

	private void m_2141(object P_0, RoutedEventArgs P_1)
	{
		bool valueOrDefault = SelectAllDevicesCheckBox.IsChecked == true;
		SelectedPhones.Clear();
		if (valueOrDefault)
		{
			SelectedPhones.AddRange(a);
		}
		m_2140();
	}

	private void m_2142(object P_0, MouseButtonEventArgs P_1)
	{
		SelectAllDevicesCheckBox.IsChecked = SelectAllDevicesCheckBox.IsChecked != true;
		m_2141(P_0, P_1);
	}

	private async void m_2143(object P_0, RoutedEventArgs P_1)
	{
		await m_2136(true);
	}

	private void m_2144(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		if (SelectedPlatform == "Phone" && a.Count > 0 && SelectedPhones.Count == 0)
		{
			CustomMessageBox.Show(this, "Vui lòng chọn ít nhất 1 thiết bị Phone để đăng nhập.", "Chưa chọn Phone", NotifyType.Warning);
			return;
		}
		if (RememberChoiceCheckBox.IsChecked == true)
		{
			try
			{
				CreateRunThreadsSettings createRunThreadsSettings = CreateRunThreadsSettings.Load("Reg Nick Facebook");
				createRunThreadsSettings.Platform = SelectedPlatform;
				if (SelectedPlatform == "Phone")
				{
					createRunThreadsSettings.AndroidPackageType = SelectedPackageType;
					createRunThreadsSettings.PhoneNames = SelectedPhones.ToList();
				}
				createRunThreadsSettings.Save("Reg Nick Facebook");
			}
			catch
			{
			}
		}
		DialogResult = true;
		Close();
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	[CompilerGenerated]
	private bool m_2146(string P_0)
	{
		return !a.Contains(P_0);
	}

	[CompilerGenerated]
	private bool m_2147(string P_0)
	{
		return B.Contains(P_0);
	}
}
