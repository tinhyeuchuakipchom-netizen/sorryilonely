using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using A;
using Google.Apis.Sheets.v4;
using Microsoft.Win32;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Data;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class PlatformAccountPage : UserControl, IComponentConnector, IStyleConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_1756
	{
		public static readonly m_1756 A = new m_1756();

		public static Func<PlatformAccountRow, bool> m_1804;

		public static Func<PlatformAccountRow, bool> a;

		public static Func<PlatformAccountRow, bool> B;

		public static Func<PlatformAccountRow, bool> b;

		public static Func<PlatformAccountRow, bool> C;

		public static Func<PlatformAccountRow, bool> c;

		public static Func<PlatformAccountRow, bool> D;

		public static Func<NickFolder, bool> m_1805;

		public static Func<PlatformAccountRow, bool> d;

		public static Func<PlatformAccountRow, bool> E;

		public static Func<PlatformAccountRow, bool> e;

		public static Func<PlatformAccountRow, int> m_1806;

		public static Func<NickFolder, bool> m_1807;

		public static Func<string, string> m_1808;

		public static Func<string, bool> m_1809;

		public static Func<NickFolder, bool> m_1810;

		public static Func<NickFolder, bool> m_1811;

		public static Func<string, string> m_1812;

		public static Func<string, bool> m_1813;

		public static Func<string, string> m_1814;

		public static Func<string, bool> m_1815;

		public static Func<NickFolder, bool> m_1816;

		public static Func<PlatformAccountRow, bool> F;

		public static Func<PlatformAccountRow, string> m_1817;

		public static Func<IGrouping<string, PlatformAccountRow>, bool> m_1818;

		public static Func<IGrouping<string, PlatformAccountRow>, string> m_1819;

		public static Func<(string Header, Func<PlatformAccountRow, string> Getter), string> m_1820;

		public static Func<PlatformAccountRow, string> m_1821;

		public static Func<PlatformAccountRow, bool> f;

		public static Func<PlatformAccountRow, Task<(string Uid, string Code)>> m_1822;

		public static Func<(string Uid, string Code), bool> m_1823;

		public static Func<(string Uid, string Code), bool> m_1824;

		public static Func<(string Uid, string Code), string> m_1825;

		public static Func<(string Uid, string Code), string> m_1826;

		public static Func<PlatformAccountRow, bool> G;

		public static Func<PlatformAccountRow, string> m_1827;

		public static Func<string, bool> m_1828;

		public static Func<PlatformAccountRow, bool> g;

		public static Func<PlatformAccountRow, bool> H;

		public static Func<PlatformAccountRow, bool> h;

		public static Func<DataGridColumn, int> m_1829;

		public static Func<DataGridColumn, string> m_1830;

		public static Func<string, bool> m_1831;

		public static Func<DataGridColumn, bool> m_1832;

		public static Func<DataGridColumn, string> m_1833;

		public static Func<string, bool> m_1834;

		public static Func<NickFolder, bool> m_1835;

		public static Func<NickFolder, (int Id, string Name)> m_1836;

		public static Func<(int Id, string Name), int> m_1837;

		public static Func<NickFolder, bool> m_1838;

		internal bool m_1839(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.BrowserProfileId);
		}

		internal bool m_1840(PlatformAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1841(PlatformAccountRow P_0)
		{
			return P_0.FolderId != -2;
		}

		internal bool m_1842(PlatformAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1843(PlatformAccountRow P_0)
		{
			return string.Equals(P_0.TinhTrang, "LIVE", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_1844(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.Proxy);
		}

		internal bool m_1845(PlatformAccountRow P_0)
		{
			return P_0.ScriptId != 0;
		}

		internal bool m_1846(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_1847(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.PhoneName);
		}

		internal bool m_1848(PlatformAccountRow P_0)
		{
			return P_0.TinhTrang == "LIVE";
		}

		internal bool m_1849(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.ProfileChrome);
		}

		internal int m_1850(PlatformAccountRow P_0)
		{
			return P_0.Index;
		}

		internal bool m_1851(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal string m_1852(string P_0)
		{
			return P_0.Trim(new char[2] { '\r', ' ' });
		}

		internal bool m_1853(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_1854(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_1855(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal string m_1856(string P_0)
		{
			return P_0.Trim(new char[2] { '\r', ' ' });
		}

		internal bool m_1857(string P_0)
		{
			return P_0.Length > 0;
		}

		internal string m_1858(string P_0)
		{
			return P_0.Trim(new char[2] { '\r', ' ' });
		}

		internal bool m_1859(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_1860(NickFolder P_0)
		{
			if (P_0.Id != -2)
			{
				return P_0.Id != -1;
			}
			return false;
		}

		internal bool m_1861(PlatformAccountRow P_0)
		{
			if (P_0.FolderId != -2)
			{
				return !string.IsNullOrWhiteSpace(P_0.Uid);
			}
			return false;
		}

		internal string m_1862(PlatformAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal bool m_1863(IGrouping<string, PlatformAccountRow> P_0)
		{
			return P_0.Count() > 1;
		}

		internal string m_1864(IGrouping<string, PlatformAccountRow> P_0)
		{
			return P_0.Key;
		}

		internal string m_1865((string Header, Func<PlatformAccountRow, string> Getter) f)
		{
			return f.Header;
		}

		internal string m_1866(PlatformAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal bool m_1867(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.TwoFA);
		}

		internal Task<(string Uid, string Code)> m_1868(PlatformAccountRow P_0)
		{
			return Task.Run(() => (Uid: P_0.Uid, Code: PlaywrightHumanHelpers.Get2fa(P_0.TwoFA)));
		}

		internal bool m_1869((string Uid, string Code) r)
		{
			return !string.IsNullOrEmpty(r.Code);
		}

		internal bool m_1870((string Uid, string Code) r)
		{
			return string.IsNullOrEmpty(r.Code);
		}

		internal string m_1871((string Uid, string Code) r)
		{
			return r.Uid + ": " + r.Code;
		}

		internal string m_1872((string Uid, string Code) f)
		{
			return f.Uid;
		}

		internal bool I(PlatformAccountRow P_0)
		{
			return string.IsNullOrEmpty(P_0.Platform);
		}

		internal string i(PlatformAccountRow P_0)
		{
			return P_0.Platform;
		}

		internal bool m_1873(string P_0)
		{
			return !string.IsNullOrEmpty(P_0);
		}

		internal bool J(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.PhoneName);
		}

		internal bool j(PlatformAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.PhoneName);
		}

		internal bool K(PlatformAccountRow P_0)
		{
			return string.Equals(P_0.Platform, "Chrome", StringComparison.OrdinalIgnoreCase);
		}

		internal int m_1874(DataGridColumn P_0)
		{
			return P_0.DisplayIndex;
		}

		internal string m_1875(DataGridColumn P_0)
		{
			return P_0.Header?.ToString() ?? "";
		}

		internal bool m_1876(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_1877(DataGridColumn P_0)
		{
			return P_0.Visibility != Visibility.Visible;
		}

		internal string m_1878(DataGridColumn P_0)
		{
			return P_0.Header?.ToString() ?? "";
		}

		internal bool m_1879(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_1880(NickFolder P_0)
		{
			return P_0 != null;
		}

		internal (int Id, string Name) m_1881(NickFolder P_0)
		{
			return (Id: P_0.Id, Name: P_0.Name);
		}

		internal int m_1882((int Id, string Name) t)
		{
			return t.Id;
		}

		internal bool m_1883(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal string k(PlatformAccountRow P_0)
		{
			return P_0.PhoneName;
		}

		internal string L(PlatformAccountRow P_0)
		{
			return P_0.ScriptName;
		}

		internal string l(PlatformAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal string M(PlatformAccountRow P_0)
		{
			return P_0.Pass;
		}

		internal string m(PlatformAccountRow P_0)
		{
			return P_0.TwoFA;
		}

		internal string N(PlatformAccountRow P_0)
		{
			return P_0.Token;
		}

		internal string n(PlatformAccountRow P_0)
		{
			return P_0.Cookie;
		}

		internal string O(PlatformAccountRow P_0)
		{
			return P_0.Mail;
		}

		internal string o(PlatformAccountRow P_0)
		{
			return P_0.PassMail;
		}

		internal string P(PlatformAccountRow P_0)
		{
			return P_0.MailKhoiPhuc;
		}

		internal string p(PlatformAccountRow P_0)
		{
			return P_0.ProfileChrome;
		}

		internal string Q(PlatformAccountRow P_0)
		{
			return P_0.TenProfile;
		}

		internal string q(PlatformAccountRow P_0)
		{
			return P_0.Proxy;
		}

		internal string R(PlatformAccountRow P_0)
		{
			return P_0.GhiChu;
		}

		internal string r(PlatformAccountRow P_0)
		{
			return P_0.TrangThai;
		}

		internal void m_1884(PlatformAccountRow P_0, string P_1)
		{
			P_0.Pass = P_1;
		}

		internal void m_1885(PlatformAccountRow P_0, string P_1)
		{
			P_0.TwoFA = P_1;
		}

		internal void m_1886(PlatformAccountRow P_0, string P_1)
		{
			P_0.Token = P_1;
		}

		internal void m_1887(PlatformAccountRow P_0, string P_1)
		{
			P_0.Cookie = P_1;
		}

		internal void m_1888(PlatformAccountRow P_0, string P_1)
		{
			P_0.Mail = P_1;
		}

		internal void m_1889(PlatformAccountRow P_0, string P_1)
		{
			P_0.PassMail = P_1;
		}

		internal void m_1890(PlatformAccountRow P_0, string P_1)
		{
			P_0.MailKhoiPhuc = P_1;
		}

		internal void m_1891(PlatformAccountRow P_0, string P_1)
		{
			P_0.Proxy = P_1;
		}

		internal void m_1892(PlatformAccountRow P_0, string P_1)
		{
			P_0.GhiChu = P_1;
		}

		internal void m_1893(PlatformAccountRow P_0, string P_1)
		{
			P_0.TrangThai = P_1;
		}

		internal void m_1894(PlatformAccountRow P_0, string P_1)
		{
			P_0.PhoneName = P_1;
		}
	}

	[CompilerGenerated]
	private sealed class m_1757
	{
		public PlatformAccountPage A;

		public List<PlatformAccountRow> m_1895;

		internal async Task? m_1896()
		{
			try
			{
				string A = (await AdbController.ListDevicesAsync()).FirstOrDefault() ?? "";
				if (string.IsNullOrEmpty(A))
				{
					return;
				}
				((DispatcherObject)this.A).Dispatcher.Invoke((Action)(() =>
				{
					foreach (PlatformAccountRow item in m_1895)
					{
						if (string.IsNullOrWhiteSpace(item.PhoneName))
						{
							item.PhoneName = A;
						}
					}
				}));
			}
			catch
			{
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_1758
	{
		public string A;

		public m_1757 m_1902;

		internal void m_1903()
		{
			foreach (PlatformAccountRow item in m_1902.m_1895)
			{
				if (string.IsNullOrWhiteSpace(item.PhoneName))
				{
					item.PhoneName = A;
				}
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_1759
	{
		public PlatformAccountPage A;

		public ScriptItem m_1904;

		internal void m_1905(object P_0, RoutedEventArgs P_1)
		{
			A.m_1733(m_1904);
		}
	}

	[CompilerGenerated]
	private sealed class m_1760
	{
		public PlatformAccountPage A;

		public CancellationToken m_1906;

		public List<PlatformAccountRow> m_1907;

		internal bool m_1908(PlatformAccountRow P_0)
		{
			if (!string.IsNullOrEmpty(P_0.Platform) && P_0.ScriptId > 0)
			{
				return A.m_1705.FirstOrDefault((ScriptItem scriptItem) => scriptItem.Id == P_0.ScriptId)?.Platform == P_0.Platform;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_1761
	{
		public PlatformAccountRow A;

		internal bool m_1909(ScriptItem P_0)
		{
			return P_0.Id == A.ScriptId;
		}
	}

	[CompilerGenerated]
	private sealed class m_1762
	{
		public string A;

		public m_1767 m_1910;

		internal string m_1911()
		{
			return m_1910.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1763
	{
		public string A;

		public m_1767 m_1912;

		internal string m_1913()
		{
			return m_1912.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1764
	{
		public AiVisionStepLog A;

		public m_1767 m_1914;

		internal string m_1915()
		{
			return m_1914.A.TrangThai = A.FlowStepLabel + A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_1765
	{
		public AiVisionStepLog A;

		public m_1767 m_1916;

		internal string m_1917()
		{
			return m_1916.A.TrangThai = A.FlowStepLabel + A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_1766
	{
		public SemaphoreSlim A;

		public int m_1918;

		public string m_1919;

		public m_1760 m_1920;

		internal async Task m_1921(PlatformAccountRow P_0)
		{
			try
			{
				await A.WaitAsync(m_1920.m_1906);
				try
				{
					if (m_1920.m_1906.IsCancellationRequested)
					{
						P_0.TrangThai = "Đã dừng.";
						return;
					}
					ScriptItem scriptItem = m_1920.A.m_1705.FirstOrDefault((ScriptItem scriptItem2) => scriptItem2.Id == P_0.ScriptId && scriptItem2.Platform == P_0.Platform);
					if (scriptItem == null)
					{
						P_0.TrangThai = "Chưa gắn kịch bản " + P_0.Platform + " cho nick này.";
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Đăng nhập")
					{
						LoginResult loginResult = await TikTokPhoneLoginService.LoginAccountAsync(P_0, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult.TrangThai);
						P_0.TinhTrang = loginResult.TinhTrang;
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Tương tác")
					{
						if (string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							P_0.TrangThai = "Nick chưa được gắn Phone.";
							P_0.TinhTrang = "ERROR";
							return;
						}
						TikTokInteractionSettings settings = TikTokInteractionSettings.FromJson(P_0.TikTokInteractionSettingsJson);
						LoginResult loginResult2 = await TikTokInteractionRunner.RunAsync(P_0.PhoneName, settings, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult2.TrangThai);
						P_0.TinhTrang = loginResult2.TinhTrang;
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Thả tim")
					{
						if (string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							P_0.TrangThai = "Nick chưa được gắn Phone.";
							P_0.TinhTrang = "ERROR";
							return;
						}
						TikTokLikeSettings settings2 = TikTokLikeSettings.FromJson(P_0.TikTokInteractionSettingsJson);
						LoginResult loginResult3 = await TikTokInteractionRunner.RunLikeOnlyAsync(P_0.PhoneName, settings2, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult3.TrangThai);
						P_0.TinhTrang = loginResult3.TinhTrang;
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Bình luận")
					{
						if (string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							P_0.TrangThai = "Nick chưa được gắn Phone.";
							P_0.TinhTrang = "ERROR";
							return;
						}
						TikTokCommentSettings settings3 = TikTokCommentSettings.FromJson(P_0.TikTokInteractionSettingsJson);
						LoginResult loginResult4 = await TikTokInteractionRunner.RunCommentOnlyAsync(P_0.PhoneName, settings3, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult4.TrangThai);
						P_0.TinhTrang = loginResult4.TinhTrang;
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Follow (Sub)")
					{
						if (string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							P_0.TrangThai = "Nick chưa được gắn Phone.";
							P_0.TinhTrang = "ERROR";
							return;
						}
						TikTokFollowSettings settings4 = TikTokFollowSettings.FromJson(P_0.TikTokInteractionSettingsJson);
						LoginResult loginResult5 = await TikTokInteractionRunner.RunFollowOnlyAsync(P_0.PhoneName, settings4, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult5.TrangThai);
						P_0.TinhTrang = loginResult5.TinhTrang;
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Chia sẻ")
					{
						if (string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							P_0.TrangThai = "Nick chưa được gắn Phone.";
							P_0.TinhTrang = "ERROR";
							return;
						}
						TikTokShareSettings settings5 = TikTokShareSettings.FromJson(P_0.TikTokInteractionSettingsJson);
						LoginResult loginResult6 = await TikTokInteractionRunner.RunShareOnlyAsync(P_0.PhoneName, settings5, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult6.TrangThai);
						P_0.TinhTrang = loginResult6.TinhTrang;
						return;
					}
					if (string.Equals(m_1920.A.PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Cập nhật Avatar")
					{
						if (string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							P_0.TrangThai = "Nick chưa được gắn Phone.";
							P_0.TinhTrang = "ERROR";
							return;
						}
						TikTokAvatarSettings settings6 = TikTokAvatarSettings.FromJson(P_0.TikTokInteractionSettingsJson);
						LoginResult loginResult7 = await TikTokInteractionRunner.RunUpdateAvatarAsync(P_0.PhoneName, settings6, (string text) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1920.m_1906);
						m_1736(P_0, loginResult7.TrangThai);
						P_0.TinhTrang = loginResult7.TinhTrang;
						return;
					}
					AiVisionFlowDocument aiVisionFlowDocument = AiVisionFlowStore.Deserialize(scriptItem.AiVisionFlowJson);
					List<AiVisionFlowStep> steps = aiVisionFlowDocument.Steps;
					if (steps.Count == 0)
					{
						P_0.TrangThai = "Kịch bản \"" + scriptItem.Name + "\" chưa có bước nào.";
						return;
					}
					Dictionary<string, string> variables = AiVisionVariables.BuildMap(P_0);
					await AiVisionVariables.ResolveVerifyVariablesAsync(variables, steps, m_1920.m_1906);
					if (P_0.Platform == "Phone")
					{
						if (!string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							await PhoneInitialSetupService.EnsureInitialSetupAsync(P_0.PhoneName, m_1920.A.PlatformKey ?? "TikTok", (string text) =>
							{
								((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
							}, m_1920.m_1906);
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = "Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)..."));
							await AdbController.EnsureEnglishLanguageAsync(P_0.PhoneName, m_1920.m_1906);
						}
						AiVisionRunResult aiVisionRunResult = await PhoneAiVisionRunner.RunFlowAsync(DeviceControllerFactory.Resolve(m_1920.A.m_1704, P_0.PhoneName), steps, variables, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
						}, m_1920.m_1906);
						m_1736(P_0, aiVisionRunResult.Message);
						if (!aiVisionRunResult.Success)
						{
							P_0.TinhTrang = "ERROR";
						}
						return;
					}
					AiVisionRunResult aiVisionRunResult2 = await ChromeAiVisionRunner.RunFlowForNickAsync(P_0, steps, variables, (AiVisionStepLog aiVisionStepLog) =>
					{
						((DispatcherObject)m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
					}, m_1920.m_1906);
					m_1736(P_0, aiVisionRunResult2.Message);
					if (!string.IsNullOrEmpty(aiVisionRunResult2.TinhTrang))
					{
						P_0.TinhTrang = aiVisionRunResult2.TinhTrang;
					}
					else if (!aiVisionRunResult2.Success)
					{
						P_0.TinhTrang = "ERROR";
					}
				}
				finally
				{
					A.Release();
				}
			}
			catch (OperationCanceledException)
			{
				P_0.TrangThai = "Đã dừng.";
			}
			catch (Exception ex2)
			{
				P_0.TinhTrang = "ERROR";
				m_1736(P_0, "Lỗi kịch bản: " + ex2.Message);
			}
			finally
			{
				Interlocked.Increment(ref m_1918);
				m_1920.A.RunScriptButtonText.Text = $"Đang chạy kịch bản... ({m_1918}/{m_1920.m_1907.Count}){m_1919}";
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_1767
	{
		public PlatformAccountRow A;

		public m_1766 m_1933;

		internal bool m_1934(ScriptItem P_0)
		{
			if (P_0.Id == A.ScriptId)
			{
				return P_0.Platform == A.Platform;
			}
			return false;
		}

		internal void m_1935(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void a(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void B(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void b(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void C(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void c(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void D(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void d(string P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal string m_1936()
		{
			return A.TrangThai = "Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...";
		}

		internal void m_1937(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.FlowStepLabel + P_0.ActionSummary));
		}

		internal void a(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1933.m_1920.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.FlowStepLabel + P_0.ActionSummary));
		}
	}

	[CompilerGenerated]
	private sealed class m_1768
	{
		public string A;

		public m_1767 m_1938;

		internal string m_1939()
		{
			return m_1938.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1769
	{
		public string A;

		public m_1767 m_1940;

		internal string m_1941()
		{
			return m_1940.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1770
	{
		public string A;

		public m_1767 m_1942;

		internal string m_1943()
		{
			return m_1942.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1771
	{
		public string A;

		public m_1767 m_1944;

		internal string m_1945()
		{
			return m_1944.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1772
	{
		public string A;

		public m_1767 m_1946;

		internal string m_1947()
		{
			return m_1946.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1773
	{
		public string A;

		public m_1767 m_1948;

		internal string m_1949()
		{
			return m_1948.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1774
	{
		public string A;

		internal bool m_1950(DataGridColumn P_0)
		{
			return (P_0.Header?.ToString() ?? "") == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1775
	{
		public DataGridColumn A;

		public PlatformAccountPage m_1951;

		internal void m_1952(object P_0, RoutedEventArgs P_1)
		{
			A.Visibility = Visibility.Visible;
			m_1951.I();
		}

		internal void a(object P_0, RoutedEventArgs P_1)
		{
			A.Visibility = Visibility.Collapsed;
			m_1951.I();
		}
	}

	[CompilerGenerated]
	private sealed class m_1776
	{
		public GoogleSheetsSyncSettings A;

		public Func<SheetsService, GoogleSheetsSyncSettings, Task> m_1953;

		public PlatformAccountPage m_1954;

		internal async Task? m_1955()
		{
			_ = 1;
			try
			{
				using SheetsService arg = await GoogleSheetsSyncService.AuthorizeAsync(this.A, CancellationToken.None);
				await m_1953(arg, this.A);
			}
			catch (Exception ex)
			{
				Exception ex2 = ex;
				Exception A = ex2;
				((DispatcherObject)m_1954).Dispatcher.Invoke((Action)(() =>
				{
					CustomMessageBox.Show(m_1954.A, "Đồng bộ Google Sheets thất bại: " + A.Message, "Đồng bộ Google Sheets", NotifyType.Warning);
				}));
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_1777
	{
		public Exception A;

		public m_1776 m_1962;

		internal void m_1963()
		{
			CustomMessageBox.Show(m_1962.m_1954.A, "Đồng bộ Google Sheets thất bại: " + A.Message, "Đồng bộ Google Sheets", NotifyType.Warning);
		}
	}

	[CompilerGenerated]
	private sealed class m_1778
	{
		public int A;

		public string m_1964;

		public List<PlatformAccountRow> m_1965;

		internal bool m_1966(PlatformAccountRow P_0)
		{
			return P_0.FolderId == A;
		}

		internal Task m_1967(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			return GoogleSheetsSyncService.SyncFolderAsync(P_0, P_1.SpreadsheetId, m_1964, GoogleSheetsSyncService.BuildRows(m_1965), CancellationToken.None);
		}
	}

	[CompilerGenerated]
	private sealed class m_1779
	{
		public string A;

		internal Task m_1968(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			return GoogleSheetsSyncService.DeleteFolderSheetAsync(P_0, P_1.SpreadsheetId, A, CancellationToken.None);
		}
	}

	[CompilerGenerated]
	private sealed class m_1780
	{
		public string A;

		public string a;

		internal Task m_1969(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			return GoogleSheetsSyncService.RenameFolderSheetAsync(P_0, P_1.SpreadsheetId, A, a, CancellationToken.None);
		}
	}

	[CompilerGenerated]
	private sealed class m_1781
	{
		public PlatformAccountPage A;

		public List<(int Id, string Name)> m_1970;

		public Dictionary<int, List<PlatformAccountRow>> m_1971;

		internal NickFolder m_1972(int P_0)
		{
			return A.Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == P_0);
		}

		internal List<PlatformAccountRow> m_1973((int Id, string Name) t)
		{
			return A.Accounts.Where((PlatformAccountRow P_0) => P_0.FolderId == t.Id).ToList();
		}

		internal async Task m_1974(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			foreach (var (key, folderName) in m_1970)
			{
				await GoogleSheetsSyncService.SyncFolderAsync(P_0, P_1.SpreadsheetId, folderName, GoogleSheetsSyncService.BuildRows(m_1971[key]), CancellationToken.None);
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_1782
	{
		public int A;

		internal bool m_1982(NickFolder P_0)
		{
			return P_0.Id == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1783
	{
		public (int Id, string Name) A;

		internal bool m_1983(PlatformAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}
	}

	[CompilerGenerated]
	private sealed class m_1784
	{
		public KeyValuePair<string, List<PlatformAccountRow>> A;

		internal bool m_1984(NickFolder P_0)
		{
			if (P_0.Id > 0)
			{
				return P_0.Name == A.Key;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_1785
	{
		public PlatformAccountRow A;

		internal bool m_1985(ScriptItem P_0)
		{
			return P_0.Name == A.ScriptName;
		}
	}

	[CompilerGenerated]
	private sealed class m_1786
	{
		public bool A;

		public UIElement m_1986;

		public Popup m_1987;

		public PlatformAccountPage m_1988;

		internal void m_1989()
		{
			if (A && m_1986 != null)
			{
				m_1987.Placement = PlacementMode.Bottom;
				m_1987.PlacementTarget = m_1986;
			}
			else
			{
				m_1987.Placement = PlacementMode.Center;
				m_1987.PlacementTarget = (UIElement)(((object)Window.GetWindow((DependencyObject)(object)m_1988)) ?? ((object)m_1988));
			}
			m_1987.IsOpen = true;
		}
	}

	[CompilerGenerated]
	private sealed class m_1787
	{
		public NickFolder A;

		internal bool m_1990(PlatformAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}
	}

	[CompilerGenerated]
	private sealed class m_1788
	{
		public NickFolder A;

		public Func<PlatformAccountRow, bool> m_1991;

		internal bool m_1992(PlatformAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}

		internal bool a(PlatformAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}
	}

	[CompilerGenerated]
	private sealed class m_1789
	{
		public PlatformAccountPage A;

		public SemaphoreSlim m_1993;

		public CancellationToken m_1994;

		public int m_1995;

		internal async Task m_1996(PlatformAccountRow P_0)
		{
			try
			{
				await m_1993.WaitAsync(m_1994);
				try
				{
					if (m_1994.IsCancellationRequested)
					{
						P_0.TrangThai = "Đã dừng.";
						return;
					}
					LoginResult A = await TikTokPhoneLoginService.LoginAccountAsync(P_0, (string text) =>
					{
						((DispatcherObject)this.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
					}, m_1994);
					((DispatcherObject)this.A).Dispatcher.Invoke((Action)(() =>
					{
						P_0.TrangThai = A.TrangThai;
						P_0.TinhTrang = A.TinhTrang;
					}));
				}
				finally
				{
					m_1993.Release();
				}
			}
			catch (OperationCanceledException)
			{
				((DispatcherObject)this.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = "Đã dừng."));
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				Exception A2 = ex3;
				((DispatcherObject)this.A).Dispatcher.Invoke((Action)(() =>
				{
					P_0.TinhTrang = "ERROR";
					P_0.TrangThai = "Lỗi: " + A2.Message;
				}));
			}
			finally
			{
				Interlocked.Increment(ref m_1995);
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_1790
	{
		public PlatformAccountRow A;

		public m_1789 m_2005;

		internal void m_2006(string P_0)
		{
			((DispatcherObject)m_2005.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal string m_2007()
		{
			return A.TrangThai = "Đã dừng.";
		}
	}

	[CompilerGenerated]
	private sealed class m_1791
	{
		public LoginResult A;

		public m_1790 m_2008;

		internal void m_2009()
		{
			m_2008.A.TrangThai = A.TrangThai;
			m_2008.A.TinhTrang = A.TinhTrang;
		}
	}

	[CompilerGenerated]
	private sealed class m_1792
	{
		public string A;

		public m_1790 m_2010;

		internal string m_2011()
		{
			return m_2010.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1793
	{
		public Exception A;

		public m_1790 m_2012;

		internal void m_2013()
		{
			m_2012.A.TinhTrang = "ERROR";
			m_2012.A.TrangThai = "Lỗi: " + A.Message;
		}
	}

	[CompilerGenerated]
	private sealed class m_1794
	{
		public PlatformAccountRow A;

		internal bool m_2014(NickFolder P_0)
		{
			return P_0.Id == A.FolderId;
		}
	}

	[CompilerGenerated]
	private sealed class m_1795
	{
		public PlatformAccountExportItem A;

		internal bool m_2015(NickFolder P_0)
		{
			if (P_0.Id > 0)
			{
				return P_0.Name == A.FolderName;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_1796
	{
		public List<PlatformAccountRow> A;

		public PlatformAccountPage m_2016;
	}

	[CompilerGenerated]
	private sealed class m_1797
	{
		public NickFolder A;

		public m_1796 m_2017;

		internal void m_2018(object P_0, RoutedEventArgs P_1)
		{
			foreach (PlatformAccountRow item in m_2017.A)
			{
				item.FolderId = A.Id;
				item.IsSelected = false;
			}
			ICollectionView? val = m_2017.m_2016.m_1697;
			if (val != null)
			{
				val.Refresh();
			}
			m_2017.m_2016.m_1725();
			m_2017.m_2016.m_1726();
			m_2017.m_2016.MoveFolderPopup.IsOpen = false;
		}
	}

	[CompilerGenerated]
	private sealed class m_1798
	{
		public PlatformAccountRow A;

		public PlatformAccountPage m_2019;

		internal string m_2020(string P_0)
		{
			return m_1708.First(((string Header, Func<PlatformAccountRow, string> Getter) tuple) => tuple.Header == P_0).Getter(A);
		}

		internal bool m_2021((string Header, Func<PlatformAccountRow, string> Getter) f)
		{
			return m_2019.B.Contains(f.Header);
		}
	}

	[CompilerGenerated]
	private sealed class m_1799
	{
		public string A;

		internal bool m_2022((string Header, Func<PlatformAccountRow, string> Getter) f)
		{
			return f.Header == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1800
	{
		public PlatformAccountRow A;

		internal string m_2023((string Header, Func<PlatformAccountRow, string> Getter) f)
		{
			return f.Getter(A);
		}
	}

	[CompilerGenerated]
	private sealed class m_1801
	{
		public string A;

		internal bool m_2024(PlatformAccountRow P_0)
		{
			return P_0.Uid == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_1802
	{
		public PlatformAccountRow A;

		internal (string Uid, string Code) m_2025()
		{
			return (Uid: A.Uid, Code: PlaywrightHumanHelpers.Get2fa(A.TwoFA));
		}
	}

	[CompilerGenerated]
	private sealed class m_1803
	{
		public List<PlatformAccountRow> A;

		public PlatformAccountPage m_2026;
	}

	[CompilerGenerated]
	private sealed class Y
	{
		public ProfileRow A;

		public m_1803 m_2027;

		internal void m_2028(object P_0, RoutedEventArgs P_1)
		{
			foreach (PlatformAccountRow item in m_2027.A)
			{
				item.PhoneName = A.Name;
				item.ProfileChrome = "";
			}
			m_2027.m_2026.AttachPhonePopup.IsOpen = false;
			CustomMessageBox.Show(m_2027.m_2026.A, $"Đã gắn máy \"{A.Name}\" cho {m_2027.A.Count} nick.", "Gắn Phone");
		}
	}

	[CompilerGenerated]
	private readonly ObservableCollection<NickFolder> m_1693 = new ObservableCollection<NickFolder>();

	[CompilerGenerated]
	private readonly ObservableCollection<PlatformAccountRow> m_1694 = new ObservableCollection<PlatformAccountRow>();

	[CompilerGenerated]
	private readonly string m_1695;

	[CompilerGenerated]
	private readonly string a;

	private readonly PlatformAccountDatabase m_1696;

	private ICollectionView? m_1697;

	private int m_1698 = -1;

	private DispatcherTimer? m_1699;

	private bool m_1700;

	private HashSet<string> m_1701 = new HashSet<string>();

	private HashSet<string>? m_1702;

	private CancellationTokenSource? m_1703;

	private ObservableCollection<ProfileRow> m_1704 = new ObservableCollection<ProfileRow>();

	private ObservableCollection<ScriptItem> m_1705 = new ObservableCollection<ScriptItem>();

	private PlatformAccountRow? m_1706;

	private DispatcherTimer? m_1707;

	private static readonly (string Header, Func<PlatformAccountRow, string> Getter)[] m_1708 = new (string, Func<PlatformAccountRow, string>)[15]
	{
		("PHONE", (PlatformAccountRow P_0) => P_0.PhoneName),
		("KỊCH BẢN", (PlatformAccountRow P_0) => P_0.ScriptName),
		("UID", (PlatformAccountRow P_0) => P_0.Uid),
		("MẬT KHẨU", (PlatformAccountRow P_0) => P_0.Pass),
		("2FA", (PlatformAccountRow P_0) => P_0.TwoFA),
		("TOKEN", (PlatformAccountRow P_0) => P_0.Token),
		("COOKIE", (PlatformAccountRow P_0) => P_0.Cookie),
		("MAIL", (PlatformAccountRow P_0) => P_0.Mail),
		("MẬT KHẨU MAIL", (PlatformAccountRow P_0) => P_0.PassMail),
		("MAIL KHÔI PHỤC", (PlatformAccountRow P_0) => P_0.MailKhoiPhuc),
		("PROFILE CHROME", (PlatformAccountRow P_0) => P_0.ProfileChrome),
		("TÊN PROFILE", (PlatformAccountRow P_0) => P_0.TenProfile),
		("PROXY", (PlatformAccountRow P_0) => P_0.Proxy),
		("GHI CHÚ", (PlatformAccountRow P_0) => P_0.GhiChu),
		("TRẠNG THÁI", (PlatformAccountRow P_0) => P_0.TrangThai)
	};

	private HashSet<string> B = new HashSet<string> { "UID", "MẬT KHẨU" };

	private static readonly Dictionary<string, Action<PlatformAccountRow, string>> m_1709 = new Dictionary<string, Action<PlatformAccountRow, string>>
	{
		["MẬT KHẨU"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.Pass = P_1;
		},
		["2FA"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.TwoFA = P_1;
		},
		["TOKEN"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.Token = P_1;
		},
		["COOKIE"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.Cookie = P_1;
		},
		["MAIL"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.Mail = P_1;
		},
		["MẬT KHẨU MAIL"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.PassMail = P_1;
		},
		["MAIL KHÔI PHỤC"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.MailKhoiPhuc = P_1;
		},
		["PROXY"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.Proxy = P_1;
		},
		["GHI CHÚ"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.GhiChu = P_1;
		},
		["TRẠNG THÁI"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.TrangThai = P_1;
		},
		["PHONE"] = (PlatformAccountRow P_0, string P_1) =>
		{
			P_0.PhoneName = P_1;
		}
	};

	private static readonly HashSet<string> b = new HashSet<string> { "STT", "CHỌN", "NỀN TẢNG", "PHONE", "KỊCH BẢN", "UID / EMAIL", "MẬT KHẨU", "TRẠNG THÁI", "TÌNH TRẠNG" };

	private readonly HashSet<int> m_1710 = new HashSet<int>();

	private DispatcherTimer? m_1711;

	private bool m_1712;

	public ObservableCollection<NickFolder> Folders
	{
		[CompilerGenerated]
		get
		{
			return m_1693;
		}
	}

	public ObservableCollection<PlatformAccountRow> Accounts
	{
		[CompilerGenerated]
		get
		{
			return m_1694;
		}
	}

	public string PlatformKey
	{
		[CompilerGenerated]
		get
		{
			return m_1695;
		}
	}

	public string DisplayTitle
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
	}

	private Window? A => Window.GetWindow((DependencyObject)(object)this);

	public void SetSharedCollections(ObservableCollection<ProfileRow> profiles, ObservableCollection<ScriptItem> scripts)
	{
		m_1704 = profiles;
		m_1705 = scripts;
		m_1705.CollectionChanged += delegate
		{
			PopulateScriptToolbar();
		};
		PopulateScriptToolbar();
	}

	public PlatformAccountPage(string platformKey, string displayTitle)
	{
		InitializeComponent();
		DataContext = this;
		m_1695 = platformKey;
		a = displayTitle;
		m_1696 = new PlatformAccountDatabase(platformKey);
		PageTitleText.Text = "Nuôi Nick " + displayTitle;
		LoginButton.ToolTip = "Đăng nhập " + displayTitle + " - tính năng đang phát triển";
		f();
		Loaded += delegate
		{
			LoadFromDatabase();
			H();
			i();
		};
	}

	private void m_1713(object P_0, ContextMenuEventArgs P_1)
	{
		object originalSource = P_1.OriginalSource;
		m_1706 = m_1720<DataGridRow>((DependencyObject?)((originalSource is DependencyObject) ? originalSource : null))?.Item as PlatformAccountRow;
		bool flag = !string.IsNullOrWhiteSpace(m_1706?.TinhTrang);
		SelectSameTinhTrangMenuItem.Header = (flag ? ("Chọn nick cùng TÌNH TRẠNG \"" + m_1714(m_1706.TinhTrang) + "\"") : "Chọn nick cùng TÌNH TRẠNG");
		SelectSameTinhTrangMenuItem.IsEnabled = flag;
		bool flag2 = !string.IsNullOrWhiteSpace(m_1706?.TrangThai);
		SelectSameTrangThaiMenuItem.Header = (flag2 ? ("Chọn nick cùng TRẠNG THÁI \"" + m_1714(m_1706.TrangThai) + "\"") : "Chọn nick cùng TRẠNG THÁI");
		SelectSameTrangThaiMenuItem.IsEnabled = flag2;
	}

	private static string m_1714(string P_0, int P_1 = 40)
	{
		if (P_0.Length <= P_1)
		{
			return P_0;
		}
		return P_0.Substring(0, P_1).TrimEnd() + "...";
	}

	private void m_1715(object P_0, RoutedEventArgs P_1)
	{
		foreach (PlatformAccountRow item in AccountGrid.SelectedItems.Cast<PlatformAccountRow>().ToList())
		{
			item.IsSelected = true;
		}
		m_1726();
	}

	private void m_1716(object P_0, RoutedEventArgs P_1)
	{
		foreach (PlatformAccountRow item in AccountGrid.SelectedItems.Cast<PlatformAccountRow>().ToList())
		{
			item.IsSelected = false;
		}
		m_1726();
	}

	private void m_1717(object P_0, RoutedEventArgs P_1)
	{
		if (m_1697 == null)
		{
			return;
		}
		foreach (PlatformAccountRow item in ((IEnumerable)m_1697).Cast<PlatformAccountRow>())
		{
			item.IsSelected = true;
		}
		m_1726();
	}

	private void m_1718(object P_0, RoutedEventArgs P_1)
	{
		if (m_1697 == null)
		{
			return;
		}
		foreach (PlatformAccountRow item in ((IEnumerable)m_1697).Cast<PlatformAccountRow>())
		{
			item.IsSelected = false;
		}
		m_1726();
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		if (m_1706 == null)
		{
			return;
		}
		string tinhTrang = m_1706.TinhTrang;
		foreach (PlatformAccountRow account in Accounts)
		{
			account.IsSelected = account.TinhTrang == tinhTrang;
		}
		m_1726();
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		if (m_1706 == null)
		{
			return;
		}
		string trangThai = m_1706.TrangThai;
		foreach (PlatformAccountRow account in Accounts)
		{
			account.IsSelected = account.TrangThai == trangThai;
		}
		m_1726();
	}

	private async void D(object P_0, RoutedEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = false;
		List<PlatformAccountRow> list = (from platformAccountRow in m_1721()
			where !string.IsNullOrWhiteSpace(platformAccountRow.BrowserProfileId)
			select platformAccountRow).ToList();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào có profile trình duyệt đang lưu.", "Reset profile", NotifyType.Warning);
			return;
		}
		IAntidetectBrowserClient client = BrowserEngineFactory.CreateActiveClient().Client;
		foreach (PlatformAccountRow item in list)
		{
			await client.StopProfileAsync(item.BrowserProfileId);
			await client.DeleteProfileAsync(item.BrowserProfileId, hard: true);
			item.BrowserProfileId = "";
		}
		CustomMessageBox.Show(A, $"Đã reset profile trình duyệt cho {list.Count} nick. Bấm Đăng nhập lại để tạo profile mới.", "Reset profile");
	}

	private void d(object P_0, RoutedEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = false;
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			list = Accounts.ToList();
		}
		if (list.Count == 0)
		{
			return;
		}
		foreach (PlatformAccountRow item in list)
		{
			item.TrangThai = "";
			item.TinhTrang = "";
		}
	}

	private void m_1719(object P_0, MouseButtonEventArgs P_1)
	{
		object originalSource = P_1.OriginalSource;
		DependencyObject val = (DependencyObject)((originalSource is DependencyObject) ? originalSource : null);
		while (val != null && !(val is DataGridRow) && !(val is CheckBox))
		{
			val = VisualTreeHelper.GetParent(val);
		}
		if (!(val is CheckBox))
		{
			while (val != null && !(val is DataGridRow))
			{
				val = VisualTreeHelper.GetParent(val);
			}
			if (val is DataGridRow { Item: PlatformAccountRow item })
			{
				item.IsSelected = !item.IsSelected;
				m_1726();
			}
		}
	}

	private void E(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is PlatformAccountRow platformAccountRow)
		{
			new TextDetailWindow(A, "Trạng thái - UID " + platformAccountRow.Uid, platformAccountRow, "TrangThai", "TrangThaiChiTiet").Show();
		}
	}

	private static gm_1692? m_1720<gm_1692>(DependencyObject? P_0) where gm_1692 : DependencyObject
	{
		while (P_0 != null && !(P_0 is gm_1692))
		{
			P_0 = VisualTreeHelper.GetParent(P_0);
		}
		return (gm_1692)(object)((P_0 is gm_1692) ? P_0 : null);
	}

	private List<PlatformAccountRow> m_1721()
	{
		List<PlatformAccountRow> list = Accounts.Where((PlatformAccountRow P_0) => P_0.IsSelected).ToList();
		if (list.Count > 0)
		{
			return list;
		}
		List<PlatformAccountRow> list2 = AccountGrid.SelectedItems.Cast<PlatformAccountRow>().ToList();
		if (list2.Count > 0)
		{
			return list2;
		}
		if (m_1706 != null && Accounts.Contains(m_1706))
		{
			return new List<PlatformAccountRow> { m_1706 };
		}
		return new List<PlatformAccountRow>();
	}

	private static bool m_1722(UIElement? P_0)
	{
		if (P_0 is FrameworkElement frameworkElement && P_0.IsVisible)
		{
			return frameworkElement.IsLoaded;
		}
		return false;
	}

	private void m_1723(Popup popup, object? P_1, UIElement? P_2 = null)
	{
		bool A = P_1 != null && P_1 == P_2 && m_1722(P_2);
		popup.IsOpen = false;
		((DispatcherObject)this).Dispatcher.BeginInvoke((Delegate)(Action)(() =>
		{
			if (A && P_2 != null)
			{
				popup.Placement = PlacementMode.Bottom;
				popup.PlacementTarget = P_2;
			}
			else
			{
				popup.Placement = PlacementMode.Center;
				popup.PlacementTarget = (UIElement)(((object)Window.GetWindow((DependencyObject)(object)this)) ?? ((object)this));
			}
			popup.IsOpen = true;
		}), (DispatcherPriority)4, Array.Empty<object>());
	}

	public void DeleteAllDataPermanently()
	{
		m_1696.DropTables();
	}

	public void LoadFromDatabase()
	{
		m_1696.EnsureCreated();
		Folders.Clear();
		Folders.Add(new NickFolder
		{
			Id = -1,
			Name = "Tất cả",
			IsSystem = true
		});
		foreach (NickFolder item in m_1696.LoadFolders())
		{
			Folders.Add(item);
		}
		Folders.Add(new NickFolder
		{
			Id = -2,
			Name = "Đã xóa",
			IsSystem = true
		});
		Accounts.Clear();
		foreach (PlatformAccountRow item2 in m_1696.LoadAll())
		{
			item2.PropertyChanged += m_1728;
			Accounts.Add(item2);
		}
		m_1697 = CollectionViewSource.GetDefaultView(Accounts);
		m_1697.Filter = m_1724;
		SortFieldCombo.ItemsSource = new string[3] { "UID / EMAIL", "TRẠNG THÁI", "TÌNH TRẠNG" };
		SortFieldCombo.SelectedIndex = 0;
		m_1725();
		SelectFolder(Folders[0]);
	}

	private bool m_1724(object P_0)
	{
		if (!(P_0 is PlatformAccountRow platformAccountRow))
		{
			return false;
		}
		if (!((m_1698 == -1) ? (platformAccountRow.FolderId != -2) : (platformAccountRow.FolderId == m_1698)))
		{
			return false;
		}
		if (m_1700 && !m_1701.Contains(platformAccountRow.Uid))
		{
			return false;
		}
		if (m_1702 != null && !m_1702.Contains(platformAccountRow.Uid))
		{
			return false;
		}
		return true;
	}

	private void m_1725()
	{
		foreach (NickFolder A in Folders)
		{
			A.Count = ((A.Id == -1) ? Accounts.Count((PlatformAccountRow P_0) => P_0.FolderId != -2) : Accounts.Count((PlatformAccountRow P_0) => P_0.FolderId == A.Id));
		}
	}

	private void m_1726()
	{
		if (m_1697 != null)
		{
			int num = ((IEnumerable)m_1697).Cast<PlatformAccountRow>().Count();
			int num2 = ((IEnumerable)m_1697).Cast<PlatformAccountRow>().Count((PlatformAccountRow P_0) => P_0.IsSelected);
			CountText.Text = $"{num} tài khoản";
			SelectedCountText.Text = $"{num2} đã chọn";
			m_1727(num, num2);
		}
	}

	private void m_1727(int P_0, int P_1)
	{
		if (StatTotalText == null)
		{
			return;
		}
		try
		{
			List<PlatformAccountRow> source = ((IEnumerable)m_1697).Cast<PlatformAccountRow>().ToList();
			int num = source.Count((PlatformAccountRow platformAccountRow) => string.Equals(platformAccountRow.TinhTrang, "LIVE", StringComparison.OrdinalIgnoreCase));
			int num2 = source.Count((PlatformAccountRow platformAccountRow) => !string.IsNullOrWhiteSpace(platformAccountRow.Proxy));
			int num3 = source.Count((PlatformAccountRow platformAccountRow) => platformAccountRow.ScriptId != 0);
			StatTotalText.Text = P_0.ToString();
			StatTotalSubText.Text = ((P_1 > 0) ? $"{P_1} đã chọn" : "tất cả nick");
			StatLiveText.Text = num.ToString();
			StatLiveSubText.Text = ((P_0 > 0) ? $"{num * 100 / P_0}% tổng số" : "0% tổng số");
			StatProxyText.Text = ((P_0 > 0) ? $"{num2 * 100 / P_0}%" : "0%");
			StatProxySubText.Text = $"{num2}/{P_0} nick";
			StatScriptText.Text = num3.ToString();
			StatScriptSubText.Text = ((num3 > 0) ? "nick đã gắn kịch bản" : "chưa gắn kịch bản");
		}
		catch
		{
		}
	}

	private void C()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Expected Obj, but got Unknown
		if (m_1707 == null)
		{
			m_1707 = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(200L)
			};
			m_1707.Tick += delegate
			{
				m_1707.Stop();
				m_1726();
			};
		}
		m_1707.Stop();
		m_1707.Start();
	}

	private void c()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Expected Obj, but got Unknown
		if (m_1699 == null)
		{
			m_1699 = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(700L)
			};
			m_1699.Tick += delegate
			{
				m_1699.Stop();
				m_1696.SaveAll(Accounts);
			};
		}
		m_1699.Stop();
		m_1699.Start();
	}

	public void FlushSave()
	{
		if (m_1699 != null && m_1699.IsEnabled)
		{
			m_1699.Stop();
			m_1696.SaveAll(Accounts);
		}
	}

	private void m_1728(object? sender, PropertyChangedEventArgs P_1)
	{
		if (P_1.PropertyName == "IsSelected")
		{
			C();
			return;
		}
		if (m_1700 && P_1.PropertyName == "Uid")
		{
			E();
			ICollectionView? val = m_1697;
			if (val != null)
			{
				val.Refresh();
			}
		}
		c();
		if (sender is PlatformAccountRow platformAccountRow)
		{
			m_1746(platformAccountRow.FolderId);
		}
	}

	public void SelectFolder(NickFolder folder)
	{
		foreach (PlatformAccountRow account in Accounts)
		{
			account.IsSelected = false;
		}
		m_1698 = folder.Id;
		ICollectionView? val = m_1697;
		if (val != null)
		{
			val.Refresh();
		}
		bool flag = folder.Id == -2;
		RestoreButton.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		DeleteButtonText.Text = (flag ? "Xóa vĩnh viễn" : "Xóa");
		MoveFolderButton.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		m_1726();
	}

	public void AddFolder()
	{
		string text = PromptDialog.Show(A, "Tạo thư mục", "Tên thư mục:");
		if (string.IsNullOrWhiteSpace(text))
		{
			return;
		}
		try
		{
			NickFolder item = m_1696.CreateFolder(text.Trim());
			Folders.Insert(Folders.Count - 1, item);
			m_1725();
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(A, "Không thể tạo thư mục: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	public void RenameFolder(NickFolder folder)
	{
		if (!folder.CanManage)
		{
			return;
		}
		string text = PromptDialog.Show(A, "Đổi tên thư mục", "Tên thư mục:", folder.Name);
		if (string.IsNullOrWhiteSpace(text) || text.Trim() == folder.Name)
		{
			return;
		}
		string name = folder.Name;
		try
		{
			m_1696.RenameFolder(folder.Id, text.Trim());
			folder.Name = text.Trim();
			m_1745(name, folder.Name);
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(A, "Không thể đổi tên: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	public bool DeleteFolder(NickFolder folder)
	{
		if (!folder.CanManage)
		{
			return false;
		}
		int num = Accounts.Count((PlatformAccountRow P_0) => P_0.FolderId == folder.Id);
		string message = ((num > 0) ? $"Thư mục \"{folder.Name}\" đang có {num} nick. Xóa thư mục sẽ chuyển các nick này về \"{"Mặc định"}\". Tiếp tục?" : ("Xóa thư mục \"" + folder.Name + "\"?"));
		if (!CustomMessageBox.Confirm(A, message, "Xóa thư mục"))
		{
			return false;
		}
		try
		{
			int folderId = Folders.FirstOrDefault((NickFolder P_0) => P_0.IsSystem && P_0.Id > 0)?.Id ?? (-1);
			foreach (PlatformAccountRow item in Accounts.Where((PlatformAccountRow P_0) => P_0.FolderId == folder.Id))
			{
				item.FolderId = folderId;
			}
			m_1696.DeleteFolder(folder.Id);
			Folders.Remove(folder);
			m_1725();
			m_1744(folder.Name);
			return true;
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(A, "Không thể xóa thư mục: " + ex.Message, "Lỗi", NotifyType.Warning);
			return false;
		}
	}

	private void e(object P_0, RoutedEventArgs P_1)
	{
		LoadFromDatabase();
	}

	private async void F(object P_0, RoutedEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = false;
		if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase))
		{
			List<PlatformAccountRow> list = m_1721();
			if (list.Count == 0)
			{
				CustomMessageBox.Show(A, "Chưa chọn nick nào để đăng nhập.", "Đăng nhập TikTok", NotifyType.Warning);
				return;
			}
			List<PlatformAccountRow> list2 = list.Where((PlatformAccountRow platformAccountRow) => !string.IsNullOrWhiteSpace(platformAccountRow.PhoneName)).ToList();
			List<PlatformAccountRow> list3 = list.Except(list2).ToList();
			if (list2.Count == 0)
			{
				if (!m_1732(list, P_0))
				{
					CustomMessageBox.Show(A, "Các nick đã chọn chưa gắn Phone. Hãy gắn Phone cho các nick trước khi đăng nhập.", "Đăng nhập TikTok", NotifyType.Warning);
				}
			}
			else
			{
				if (list3.Count > 0 && !CustomMessageBox.Confirm(A, $"{list3.Count} nick chưa gắn Phone và sẽ bị bỏ qua. Tiếp tục đăng nhập cho {list2.Count} nick đã gắn Phone?", "Đăng nhập TikTok"))
				{
					return;
				}
				m_1703 = new CancellationTokenSource();
				CancellationToken m_1994 = m_1703.Token;
				LoginButton.IsEnabled = false;
				StopScriptButton.IsEnabled = true;
				StopScriptButton.Visibility = Visibility.Visible;
				int m_1995 = 0;
				int initialCount = Math.Max(1, AiVisionSettings.Load().MaxConcurrentDevices);
				SemaphoreSlim m_1996 = new SemaphoreSlim(initialCount);
				try
				{
					try
					{
						await Task.WhenAll(((IEnumerable<PlatformAccountRow>)list2).Select((Func<PlatformAccountRow, Task>)(async (PlatformAccountRow platformAccountRow) =>
						{
							try
							{
								await m_1996.WaitAsync(m_1994);
								try
								{
									if (m_1994.IsCancellationRequested)
									{
										platformAccountRow.TrangThai = "Đã dừng.";
									}
									else
									{
										LoginResult A = await TikTokPhoneLoginService.LoginAccountAsync(platformAccountRow, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1994);
										((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
										{
											platformAccountRow.TrangThai = A.TrangThai;
											platformAccountRow.TinhTrang = A.TinhTrang;
										}));
									}
								}
								finally
								{
									m_1996.Release();
								}
							}
							catch (OperationCanceledException)
							{
								((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = "Đã dừng."));
							}
							catch (Exception ex2)
							{
								Exception ex3 = ex2;
								Exception A2 = ex3;
								((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
								{
									platformAccountRow.TinhTrang = "ERROR";
									platformAccountRow.TrangThai = "Lỗi: " + A2.Message;
								}));
							}
							finally
							{
								Interlocked.Increment(ref m_1995);
							}
						})));
					}
					finally
					{
						m_1703.Dispose();
						m_1703 = null;
						LoginButton.IsEnabled = true;
						StopScriptButton.Visibility = Visibility.Collapsed;
						c();
					}
					int num = list2.Count((PlatformAccountRow platformAccountRow) => platformAccountRow.TinhTrang == "LIVE");
					CustomMessageBox.Show(A, $"Đã hoàn tất đăng nhập cho {list2.Count} nick TikTok.\n- Thành công: {num}\n- Thất bại / Cần kiểm tra: {list2.Count - num}", "Đăng nhập TikTok", (num <= 0) ? NotifyType.Warning : NotifyType.Success);
				}
				finally
				{
					if (m_1996 != null)
					{
						((IDisposable)m_1996).Dispose();
					}
				}
			}
		}
		else
		{
			CustomMessageBox.Show(A, "Đăng nhập tự động cho " + DisplayTitle + " đang được phát triển (mỗi nền tảng cần cơ chế đăng nhập riêng). Bạn có thể dùng kịch bản AI Vision (Danh sách kịch bản) để tự động hoá ngay bây giờ.", "Đăng nhập", NotifyType.Warning);
		}
	}

	private void f(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is PlatformAccountRow platformAccountRow)
		{
			new TextDetailWindow(Window.GetWindow((DependencyObject)(object)this), "Kịch bản - UID " + platformAccountRow.Uid, platformAccountRow, "ScriptName").Show();
		}
	}

	private async void G(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào.", "Mở Chrome", NotifyType.Warning);
			return;
		}
		List<PlatformAccountRow> list2 = list.Where((PlatformAccountRow platformAccountRow) => !string.IsNullOrWhiteSpace(platformAccountRow.ProfileChrome)).ToList();
		if (list2.Count == 0)
		{
			CustomMessageBox.Show(A, "Các nick đã chọn chưa gắn Chrome. Bấm \"Gắn Chrome\" cho nick trước.", "Mở Chrome", NotifyType.Warning);
			return;
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			CustomMessageBox.Show(A, $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.", "Mở Chrome", NotifyType.Warning);
			return;
		}
		int num = 0;
		foreach (PlatformAccountRow item in list2)
		{
			try
			{
				await global::A.F.A(client, settings, item);
				num++;
			}
			catch (Exception ex)
			{
				item.TrangThai = "Không mở được Chrome: " + ex.Message;
			}
		}
		if (num == 0)
		{
			CustomMessageBox.Show(A, "Không mở được Chrome cho nick nào - xem cột Trạng thái.", "Mở Chrome", NotifyType.Warning);
		}
	}

	[SpecialName]
	private int D()
	{
		if (Accounts.Count != 0)
		{
			return Accounts.Max((PlatformAccountRow P_0) => P_0.Index) + 1;
		}
		return 1;
	}

	private int d()
	{
		if (m_1698 != -1 && m_1698 != -2)
		{
			return m_1698;
		}
		return Folders.FirstOrDefault((NickFolder P_0) => P_0.IsSystem && P_0.Id > 0)?.Id ?? (-1);
	}

	private void m_1729(PlatformAccountRow P_0)
	{
		P_0.Index = D();
		P_0.FolderId = d();
		P_0.PropertyChanged += m_1728;
		Accounts.Add(P_0);
		m_1746(P_0.FolderId);
	}

	private void g(object P_0, RoutedEventArgs P_1)
	{
		ImportPanel.Visibility = Visibility.Visible;
		ImportTextBox.Clear();
	}

	private void H(object P_0, RoutedEventArgs P_1)
	{
		ImportPanel.Visibility = Visibility.Collapsed;
	}

	private void h(object P_0, RoutedEventArgs P_1)
	{
		string[] array = (from text2 in ImportTextBox.Text.Split('\n')
			select text2.Trim(new char[2] { '\r', ' ' }) into text2
			where text2.Length > 0
			select text2).ToArray();
		int num = 0;
		string[] array2 = array;
		for (int num2 = 0; num2 < array2.Length; num2++)
		{
			string[] array3 = array2[num2].Split('|');
			string text = ((array3.Length != 0) ? array3[0].Trim() : "");
			if (!string.IsNullOrWhiteSpace(text))
			{
				m_1729(new PlatformAccountRow
				{
					Uid = text,
					Pass = ((array3.Length > 1) ? array3[1].Trim() : ""),
					TwoFA = ((array3.Length > 2) ? array3[2].Trim() : ""),
					Token = ((array3.Length > 3) ? array3[3].Trim() : ""),
					Cookie = ((array3.Length > 4) ? array3[4].Trim() : ""),
					Mail = ((array3.Length > 5) ? array3[5].Trim() : ""),
					PassMail = ((array3.Length > 6) ? array3[6].Trim() : ""),
					MailKhoiPhuc = ((array3.Length > 7) ? array3[7].Trim() : ""),
					Proxy = ((array3.Length > 8) ? array3[8].Trim() : ""),
					GhiChu = ((array3.Length > 9) ? array3[9].Trim() : ""),
					TrangThai = "Chưa dùng"
				});
				num++;
			}
		}
		ImportPanel.Visibility = Visibility.Collapsed;
		m_1725();
		m_1726();
		CustomMessageBox.Show(A, $"Đã thêm {num}/{array.Length} nick.", "Nhập nick", (num != array.Length) ? NotifyType.Warning : NotifyType.Success);
	}

	private void I(object P_0, RoutedEventArgs P_1)
	{
		m_1723(ExportImportFilePopup, P_0, ExportImportFileButton);
	}

	private void i(object P_0, RoutedEventArgs P_1)
	{
		ExportImportFilePopup.IsOpen = false;
		if (Accounts.Count == 0)
		{
			CustomMessageBox.Show(A, "Không có nick nào để xuất.", "Xuất file", NotifyType.Warning);
			return;
		}
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "BaoSamNuoi " + DisplayTitle + " Export (*.json)|*.json",
			FileName = $"{PlatformKey.ToLowerInvariant()}_export_{DateTime.Now:yyyyMMdd_HHmmss}.json"
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			List<PlatformAccountExportItem> list = Accounts.Select((PlatformAccountRow platformAccountRow) => new PlatformAccountExportItem
			{
				FolderName = (Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == platformAccountRow.FolderId)?.Name ?? ""),
				Uid = platformAccountRow.Uid,
				Pass = platformAccountRow.Pass,
				TwoFA = platformAccountRow.TwoFA,
				Token = platformAccountRow.Token,
				Cookie = platformAccountRow.Cookie,
				Mail = platformAccountRow.Mail,
				PassMail = platformAccountRow.PassMail,
				MailKhoiPhuc = platformAccountRow.MailKhoiPhuc,
				ProfileChrome = platformAccountRow.ProfileChrome,
				TenProfile = platformAccountRow.TenProfile,
				Proxy = platformAccountRow.Proxy,
				GhiChu = platformAccountRow.GhiChu,
				TrangThai = platformAccountRow.TrangThai,
				TinhTrang = platformAccountRow.TinhTrang
			}).ToList();
			File.WriteAllText(saveFileDialog.FileName, JsonSerializer.Serialize(list, new JsonSerializerOptions
			{
				WriteIndented = true
			}));
			CustomMessageBox.Show(A, $"Đã xuất {list.Count} nick ra file:\n{saveFileDialog.FileName}", "Xuất file");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(A, "Không thể xuất file: " + ex.Message, "Xuất file", NotifyType.Warning);
		}
	}

	private void J(object P_0, RoutedEventArgs P_1)
	{
		ExportImportFilePopup.IsOpen = false;
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "BaoSamNuoi Export (*.json)|*.json|Tất cả file (*.*)|*.*"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			List<PlatformAccountExportItem> list = JsonSerializer.Deserialize<List<PlatformAccountExportItem>>(File.ReadAllText(openFileDialog.FileName));
			if (list == null || list.Count == 0)
			{
				CustomMessageBox.Show(this.A, "File không có dữ liệu hợp lệ.", "Nạp file", NotifyType.Warning);
				return;
			}
			int num = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.IsSystem && nickFolder3.Id > 0)?.Id ?? (-1);
			foreach (PlatformAccountExportItem A in list)
			{
				int folderId = num;
				if (!string.IsNullOrWhiteSpace(A.FolderName))
				{
					NickFolder nickFolder = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.Id > 0 && nickFolder3.Name == A.FolderName);
					if (nickFolder == null)
					{
						try
						{
							NickFolder nickFolder2 = m_1696.CreateFolder(A.FolderName);
							Folders.Insert(Folders.Count - 1, nickFolder2);
							nickFolder = nickFolder2;
						}
						catch
						{
						}
					}
					if (nickFolder != null)
					{
						folderId = nickFolder.Id;
					}
				}
				PlatformAccountRow platformAccountRow = new PlatformAccountRow
				{
					Index = D(),
					FolderId = folderId,
					Uid = A.Uid,
					Pass = A.Pass,
					TwoFA = A.TwoFA,
					Token = A.Token,
					Cookie = A.Cookie,
					Mail = A.Mail,
					PassMail = A.PassMail,
					MailKhoiPhuc = A.MailKhoiPhuc,
					ProfileChrome = A.ProfileChrome,
					TenProfile = A.TenProfile,
					Proxy = A.Proxy,
					GhiChu = A.GhiChu,
					TrangThai = A.TrangThai,
					TinhTrang = A.TinhTrang
				};
				platformAccountRow.PropertyChanged += m_1728;
				Accounts.Add(platformAccountRow);
				m_1746(platformAccountRow.FolderId);
			}
			m_1725();
			m_1726();
			CustomMessageBox.Show(this.A, $"Đã nạp {list.Count} nick từ file.", "Nạp file");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this.A, "Không thể nạp file: " + ex.Message, "Nạp file", NotifyType.Warning);
		}
	}

	private void j(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào.", "Xóa", NotifyType.Warning);
		}
		else if (m_1698 == -2)
		{
			if (!CustomMessageBox.Confirm(A, $"Xóa vĩnh viễn {list.Count} nick đã chọn?", "Xóa vĩnh viễn"))
			{
				return;
			}
			foreach (PlatformAccountRow item in list)
			{
				item.PropertyChanged -= m_1728;
				Accounts.Remove(item);
				m_1746(item.FolderId);
			}
			ICollectionView? val = m_1697;
			if (val != null)
			{
				val.Refresh();
			}
			m_1725();
			m_1726();
			c();
			CustomMessageBox.Show(A, $"Đã xóa vĩnh viễn {list.Count} nick.", "Xóa vĩnh viễn");
		}
		else
		{
			if (!CustomMessageBox.Confirm(A, $"Xóa {list.Count} nick đã chọn?", "Xóa"))
			{
				return;
			}
			foreach (PlatformAccountRow item2 in list)
			{
				m_1746(item2.FolderId);
				item2.FolderId = -2;
				item2.IsSelected = false;
			}
			ICollectionView? val2 = m_1697;
			if (val2 != null)
			{
				val2.Refresh();
			}
			m_1725();
			m_1726();
			c();
			CustomMessageBox.Show(A, $"Đã chuyển {list.Count} nick vào Đã xóa.", "Xóa");
		}
	}

	private void K(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào.", "Khôi phục", NotifyType.Warning);
			return;
		}
		int folderId = Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.IsSystem && nickFolder.Id > 0)?.Id ?? (-1);
		foreach (PlatformAccountRow item in list)
		{
			item.FolderId = folderId;
			item.IsSelected = false;
			m_1746(item.FolderId);
		}
		ICollectionView? val = m_1697;
		if (val != null)
		{
			val.Refresh();
		}
		m_1725();
		m_1726();
		c();
		CustomMessageBox.Show(A, $"Đã khôi phục {list.Count} nick.", "Khôi phục");
	}

	private void k(object P_0, RoutedEventArgs P_1)
	{
		bool isSelected = ((P_0 as CheckBox)?.IsChecked == true);
		foreach (PlatformAccountRow item in ((IEnumerable)m_1697)?.Cast<PlatformAccountRow>() ?? Enumerable.Empty<PlatformAccountRow>())
		{
			item.IsSelected = isSelected;
		}
		m_1726();
	}

	private void L(object P_0, RoutedEventArgs P_1)
	{
		m_1723(SortPopup, P_0, SortButton);
	}

	private void m_1730(object P_0, SelectionChangedEventArgs P_1)
	{
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		if (m_1697 != null && SortFieldCombo.SelectedItem != null && SortDirectionCombo.SelectedItem != null)
		{
			string text = (SortFieldCombo.SelectedItem as string) switch
			{
				"UID / EMAIL" => "Uid", 
				"TRẠNG THÁI" => "TrangThai", 
				"TÌNH TRẠNG" => "TinhTrang", 
				_ => "Uid", 
			};
			bool flag = (SortDirectionCombo.SelectedItem as ComboBoxItem)?.Content as string == "Giảm dần";
			((Collection<SortDescription>)(object)m_1697.SortDescriptions).Clear();
			((Collection<SortDescription>)(object)m_1697.SortDescriptions).Add(new SortDescription(text, flag ? ListSortDirection.Descending : ListSortDirection.Ascending));
		}
	}

	private void l(object P_0, RoutedEventArgs P_1)
	{
		m_1723(BulkSearchPopup, P_0, BulkSearchButton);
	}

	private void m_1731(object P_0, TextChangedEventArgs P_1)
	{
		int value = (from text in BulkSearchTextBox.Text.Split('\n')
			select text.Trim(new char[2] { '\r', ' ' })).Count((string text) => text.Length > 0);
		BulkSearchCountText.Text = $"{value} UID";
	}

	private void M(object P_0, RoutedEventArgs P_1)
	{
		HashSet<string> hashSet = (from text in BulkSearchTextBox.Text.Split('\n')
			select text.Trim(new char[2] { '\r', ' ' }) into text
			where text.Length > 0
			select text).ToHashSet();
		if (hashSet.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa nhập UID nào.", "Tìm nhiều UID", NotifyType.Warning);
			return;
		}
		m_1702 = hashSet;
		SelectFolder(Folders[0]);
		BulkSearchButtonText.Text = $"Tìm nhiều UID ✓ ({hashSet.Count})";
		BulkSearchButton.Background = (Brush)FindResource("BrushAccentSoft");
		BulkSearchPopup.IsOpen = false;
		ICollectionView? val = m_1697;
		if (val != null)
		{
			val.Refresh();
		}
		m_1726();
		int value = ((IEnumerable)m_1697)?.Cast<PlatformAccountRow>().Count() ?? 0;
		CustomMessageBox.Show(A, $"Tìm thấy {value}/{hashSet.Count} UID trong danh sách.", "Tìm nhiều UID");
	}

	private void m(object P_0, RoutedEventArgs P_1)
	{
		m_1702 = null;
		BulkSearchTextBox.Clear();
		BulkSearchButtonText.Text = "Tìm nhiều UID";
		BulkSearchButton.Background = (Brush)FindResource("BrushCard");
		BulkSearchPopup.IsOpen = false;
		ICollectionView? val = m_1697;
		if (val != null)
		{
			val.Refresh();
		}
		m_1726();
	}

	private void N(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> A = m_1721();
		if (A.Count == 0)
		{
			CustomMessageBox.Show(this.A, "Chưa chọn nick nào.", "Chuyển thư mục", NotifyType.Warning);
			return;
		}
		MoveFolderPanel.Children.Clear();
		foreach (NickFolder A2 in Folders.Where((NickFolder nickFolder) => nickFolder.Id != -2 && nickFolder.Id != -1))
		{
			Button button = new Button
			{
				Style = (Style)FindResource("OutlineButtonStyle"),
				Content = A2.Name,
				Margin = new Thickness(2.0),
				HorizontalContentAlignment = HorizontalAlignment.Left
			};
			button.Click += delegate
			{
				foreach (PlatformAccountRow item in A)
				{
					item.FolderId = A2.Id;
					item.IsSelected = false;
				}
				ICollectionView? val = m_1697;
				if (val != null)
				{
					val.Refresh();
				}
				m_1725();
				m_1726();
				MoveFolderPopup.IsOpen = false;
			};
			MoveFolderPanel.Children.Add(button);
		}
		m_1723(MoveFolderPopup, P_0, MoveFolderButton);
	}

	private void E()
	{
		m_1701 = (from P_0 in Accounts
			where P_0.FolderId != -2 && !string.IsNullOrWhiteSpace(P_0.Uid)
			group P_0 by P_0.Uid into P_0
			where P_0.Count() > 1
			select P_0.Key).ToHashSet();
	}

	private void n(object P_0, RoutedEventArgs P_1)
	{
		m_1700 = !m_1700;
		if (m_1700)
		{
			E();
			SelectFolder(Folders[0]);
		}
		DuplicateFilterButtonText.Text = (m_1700 ? "Lọc trùng ✓" : "Lọc trùng");
		DuplicateFilterButton.Background = (m_1700 ? ((Brush)FindResource("BrushAccentSoft")) : ((Brush)FindResource("BrushCard")));
		ICollectionView? val = m_1697;
		if (val != null)
		{
			val.Refresh();
		}
		m_1726();
		if (m_1700 && m_1701.Count == 0)
		{
			CustomMessageBox.Show(A, "Không tìm thấy UID nào trùng nhau.", "Lọc trùng");
		}
	}

	[SpecialName]
	private string e()
	{
		return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", PlatformKey.ToLowerInvariant() + "_copy_columns.json");
	}

	private void O(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this.A, "Chưa chọn nick nào.", "Copy", NotifyType.Warning);
			return;
		}
		PlatformAccountRow A = list[0];
		List<string> list2 = CopyColumnsWindow.Show(this.A, m_1708.Select(((string Header, Func<PlatformAccountRow, string> Getter) tuple) => tuple.Header).ToArray(), B, list.Count, (string text) => m_1708.First(((string Header, Func<PlatformAccountRow, string> Getter) tuple) => tuple.Header == text).Getter(A));
		if (list2 == null)
		{
			return;
		}
		B = list2.ToHashSet();
		F();
		List<(string, Func<PlatformAccountRow, string>)> list3 = m_1708.Where(((string Header, Func<PlatformAccountRow, string> Getter) tuple) => B.Contains(tuple.Header)).ToList();
		StringBuilder stringBuilder = new StringBuilder();
		foreach (PlatformAccountRow A2 in list)
		{
			stringBuilder.AppendLine(string.Join("|", list3.Select(((string Header, Func<PlatformAccountRow, string> Getter) tuple) => tuple.Getter(A2))));
		}
		try
		{
			Clipboard.SetText(stringBuilder.ToString());
			CustomMessageBox.Show(this.A, $"Đã copy {list.Count} nick ({list3.Count} cột) vào clipboard.", "Copy");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this.A, "Không thể copy: " + ex.Message, "Copy", NotifyType.Warning);
		}
	}

	private void F()
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(e()));
			File.WriteAllText(e(), JsonSerializer.Serialize(B.ToList()));
		}
		catch
		{
		}
	}

	private void f()
	{
		try
		{
			if (File.Exists(e()))
			{
				List<string> list = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(e()));
				if (list != null)
				{
					B = list.ToHashSet();
				}
			}
		}
		catch
		{
		}
	}

	private void o(object P_0, RoutedEventArgs P_1)
	{
		BulkUpdateWindow bulkUpdateWindow = new BulkUpdateWindow(Accounts.Select((PlatformAccountRow platformAccountRow2) => platformAccountRow2.Uid))
		{
			Owner = this.A
		};
		if (bulkUpdateWindow.ShowDialog() != true)
		{
			return;
		}
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		foreach (var entry in bulkUpdateWindow.Entries)
		{
			string A = entry.Uid;
			Dictionary<string, string> item = entry.Fields;
			PlatformAccountRow platformAccountRow = Accounts.FirstOrDefault((PlatformAccountRow platformAccountRow2) => platformAccountRow2.Uid == A);
			if (platformAccountRow == null)
			{
				num3++;
				continue;
			}
			foreach (var (key, arg) in item)
			{
				if (m_1709.TryGetValue(key, out Action<PlatformAccountRow, string> value))
				{
					value(platformAccountRow, arg);
					num2++;
				}
			}
			num++;
		}
		string text3 = $"Đã cập nhật {num} nick ({num2} trường).";
		if (num3 > 0)
		{
			text3 += $"\n{num3} UID không tìm thấy trong danh sách.";
		}
		CustomMessageBox.Show(this.A, text3, "Cập nhật hàng loạt", (num3 > 0) ? NotifyType.Warning : NotifyType.Success);
	}

	private void P(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào để gán proxy.", "Thêm Proxy", NotifyType.Warning);
			return;
		}
		AddProxyWindow addProxyWindow = new AddProxyWindow
		{
			Owner = A
		};
		if (addProxyWindow.ShowDialog() != true)
		{
			return;
		}
		List<string> parsedProxies = addProxyWindow.ParsedProxies;
		if (parsedProxies.Count != 0)
		{
			for (int i = 0; i < list.Count; i++)
			{
				list[i].Proxy = parsedProxies[i % parsedProxies.Count];
			}
			CustomMessageBox.Show(A, $"Đã gán proxy cho {list.Count} nick từ {parsedProxies.Count} proxy nhập vào.", "Thêm Proxy");
		}
	}

	private void p(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào để xóa proxy.", "Xóa Proxy", NotifyType.Warning);
		}
		else
		{
			if (!CustomMessageBox.Confirm(A, $"Xóa proxy khỏi {list.Count} nick đã chọn?", "Xóa Proxy"))
			{
				return;
			}
			foreach (PlatformAccountRow item in list)
			{
				item.Proxy = "";
			}
			CustomMessageBox.Show(A, $"Đã xóa proxy khỏi {list.Count} nick.", "Xóa Proxy");
		}
	}

	private async void Q(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = (from platformAccountRow in m_1721()
			where !string.IsNullOrWhiteSpace(platformAccountRow.TwoFA)
			select platformAccountRow).ToList();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào có mã 2FA.", "Lấy mã 2FA", NotifyType.Warning);
			return;
		}
		GetTwoFaCodesButton.IsEnabled = false;
		GetTwoFaCodesButtonText.Text = "Đang lấy mã...";
		List<(string, string)> list2;
		try
		{
			list2 = (await Task.WhenAll(list.Select((PlatformAccountRow platformAccountRow) => Task.Run(() => (Uid: platformAccountRow.Uid, Code: PlaywrightHumanHelpers.Get2fa(platformAccountRow.TwoFA)))))).ToList();
		}
		finally
		{
			GetTwoFaCodesButton.IsEnabled = true;
			GetTwoFaCodesButtonText.Text = "Lấy mã 2FA";
		}
		List<(string, string)> list3 = list2.Where(((string Uid, string Code) r) => !string.IsNullOrEmpty(r.Code)).ToList();
		List<(string, string)> list4 = list2.Where(((string Uid, string Code) r) => string.IsNullOrEmpty(r.Code)).ToList();
		if (list3.Count == 1 && list4.Count == 0)
		{
			try
			{
				Clipboard.SetText(list3[0].Item2);
			}
			catch
			{
			}
			CustomMessageBox.Show(A, $"Mã 2FA của {list3[0].Item1}: {list3[0].Item2}\n(đã copy vào clipboard)", "Lấy mã 2FA");
			return;
		}
		if (list3.Count > 0)
		{
			try
			{
				Clipboard.SetText(string.Join("\n", list3.Select(((string Uid, string Code) r) => r.Uid + ": " + r.Code)));
			}
			catch
			{
			}
		}
		string text = $"Lấy được {list3.Count}/{list2.Count} mã 2FA, đã copy vào clipboard.";
		if (list4.Count > 0)
		{
			text += $"\n{list4.Count} nick lỗi (sai định dạng mã 2FA): {string.Join(", ", list4.Select(((string Uid, string Code) tuple) => tuple.Uid))}";
		}
		CustomMessageBox.Show(A, text, "Lấy mã 2FA", (list4.Count > 0) ? NotifyType.Warning : NotifyType.Success);
	}

	private void q(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> A = m_1721();
		if (A.Count == 0)
		{
			CustomMessageBox.Show(this.A, "Chưa chọn nick nào.", "Gắn Phone", NotifyType.Warning);
			return;
		}
		AttachPhonePanel.Children.Clear();
		if (m_1704.Count == 0)
		{
			AttachPhonePanel.Children.Add(new TextBlock
			{
				Text = "Chưa có phone nào.",
				Foreground = (Brush)FindResource("BrushTextMuted"),
				Margin = new Thickness(6.0)
			});
		}
		foreach (ProfileRow A2 in m_1704)
		{
			Button button = new Button
			{
				Style = (Style)FindResource("OutlineButtonStyle"),
				Content = A2.Name,
				Margin = new Thickness(2.0),
				HorizontalContentAlignment = HorizontalAlignment.Left
			};
			button.Click += delegate
			{
				foreach (PlatformAccountRow item in A)
				{
					item.PhoneName = A2.Name;
					item.ProfileChrome = "";
				}
				AttachPhonePopup.IsOpen = false;
				CustomMessageBox.Show(this.A, $"Đã gắn máy \"{A2.Name}\" cho {A.Count} nick.", "Gắn Phone");
			};
			AttachPhonePanel.Children.Add(button);
		}
		m_1723(AttachPhonePopup, P_0, AttachPhoneButton);
	}

	private void R(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào.", "Gắn Chrome", NotifyType.Warning);
			return;
		}
		foreach (PlatformAccountRow item in list)
		{
			if (string.IsNullOrWhiteSpace(item.ProfileChrome))
			{
				item.ProfileChrome = ((!string.IsNullOrWhiteSpace(item.Uid)) ? item.Uid : $"{PlatformKey}_{item.Index}_{DateTime.Now:HHmmss}");
			}
			item.PhoneName = "";
		}
		CustomMessageBox.Show(A, $"Đã gắn Chrome cho {list.Count} nick.", "Gắn Chrome");
	}

	private bool m_1732(List<PlatformAccountRow> P_0, object? sender)
	{
		List<PlatformAccountRow> list = P_0.Where((PlatformAccountRow platformAccountRow) => string.IsNullOrEmpty(platformAccountRow.Platform)).ToList();
		if (list.Count == 0)
		{
			return false;
		}
		AttachPlatformPromptText.Text = ((list.Count == P_0.Count) ? $"{list.Count} nick đã chọn chưa gắn Phone hoặc Chrome. Chọn loại để gắn:" : $"{list.Count}/{P_0.Count} nick đã chọn chưa gắn Phone hoặc Chrome. Chọn loại để gắn:");
		AttachPlatformPromptPopup.PlacementTarget = A;
		AttachPlatformPromptPopup.Placement = PlacementMode.Center;
		AttachPlatformPromptPopup.HorizontalOffset = 0.0;
		AttachPlatformPromptPopup.VerticalOffset = 0.0;
		AttachPlatformPromptPopup.IsOpen = true;
		return true;
	}

	private void r(object P_0, RoutedEventArgs P_1)
	{
		AttachPlatformPromptPopup.IsOpen = false;
		R(RunScriptButton, P_1);
	}

	private void S(object P_0, RoutedEventArgs P_1)
	{
		AttachPlatformPromptPopup.IsOpen = false;
		q(RunScriptButton, P_1);
	}

	private void s(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào.", "Gắn Kịch Bản", NotifyType.Warning);
		}
		else if (!m_1732(list, (P_0 as FrameworkElement) ?? AttachScriptButton))
		{
			string text = list.Select((PlatformAccountRow platformAccountRow) => platformAccountRow.Platform).ToHashSet().FirstOrDefault((string value) => !string.IsNullOrEmpty(value)) ?? "Chrome";
			if (text == "Phone")
			{
				text = "Android";
			}
			List<ScriptItem> scripts = m_1705.Where((ScriptItem scriptItem2) => scriptItem2.ChuDe == PlatformKey).ToList();
			ScriptItem scriptItem = AttachScriptWindow.ShowFor(A, scripts, text, list.Count, DisplayTitle);
			if (scriptItem != null)
			{
				m_1733(scriptItem);
			}
		}
	}

	private void m_1733(ScriptItem P_0)
	{
		List<PlatformAccountRow> m_1895 = m_1721();
		if (m_1895.Count == 0)
		{
			CustomMessageBox.Show(A, "Chưa chọn nick nào.", "Gắn Kịch Bản", NotifyType.Warning);
		}
		else
		{
			if (m_1732(m_1895, null))
			{
				return;
			}
			bool flag = P_0.Platform.Equals("Chrome", StringComparison.OrdinalIgnoreCase);
			bool flag2 = P_0.Platform.Equals("Phone", StringComparison.OrdinalIgnoreCase) || P_0.Platform.Equals("Android", StringComparison.OrdinalIgnoreCase);
			bool flag3 = P_0.Platform.Equals("iPhone", StringComparison.OrdinalIgnoreCase) || P_0.Platform.Equals("iOS", StringComparison.OrdinalIgnoreCase);
			if (flag)
			{
				foreach (PlatformAccountRow item in m_1895)
				{
					if (string.IsNullOrWhiteSpace(item.ProfileChrome))
					{
						item.ProfileChrome = ((!string.IsNullOrWhiteSpace(item.Uid)) ? item.Uid : $"{PlatformKey}_{item.Index}_{DateTime.Now:HHmmss}");
					}
					item.PhoneName = "";
				}
			}
			else if (flag2 | flag3)
			{
				string text = m_1895.FirstOrDefault((PlatformAccountRow platformAccountRow) => !string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))?.PhoneName ?? Accounts.FirstOrDefault((PlatformAccountRow platformAccountRow) => !string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))?.PhoneName ?? "";
				foreach (PlatformAccountRow item2 in m_1895)
				{
					if (string.IsNullOrWhiteSpace(item2.PhoneName) && !string.IsNullOrEmpty(text))
					{
						item2.PhoneName = text;
					}
					item2.ProfileChrome = "";
				}
				if (string.IsNullOrEmpty(text) & flag2)
				{
					Task.Run(async () =>
					{
						try
						{
							string A = (await AdbController.ListDevicesAsync()).FirstOrDefault() ?? "";
							if (!string.IsNullOrEmpty(A))
							{
								((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
								{
									foreach (PlatformAccountRow item3 in m_1895)
									{
										if (string.IsNullOrWhiteSpace(item3.PhoneName))
										{
											item3.PhoneName = A;
										}
									}
								}));
							}
						}
						catch
						{
						}
					});
				}
			}
			if (P_0.IsSystem && string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && P_0.Name == "Tương tác")
			{
				TikTokInteractionSettings initial = TikTokInteractionSettings.FromJson(m_1895[0].TikTokInteractionSettingsJson);
				TikTokInteractionSettings tikTokInteractionSettings = TikTokInteractionSettingsWindow.Show(A, initial);
				if (tikTokInteractionSettings == null)
				{
					return;
				}
				string tikTokInteractionSettingsJson = tikTokInteractionSettings.ToJson();
				foreach (PlatformAccountRow item4 in m_1895)
				{
					item4.ScriptId = P_0.Id;
					item4.ScriptName = P_0.Name;
					item4.TikTokInteractionSettingsJson = tikTokInteractionSettingsJson;
				}
				CustomMessageBox.Show(A, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1895.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && (P_0.Name == "Thả tim" || P_0.Name == "Bình luận" || P_0.Name == "Follow (Sub)" || P_0.Name == "Chia sẻ" || P_0.Name == "Cập nhật Avatar"))
			{
				string text2 = TikTokActionSettingsWindow.Show(A, P_0.Name, m_1895[0].TikTokInteractionSettingsJson);
				if (text2 == null)
				{
					return;
				}
				foreach (PlatformAccountRow item5 in m_1895)
				{
					item5.ScriptId = P_0.Id;
					item5.ScriptName = P_0.Name;
					item5.TikTokInteractionSettingsJson = text2;
				}
				CustomMessageBox.Show(A, $"Đã cấu hình & gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1895.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			foreach (PlatformAccountRow item6 in m_1895)
			{
				item6.ScriptId = P_0.Id;
				item6.ScriptName = P_0.Name;
			}
			CustomMessageBox.Show(A, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1895.Count} nick.", "Gắn Kịch Bản");
		}
	}

	public void PopulateScriptToolbar()
	{
		if (ScriptCardsToolbarPanel == null)
		{
			return;
		}
		ScriptCardsToolbarPanel.Children.Clear();
		foreach (ScriptItem item in m_1705.Where((ScriptItem P_0) => P_0.ChuDe == PlatformKey))
		{
			ScriptCardsToolbarPanel.Children.Add(m_1734(item));
		}
	}

	private Button m_1734(ScriptItem P_0)
	{
		(string Glyph, string Accent, string Subtitle) tuple = AttachScriptWindow.m_296(P_0);
		string item = tuple.Glyph;
		string item2 = tuple.Accent;
		string item3 = tuple.Subtitle;
		Color color = (Color)ColorConverter.ConvertFromString(item2);
		FontFamily fontFamily = (FontFamily)FindResource("IconFont");
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(1.0, GridUnitType.Star)
		});
		Border element = new Border
		{
			Width = 4.0,
			Height = 26.0,
			CornerRadius = new CornerRadius(2.0),
			Background = new SolidColorBrush(color),
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(0.0, 0.0, 9.0, 0.0)
		};
		Grid.SetColumn(element, 0);
		grid.Children.Add(element);
		Border element2 = new Border
		{
			Width = 28.0,
			Height = 28.0,
			CornerRadius = new CornerRadius(8.0),
			Background = new SolidColorBrush(color)
			{
				Opacity = 0.18
			},
			VerticalAlignment = VerticalAlignment.Center,
			Child = new TextBlock
			{
				Text = item,
				FontFamily = fontFamily,
				FontSize = 15.0,
				Foreground = new SolidColorBrush(color),
				HorizontalAlignment = HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center
			}
		};
		Grid.SetColumn(element2, 1);
		grid.Children.Add(element2);
		TextBlock element3 = new TextBlock
		{
			Text = P_0.Name,
			FontSize = 12.5,
			FontWeight = FontWeights.SemiBold,
			VerticalAlignment = VerticalAlignment.Center,
			TextTrimming = TextTrimming.CharacterEllipsis
		};
		StackPanel stackPanel = new StackPanel
		{
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(9.0, 0.0, 0.0, 0.0)
		};
		stackPanel.Children.Add(m_1735(P_0.Platform));
		stackPanel.Children.Add(element3);
		Grid.SetColumn(stackPanel, 2);
		grid.Children.Add(stackPanel);
		Button button = new Button();
		button.Style = (Style)FindResource("ScriptCardButtonStyle");
		button.Content = grid;
		button.Width = 224.0;
		button.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		button.Padding = new Thickness(10.0, 8.0, 12.0, 8.0);
		button.ToolTip = item3;
		button.Background = new SolidColorBrush(color)
		{
			Opacity = 0.09
		};
		button.BorderBrush = new SolidColorBrush(color)
		{
			Opacity = 0.55
		};
		button.Click += delegate
		{
			m_1733(P_0);
		};
		return button;
	}

	private Border m_1735(string P_0)
	{
		(string, string, string) tuple;
		if (P_0 == "iPhone")
		{
			tuple = ("iPhone", "#9CA3AF", "\ue8ea");
		}
		else
		{
			tuple = ((!(P_0 == "Chrome")) ? ("Android", "#22C55E", "\ue8ea") : ("Chrome", "#4285F4", "\ue774"));
		}
		(string, string, string) tuple2 = tuple;
		string item = tuple2.Item1;
		string item2 = tuple2.Item2;
		string item3 = tuple2.Item3;
		Color color = (Color)ColorConverter.ConvertFromString(item2);
		StackPanel stackPanel = new StackPanel
		{
			Orientation = Orientation.Horizontal
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = item3,
			FontFamily = (FontFamily)FindResource("IconFont"),
			FontSize = 9.0,
			Foreground = new SolidColorBrush(color),
			VerticalAlignment = VerticalAlignment.Center
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = item,
			FontSize = 9.5,
			FontWeight = FontWeights.Bold,
			Foreground = new SolidColorBrush(color),
			Margin = new Thickness(4.0, 0.0, 0.0, 0.0),
			VerticalAlignment = VerticalAlignment.Center
		});
		return new Border
		{
			Background = new SolidColorBrush(color)
			{
				Opacity = 0.16
			},
			BorderBrush = new SolidColorBrush(color)
			{
				Opacity = 0.7
			},
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(9.0),
			Padding = new Thickness(6.0, 1.0, 7.0, 1.0),
			HorizontalAlignment = HorizontalAlignment.Left,
			Margin = new Thickness(0.0, 0.0, 0.0, 3.0),
			Child = stackPanel
		};
	}

	private async void T(object P_0, RoutedEventArgs P_1)
	{
		List<PlatformAccountRow> list = m_1721();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this.A, "Chưa chọn nick nào.", "Chạy kịch bản", NotifyType.Warning);
			return;
		}
		List<PlatformAccountRow> m_1907 = list.Where((PlatformAccountRow platformAccountRow) => !string.IsNullOrEmpty(platformAccountRow.Platform) && platformAccountRow.ScriptId > 0 && m_1705.FirstOrDefault((ScriptItem scriptItem) => scriptItem.Id == platformAccountRow.ScriptId)?.Platform == platformAccountRow.Platform).ToList();
		List<PlatformAccountRow> list2 = list.Except(m_1907).ToList();
		if (m_1907.Count == 0)
		{
			if (!m_1732(list, RunScriptButton))
			{
				CustomMessageBox.Show(this.A, "Các nick đã chọn chưa gắn Kịch bản đúng nền tảng (Phone/Chrome đã gắn rồi). Bấm \"Gắn Kịch Bản\" hoặc chọn 1 thẻ kịch bản phía dưới.", "Chạy kịch bản", NotifyType.Warning);
			}
			return;
		}
		m_1703 = new CancellationTokenSource();
		CancellationToken m_1908 = m_1703.Token;
		RunScriptButton.IsEnabled = false;
		StopScriptButton.IsEnabled = true;
		StopScriptButton.Visibility = Visibility.Visible;
		BaoSamBrowserSettings baoSamBrowserSettings = BaoSamBrowserSettings.Load();
		bool repeatForever = baoSamBrowserSettings.RepeatForever;
		int num = Math.Max(0, baoSamBrowserSettings.RepeatDelaySeconds);
		int initialCount = (m_1907.Any((PlatformAccountRow platformAccountRow) => string.Equals(platformAccountRow.Platform, "Chrome", StringComparison.OrdinalIgnoreCase)) ? Math.Max(1, baoSamBrowserSettings.ThreadCount) : Math.Max(1, AiVisionSettings.Load().MaxConcurrentDevices));
		int num2 = 0;
		while (true)
		{
			num2++;
			string m_1919 = (repeatForever ? $" · vòng {num2}" : "");
			RunScriptButtonText.Text = $"Đang chạy kịch bản... (0/{m_1907.Count}){m_1919}";
			foreach (PlatformAccountRow item in m_1907)
			{
				item.TrangThai = "Đang chạy kịch bản...";
				item.TinhTrang = "";
			}
			int m_1920 = 0;
			SemaphoreSlim A = new SemaphoreSlim(initialCount);
			try
			{
				await Task.WhenAll(((IEnumerable<PlatformAccountRow>)m_1907).Select((Func<PlatformAccountRow, Task>)(async (PlatformAccountRow platformAccountRow) =>
				{
					try
					{
						await A.WaitAsync(m_1908);
						try
						{
							if (m_1908.IsCancellationRequested)
							{
								platformAccountRow.TrangThai = "Đã dừng.";
							}
							else
							{
								ScriptItem scriptItem = m_1705.FirstOrDefault((ScriptItem scriptItem2) => scriptItem2.Id == platformAccountRow.ScriptId && scriptItem2.Platform == platformAccountRow.Platform);
								if (scriptItem == null)
								{
									platformAccountRow.TrangThai = "Chưa gắn kịch bản " + platformAccountRow.Platform + " cho nick này.";
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Đăng nhập")
								{
									LoginResult loginResult = await TikTokPhoneLoginService.LoginAccountAsync(platformAccountRow, (string text) =>
									{
										((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
									}, m_1908);
									m_1736(platformAccountRow, loginResult.TrangThai);
									platformAccountRow.TinhTrang = loginResult.TinhTrang;
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Tương tác")
								{
									if (string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
									{
										platformAccountRow.TrangThai = "Nick chưa được gắn Phone.";
										platformAccountRow.TinhTrang = "ERROR";
									}
									else
									{
										TikTokInteractionSettings settings = TikTokInteractionSettings.FromJson(platformAccountRow.TikTokInteractionSettingsJson);
										LoginResult loginResult2 = await TikTokInteractionRunner.RunAsync(platformAccountRow.PhoneName, settings, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1908);
										m_1736(platformAccountRow, loginResult2.TrangThai);
										platformAccountRow.TinhTrang = loginResult2.TinhTrang;
									}
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Thả tim")
								{
									if (string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
									{
										platformAccountRow.TrangThai = "Nick chưa được gắn Phone.";
										platformAccountRow.TinhTrang = "ERROR";
									}
									else
									{
										TikTokLikeSettings settings2 = TikTokLikeSettings.FromJson(platformAccountRow.TikTokInteractionSettingsJson);
										LoginResult loginResult3 = await TikTokInteractionRunner.RunLikeOnlyAsync(platformAccountRow.PhoneName, settings2, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1908);
										m_1736(platformAccountRow, loginResult3.TrangThai);
										platformAccountRow.TinhTrang = loginResult3.TinhTrang;
									}
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Bình luận")
								{
									if (string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
									{
										platformAccountRow.TrangThai = "Nick chưa được gắn Phone.";
										platformAccountRow.TinhTrang = "ERROR";
									}
									else
									{
										TikTokCommentSettings settings3 = TikTokCommentSettings.FromJson(platformAccountRow.TikTokInteractionSettingsJson);
										LoginResult loginResult4 = await TikTokInteractionRunner.RunCommentOnlyAsync(platformAccountRow.PhoneName, settings3, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1908);
										m_1736(platformAccountRow, loginResult4.TrangThai);
										platformAccountRow.TinhTrang = loginResult4.TinhTrang;
									}
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Follow (Sub)")
								{
									if (string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
									{
										platformAccountRow.TrangThai = "Nick chưa được gắn Phone.";
										platformAccountRow.TinhTrang = "ERROR";
									}
									else
									{
										TikTokFollowSettings settings4 = TikTokFollowSettings.FromJson(platformAccountRow.TikTokInteractionSettingsJson);
										LoginResult loginResult5 = await TikTokInteractionRunner.RunFollowOnlyAsync(platformAccountRow.PhoneName, settings4, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1908);
										m_1736(platformAccountRow, loginResult5.TrangThai);
										platformAccountRow.TinhTrang = loginResult5.TinhTrang;
									}
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Chia sẻ")
								{
									if (string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
									{
										platformAccountRow.TrangThai = "Nick chưa được gắn Phone.";
										platformAccountRow.TinhTrang = "ERROR";
									}
									else
									{
										TikTokShareSettings settings5 = TikTokShareSettings.FromJson(platformAccountRow.TikTokInteractionSettingsJson);
										LoginResult loginResult6 = await TikTokInteractionRunner.RunShareOnlyAsync(platformAccountRow.PhoneName, settings5, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1908);
										m_1736(platformAccountRow, loginResult6.TrangThai);
										platformAccountRow.TinhTrang = loginResult6.TinhTrang;
									}
								}
								else if (string.Equals(PlatformKey, "TikTok", StringComparison.OrdinalIgnoreCase) && scriptItem.Name == "Cập nhật Avatar")
								{
									if (string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
									{
										platformAccountRow.TrangThai = "Nick chưa được gắn Phone.";
										platformAccountRow.TinhTrang = "ERROR";
									}
									else
									{
										TikTokAvatarSettings settings6 = TikTokAvatarSettings.FromJson(platformAccountRow.TikTokInteractionSettingsJson);
										LoginResult loginResult7 = await TikTokInteractionRunner.RunUpdateAvatarAsync(platformAccountRow.PhoneName, settings6, (string text) =>
										{
											((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
										}, m_1908);
										m_1736(platformAccountRow, loginResult7.TrangThai);
										platformAccountRow.TinhTrang = loginResult7.TinhTrang;
									}
								}
								else
								{
									AiVisionFlowDocument aiVisionFlowDocument = AiVisionFlowStore.Deserialize(scriptItem.AiVisionFlowJson);
									List<AiVisionFlowStep> steps = aiVisionFlowDocument.Steps;
									if (steps.Count == 0)
									{
										platformAccountRow.TrangThai = "Kịch bản \"" + scriptItem.Name + "\" chưa có bước nào.";
									}
									else
									{
										Dictionary<string, string> variables = AiVisionVariables.BuildMap(platformAccountRow);
										await AiVisionVariables.ResolveVerifyVariablesAsync(variables, steps, m_1908);
										if (platformAccountRow.Platform == "Phone")
										{
											if (!string.IsNullOrWhiteSpace(platformAccountRow.PhoneName))
											{
												await PhoneInitialSetupService.EnsureInitialSetupAsync(platformAccountRow.PhoneName, PlatformKey ?? "TikTok", (string text) =>
												{
													((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = text));
												}, m_1908);
												((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = "Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)..."));
												await AdbController.EnsureEnglishLanguageAsync(platformAccountRow.PhoneName, m_1908);
											}
											AiVisionRunResult aiVisionRunResult = await PhoneAiVisionRunner.RunFlowAsync(DeviceControllerFactory.Resolve(m_1704, platformAccountRow.PhoneName), steps, variables, (AiVisionStepLog aiVisionStepLog) =>
											{
												((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
											}, m_1908);
											m_1736(platformAccountRow, aiVisionRunResult.Message);
											if (!aiVisionRunResult.Success)
											{
												platformAccountRow.TinhTrang = "ERROR";
											}
										}
										else
										{
											AiVisionRunResult aiVisionRunResult2 = await ChromeAiVisionRunner.RunFlowForNickAsync(platformAccountRow, steps, variables, (AiVisionStepLog aiVisionStepLog) =>
											{
												((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => platformAccountRow.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
											}, m_1908);
											m_1736(platformAccountRow, aiVisionRunResult2.Message);
											if (!string.IsNullOrEmpty(aiVisionRunResult2.TinhTrang))
											{
												platformAccountRow.TinhTrang = aiVisionRunResult2.TinhTrang;
											}
											else if (!aiVisionRunResult2.Success)
											{
												platformAccountRow.TinhTrang = "ERROR";
											}
										}
									}
								}
							}
						}
						finally
						{
							A.Release();
						}
					}
					catch (OperationCanceledException)
					{
						platformAccountRow.TrangThai = "Đã dừng.";
					}
					catch (Exception ex3)
					{
						platformAccountRow.TinhTrang = "ERROR";
						m_1736(platformAccountRow, "Lỗi kịch bản: " + ex3.Message);
					}
					finally
					{
						Interlocked.Increment(ref m_1920);
						RunScriptButtonText.Text = $"Đang chạy kịch bản... ({m_1920}/{m_1907.Count}){m_1919}";
					}
				})));
				if (!repeatForever || m_1908.IsCancellationRequested)
				{
					break;
				}
				if (num > 0)
				{
					try
					{
						RunScriptButtonText.Text = $"Nghỉ {num}s trước vòng {num2 + 1}...";
						await Task.Delay(TimeSpan.FromSeconds(num), m_1908);
					}
					catch (OperationCanceledException)
					{
						goto end_IL_02fa;
					}
				}
				continue;
				end_IL_02fa:;
			}
			finally
			{
				if (A != null)
				{
					((IDisposable)A).Dispose();
				}
			}
			break;
		}
		m_1703.Dispose();
		m_1703 = null;
		RunScriptButton.IsEnabled = true;
		StopScriptButton.Visibility = Visibility.Collapsed;
		RunScriptButtonText.Text = "Bắt Đầu Chạy Kịch Bản";
		if (list2.Count > 0)
		{
			CustomMessageBox.Show(this.A, $"{list2.Count} nick bị bỏ qua vì chưa gắn đủ Phone/Chrome + Kịch bản đúng nền tảng.", "Chạy kịch bản", NotifyType.Warning);
		}
	}

	private static void m_1736(PlatformAccountRow P_0, string P_1)
	{
		P_0.TrangThai = m_1737(P_1);
		P_0.TrangThaiChiTiet = P_1 ?? "";
	}

	private static string m_1737(string P_0)
	{
		if (string.IsNullOrEmpty(P_0))
		{
			return P_0 ?? "";
		}
		if (P_0.Contains("Call log:") || (P_0.Contains("Timeout") && P_0.Contains("exceeded")))
		{
			return "Dừng chrome sớm hơn dự tính";
		}
		return P_0;
	}

	private void t(object P_0, RoutedEventArgs P_1)
	{
		m_1703?.Cancel();
		StopScriptButton.IsEnabled = false;
	}

	[SpecialName]
	private string G()
	{
		return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", PlatformKey.ToLowerInvariant() + "_column_order.json");
	}

	private void m_1738(object P_0, DataGridColumnEventArgs P_1)
	{
		g();
	}

	private void g()
	{
		try
		{
			List<string> value = (from P_0 in AccountGrid.Columns
				orderby P_0.DisplayIndex
				select P_0.Header?.ToString() ?? "" into P_0
				where P_0.Length > 0
				select P_0).ToList();
			Directory.CreateDirectory(Path.GetDirectoryName(G()));
			File.WriteAllText(G(), JsonSerializer.Serialize(value));
		}
		catch
		{
		}
	}

	private void H()
	{
		try
		{
			if (!File.Exists(G()))
			{
				return;
			}
			List<string> list = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(G()));
			if (list == null || list.Count == 0)
			{
				return;
			}
			int num = 0;
			foreach (string A in list)
			{
				DataGridColumn dataGridColumn = AccountGrid.Columns.FirstOrDefault((DataGridColumn P_0) => (P_0.Header?.ToString() ?? "") == A);
				if (dataGridColumn != null)
				{
					int val = AccountGrid.Columns.Count - 1;
					dataGridColumn.DisplayIndex = Math.Min(num, val);
					num++;
				}
			}
		}
		catch
		{
		}
	}

	private static ScrollViewer? m_1739(DependencyObject P_0)
	{
		int childrenCount = VisualTreeHelper.GetChildrenCount(P_0);
		for (int i = 0; i < childrenCount; i++)
		{
			DependencyObject child = VisualTreeHelper.GetChild(P_0, i);
			if (child is ScrollViewer result)
			{
				return result;
			}
			ScrollViewer scrollViewer = m_1739(child);
			if (scrollViewer != null)
			{
				return scrollViewer;
			}
		}
		return null;
	}

	private void U(object P_0, RoutedEventArgs P_1)
	{
		m_1739((DependencyObject)(object)AccountGrid)?.PageLeft();
	}

	private void u(object P_0, RoutedEventArgs P_1)
	{
		m_1739((DependencyObject)(object)AccountGrid)?.PageRight();
	}

	private void m_1740(object P_0, MouseButtonEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = true;
	}

	private void V(object P_0, RoutedEventArgs P_1)
	{
		bool flag = ToolbarWrapPanel.Visibility == Visibility.Visible;
		ToolbarWrapPanel.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		ToolbarCollapseToggleIcon.Text = (flag ? "▽" : "△");
	}

	[SpecialName]
	private string h()
	{
		return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", PlatformKey.ToLowerInvariant() + "_columns.json");
	}

	private void v(object P_0, RoutedEventArgs P_1)
	{
		if (ColumnTogglePanel.Children.Count == 0)
		{
			foreach (DataGridColumn A in AccountGrid.Columns)
			{
				CheckBox checkBox = new CheckBox
				{
					IsChecked = (A.Visibility == Visibility.Visible),
					VerticalAlignment = VerticalAlignment.Center
				};
				checkBox.Checked += delegate
				{
					A.Visibility = Visibility.Visible;
					I();
				};
				checkBox.Unchecked += delegate
				{
					A.Visibility = Visibility.Collapsed;
					I();
				};
				TextBlock element = new TextBlock
				{
					Text = A.Header?.ToString(),
					Margin = new Thickness(8.0, 0.0, 0.0, 0.0),
					VerticalAlignment = VerticalAlignment.Center
				};
				StackPanel stackPanel = new StackPanel
				{
					Orientation = Orientation.Horizontal,
					Margin = new Thickness(6.0, 4.0, 6.0, 4.0)
				};
				stackPanel.Children.Add(checkBox);
				stackPanel.Children.Add(element);
				ColumnTogglePanel.Children.Add(stackPanel);
			}
		}
		m_1723(ColumnConfigPopup, P_0, ColumnConfigButton);
	}

	private void I()
	{
		try
		{
			List<string> value = (from P_0 in AccountGrid.Columns
				where P_0.Visibility != Visibility.Visible
				select P_0.Header?.ToString() ?? "" into P_0
				where P_0.Length > 0
				select P_0).ToList();
			Directory.CreateDirectory(Path.GetDirectoryName(h()));
			File.WriteAllText(h(), JsonSerializer.Serialize(value));
		}
		catch
		{
		}
	}

	private void i()
	{
		try
		{
			if (!File.Exists(h()))
			{
				foreach (DataGridColumn column in AccountGrid.Columns)
				{
					string item = column.Header?.ToString() ?? "";
					column.Visibility = ((!b.Contains(item)) ? Visibility.Collapsed : Visibility.Visible);
				}
				return;
			}
			List<string> list = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(h()));
			if (list == null)
			{
				return;
			}
			foreach (DataGridColumn column2 in AccountGrid.Columns)
			{
				string item2 = column2.Header?.ToString() ?? "";
				column2.Visibility = (list.Contains(item2) ? Visibility.Collapsed : Visibility.Visible);
			}
		}
		catch
		{
		}
	}

	private bool m_1741(GoogleSheetsSyncSettings P_0)
	{
		if (P_0.Enabled && !string.IsNullOrWhiteSpace(P_0.SpreadsheetId) && !string.IsNullOrWhiteSpace(P_0.ClientId))
		{
			return !string.IsNullOrWhiteSpace(P_0.ClientSecret);
		}
		return false;
	}

	private void m_1742(Func<SheetsService, GoogleSheetsSyncSettings, Task> P_0)
	{
		GoogleSheetsSyncSettings A = GoogleSheetsSyncSettings.Load(PlatformKey);
		if (!m_1741(A))
		{
			return;
		}
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				using SheetsService arg = await GoogleSheetsSyncService.AuthorizeAsync(A, CancellationToken.None);
				await P_0(arg, A);
			}
			catch (Exception ex)
			{
				Exception ex2 = ex;
				Exception A2 = ex2;
				((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
				{
					CustomMessageBox.Show(this.A, "Đồng bộ Google Sheets thất bại: " + A2.Message, "Đồng bộ Google Sheets", NotifyType.Warning);
				}));
			}
		});
	}

	private void m_1743(int P_0, string P_1)
	{
		List<PlatformAccountRow> m_1965 = Accounts.Where((PlatformAccountRow platformAccountRow) => platformAccountRow.FolderId == P_0).ToList();
		m_1742((SheetsService service, GoogleSheetsSyncSettings googleSheetsSyncSettings) => GoogleSheetsSyncService.SyncFolderAsync(service, googleSheetsSyncSettings.SpreadsheetId, P_1, GoogleSheetsSyncService.BuildRows(m_1965), CancellationToken.None));
	}

	private void m_1744(string P_0)
	{
		m_1742((SheetsService service, GoogleSheetsSyncSettings googleSheetsSyncSettings) => GoogleSheetsSyncService.DeleteFolderSheetAsync(service, googleSheetsSyncSettings.SpreadsheetId, P_0, CancellationToken.None));
	}

	private void m_1745(string P_0, string P_1)
	{
		m_1742((SheetsService service, GoogleSheetsSyncSettings googleSheetsSyncSettings) => GoogleSheetsSyncService.RenameFolderSheetAsync(service, googleSheetsSyncSettings.SpreadsheetId, P_0, P_1, CancellationToken.None));
	}

	private void m_1746(int P_0)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Expected Obj, but got Unknown
		GoogleSheetsSyncSettings googleSheetsSyncSettings = GoogleSheetsSyncSettings.Load(PlatformKey);
		if (!m_1741(googleSheetsSyncSettings))
		{
			return;
		}
		m_1710.Add(P_0);
		if (m_1711 == null)
		{
			m_1711 = new DispatcherTimer
			{
				Interval = TimeSpan.FromSeconds(10L)
			};
			m_1711.Tick += delegate
			{
				m_1711.Stop();
				J();
			};
		}
		m_1711.Stop();
		m_1711.Start();
	}

	private void J()
	{
		if (m_1710.Count == 0)
		{
			return;
		}
		List<(int Id, string Name)> m_1970 = (from P_0 in m_1710
			select Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == P_0) into P_0
			where P_0 != null
			select (Id: P_0.Id, Name: P_0.Name)).ToList();
		m_1710.Clear();
		if (m_1970.Count == 0)
		{
			return;
		}
		Dictionary<int, List<PlatformAccountRow>> m_1971 = m_1970.ToDictionary(((int Id, string Name) t) => t.Id, ((int Id, string Name) t) => Accounts.Where((PlatformAccountRow P_0) => P_0.FolderId == t.Id).ToList());
		m_1742(async (SheetsService P_0, GoogleSheetsSyncSettings P_1) =>
		{
			foreach (var (key, folderName) in m_1970)
			{
				await GoogleSheetsSyncService.SyncFolderAsync(P_0, P_1.SpreadsheetId, folderName, GoogleSheetsSyncService.BuildRows(m_1971[key]), CancellationToken.None);
			}
		});
	}

	public void FlushGoogleSheetsSyncPending()
	{
		J();
	}

	private void W(object P_0, RoutedEventArgs P_1)
	{
		NickSettingsPopup.IsOpen = true;
	}

	private void w(object P_0, RoutedEventArgs P_1)
	{
		NickSettingsPopup.IsOpen = false;
		QuickActionsPopup.IsOpen = false;
		GoogleSheetsSyncWindow googleSheetsSyncWindow = new GoogleSheetsSyncWindow(PlatformKey, DisplayTitle);
		googleSheetsSyncWindow.Owner = A;
		googleSheetsSyncWindow.ShowDialog();
	}

	private async void X(object P_0, RoutedEventArgs P_1)
	{
		ExportImportFilePopup.IsOpen = false;
		GoogleSheetsSyncSettings googleSheetsSyncSettings = GoogleSheetsSyncSettings.Load(PlatformKey);
		if (string.IsNullOrWhiteSpace(googleSheetsSyncSettings.SpreadsheetId) || string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientId) || string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientSecret))
		{
			CustomMessageBox.Show(this.A, "Chưa cấu hình Google Trang tính. Vào \"Cài đặt > Cài đặt đồng bộ Google Sheets\" để thiết lập trước.", "Nạp từ Google Trang tính", NotifyType.Warning);
			return;
		}
		ExportImportFileButton.IsEnabled = false;
		try
		{
			using SheetsService service = await GoogleSheetsSyncService.AuthorizeAsync(googleSheetsSyncSettings, CancellationToken.None);
			Dictionary<string, List<PlatformAccountRow>> dictionary = await GoogleSheetsSyncService.ImportAllSheetsAsPlatformRowsAsync(service, googleSheetsSyncSettings.SpreadsheetId, CancellationToken.None);
			int num = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.IsSystem && nickFolder3.Id > 0)?.Id ?? (-1);
			int num2 = 0;
			int num3 = 0;
			foreach (KeyValuePair<string, List<PlatformAccountRow>> A in dictionary)
			{
				if (A.Value.Count == 0)
				{
					continue;
				}
				NickFolder nickFolder = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.Id > 0 && nickFolder3.Name == A.Key);
				if (nickFolder == null)
				{
					try
					{
						NickFolder nickFolder2 = m_1696.CreateFolder(A.Key);
						Folders.Insert(Folders.Count - 1, nickFolder2);
						nickFolder = nickFolder2;
					}
					catch
					{
					}
				}
				int folderId = nickFolder?.Id ?? num;
				num3++;
				foreach (PlatformAccountRow A2 in A.Value)
				{
					if (!string.IsNullOrWhiteSpace(A2.ScriptName))
					{
						ScriptItem scriptItem = m_1705.FirstOrDefault((ScriptItem scriptItem2) => scriptItem2.Name == A2.ScriptName);
						A2.ScriptId = scriptItem?.Id ?? 0;
					}
					A2.Index = D();
					A2.FolderId = folderId;
					A2.PropertyChanged += m_1728;
					Accounts.Add(A2);
					num2++;
				}
			}
			m_1725();
			m_1726();
			if (num2 == 0)
			{
				CustomMessageBox.Show(this.A, "Không tìm thấy nick nào trong Google Trang tính.", "Nạp từ Google Trang tính", NotifyType.Warning);
				return;
			}
			CustomMessageBox.Show(this.A, $"Đã nạp {num2} nick từ {num3} trang tính (thư mục).", "Nạp từ Google Trang tính");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this.A, "Không thể nạp từ Google Trang tính: " + ex.Message, "Nạp từ Google Trang tính", NotifyType.Warning);
		}
		finally
		{
			ExportImportFileButton.IsEnabled = true;
		}
	}

	[CompilerGenerated]
	private void m_1749(object? _, NotifyCollectionChangedEventArgs P_1)
	{
		PopulateScriptToolbar();
	}

	[CompilerGenerated]
	private void x(object P_0, RoutedEventArgs P_1)
	{
		LoadFromDatabase();
		H();
		i();
	}

	[CompilerGenerated]
	private void m_1750(object? _, EventArgs P_1)
	{
		m_1707.Stop();
		m_1726();
	}

	[CompilerGenerated]
	private void m_1751(object? _, EventArgs P_1)
	{
		m_1699.Stop();
		m_1696.SaveAll(Accounts);
	}

	[CompilerGenerated]
	private PlatformAccountExportItem m_1752(PlatformAccountRow P_0)
	{
		return new PlatformAccountExportItem
		{
			FolderName = (Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == P_0.FolderId)?.Name ?? ""),
			Uid = P_0.Uid,
			Pass = P_0.Pass,
			TwoFA = P_0.TwoFA,
			Token = P_0.Token,
			Cookie = P_0.Cookie,
			Mail = P_0.Mail,
			PassMail = P_0.PassMail,
			MailKhoiPhuc = P_0.MailKhoiPhuc,
			ProfileChrome = P_0.ProfileChrome,
			TenProfile = P_0.TenProfile,
			Proxy = P_0.Proxy,
			GhiChu = P_0.GhiChu,
			TrangThai = P_0.TrangThai,
			TinhTrang = P_0.TinhTrang
		};
	}

	[CompilerGenerated]
	private bool m_1753(ScriptItem P_0)
	{
		return P_0.ChuDe == PlatformKey;
	}

	[CompilerGenerated]
	private bool m_1754(ScriptItem P_0)
	{
		return P_0.ChuDe == PlatformKey;
	}

	[CompilerGenerated]
	private void m_1755(object? _, EventArgs P_1)
	{
		m_1711.Stop();
		J();
	}
}
