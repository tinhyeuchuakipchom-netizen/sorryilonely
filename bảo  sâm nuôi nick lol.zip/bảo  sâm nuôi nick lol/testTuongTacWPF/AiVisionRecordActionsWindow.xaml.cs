using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class AiVisionRecordActionsWindow : Window, IComponentConnector, IStyleConnector
{
	[CompilerGenerated]
	private sealed class m_217
	{
		public AiVisionRecordActionsWindow A;

		public LiveRecordedAction m_231;

		internal void m_232()
		{
			if (A.m_186)
			{
				A.m_191();
				A.RecordedSteps.Add(new AiVisionFlowStep
				{
					Type = AiVisionStepType.Text,
					Text = (m_231.Value ?? ""),
					IsMarkedComplete = true
				});
			}
		}

		internal void a()
		{
			if (A.m_186)
			{
				A.m_191();
				A.RecordedSteps.Add(new AiVisionFlowStep
				{
					Type = AiVisionStepType.Goto,
					Url = (m_231.Url ?? ""),
					IsMarkedComplete = true
				});
			}
		}

		internal void B()
		{
			if (A.m_186)
			{
				A.m_191();
				A.RecordedSteps.Add(new AiVisionFlowStep
				{
					Type = AiVisionStepType.Scroll,
					X = m_231.X,
					Y = m_231.Y,
					X2 = m_231.DeltaX,
					Y2 = m_231.DeltaY,
					IsMarkedComplete = true
				});
			}
		}

		internal void b()
		{
			if (A.m_186)
			{
				A.m_191();
				A.RecordedSteps.Add(new AiVisionFlowStep
				{
					Type = AiVisionStepType.KeyPress,
					Text = (m_231.Value ?? ""),
					IsMarkedComplete = true
				});
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_218
	{
		public AiVisionRecordActionsWindow A;

		public AiVisionFlowStep m_233;

		internal void m_234()
		{
			if (A.m_186)
			{
				A.m_191();
				A.RecordedSteps.Add(m_233);
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_219
	{
		public string A;

		public AiVisionRecordActionsWindow m_235;

		internal void m_236(object P_0, RoutedEventArgs P_1)
		{
			m_235.m_210(A);
		}
	}

	private readonly IMarkStepsDeviceAdapter A;

	private readonly IReadOnlyList<AiVisionFlowStep> m_176;

	[CompilerGenerated]
	private readonly ObservableCollection<AiVisionFlowStep> m_177 = new ObservableCollection<AiVisionFlowStep>();

	private List<UiElement> m_178 = new List<UiElement>();

	private BitmapImage? m_179;

	private bool m_180;

	private Point? m_181;

	private (int RealX, int RealY)? m_182;

	private Line? m_183;

	private const double m_184 = 0.1;

	private const double a = 2.0;

	private const double B = 0.2;

	private double b = 0.2;

	private const int m_185 = 12;

	private bool m_186;

	private DateTime? m_187;

	private static readonly string[] m_188 = new string[18]
	{
		"{{Uid}}", "{{Pass}}", "{{Mail}}", "{{PassMail}}", "{{MailKhoiPhuc}}", "{{HoTen}}", "{{TwoFA}}", "{{TwoFaCode}}", "{{GhiChu}}", "{{Cookie}}",
		"{{Token}}", "{{PhoneName}}", "{{Proxy}}", "{{VerifyMail}}", "{{VerifyPhone}}", "{{RandomSo}}", "{{RandomChu}}", "{{RandomSoChu}}"
	};

	private bool m_189;

	public ObservableCollection<AiVisionFlowStep> RecordedSteps
	{
		[CompilerGenerated]
		get
		{
			return m_177;
		}
	}

	public AiVisionRecordActionsWindow(IMarkStepsDeviceAdapter adapter, IReadOnlyList<AiVisionFlowStep> allSteps)
	{
		InitializeComponent();
		A = adapter;
		m_176 = allSteps;
		RecordedStepsListBox.ItemsSource = RecordedSteps;
		RecordedSteps.CollectionChanged += delegate
		{
			RecordedCountText.Text = $"{RecordedSteps.Count} bước";
		};
		LiveRecordToggleButton.Visibility = ((!A.SupportsLiveRecording) ? Visibility.Collapsed : Visibility.Visible);
		m_203(0.2);
		Closed += async delegate
		{
			if (m_186)
			{
				await A.StopLiveRecordingAsync(CancellationToken.None);
			}
		};
	}

	private async void m_190(object P_0, RoutedEventArgs P_1)
	{
		m_186 = !m_186;
		if (m_186)
		{
			LiveRecordToggleButton.Content = "⏺ Đang ghi... (bấm để dừng)";
			LiveRecordToggleButton.Background = new SolidColorBrush(Color.FromRgb(239, 68, 68));
			ModeHintText.Text = "Đang ghi trực tiếp - cứ thao tác (click/gõ chữ) THẬT trên cửa sổ Chrome đang mở, mỗi lần sẽ tự thành 1 bước ở cột bên phải. Bấm \"⏺ Đang ghi...\" lần nữa để dừng.";
			m_187 = null;
			try
			{
				await A.StartLiveRecordingAsync(m_192, CancellationToken.None);
				return;
			}
			catch (Exception ex)
			{
				m_186 = false;
				LiveRecordToggleButton.Content = "\ud83d\udd34 Ghi trực tiếp";
				LiveRecordToggleButton.Background = (Brush)FindResource("BrushGreen");
				CustomMessageBox.Show(this, "Không bật được ghi trực tiếp: " + ex.Message, "Lỗi", NotifyType.Warning);
				return;
			}
		}
		LiveRecordToggleButton.Content = "\ud83d\udd34 Ghi trực tiếp";
		LiveRecordToggleButton.Background = (Brush)FindResource("BrushGreen");
		ModeHintText.Text = "Bấm \"Làm mới\" để chụp màn hình hiện tại, rồi bấm/kéo vuốt/gõ chữ trên ảnh - từng thao tác thực thi ngay trên máy và tự ghi thành bước. Bấm \"Làm mới\" lại sau mỗi thao tác để thấy đúng trạng thái mới trước khi làm bước tiếp theo.";
		await A.StopLiveRecordingAsync(CancellationToken.None);
	}

	private void m_191()
	{
		DateTime utcNow = DateTime.UtcNow;
		if (m_187.HasValue)
		{
			int num = (int)(utcNow - m_187.Value).TotalMilliseconds;
			if (num > 800)
			{
				int randomMinMs = Math.Max(300, num - 500);
				int randomMaxMs = num + 500;
				RecordedSteps.Add(new AiVisionFlowStep
				{
					Type = AiVisionStepType.RandomWait,
					RandomMinMs = randomMinMs,
					RandomMaxMs = randomMaxMs
				});
			}
		}
		m_187 = utcNow;
	}

	private void m_192(LiveRecordedAction P_0)
	{
		switch (P_0.Kind)
		{
		case LiveRecordedActionKind.Tap:
			m_193(P_0);
			break;
		case LiveRecordedActionKind.Text:
			((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
			{
				if (m_186)
				{
					m_191();
					RecordedSteps.Add(new AiVisionFlowStep
					{
						Type = AiVisionStepType.Text,
						Text = (P_0.Value ?? ""),
						IsMarkedComplete = true
					});
				}
			}));
			break;
		case LiveRecordedActionKind.Navigate:
			((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
			{
				if (m_186)
				{
					m_191();
					RecordedSteps.Add(new AiVisionFlowStep
					{
						Type = AiVisionStepType.Goto,
						Url = (P_0.Url ?? ""),
						IsMarkedComplete = true
					});
				}
			}));
			break;
		case LiveRecordedActionKind.Scroll:
			((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
			{
				if (m_186)
				{
					m_191();
					RecordedSteps.Add(new AiVisionFlowStep
					{
						Type = AiVisionStepType.Scroll,
						X = P_0.X,
						Y = P_0.Y,
						X2 = P_0.DeltaX,
						Y2 = P_0.DeltaY,
						IsMarkedComplete = true
					});
				}
			}));
			break;
		case LiveRecordedActionKind.KeyPress:
			((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
			{
				if (m_186)
				{
					m_191();
					RecordedSteps.Add(new AiVisionFlowStep
					{
						Type = AiVisionStepType.KeyPress,
						Text = (P_0.Value ?? ""),
						IsMarkedComplete = true
					});
				}
			}));
			break;
		}
	}

	private async Task m_193(LiveRecordedAction P_0)
	{
		string resourceId = P_0.ResourceId;
		string contentDesc = P_0.ContentDesc;
		string text = P_0.ElementText;
		if (string.IsNullOrWhiteSpace(resourceId) && string.IsNullOrWhiteSpace(contentDesc) && string.IsNullOrWhiteSpace(text))
		{
			try
			{
				UiElement uiElement = m_211(await A.DumpElementsAsync(CancellationToken.None), P_0.X, P_0.Y);
				if (uiElement != null)
				{
					resourceId = uiElement.ResourceId;
					contentDesc = uiElement.ContentDesc;
					text = uiElement.Text;
				}
			}
			catch
			{
			}
		}
		AiVisionFlowStep m_233 = new AiVisionFlowStep
		{
			Type = AiVisionStepType.Tap,
			X = P_0.X,
			Y = P_0.Y,
			ResourceId = resourceId,
			ContentDesc = contentDesc,
			ElementText = text,
			IsMarkedComplete = true
		};
		((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
		{
			if (m_186)
			{
				m_191();
				RecordedSteps.Add(m_233);
			}
		}));
	}

	private async Task m_194()
	{
		if (m_180)
		{
			return;
		}
		m_197(true);
		try
		{
			byte[] buffer = await A.CaptureScreenshotAsync(CancellationToken.None);
			m_178 = await A.DumpElementsAsync(CancellationToken.None);
			BitmapImage bitmapImage = new BitmapImage();
			using (MemoryStream streamSource = new MemoryStream(buffer))
			{
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = streamSource;
				bitmapImage.EndInit();
				((Freezable)bitmapImage).Freeze();
			}
			m_179 = bitmapImage;
			ScreenImage.Source = bitmapImage;
			NoImageHintText.Visibility = Visibility.Collapsed;
			m_198();
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Lỗi chụp màn hình: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
		finally
		{
			m_197(false);
		}
	}

	private void m_195(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_196(object P_0, RoutedEventArgs P_1)
	{
		WindowState = WindowState.Minimized;
	}

	private void m_197(bool P_0)
	{
		m_180 = P_0;
		BusyOverlay.Visibility = ((!P_0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void m_198()
	{
		if (m_179 != null && !(ScreenImage.ActualWidth <= 0.0) && !(ScreenImage.ActualHeight <= 0.0))
		{
			InteractionCanvas.Width = ScreenImage.ActualWidth;
			InteractionCanvas.Height = ScreenImage.ActualHeight;
		}
	}

	private void m_199(object P_0, SizeChangedEventArgs P_1)
	{
		m_198();
	}

	private async void m_200(object P_0, RoutedEventArgs P_1)
	{
		await m_194();
	}

	private void m_201(object P_0, RoutedEventArgs P_1)
	{
		m_203(b + 0.1);
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		m_203(b - 0.1);
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		m_203(0.2);
	}

	private void m_202(object P_0, MouseWheelEventArgs P_1)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Invalid comparison between Unknown and I4
		if ((int)Keyboard.Modifiers == 2)
		{
			P_1.Handled = true;
			m_203(b + ((P_1.Delta > 0) ? 0.05 : (-0.05)));
		}
	}

	private void m_203(double P_0)
	{
		b = Math.Clamp(P_0, 0.1, 2.0);
		ScreenZoomTransform.ScaleX = b;
		ScreenZoomTransform.ScaleY = b;
		ZoomLevelText.Text = $"{b * 100.0:0}%";
	}

	private (int RealX, int RealY)? m_204(Point P_0)
	{
		if (m_179 == null || InteractionCanvas.Width <= 0.0 || InteractionCanvas.Height <= 0.0)
		{
			return null;
		}
		double num = (double)m_179.PixelWidth / InteractionCanvas.Width;
		double num2 = (double)m_179.PixelHeight / InteractionCanvas.Height;
		int value = (int)Math.Round(P_0.X * num);
		return new ValueTuple<int, int>(item2: Math.Clamp((int)Math.Round(P_0.Y * num2), 0, m_179.PixelHeight - 1), item1: Math.Clamp(value, 0, m_179.PixelWidth - 1));
	}

	private void m_205(object P_0, MouseButtonEventArgs P_1)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (!m_180 && P_1.ChangedButton == MouseButton.Left)
		{
			Point position = P_1.GetPosition(InteractionCanvas);
			(int, int)? tuple = m_204(position);
			if (tuple.HasValue)
			{
				m_181 = position;
				m_182 = tuple;
				InteractionCanvas.CaptureMouse();
				m_183 = new Line
				{
					X1 = position.X,
					Y1 = position.Y,
					X2 = position.X,
					Y2 = position.Y,
					Stroke = new SolidColorBrush(Color.FromRgb(139, 92, 246)),
					StrokeThickness = 3.0,
					StrokeDashArray = new DoubleCollection { 2.0, 2.0 }
				};
				InteractionCanvas.Children.Add(m_183);
			}
		}
	}

	private void m_206(object P_0, MouseEventArgs P_1)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		if (m_181.HasValue && m_183 != null)
		{
			Point position = P_1.GetPosition(InteractionCanvas);
			m_183.X2 = position.X;
			m_183.Y2 = position.Y;
		}
	}

	private async void m_207(object P_0, MouseButtonEventArgs P_1)
	{
		if (!m_181.HasValue || !m_182.HasValue || P_1.ChangedButton != MouseButton.Left)
		{
			return;
		}
		InteractionCanvas.ReleaseMouseCapture();
		Point position = P_1.GetPosition(InteractionCanvas);
		(int, int)? tuple = m_204(position);
		if (m_183 != null)
		{
			InteractionCanvas.Children.Remove(m_183);
			m_183 = null;
		}
		Point value = m_181.Value;
		(int, int) value2 = m_182.Value;
		m_181 = null;
		m_182 = null;
		if (tuple.HasValue)
		{
			(int, int) value3 = tuple.Value;
			if (Math.Sqrt((position.X - value.X) * (position.X - value.X) + (position.Y - value.Y) * (position.Y - value.Y)) >= 12.0)
			{
				await m_209(value2.Item1, value2.Item2, value3.Item1, value3.Item2);
			}
			else
			{
				await m_208(value2.Item1, value2.Item2);
			}
		}
	}

	private async Task m_208(int P_0, int P_1)
	{
		m_197(true);
		try
		{
			var (num, num2) = await A.ToDeviceCoordinatesAsync(P_0, P_1, CancellationToken.None);
			await A.TapAsync(num, num2, CancellationToken.None);
			UiElement uiElement = m_211(m_178, num, num2);
			RecordedSteps.Add(new AiVisionFlowStep
			{
				Type = AiVisionStepType.Tap,
				X = num,
				Y = num2,
				ResourceId = uiElement?.ResourceId,
				ContentDesc = uiElement?.ContentDesc,
				ElementText = uiElement?.Text,
				IsMarkedComplete = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Lỗi thực thi Tap: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
		finally
		{
			m_197(false);
		}
	}

	private async Task m_209(int P_0, int P_1, int P_2, int P_3)
	{
		m_197(true);
		try
		{
			var (num, num2) = await A.ToDeviceCoordinatesAsync(P_0, P_1, CancellationToken.None);
			var (x, y) = await A.ToDeviceCoordinatesAsync(P_2, P_3, CancellationToken.None);
			await A.SwipeAsync(num, num2, x, y, CancellationToken.None);
			RecordedSteps.Add(new AiVisionFlowStep
			{
				Type = AiVisionStepType.Swipe,
				X = num,
				Y = num2,
				X2 = x,
				Y2 = y,
				IsMarkedComplete = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Lỗi thực thi Swipe: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
		finally
		{
			m_197(false);
		}
	}

	private void D(object P_0, RoutedEventArgs P_1)
	{
		ContextMenu contextMenu = new ContextMenu
		{
			Style = (Style)FindResource("AppContextMenuStyle"),
			PlacementTarget = InsertVariableButton
		};
		string[] array = m_188;
		foreach (string A in array)
		{
			MenuItem menuItem = new MenuItem
			{
				Header = A
			};
			menuItem.Click += delegate
			{
				m_210(A);
			};
			contextMenu.Items.Add(menuItem);
		}
		contextMenu.IsOpen = true;
	}

	private void m_210(string P_0)
	{
		int selectionStart = TextInputBox.SelectionStart;
		TextInputBox.Text = TextInputBox.Text.Insert(selectionStart, P_0);
		TextInputBox.SelectionStart = selectionStart + P_0.Length;
		TextInputBox.Focus();
	}

	private async void d(object P_0, RoutedEventArgs P_1)
	{
		string text = TextInputBox.Text;
		if (string.IsNullOrWhiteSpace(text))
		{
			CustomMessageBox.Show(this, "Vui lòng nhập văn bản trước khi bấm Gõ.", "Thông báo", NotifyType.Warning);
			return;
		}
		m_197(true);
		try
		{
			await A.TypeTextAsync(text, CancellationToken.None);
			RecordedSteps.Add(new AiVisionFlowStep
			{
				Type = AiVisionStepType.Text,
				Text = text,
				IsMarkedComplete = true
			});
			TextInputBox.Clear();
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Lỗi gõ chữ: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
		finally
		{
			m_197(false);
		}
	}

	private void E(object P_0, RoutedEventArgs P_1)
	{
		AiVisionFlowStep item = new AiVisionFlowStep
		{
			Type = AiVisionStepType.RandomWait,
			RandomMinMs = 1000,
			RandomMaxMs = 3000
		};
		RecordedSteps.Add(item);
	}

	private void e(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.Tag is AiVisionFlowStep item)
		{
			RecordedSteps.Remove(item);
		}
	}

	private void F(object P_0, RoutedEventArgs P_1)
	{
		if (RecordedSteps.Count != 0 && CustomMessageBox.Confirm(this, "Bạn có chắc chắn muốn xóa toàn bộ các bước vừa ghi?", "Xác nhận"))
		{
			RecordedSteps.Clear();
		}
	}

	private void f(object P_0, RoutedEventArgs P_1)
	{
		if (RecordedSteps.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa ghi nhận bước nào.", "Thông báo", NotifyType.Warning);
			return;
		}
		DialogResult = true;
		Close();
	}

	private void G(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	private static UiElement? m_211(List<UiElement> P_0, int P_1, int P_2)
	{
		if (P_0 == null || P_0.Count == 0)
		{
			return null;
		}
		UiElement result = null;
		double num = 80.0;
		foreach (UiElement item in P_0)
		{
			double num2 = Math.Sqrt((item.CenterX - P_1) * (item.CenterX - P_1) + (item.CenterY - P_2) * (item.CenterY - P_2));
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	[CompilerGenerated]
	private void m_214(object? s, NotifyCollectionChangedEventArgs P_1)
	{
		RecordedCountText.Text = $"{RecordedSteps.Count} bước";
	}

	[CompilerGenerated]
	private async void m_215(object? _, EventArgs P_1)
	{
		if (m_186)
		{
			await A.StopLiveRecordingAsync(CancellationToken.None);
		}
	}
}
