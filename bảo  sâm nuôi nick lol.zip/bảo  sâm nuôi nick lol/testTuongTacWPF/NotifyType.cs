namespace testTuongTacWPF;

public enum NotifyType
{
	Success,
	Warning
}
