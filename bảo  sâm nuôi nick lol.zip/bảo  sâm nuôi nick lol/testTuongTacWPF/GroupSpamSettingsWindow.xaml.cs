using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class GroupSpamSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private GroupSpamSettingsWindow(GroupSpamSettings P_0)
	{
		InitializeComponent();
		string groupSource = P_0.GroupSource;
		((groupSource == "ExistingInAccount") ? GroupSourceExistingRadio : ((!(groupSource == "SearchAndJoin")) ? GroupSourceInputLinksRadio : GroupSourceSearchRadio)).IsChecked = true;
		GroupLinksTextBox.Text = string.Join("\n", P_0.GroupLinks);
		SearchKeywordTextBox.Text = P_0.SearchKeyword;
		MaxGroupsToJoinTextBox.Text = P_0.MaxGroupsToJoin.ToString();
		((P_0.FindMode == "RefreshWait") ? FindModeRefreshRadio : FindModeScrollRadio).IsChecked = true;
		MinMinutesTextBox.Text = P_0.MinMinutes.ToString();
		MaxMinutesTextBox.Text = P_0.MaxMinutes.ToString();
		MinCommentSpacingSecondsTextBox.Text = P_0.MinCommentSpacingSeconds.ToString();
		MaxCommentSpacingSecondsTextBox.Text = P_0.MaxCommentSpacingSeconds.ToString();
		CommentTextsTextBox.Text = string.Join("\n", P_0.CommentTexts);
		m_394();
	}

	private void m_392(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_393(object P_0, RoutedEventArgs P_1)
	{
		m_394();
	}

	private void m_394()
	{
		if (GroupLinksPanel != null)
		{
			GroupLinksPanel.Visibility = ((GroupSourceInputLinksRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			GroupSearchPanel.Visibility = ((GroupSourceSearchRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void m_395(object P_0, RoutedEventArgs P_1)
	{
		if (!m_396(out GroupSpamSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_396(out GroupSpamSettings P_0, out string P_1)
	{
		P_0 = new GroupSpamSettings();
		P_1 = "";
		string text;
		if (GroupSourceExistingRadio.IsChecked == true)
		{
			text = "ExistingInAccount";
		}
		else
		{
			text = ((GroupSourceSearchRadio.IsChecked == true) ? "SearchAndJoin" : "InputLinks");
		}
		List<string> list = GroupLinksTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (text == "InputLinks" && list.Count == 0)
		{
			P_1 = "Chưa nhập link nhóm nào.";
			return false;
		}
		if (text == "SearchAndJoin")
		{
			if (string.IsNullOrWhiteSpace(SearchKeywordTextBox.Text))
			{
				P_1 = "Chưa nhập từ khoá tìm nhóm.";
				return false;
			}
			if (!int.TryParse(MaxGroupsToJoinTextBox.Text.Trim(), out var result) || result < 1)
			{
				P_1 = "\"Tối đa tham gia\" phải là 1 số nguyên dương.";
				return false;
			}
		}
		if (!int.TryParse(MinMinutesTextBox.Text.Trim(), out var result2) || result2 < 1)
		{
			P_1 = "\"Từ\" (phút) phải là 1 số nguyên dương.";
			return false;
		}
		if (!int.TryParse(MaxMinutesTextBox.Text.Trim(), out var result3) || result3 < result2)
		{
			P_1 = "\"Đến\" (phút) phải là 1 số nguyên >= \"Từ\".";
			return false;
		}
		if (!int.TryParse(MinCommentSpacingSecondsTextBox.Text.Trim(), out var result4) || result4 < 0)
		{
			P_1 = "\"Từ\" (giây, khoảng cách bình luận) phải là 1 số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(MaxCommentSpacingSecondsTextBox.Text.Trim(), out var result5) || result5 < result4)
		{
			P_1 = "\"Đến\" (giây, khoảng cách bình luận) phải là 1 số nguyên >= \"Từ\".";
			return false;
		}
		P_0.GroupSource = text;
		P_0.GroupLinks = list;
		P_0.SearchKeyword = SearchKeywordTextBox.Text.Trim();
		P_0.MaxGroupsToJoin = ((text == "SearchAndJoin") ? int.Parse(MaxGroupsToJoinTextBox.Text.Trim()) : P_0.MaxGroupsToJoin);
		P_0.FindMode = ((FindModeRefreshRadio.IsChecked == true) ? "RefreshWait" : "Scroll");
		P_0.MinMinutes = result2;
		P_0.MaxMinutes = result3;
		P_0.MinCommentSpacingSeconds = result4;
		P_0.MaxCommentSpacingSeconds = result5;
		P_0.CommentTexts = CommentTextsTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		return true;
	}

	public static GroupSpamSettings? Show(Window? owner, GroupSpamSettings initial)
	{
		GroupSpamSettingsWindow groupSpamSettingsWindow = new GroupSpamSettingsWindow(initial);
		if (owner != null)
		{
			groupSpamSettingsWindow.Owner = owner;
		}
		groupSpamSettingsWindow.ShowDialog();
		if (!groupSpamSettingsWindow.A)
		{
			return null;
		}
		groupSpamSettingsWindow.m_396(out GroupSpamSettings result, out string _);
		return result;
	}
}
