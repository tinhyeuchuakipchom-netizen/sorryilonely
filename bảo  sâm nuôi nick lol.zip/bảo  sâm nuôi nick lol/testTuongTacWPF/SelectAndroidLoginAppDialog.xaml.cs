using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;

namespace testTuongTacWPF;

public partial class SelectAndroidLoginAppDialog : Window, IComponentConnector
{
	private bool A;

	public string SelectedPackageType
	{
		get
		{
			if (AppLiteRadio.IsChecked != true)
			{
				return "Katana";
			}
			return "Lite";
		}
	}

	public SelectAndroidLoginAppDialog(Window? owner = null)
	{
		InitializeComponent();
		if (owner != null)
		{
			Owner = owner;
		}
	}

	private void m_2129(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2130(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = true;
		Close();
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}
}
