using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Licensing;

namespace testTuongTacWPF;

public partial class App : Application
{
	private static Mutex? A;

	private const int m_270 = 9;

	private static readonly Stopwatch m_271 = Stopwatch.StartNew();

	private static readonly StringBuilder m_272 = new StringBuilder();

	private bool m_273;

	[DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
	private static extern bool m_274(nint P_0);

	[DllImport("user32.dll", EntryPoint = "ShowWindow")]
	private static extern bool m_275(nint P_0, int P_1);

	private static bool m_276()
	{
		try
		{
			string name = "Local\\FastBoxPhone_SingleInstance";
			A = new Mutex(initiallyOwned: true, name, out var createdNew);
			if (!createdNew)
			{
				a();
				return false;
			}
			return true;
		}
		catch
		{
			return true;
		}
	}

	private static void a()
	{
		try
		{
			int id = Process.GetCurrentProcess().Id;
			string text = Process.GetCurrentProcess().MainModule?.FileName ?? "";
			string text2 = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(new char[2] { '\\', '/' });
			Process[] processesByName = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName);
			foreach (Process process in processesByName)
			{
				if (process.Id == id)
				{
					continue;
				}
				try
				{
					string text3 = process.MainModule?.FileName;
					if (!string.IsNullOrEmpty(text3) && (string.Equals(text3, text, StringComparison.OrdinalIgnoreCase) || string.Equals(Path.GetDirectoryName(text3)?.TrimEnd(new char[2] { '\\', '/' }), text2, StringComparison.OrdinalIgnoreCase)))
					{
						nint mainWindowHandle = process.MainWindowHandle;
						if (mainWindowHandle != IntPtr.Zero)
						{
							m_275(mainWindowHandle, 9);
							m_274(mainWindowHandle);
						}
						break;
					}
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
	}

	protected override void OnExit(ExitEventArgs e)
	{
		try
		{
			if (A != null)
			{
				A.ReleaseMutex();
				A.Dispose();
				A = null;
			}
		}
		catch
		{
		}
		base.OnExit(e);
	}

	internal static void m_277(string P_0)
	{
		StringBuilder stringBuilder = m_272;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(6, 2, stringBuilder);
		handler.AppendFormatted(m_271.ElapsedMilliseconds, 6);
		handler.AppendLiteral(" ms - ");
		handler.AppendFormatted(P_0);
		stringBuilder.AppendLine(ref handler);
	}

	private static void B()
	{
		try
		{
			string path = Path.Combine(AppContext.BaseDirectory, "dulieukhach", "startup_timing.txt");
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			File.WriteAllText(path, m_272.ToString());
		}
		catch
		{
		}
	}

	private static void b()
	{
		try
		{
			foreach (string item in Directory.EnumerateDirectories(Path.GetTempPath(), "FastBoxPhone_selfupdate_*"))
			{
				Directory.Delete(item, recursive: true);
			}
		}
		catch
		{
		}
	}

	private void m_278(object P_0, StartupEventArgs P_1)
	{
		if (P_1.Args.Length >= 2 && P_1.Args[0] == "--apply-update")
		{
			new UpdateApplyWindow(P_1.Args[1]).Show();
			return;
		}
		if (!m_276())
		{
			Shutdown();
			Environment.Exit(0);
			return;
		}
		try
		{
			SQLitePCL.Batteries_V2.Init();
			m_277("Application_Startup bắt đầu");
			b();
			UiPreferences uiPreferences = UiPreferences.Load();
			if (!uiPreferences.ThemeForcedToNeonV1)
			{
				uiPreferences.Theme = "Neon";
				uiPreferences.ThemeForcedToNeonV1 = true;
				uiPreferences.Save();
			}
			ThemeManager.Apply(uiPreferences.Theme);
			MainWindow mainWindow = (MainWindow)(MainWindow = new MainWindow());
			mainWindow.Closed += delegate
			{
				Shutdown();
			};
			mainWindow.Show();
			m_277("MainWindow.Show() xong");
			B();
		}
		catch (Exception ex)
		{
			try
			{
				File.WriteAllText(Path.Combine(AppContext.BaseDirectory, "startup_crash.txt"), ex.ToString());
			}
			catch
			{
			}
			MessageBox.Show(ex.ToString(), "FastBoxPhone không mở được");
			Shutdown();
		}
	}

	[CompilerGenerated]
	private void m_279(object? _, EventArgs P_1)
	{
		Shutdown();
	}
}
