using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace testTuongTacWPF;

public partial class AddProxyWindow : Window, IComponentConnector
{
	[CompilerGenerated]
	private static class m_55
	{
		public static Func<string, ProxyParseResult> A;
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class m_56
	{
		public static readonly m_56 A = new m_56();

		public static Func<string, string> m_58;

		public static Func<string, bool> m_59;

		public static Func<ProxyParseResult, bool> m_60;

		public static Func<ProxyParseResult, bool> a;

		public static Func<ProxyParseResult, bool> B;

		public static Func<ProxyParseResult, bool> b;

		public static Func<ProxyParseResult, bool> C;

		public static Func<ProxyParseResult, bool> c;

		public static Func<ProxyParseResult, string> m_61;

		public static Func<ProxyParseResult, bool> D;

		internal string m_62(string P_0)
		{
			return P_0.Trim('\r');
		}

		internal bool m_63(string P_0)
		{
			return P_0.Trim().Length > 0;
		}

		internal bool m_64(ProxyParseResult P_0)
		{
			return P_0.Kind == ProxyKind.IPv4;
		}

		internal bool m_65(ProxyParseResult P_0)
		{
			return P_0.Kind == ProxyKind.Domain;
		}

		internal bool m_66(ProxyParseResult P_0)
		{
			return P_0.Kind == ProxyKind.IPv6Single;
		}

		internal bool m_67(ProxyParseResult P_0)
		{
			return P_0.Kind == ProxyKind.IPv6Range;
		}

		internal bool m_68(ProxyParseResult P_0)
		{
			return !P_0.IsValid;
		}

		internal bool m_69(ProxyParseResult P_0)
		{
			return !P_0.IsValid;
		}

		internal string m_70(ProxyParseResult P_0)
		{
			return "\"" + P_0.OriginalLine + "\": " + P_0.Error;
		}

		internal bool d(ProxyParseResult P_0)
		{
			return P_0.IsValid;
		}
	}

	[CompilerGenerated]
	private sealed class m_57
	{
		public string A;

		internal string m_71(ProxyParseResult P_0)
		{
			return P_0.BuildProxyString(A);
		}
	}

	[CompilerGenerated]
	private readonly List<string> m_49 = new List<string>();

	private bool m_50;

	public List<string> ParsedProxies
	{
		[CompilerGenerated]
		get
		{
			return m_49;
		}
	}

	private string A
	{
		get
		{
			if (Socks5ProtocolRadio.IsChecked != true)
			{
				return "http";
			}
			return "socks5";
		}
	}

	public AddProxyWindow()
	{
		InitializeComponent();
	}

	private void m_51(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_52(object P_0, RoutedEventArgs P_1)
	{
		WindowState = WindowState.Minimized;
	}

	private List<ProxyParseResult> a()
	{
		return (from P_0 in ProxyTextBox.Text.Split('\n')
			select P_0.Trim('\r') into P_0
			where P_0.Trim().Length > 0
			select P_0).Select(ProxyParser.Parse).ToList();
	}

	private void m_53(object P_0, TextChangedEventArgs P_1)
	{
		List<ProxyParseResult> list = a();
		TotalCountText.Text = list.Count.ToString();
		IPv4CountText.Text = list.Count((ProxyParseResult proxyParseResult) => proxyParseResult.Kind == ProxyKind.IPv4).ToString();
		DomainCountText.Text = list.Count((ProxyParseResult proxyParseResult) => proxyParseResult.Kind == ProxyKind.Domain).ToString();
		IPv6CountText.Text = list.Count((ProxyParseResult proxyParseResult) => proxyParseResult.Kind == ProxyKind.IPv6Single).ToString();
		IPv6RangeCountText.Text = list.Count((ProxyParseResult proxyParseResult) => proxyParseResult.Kind == ProxyKind.IPv6Range).ToString();
		InvalidCountText.Text = list.Count((ProxyParseResult proxyParseResult) => !proxyParseResult.IsValid).ToString();
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		List<ProxyParseResult> list = a();
		List<ProxyParseResult> list2 = list.Where((ProxyParseResult proxyParseResult) => !proxyParseResult.IsValid).ToList();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa nhập proxy nào.", "Thêm Proxy", NotifyType.Warning);
			return;
		}
		if (list2.Count > 0)
		{
			string text = string.Join("\n", from proxyParseResult in list2.Take(5)
				select "\"" + proxyParseResult.OriginalLine + "\": " + proxyParseResult.Error);
			if (list2.Count > 5)
			{
				text += $"\n... và {list2.Count - 5} dòng lỗi khác.";
			}
			if (!CustomMessageBox.Confirm(this, $"Có {list2.Count} dòng sai định dạng, sẽ bị bỏ qua:\n{text}\n\nVẫn áp dụng {list.Count - list2.Count} proxy hợp lệ?", "Thêm Proxy"))
			{
				return;
			}
		}
		string A = this.A;
		ParsedProxies.Clear();
		ParsedProxies.AddRange(from proxyParseResult in list
			where proxyParseResult.IsValid
			select proxyParseResult.BuildProxyString(A));
		if (ParsedProxies.Count == 0)
		{
			CustomMessageBox.Show(this, "Không có proxy hợp lệ nào để áp dụng.", "Thêm Proxy", NotifyType.Warning);
			return;
		}
		DialogResult = true;
		Close();
	}
}
