using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Licensing;

namespace testTuongTacWPF;

public partial class RegisterWindow : Window, IComponentConnector
{
	[CompilerGenerated]
	private static class m_2123
	{
		public static Func<char, bool> A;
	}

	[CompilerGenerated]
	private string A = "";

	private bool m_2117;

	public string RegisteredUsername
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		private set
		{
			A = value;
		}
	}

	public RegisterWindow()
	{
		InitializeComponent();
	}

	private void m_2118(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2119(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	private void m_2120(object P_0, KeyEventArgs P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)P_1.Key == 6)
		{
			a(P_0, P_1);
		}
	}

	private async void a(object P_0, RoutedEventArgs P_1)
	{
		string text = UsernameTextBox.Text.Trim();
		string text2 = LastNameTextBox.Text.Trim();
		string text3 = FirstNameTextBox.Text.Trim();
		string password = PasswordBox.Password;
		string password2 = ConfirmPasswordBox.Password;
		if (string.IsNullOrWhiteSpace(text) || !text.All(char.IsDigit))
		{
			m_2121("Tên đăng nhập chỉ được phép nhập số (số điện thoại).");
			return;
		}
		if (string.IsNullOrWhiteSpace(text2) || string.IsNullOrWhiteSpace(text3))
		{
			m_2121("Vui lòng nhập đầy đủ họ và tên.");
			return;
		}
		if (string.IsNullOrWhiteSpace(password))
		{
			m_2121("Vui lòng nhập mật khẩu.");
			return;
		}
		if (password != password2)
		{
			m_2121("Mật khẩu xác nhận không khớp.");
			return;
		}
		RegisterButton.IsEnabled = false;
		RegisterButton.Content = "Đang đăng ký...";
		m_2121("");
		LicenseLoginResult licenseLoginResult = await LicenseClient.RegisterAsync(text, password, text2, text3);
		RegisterButton.IsEnabled = true;
		RegisterButton.Content = "Tạo tài khoản";
		if (licenseLoginResult.Success)
		{
			RegisteredUsername = text;
			CustomMessageBox.Show(this, "Đăng ký thành công! Đăng nhập lại bằng tài khoản vừa tạo.", "Đăng ký");
			DialogResult = true;
			Close();
		}
		else
		{
			m_2121(licenseLoginResult.Message);
		}
	}

	private void m_2121(string P_0)
	{
		StatusText.Text = P_0;
		StatusText.Visibility = (string.IsNullOrWhiteSpace(P_0) ? Visibility.Collapsed : Visibility.Visible);
	}
}
