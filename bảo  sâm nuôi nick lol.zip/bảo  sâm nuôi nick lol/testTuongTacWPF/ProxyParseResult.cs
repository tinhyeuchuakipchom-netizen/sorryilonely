using System.Runtime.CompilerServices;

namespace testTuongTacWPF;

public class ProxyParseResult
{
	[CompilerGenerated]
	private ProxyKind A;

	[CompilerGenerated]
	private string m_2112 = "";

	[CompilerGenerated]
	private string? a;

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string? C;

	[CompilerGenerated]
	private string? c;

	[CompilerGenerated]
	private string? D;

	public ProxyKind Kind
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string OriginalLine
	{
		[CompilerGenerated]
		get
		{
			return m_2112;
		}
		[CompilerGenerated]
		set
		{
			m_2112 = value;
		}
	}

	public string? Scheme
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Host
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string Port
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string? User
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public string? Pass
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string? Error
	{
		[CompilerGenerated]
		get
		{
			return D;
		}
		[CompilerGenerated]
		set
		{
			D = value;
		}
	}

	public bool IsValid => Kind != ProxyKind.Invalid;

	public string BuildProxyString(string? defaultScheme)
	{
		string text = Scheme ?? defaultScheme ?? "";
		bool flag = User != null;
		if (text.Length == 0)
		{
			if (!flag)
			{
				return Host + ":" + Port;
			}
			return $"{Host}:{Port}:{User}:{Pass}";
		}
		string value = (flag ? (User + ":" + Pass + "@") : "");
		return $"{text}://{value}{Host}:{Port}";
	}
}
