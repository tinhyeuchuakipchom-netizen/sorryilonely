using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.Win32;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class TikTokActionSettingsWindow : Window, IComponentConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_2182
	{
		public static readonly m_2182 A = new m_2182();

		public static Func<string, string> m_2184;

		public static Func<string, bool> m_2185;

		public static Func<string, string> a;

		public static Func<string, bool> m_2186;

		public static Func<string, string> B;

		public static Func<string, bool> m_2187;

		internal string m_2188(string P_0)
		{
			return P_0.Trim();
		}

		internal bool m_2189(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_2190(string P_0)
		{
			return P_0.Trim();
		}

		internal bool b(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string C(string P_0)
		{
			return P_0.Trim();
		}

		internal bool c(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_2183
	{
		public string[] A;

		internal bool m_2191(string P_0)
		{
			return A.Contains(Path.GetExtension(P_0).ToLowerInvariant());
		}
	}

	private readonly string A;

	private bool m_2171;

	[CompilerGenerated]
	private string a = "";

	private bool m_2172;

	public string ResultJson
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		private set
		{
			a = value;
		}
	}

	public TikTokActionSettingsWindow(string scriptName, string initialJson)
	{
		InitializeComponent();
		A = scriptName;
		TitleBarText.Text = "Cấu hình " + scriptName + " TikTok";
		HeaderTitleText.Text = scriptName + " TikTok";
		switch (scriptName)
		{
		case "Thả tim":
			m_2175(initialJson);
			break;
		case "Bình luận":
			m_2177(initialJson);
			break;
		case "Follow (Sub)":
			B(initialJson);
			break;
		case "Chia sẻ":
			b(initialJson);
			break;
		case "Cập nhật Avatar":
			C(initialJson);
			break;
		}
	}

	public static string? Show(Window? owner, string scriptName, string currentJson)
	{
		TikTokActionSettingsWindow tikTokActionSettingsWindow = new TikTokActionSettingsWindow(scriptName, currentJson);
		if (owner != null && owner.IsVisible)
		{
			tikTokActionSettingsWindow.Owner = owner;
		}
		tikTokActionSettingsWindow.ShowDialog();
		if (!tikTokActionSettingsWindow.m_2171)
		{
			return null;
		}
		return tikTokActionSettingsWindow.ResultJson;
	}

	private void m_2173(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2174(object P_0, RoutedEventArgs P_1)
	{
		m_2171 = false;
		Close();
	}

	private void m_2175(string P_0)
	{
		LikePanel.Visibility = Visibility.Visible;
		HeaderSubtitleText.Text = "Tự động lướt video trên bảng tin và thả tim theo số lượng và tỷ lệ cấu hình bên dưới.";
		TikTokLikeSettings tikTokLikeSettings = TikTokLikeSettings.FromJson(P_0);
		LikeMinCountBox.Text = tikTokLikeSettings.MinCount.ToString();
		LikeMaxCountBox.Text = tikTokLikeSettings.MaxCount.ToString();
		LikeMinDelayBox.Text = tikTokLikeSettings.MinDelaySec.ToString();
		LikeMaxDelayBox.Text = tikTokLikeSettings.MaxDelaySec.ToString();
		LikeRateBox.Text = tikTokLikeSettings.LikeRatePercent.ToString();
	}

	private bool m_2176(out string P_0, out string P_1)
	{
		P_0 = "";
		P_1 = "";
		if (!int.TryParse(LikeMinCountBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "Số lượng video 'Từ' phải >= 1.";
			return false;
		}
		if (!int.TryParse(LikeMaxCountBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "Số lượng video 'Đến' phải >= 'Từ'.";
			return false;
		}
		if (!int.TryParse(LikeMinDelayBox.Text.Trim(), out var result3) || result3 < 1)
		{
			P_1 = "Thời gian xem 'Từ' phải >= 1 giây.";
			return false;
		}
		if (!int.TryParse(LikeMaxDelayBox.Text.Trim(), out var result4) || result4 < result3)
		{
			P_1 = "Thời gian xem 'Đến' phải >= 'Từ'.";
			return false;
		}
		if (!int.TryParse(LikeRateBox.Text.Trim(), out var result5) || result5 < 1 || result5 > 100)
		{
			P_1 = "Tỉ lệ thả tim phải từ 1 đến 100%.";
			return false;
		}
		TikTokLikeSettings tikTokLikeSettings = new TikTokLikeSettings
		{
			MinCount = result,
			MaxCount = result2,
			MinDelaySec = result3,
			MaxDelaySec = result4,
			LikeRatePercent = result5
		};
		P_0 = tikTokLikeSettings.ToJson();
		return true;
	}

	private void m_2177(string P_0)
	{
		CommentPanel.Visibility = Visibility.Visible;
		HeaderSubtitleText.Text = "Tự động mở khung bình luận, nhập văn bản/ảnh/emoji ngẫu nhiên và đăng bình luận.";
		TikTokCommentSettings tikTokCommentSettings = TikTokCommentSettings.FromJson(P_0);
		CmtMinCountBox.Text = tikTokCommentSettings.MinCount.ToString();
		CmtMaxCountBox.Text = tikTokCommentSettings.MaxCount.ToString();
		CmtMinDelayBox.Text = tikTokCommentSettings.MinDelaySec.ToString();
		CmtMaxDelayBox.Text = tikTokCommentSettings.MaxDelaySec.ToString();
		CmtTextsBox.Text = string.Join(Environment.NewLine, tikTokCommentSettings.CommentTexts);
		CmtAppendEmojiCheckBox.IsChecked = tikTokCommentSettings.AppendEmoji;
		CmtEmojisBox.Text = string.Join(" ", tikTokCommentSettings.CommentEmojis);
		CmtEmojiPanel.Visibility = ((!tikTokCommentSettings.AppendEmoji) ? Visibility.Collapsed : Visibility.Visible);
		CmtWithImageCheckBox.IsChecked = tikTokCommentSettings.CommentWithImage;
		CmtImageFolderBox.Text = tikTokCommentSettings.CommentImageFolder;
		CmtImagePanel.Visibility = ((!tikTokCommentSettings.CommentWithImage) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void m_2178(object P_0, RoutedEventArgs P_1)
	{
		if (CmtEmojiPanel != null)
		{
			CmtEmojiPanel.Visibility = ((CmtAppendEmojiCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		if (CmtImagePanel != null)
		{
			CmtImagePanel.Visibility = ((CmtWithImageCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		OpenFolderDialog openFolderDialog = new OpenFolderDialog
		{
			Title = "Chọn thư mục ảnh bình luận"
		};
		if (!string.IsNullOrWhiteSpace(CmtImageFolderBox.Text) && Directory.Exists(CmtImageFolderBox.Text))
		{
			openFolderDialog.InitialDirectory = CmtImageFolderBox.Text;
		}
		if (openFolderDialog.ShowDialog(this) == true)
		{
			CmtImageFolderBox.Text = openFolderDialog.FolderName;
		}
	}

	private bool m_2179(out string P_0, out string P_1)
	{
		P_0 = "";
		P_1 = "";
		if (!int.TryParse(CmtMinCountBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "Số lượng bình luận 'Từ' phải >= 1.";
			return false;
		}
		if (!int.TryParse(CmtMaxCountBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "Số lượng bình luận 'Đến' phải >= 'Từ'.";
			return false;
		}
		if (!int.TryParse(CmtMinDelayBox.Text.Trim(), out var result3) || result3 < 1)
		{
			P_1 = "Thời gian xem 'Từ' phải >= 1 giây.";
			return false;
		}
		if (!int.TryParse(CmtMaxDelayBox.Text.Trim(), out var result4) || result4 < result3)
		{
			P_1 = "Thời gian xem 'Đến' phải >= 'Từ'.";
			return false;
		}
		List<string> list = (from text in CmtTextsBox.Text.Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
			select text.Trim() into value
			where !string.IsNullOrWhiteSpace(value)
			select value).ToList();
		bool valueOrDefault = CmtWithImageCheckBox.IsChecked == true;
		if (list.Count == 0 && !valueOrDefault)
		{
			P_1 = "Vui lòng nhập ít nhất 1 nội dung bình luận (hoặc bật bình luận bằng ảnh).";
			return false;
		}
		if (valueOrDefault && (string.IsNullOrWhiteSpace(CmtImageFolderBox.Text) || !Directory.Exists(CmtImageFolderBox.Text)))
		{
			P_1 = "Thư mục ảnh bình luận không tồn tại. Vui lòng chọn lại.";
			return false;
		}
		List<string> commentEmojis = (from text in CmtEmojisBox.Text.Split(new char[3] { ' ', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
			select text.Trim() into value
			where !string.IsNullOrWhiteSpace(value)
			select value).ToList();
		TikTokCommentSettings tikTokCommentSettings = new TikTokCommentSettings
		{
			MinCount = result,
			MaxCount = result2,
			MinDelaySec = result3,
			MaxDelaySec = result4,
			CommentTexts = list,
			AppendEmoji = (CmtAppendEmojiCheckBox.IsChecked == true),
			CommentEmojis = commentEmojis,
			CommentWithImage = valueOrDefault,
			CommentImageFolder = CmtImageFolderBox.Text.Trim()
		};
		P_0 = tikTokCommentSettings.ToJson();
		return true;
	}

	private void B(string P_0)
	{
		FollowPanel.Visibility = Visibility.Visible;
		HeaderSubtitleText.Text = "Tự động theo dõi (follow) kênh theo feed video, danh sách username hoặc gợi ý.";
		TikTokFollowSettings tikTokFollowSettings = TikTokFollowSettings.FromJson(P_0);
		FollowMinCountBox.Text = tikTokFollowSettings.MinCount.ToString();
		FollowMaxCountBox.Text = tikTokFollowSettings.MaxCount.ToString();
		FollowMinDelayBox.Text = tikTokFollowSettings.MinDelaySec.ToString();
		FollowMaxDelayBox.Text = tikTokFollowSettings.MaxDelaySec.ToString();
		if (tikTokFollowSettings.FollowMode == "List")
		{
			FollowModeListRadio.IsChecked = true;
		}
		else if (tikTokFollowSettings.FollowMode == "Suggest")
		{
			FollowModeSuggestRadio.IsChecked = true;
		}
		else
		{
			FollowModeFeedRadio.IsChecked = true;
		}
		FollowUsernamesBox.Text = string.Join(Environment.NewLine, tikTokFollowSettings.TargetUsernames);
		m_2180();
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		m_2180();
	}

	private void m_2180()
	{
		if (FollowTargetsPanel != null)
		{
			FollowTargetsPanel.Visibility = ((FollowModeListRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private bool B(out string P_0, out string P_1)
	{
		P_0 = "";
		P_1 = "";
		if (!int.TryParse(FollowMinCountBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "Số lượng follow 'Từ' phải >= 1.";
			return false;
		}
		if (!int.TryParse(FollowMaxCountBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "Số lượng follow 'Đến' phải >= 'Từ'.";
			return false;
		}
		if (!int.TryParse(FollowMinDelayBox.Text.Trim(), out var result3) || result3 < 1)
		{
			P_1 = "Thời gian delay 'Từ' phải >= 1 giây.";
			return false;
		}
		if (!int.TryParse(FollowMaxDelayBox.Text.Trim(), out var result4) || result4 < result3)
		{
			P_1 = "Thời gian delay 'Đến' phải >= 'Từ'.";
			return false;
		}
		string text = "Feed";
		if (FollowModeListRadio.IsChecked == true)
		{
			text = "List";
		}
		else if (FollowModeSuggestRadio.IsChecked == true)
		{
			text = "Suggest";
		}
		List<string> list = (from text2 in FollowUsernamesBox.Text.Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
			select text2.Trim() into value
			where !string.IsNullOrWhiteSpace(value)
			select value).ToList();
		if (text == "List" && list.Count == 0)
		{
			P_1 = "Chế độ 'Theo danh sách' yêu cầu nhập ít nhất 1 Username.";
			return false;
		}
		TikTokFollowSettings tikTokFollowSettings = new TikTokFollowSettings
		{
			MinCount = result,
			MaxCount = result2,
			MinDelaySec = result3,
			MaxDelaySec = result4,
			FollowMode = text,
			TargetUsernames = list
		};
		P_0 = tikTokFollowSettings.ToJson();
		return true;
	}

	private void b(string P_0)
	{
		SharePanel.Visibility = Visibility.Visible;
		HeaderSubtitleText.Text = "Tự động mở chia sẻ video (Đăng lại / Repost hoặc Sao chép liên kết).";
		TikTokShareSettings tikTokShareSettings = TikTokShareSettings.FromJson(P_0);
		ShareMinCountBox.Text = tikTokShareSettings.MinCount.ToString();
		ShareMaxCountBox.Text = tikTokShareSettings.MaxCount.ToString();
		ShareMinDelayBox.Text = tikTokShareSettings.MinDelaySec.ToString();
		ShareMaxDelayBox.Text = tikTokShareSettings.MaxDelaySec.ToString();
		if (tikTokShareSettings.ShareType == "CopyLink")
		{
			ShareTypeCopyLinkRadio.IsChecked = true;
		}
		else
		{
			ShareTypeRepostRadio.IsChecked = true;
		}
	}

	private bool b(out string P_0, out string P_1)
	{
		P_0 = "";
		P_1 = "";
		if (!int.TryParse(ShareMinCountBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "Số lượng chia sẻ 'Từ' phải >= 1.";
			return false;
		}
		if (!int.TryParse(ShareMaxCountBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "Số lượng chia sẻ 'Đến' phải >= 'Từ'.";
			return false;
		}
		if (!int.TryParse(ShareMinDelayBox.Text.Trim(), out var result3) || result3 < 1)
		{
			P_1 = "Thời gian xem 'Từ' phải >= 1 giây.";
			return false;
		}
		if (!int.TryParse(ShareMaxDelayBox.Text.Trim(), out var result4) || result4 < result3)
		{
			P_1 = "Thời gian xem 'Đến' phải >= 'Từ'.";
			return false;
		}
		string shareType = ((ShareTypeCopyLinkRadio.IsChecked == true) ? "CopyLink" : "Repost");
		TikTokShareSettings tikTokShareSettings = new TikTokShareSettings
		{
			MinCount = result,
			MaxCount = result2,
			MinDelaySec = result3,
			MaxDelaySec = result4,
			ShareType = shareType
		};
		P_0 = tikTokShareSettings.ToJson();
		return true;
	}

	private void C(string P_0)
	{
		AvatarPanel.Visibility = Visibility.Visible;
		HeaderSubtitleText.Text = "Tự động đẩy ảnh từ máy tính vào điện thoại và đổi ảnh đại diện TikTok.";
		TikTokAvatarSettings tikTokAvatarSettings = TikTokAvatarSettings.FromJson(P_0);
		AvatarFolderBox.Text = tikTokAvatarSettings.AvatarFolder;
		AvatarRandomOrderCheckBox.IsChecked = tikTokAvatarSettings.RandomOrder;
		AvatarDeleteAfterUseCheckBox.IsChecked = tikTokAvatarSettings.DeleteAfterUse;
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		OpenFolderDialog openFolderDialog = new OpenFolderDialog
		{
			Title = "Chọn thư mục ảnh đại diện"
		};
		if (!string.IsNullOrWhiteSpace(AvatarFolderBox.Text) && Directory.Exists(AvatarFolderBox.Text))
		{
			openFolderDialog.InitialDirectory = AvatarFolderBox.Text;
		}
		if (openFolderDialog.ShowDialog(this) == true)
		{
			AvatarFolderBox.Text = openFolderDialog.FolderName;
		}
	}

	private bool C(out string P_0, out string P_1)
	{
		P_0 = "";
		P_1 = "";
		string text = AvatarFolderBox.Text.Trim();
		if (string.IsNullOrWhiteSpace(text) || !Directory.Exists(text))
		{
			P_1 = "Thư mục ảnh đại diện không tồn tại. Vui lòng chọn lại.";
			return false;
		}
		string[] A = new string[3] { ".jpg", ".jpeg", ".png" };
		if (Directory.EnumerateFiles(text).Count((string path) => A.Contains(Path.GetExtension(path).ToLowerInvariant())) == 0)
		{
			P_1 = "Thư mục đã chọn không có file ảnh nào (.jpg, .jpeg, .png).";
			return false;
		}
		TikTokAvatarSettings tikTokAvatarSettings = new TikTokAvatarSettings
		{
			AvatarFolder = text,
			RandomOrder = (AvatarRandomOrderCheckBox.IsChecked == true),
			DeleteAfterUse = (AvatarDeleteAfterUseCheckBox.IsChecked == true)
		};
		P_0 = tikTokAvatarSettings.ToJson();
		return true;
	}

	private void D(object P_0, RoutedEventArgs P_1)
	{
		string resultJson = "";
		string text = "";
		if (!(A switch
		{
			"Thả tim" => m_2176(out resultJson, out text), 
			"Bình luận" => m_2179(out resultJson, out text), 
			"Follow (Sub)" => B(out resultJson, out text), 
			"Chia sẻ" => b(out resultJson, out text), 
			"Cập nhật Avatar" => C(out resultJson, out text), 
			_ => false, 
		}))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			ResultJson = resultJson;
			m_2171 = true;
			Close();
		}
	}
}
