using System;
using System.IO;
using System.Windows;
using System.Windows.Markup;

namespace testTuongTacWPF;

public partial class LoadingSplashWindow : Window, IComponentConnector
{
	private bool m_470;

	public LoadingSplashWindow()
	{
		InitializeComponent();
		string text = Path.Combine(AppContext.BaseDirectory, "Assets", "loading.mp4");
		if (File.Exists(text))
		{
			LoadingVideo.IsMuted = true;
			LoadingVideo.Source = new Uri(text, UriKind.Absolute);
			LoadingVideo.Play();
		}
	}

	private void m_471(object P_0, RoutedEventArgs P_1)
	{
		LoadingVideo.Position = TimeSpan.Zero;
		LoadingVideo.Play();
	}
}
