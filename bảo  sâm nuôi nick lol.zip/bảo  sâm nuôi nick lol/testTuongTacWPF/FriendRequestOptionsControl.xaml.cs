using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Data;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class FriendRequestOptionsControl : UserControl, IComponentConnector
{
	private bool A;

	public FriendRequestOptionsControl()
	{
		InitializeComponent();
		FolderComboBox.ItemsSource = FacebookAccountDatabase.LoadFolders();
		Load(new FriendRequestSettings());
	}

	public void Load(FriendRequestSettings initial)
	{
		FolderComboBox.SelectedValue = initial.NickFolderId;
		if (FolderComboBox.SelectedItem == null && FolderComboBox.Items.Count > 0)
		{
			FolderComboBox.SelectedIndex = 0;
		}
		UidListTextBox.Text = string.Join("\n", initial.Uids);
		GroupLinkTextBox.Text = initial.GroupLink;
		MaxScrollsTextBox.Text = initial.MaxScrolls.ToString();
		MaxRequestsTextBox.Text = initial.MaxRequestsPerRun.ToString();
		MinDelayTextBox.Text = initial.MinDelaySeconds.ToString();
		MaxDelayTextBox.Text = initial.MaxDelaySeconds.ToString();
		MaxConfirmsTextBox.Text = initial.MaxConfirmsPerRun.ToString();
		ActionSendRadio.IsChecked = initial.Action == FriendRequestAction.SendRequests;
		ActionConfirmRadio.IsChecked = initial.Action == FriendRequestAction.ConfirmIncoming;
		SourceFolderRadio.IsChecked = initial.Source == FriendRequestSource.NickFolder;
		SourceUidListRadio.IsChecked = initial.Source == FriendRequestSource.UidList;
		SourceGroupRadio.IsChecked = initial.Source == FriendRequestSource.GroupPosters;
		m_353();
	}

	private void m_352(object P_0, RoutedEventArgs P_1)
	{
		m_353();
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		m_353();
	}

	private void m_353()
	{
		if (FolderPanel != null)
		{
			bool valueOrDefault = ActionSendRadio.IsChecked == true;
			SourceCard.Visibility = ((!valueOrDefault) ? Visibility.Collapsed : Visibility.Visible);
			SafetyLimitCard.Visibility = ((!valueOrDefault) ? Visibility.Collapsed : Visibility.Visible);
			ConfirmCard.Visibility = (valueOrDefault ? Visibility.Collapsed : Visibility.Visible);
			FolderPanel.Visibility = ((SourceFolderRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			UidListPanel.Visibility = ((SourceUidListRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			GroupPanel.Visibility = ((SourceGroupRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	public bool TryRead(out FriendRequestSettings settings, out string error)
	{
		settings = new FriendRequestSettings();
		error = "";
		FriendRequestAction friendRequestAction = ((ActionConfirmRadio.IsChecked == true) ? FriendRequestAction.ConfirmIncoming : FriendRequestAction.SendRequests);
		if (friendRequestAction == FriendRequestAction.ConfirmIncoming)
		{
			if (!int.TryParse(MaxConfirmsTextBox.Text.Trim(), out var result) || result < 1)
			{
				error = "\"Tối đa ... lời mời xác nhận\" phải là 1 số nguyên >= 1.";
				return false;
			}
			settings.Action = friendRequestAction;
			settings.MaxConfirmsPerRun = result;
			return true;
		}
		FriendRequestSource friendRequestSource = ((SourceUidListRadio.IsChecked == true) ? FriendRequestSource.UidList : ((SourceGroupRadio.IsChecked == true) ? FriendRequestSource.GroupPosters : FriendRequestSource.NickFolder));
		List<string> list = UidListTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (friendRequestSource == FriendRequestSource.NickFolder && !(FolderComboBox.SelectedItem is NickFolder))
		{
			error = "Chưa chọn thư mục nick nào.";
			return false;
		}
		if (friendRequestSource == FriendRequestSource.UidList && list.Count == 0)
		{
			error = "Chưa nhập UID nào.";
			return false;
		}
		if (!int.TryParse(MaxScrollsTextBox.Text.Trim(), out var result2) || result2 < 1)
		{
			error = "\"Cuộn tối đa\" phải là 1 số nguyên >= 1.";
			return false;
		}
		if (!int.TryParse(MaxRequestsTextBox.Text.Trim(), out var result3) || result3 < 1)
		{
			error = "\"Tối đa ... lời mời\" phải là 1 số nguyên >= 1.";
			return false;
		}
		if (!int.TryParse(MinDelayTextBox.Text.Trim(), out var result4) || result4 < 0)
		{
			error = "\"Chờ từ\" (giây) phải là 1 số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(MaxDelayTextBox.Text.Trim(), out var result5) || result5 < result4)
		{
			error = "\"đến\" (giây) phải là 1 số nguyên >= \"Chờ từ\".";
			return false;
		}
		settings.Action = friendRequestAction;
		settings.Source = friendRequestSource;
		if (FolderComboBox.SelectedItem is NickFolder nickFolder)
		{
			settings.NickFolderId = nickFolder.Id;
			settings.NickFolderName = nickFolder.Name;
		}
		settings.Uids = list;
		settings.GroupLink = GroupLinkTextBox.Text.Trim();
		settings.MaxScrolls = result2;
		settings.MaxRequestsPerRun = result3;
		settings.MinDelaySeconds = result4;
		settings.MaxDelaySeconds = result5;
		return true;
	}
}
