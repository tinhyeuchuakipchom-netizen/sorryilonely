using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class VietnameseInputToast : Window, IComponentConnector
{
	private bool m_2225;

	public VietnameseInputToast()
	{
		InitializeComponent();
		Loaded += delegate
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			Rect workArea = SystemParameters.WorkArea;
			Left = workArea.Right - Width - 20.0;
			Top = workArea.Bottom - ActualHeight - 20.0;
		};
	}

	private void m_2226(object P_0, RoutedEventArgs P_1)
	{
		UiPreferences uiPreferences = UiPreferences.Load();
		uiPreferences.HasSeenVietnameseInputNotice = true;
		uiPreferences.Save();
		Close();
	}

	[CompilerGenerated]
	private void a(object P_0, RoutedEventArgs P_1)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		Rect workArea = SystemParameters.WorkArea;
		Left = workArea.Right - Width - 20.0;
		Top = workArea.Bottom - ActualHeight - 20.0;
	}
}
