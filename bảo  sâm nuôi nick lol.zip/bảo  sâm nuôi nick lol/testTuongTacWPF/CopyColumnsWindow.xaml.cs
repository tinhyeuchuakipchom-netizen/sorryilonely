using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace testTuongTacWPF;

public partial class CopyColumnsWindow : Window, IComponentConnector
{
	[CompilerGenerated]
	private sealed class m_335
	{
		public CheckBox A;

		internal void m_336(object P_0, MouseButtonEventArgs P_1)
		{
			A.IsChecked = A.IsChecked != true;
		}
	}

	private readonly List<CheckBox> A = new List<CheckBox>();

	private readonly string[] m_325;

	private readonly Func<string, string>? m_326;

	[CompilerGenerated]
	private List<string> m_327 = new List<string>();

	private bool m_328;

	public List<string> SelectedHeaders
	{
		[CompilerGenerated]
		get
		{
			return m_327;
		}
		[CompilerGenerated]
		private set
		{
			m_327 = value;
		}
	}

	private CopyColumnsWindow(Window? owner, string[] P_1, IEnumerable<string> P_2, int P_3, Func<string, string>? sampleValue)
	{
		InitializeComponent();
		if (owner != null)
		{
			Owner = owner;
		}
		m_325 = P_1;
		m_326 = sampleValue;
		SubtitleText.Text = $"Chọn các giá trị muốn copy của {P_3} nick đã chọn. Các giá trị được ghép trên cùng 1 dòng, ngăn nhau bằng dấu \"|\".";
		HashSet<string> hashSet = P_2.ToHashSet();
		foreach (string text in P_1)
		{
			CheckBox A = new CheckBox
			{
				IsChecked = hashSet.Contains(text),
				VerticalAlignment = VerticalAlignment.Center
			};
			A.Checked += delegate
			{
				a();
			};
			A.Unchecked += delegate
			{
				a();
			};
			this.A.Add(A);
			StackPanel stackPanel = new StackPanel
			{
				Orientation = Orientation.Horizontal
			};
			stackPanel.Children.Add(A);
			stackPanel.Children.Add(new TextBlock
			{
				Text = text,
				FontSize = 13.0,
				Margin = new Thickness(10.0, 0.0, 0.0, 0.0),
				VerticalAlignment = VerticalAlignment.Center
			});
			Border border = new Border
			{
				Background = Brushes.Transparent,
				Padding = new Thickness(6.0, 6.0, 6.0, 6.0),
				CornerRadius = new CornerRadius(6.0),
				Cursor = Cursors.Hand,
				Child = stackPanel
			};
			border.MouseLeftButtonUp += delegate
			{
				A.IsChecked = A.IsChecked != true;
			};
			ColumnsPanel.Children.Add(border);
		}
		a();
	}

	public static List<string>? Show(Window? owner, string[] allHeaders, IEnumerable<string> preselected, int rowCount, Func<string, string>? sampleValue = null)
	{
		CopyColumnsWindow copyColumnsWindow = new CopyColumnsWindow(owner, allHeaders, preselected, rowCount, sampleValue);
		if (copyColumnsWindow.ShowDialog() != true)
		{
			return null;
		}
		return copyColumnsWindow.SelectedHeaders;
	}

	private List<string> m_329()
	{
		return m_325.Where((string P_0, int P_1) => A[P_1].IsChecked == true).ToList();
	}

	private void a()
	{
		List<string> list = m_329();
		if (list.Count == 0)
		{
			PreviewText.Text = "(chưa chọn giá trị nào)";
			CopyButton.IsEnabled = false;
			return;
		}
		CopyButton.IsEnabled = true;
		PreviewText.Text = ((m_326 == null) ? string.Join("|", list) : string.Join("|", list.Select((string P_0) => m_326(P_0))));
	}

	private void m_330(object P_0, RoutedEventArgs P_1)
	{
		foreach (CheckBox item in A)
		{
			item.IsChecked = true;
		}
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		foreach (CheckBox item in A)
		{
			item.IsChecked = false;
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		SelectedHeaders = m_329();
		if (SelectedHeaders.Count != 0)
		{
			DialogResult = true;
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
	}

	private void m_331(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.ChangedButton == MouseButton.Left)
		{
			DragMove();
		}
	}

	[CompilerGenerated]
	private void C(object P_0, RoutedEventArgs P_1)
	{
		a();
	}

	[CompilerGenerated]
	private void c(object P_0, RoutedEventArgs P_1)
	{
		a();
	}

	[CompilerGenerated]
	private bool m_333(string P_0, int P_1)
	{
		return A[P_1].IsChecked == true;
	}

	[CompilerGenerated]
	private string m_334(string P_0)
	{
		return m_326(P_0);
	}
}
