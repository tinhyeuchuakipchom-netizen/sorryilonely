using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class PageFarmingSettingsWindow : Window, IComponentConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_1683
	{
		public static readonly m_1683 A = new m_1683();

		public static Func<string, bool> m_1684;

		internal bool m_1685(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	private bool A;

	private PostCreationSettings m_1676 = new PostCreationSettings();

	private bool a;

	public PageFarmingSettingsWindow(PageFarmingSettings initial)
	{
		InitializeComponent();
		m_1676 = initial.Post ?? new PostCreationSettings();
		MinMinutesTextBox.Text = initial.MinMinutesPerPage.ToString();
		MaxMinutesTextBox.Text = initial.MaxMinutesPerPage.ToString();
		MaxPagesTextBox.Text = initial.MaxPages.ToString();
		PageSwitchDelayTextBox.Text = initial.PageSwitchDelaySeconds.ToString();
		TargetPageNamesTextBox.Text = string.Join(Environment.NewLine, initial.TargetPageNames ?? new List<string>());
		AutoLikeCheckBox.IsChecked = initial.AutoLike;
		LikeChanceTextBox.Text = initial.LikeChancePercent.ToString();
		WatchReelsCheckBox.IsChecked = initial.WatchReels;
		AutoPostCheckBox.IsChecked = initial.AutoPost;
		PostsPerPageTextBox.Text = initial.PostsPerPage.ToString();
		m_1680();
	}

	private void m_1677(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_1678(object P_0, RoutedEventArgs P_1)
	{
		m_1680();
	}

	private void m_1679(object P_0, RoutedEventArgs P_1)
	{
		m_1680();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		PostCreationSettings postCreationSettings = PostCreationSettingsWindow.Show(this, m_1676);
		if (postCreationSettings != null)
		{
			m_1676 = postCreationSettings;
		}
	}

	private void m_1680()
	{
		if (LikeChancePanel != null)
		{
			LikeChancePanel.Visibility = ((AutoLikeCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			PostOptionsPanel.Visibility = ((AutoPostCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		if (!m_1681(out PageFarmingSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_1681(out PageFarmingSettings P_0, out string P_1)
	{
		P_0 = new PageFarmingSettings();
		P_1 = "";
		if (!int.TryParse(MinMinutesTextBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "\"Thời lượng / mỗi Page (phút)\" từ phải là số nguyên >= 1.";
			return false;
		}
		if (!int.TryParse(MaxMinutesTextBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "\"Thời lượng / mỗi Page (phút)\" đến phải lớn hơn hoặc bằng thời lượng bắt đầu.";
			return false;
		}
		if (!int.TryParse(MaxPagesTextBox.Text.Trim(), out var result3) || result3 < 0)
		{
			P_1 = "\"Số Page tối đa\" phải là số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(PageSwitchDelayTextBox.Text.Trim(), out var result4) || result4 < 0)
		{
			P_1 = "\"Chờ chuyển Page\" phải là số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(LikeChanceTextBox.Text.Trim(), out var result5) || result5 < 0 || result5 > 100)
		{
			P_1 = "Tỉ lệ thả Like phải từ 0 đến 100%.";
			return false;
		}
		if (!int.TryParse(PostsPerPageTextBox.Text.Trim(), out var result6) || result6 < 1)
		{
			P_1 = "\"Số bài đăng / mỗi Page\" phải là số nguyên >= 1.";
			return false;
		}
		P_0.MinMinutesPerPage = result;
		P_0.MaxMinutesPerPage = result2;
		P_0.MaxPages = result3;
		P_0.PageSwitchDelaySeconds = result4;
		P_0.TargetPageNames = (from value in TargetPageNamesTextBox.Text.Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
			where !string.IsNullOrWhiteSpace(value)
			select value).ToList();
		P_0.AutoLike = AutoLikeCheckBox.IsChecked == true;
		P_0.LikeChancePercent = result5;
		P_0.WatchReels = WatchReelsCheckBox.IsChecked == true;
		P_0.AutoPost = AutoPostCheckBox.IsChecked == true;
		P_0.PostsPerPage = result6;
		P_0.Post = m_1676;
		return true;
	}

	public static PageFarmingSettings? Show(Window? owner, PageFarmingSettings initial)
	{
		PageFarmingSettingsWindow pageFarmingSettingsWindow = new PageFarmingSettingsWindow(initial)
		{
			Owner = owner
		};
		pageFarmingSettingsWindow.ShowDialog();
		if (!pageFarmingSettingsWindow.A)
		{
			return null;
		}
		pageFarmingSettingsWindow.m_1681(out PageFarmingSettings result, out string _);
		return result;
	}
}
