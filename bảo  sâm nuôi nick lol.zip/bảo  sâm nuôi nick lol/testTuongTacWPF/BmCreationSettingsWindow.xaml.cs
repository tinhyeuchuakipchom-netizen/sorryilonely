using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class BmCreationSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private BmCreationSettingsWindow(BmCreationSettings P_0)
	{
		InitializeComponent();
		BizModeEnglishRadio.IsChecked = P_0.BusinessNameMode == BmBusinessNameMode.RandomEnglish;
		BizModeVietnameseRadio.IsChecked = P_0.BusinessNameMode == BmBusinessNameMode.RandomVietnamese;
		BizModeCustomRadio.IsChecked = P_0.BusinessNameMode == BmBusinessNameMode.CustomList;
		CustomBizNamesTextBox.Text = string.Join("\n", P_0.CustomBusinessNames);
		PickBizRandomlyCheckBox.IsChecked = P_0.PickCustomBusinessNameRandomly;
		AdminModeKeepRadio.IsChecked = P_0.AdminNameMode == BmAdminNameMode.KeepAccountName;
		AdminModeEnglishRadio.IsChecked = P_0.AdminNameMode == BmAdminNameMode.RandomEnglish;
		AdminModeVietnameseRadio.IsChecked = P_0.AdminNameMode == BmAdminNameMode.RandomVietnamese;
		AdminModeCustomRadio.IsChecked = P_0.AdminNameMode == BmAdminNameMode.CustomList;
		CustomAdminNamesTextBox.Text = string.Join("\n", P_0.CustomAdminNames);
		PickAdminRandomlyCheckBox.IsChecked = P_0.PickCustomAdminNameRandomly;
		EmailDomainTextBox.Text = (string.IsNullOrWhiteSpace(P_0.EmailDomain) ? "gmail.com" : P_0.EmailDomain.Trim());
		BmCountTextBox.Text = ((P_0.BmCount > 0) ? P_0.BmCount.ToString() : "1");
		MinDelaySecondsTextBox.Text = ((P_0.MinDelaySeconds >= 0) ? P_0.MinDelaySeconds.ToString() : "10");
		MaxDelaySecondsTextBox.Text = ((P_0.MaxDelaySeconds >= 0) ? P_0.MaxDelaySeconds.ToString() : "30");
		m_310();
	}

	private void m_307(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_308(object P_0, RoutedEventArgs P_1)
	{
		m_310();
	}

	private void m_309(object P_0, RoutedEventArgs P_1)
	{
		m_310();
	}

	private void m_310()
	{
		if (BizEnglishPanel != null)
		{
			BizEnglishPanel.Visibility = ((BizModeEnglishRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			BizVietnamesePanel.Visibility = ((BizModeVietnameseRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			BizCustomPanel.Visibility = ((BizModeCustomRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			AdminKeepPanel.Visibility = ((AdminModeKeepRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			AdminEnglishPanel.Visibility = ((AdminModeEnglishRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			AdminVietnamesePanel.Visibility = ((AdminModeVietnameseRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			AdminCustomPanel.Visibility = ((AdminModeCustomRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		if (!m_311(out BmCreationSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_311(out BmCreationSettings P_0, out string P_1)
	{
		P_0 = new BmCreationSettings();
		P_1 = "";
		if (!int.TryParse(BmCountTextBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "Số lượng BM mỗi nick phải là số nguyên lớn hơn hoặc bằng 1.";
			return false;
		}
		if (!int.TryParse(MinDelaySecondsTextBox.Text.Trim(), out var result2) || result2 < 0)
		{
			P_1 = "Thời gian chờ tối thiểu (giây) không hợp lệ.";
			return false;
		}
		if (!int.TryParse(MaxDelaySecondsTextBox.Text.Trim(), out var result3) || result3 < result2)
		{
			P_1 = "Thời gian chờ tối đa phải lớn hơn hoặc bằng thời gian chờ tối thiểu.";
			return false;
		}
		BmBusinessNameMode bmBusinessNameMode = ((BizModeVietnameseRadio.IsChecked == true) ? BmBusinessNameMode.RandomVietnamese : ((BizModeCustomRadio.IsChecked == true) ? BmBusinessNameMode.CustomList : BmBusinessNameMode.RandomEnglish));
		List<string> list = CustomBizNamesTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (bmBusinessNameMode == BmBusinessNameMode.CustomList && list.Count == 0)
		{
			P_1 = "Chưa nhập tên doanh nghiệp nào cho danh sách tự nạp.";
			return false;
		}
		BmAdminNameMode bmAdminNameMode = ((AdminModeEnglishRadio.IsChecked == true) ? BmAdminNameMode.RandomEnglish : ((AdminModeVietnameseRadio.IsChecked == true) ? BmAdminNameMode.RandomVietnamese : ((AdminModeCustomRadio.IsChecked == true) ? BmAdminNameMode.CustomList : BmAdminNameMode.KeepAccountName)));
		List<string> list2 = CustomAdminNamesTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (bmAdminNameMode == BmAdminNameMode.CustomList && list2.Count == 0)
		{
			P_1 = "Chưa nhập họ tên quản trị viên nào cho danh sách tự nạp.";
			return false;
		}
		string text = EmailDomainTextBox.Text.Trim().TrimStart('@');
		if (string.IsNullOrWhiteSpace(text))
		{
			P_1 = "Đuôi domain email không được để trống (ví dụ gmail.com).";
			return false;
		}
		P_0.BmCount = result;
		P_0.MinDelaySeconds = result2;
		P_0.MaxDelaySeconds = result3;
		P_0.BusinessNameMode = bmBusinessNameMode;
		P_0.CustomBusinessNames = list;
		P_0.PickCustomBusinessNameRandomly = PickBizRandomlyCheckBox.IsChecked == true;
		P_0.AdminNameMode = bmAdminNameMode;
		P_0.CustomAdminNames = list2;
		P_0.PickCustomAdminNameRandomly = PickAdminRandomlyCheckBox.IsChecked == true;
		P_0.EmailDomain = text;
		return true;
	}

	public static BmCreationSettings? Show(Window? owner, BmCreationSettings initial)
	{
		BmCreationSettingsWindow bmCreationSettingsWindow = new BmCreationSettingsWindow(initial);
		if (owner != null)
		{
			bmCreationSettingsWindow.Owner = owner;
		}
		bmCreationSettingsWindow.ShowDialog();
		if (!bmCreationSettingsWindow.A)
		{
			return null;
		}
		bmCreationSettingsWindow.m_311(out BmCreationSettings result, out string _);
		return result;
	}
}
