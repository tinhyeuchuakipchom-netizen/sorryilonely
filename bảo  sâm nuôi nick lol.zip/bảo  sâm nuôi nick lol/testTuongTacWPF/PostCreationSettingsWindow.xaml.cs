using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.Win32;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class PostCreationSettingsWindow : Window, IComponentConnector
{
	private const string A = "---";

	private bool m_2089;

	private bool a;

	private PostCreationSettingsWindow(PostCreationSettings P_0)
	{
		InitializeComponent();
		ContentsTextBox.Text = string.Join("\n---\n", P_0.Contents);
		AttachImageCheck.IsChecked = P_0.AttachImage;
		ImageFolderTextBox.Text = P_0.ImageFolder;
		MinImagesTextBox.Text = P_0.MinImages.ToString();
		MaxImagesTextBox.Text = P_0.MaxImages.ToString();
		AttachVideoCheck.IsChecked = P_0.AttachVideo;
		VideoFolderTextBox.Text = P_0.VideoFolder;
		AudiencePublicRadio.IsChecked = P_0.Audience == "Public";
		AudienceFriendsRadio.IsChecked = P_0.Audience == "Friends";
		AudienceOnlyMeRadio.IsChecked = P_0.Audience == "OnlyMe";
		AudienceKeepRadio.IsChecked = AudiencePublicRadio.IsChecked != true && AudienceFriendsRadio.IsChecked != true && AudienceOnlyMeRadio.IsChecked != true;
		PostCountTextBox.Text = P_0.PostCount.ToString();
		MinSpacingSecondsTextBox.Text = P_0.MinSpacingSeconds.ToString();
		MaxSpacingSecondsTextBox.Text = P_0.MaxSpacingSeconds.ToString();
		m_2093();
	}

	private void m_2090(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2091(object P_0, RoutedEventArgs P_1)
	{
		m_2093();
	}

	private void m_2092(object P_0, RoutedEventArgs P_1)
	{
		m_2093();
	}

	private void m_2093()
	{
		if (ImageOptionsPanel != null)
		{
			ImageOptionsPanel.Visibility = ((AttachImageCheck.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			VideoOptionsPanel.Visibility = ((AttachVideoCheck.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		m_2094(ImageFolderTextBox);
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		m_2094(VideoFolderTextBox);
	}

	private void m_2094(TextBox P_0)
	{
		OpenFolderDialog openFolderDialog = new OpenFolderDialog
		{
			Title = "Chọn thư mục"
		};
		if (!string.IsNullOrWhiteSpace(P_0.Text) && Directory.Exists(P_0.Text))
		{
			openFolderDialog.InitialDirectory = P_0.Text;
		}
		if (openFolderDialog.ShowDialog(this) == true)
		{
			P_0.Text = openFolderDialog.FolderName;
		}
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		if (!m_2095(out PostCreationSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			m_2089 = true;
			Close();
		}
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		m_2089 = false;
		Close();
	}

	private bool m_2095(out PostCreationSettings P_0, out string P_1)
	{
		P_0 = new PostCreationSettings();
		P_1 = "";
		List<string> list = m_2096(ContentsTextBox.Text);
		bool valueOrDefault = AttachImageCheck.IsChecked == true;
		bool valueOrDefault2 = AttachVideoCheck.IsChecked == true;
		if (list.Count == 0 && !valueOrDefault && !valueOrDefault2)
		{
			P_1 = "Bài viết trống: chưa nhập nội dung và cũng chưa bật đính kèm ảnh/video.";
			return false;
		}
		if (valueOrDefault)
		{
			if (string.IsNullOrWhiteSpace(ImageFolderTextBox.Text) || !Directory.Exists(ImageFolderTextBox.Text))
			{
				P_1 = "Đã bật đính kèm ảnh nhưng thư mục ảnh chưa hợp lệ (không tồn tại).";
				return false;
			}
			if (!int.TryParse(MinImagesTextBox.Text.Trim(), out var result) || result < 1)
			{
				P_1 = "\"Từ\" (số ảnh) phải là 1 số nguyên >= 1.";
				return false;
			}
			if (!int.TryParse(MaxImagesTextBox.Text.Trim(), out var result2) || result2 < result)
			{
				P_1 = "\"Đến\" (số ảnh) phải là 1 số nguyên >= \"Từ\".";
				return false;
			}
			P_0.MinImages = result;
			P_0.MaxImages = result2;
		}
		if (valueOrDefault2 && (string.IsNullOrWhiteSpace(VideoFolderTextBox.Text) || !Directory.Exists(VideoFolderTextBox.Text)))
		{
			P_1 = "Đã bật đính kèm video nhưng thư mục video chưa hợp lệ (không tồn tại).";
			return false;
		}
		if (!int.TryParse(PostCountTextBox.Text.Trim(), out var result3) || result3 < 1)
		{
			P_1 = "Số bài đăng phải là 1 số nguyên >= 1.";
			return false;
		}
		if (!int.TryParse(MinSpacingSecondsTextBox.Text.Trim(), out var result4) || result4 < 0)
		{
			P_1 = "\"Từ\" (giây) phải là 1 số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(MaxSpacingSecondsTextBox.Text.Trim(), out var result5) || result5 < result4)
		{
			P_1 = "\"Đến\" (giây) phải là 1 số nguyên >= \"Từ\".";
			return false;
		}
		PostCreationSettings obj = P_0;
		string audience;
		if (AudiencePublicRadio.IsChecked == true)
		{
			audience = "Public";
		}
		else if (AudienceFriendsRadio.IsChecked == true)
		{
			audience = "Friends";
		}
		else
		{
			audience = ((AudienceOnlyMeRadio.IsChecked == true) ? "OnlyMe" : "Keep");
		}
		obj.Audience = audience;
		P_0.Contents = list;
		P_0.AttachImage = valueOrDefault;
		P_0.ImageFolder = ImageFolderTextBox.Text.Trim();
		P_0.AttachVideo = valueOrDefault2;
		P_0.VideoFolder = VideoFolderTextBox.Text.Trim();
		P_0.PostCount = result3;
		P_0.MinSpacingSeconds = result4;
		P_0.MaxSpacingSeconds = result5;
		return true;
	}

	private static List<string> m_2096(string P_0)
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		string[] array = P_0.Replace("\r\n", "\n").Split('\n');
		foreach (string text in array)
		{
			if (text.Trim() == "---")
			{
				m_2097(list, list2);
				list2 = new List<string>();
			}
			else
			{
				list2.Add(text);
			}
		}
		m_2097(list, list2);
		return list;
	}

	private static void m_2097(List<string> P_0, List<string> P_1)
	{
		string text = string.Join("\n", P_1).Trim();
		if (text.Length > 0)
		{
			P_0.Add(text);
		}
	}

	public static PostCreationSettings? Show(Window? owner, PostCreationSettings initial)
	{
		PostCreationSettingsWindow postCreationSettingsWindow = new PostCreationSettingsWindow(initial);
		if (owner != null)
		{
			postCreationSettingsWindow.Owner = owner;
		}
		postCreationSettingsWindow.ShowDialog();
		if (!postCreationSettingsWindow.m_2089)
		{
			return null;
		}
		postCreationSettingsWindow.m_2095(out PostCreationSettings result, out string _);
		return result;
	}
}
