using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class MessagingSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private MessagingSettingsWindow(MessagingSettings P_0)
	{
		InitializeComponent();
		PostLinkTextBox.Text = P_0.PostLink;
		LoadMoreTextBox.Text = P_0.LoadMoreCommentsClicks.ToString();
		MessagesTextBox.Text = string.Join("\n", P_0.Messages);
		MaxMessagesTextBox.Text = P_0.MaxMessagesPerRun.ToString();
		MinDelayTextBox.Text = P_0.MinDelaySeconds.ToString();
		MaxDelayTextBox.Text = P_0.MaxDelaySeconds.ToString();
		TargetOpenNicksRadio.IsChecked = P_0.Target == MessagingTarget.OpenChromeNicks;
		TargetCommentersRadio.IsChecked = P_0.Target == MessagingTarget.PostCommenters;
		m_1663();
	}

	private void m_1661(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_1662(object P_0, RoutedEventArgs P_1)
	{
		m_1663();
	}

	private void m_1663()
	{
		if (OpenNicksPanel != null)
		{
			OpenNicksPanel.Visibility = ((TargetOpenNicksRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			CommentersPanel.Visibility = ((TargetCommentersRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void m_1664(object P_0, RoutedEventArgs P_1)
	{
		if (!m_1665(out MessagingSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_1665(out MessagingSettings P_0, out string P_1)
	{
		P_0 = new MessagingSettings();
		P_1 = "";
		MessagingTarget messagingTarget = ((TargetCommentersRadio.IsChecked == true) ? MessagingTarget.PostCommenters : MessagingTarget.OpenChromeNicks);
		List<string> list = MessagesTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (list.Count == 0)
		{
			P_1 = "Chưa nhập nội dung tin nhắn nào.";
			return false;
		}
		if (messagingTarget == MessagingTarget.PostCommenters)
		{
			if (string.IsNullOrWhiteSpace(PostLinkTextBox.Text))
			{
				P_1 = "Chưa nhập link bài viết.";
				return false;
			}
			if (!int.TryParse(LoadMoreTextBox.Text.Trim(), out var result) || result < 0)
			{
				P_1 = "Số lần bấm \"Xem thêm bình luận\" phải là 1 số nguyên >= 0.";
				return false;
			}
			P_0.LoadMoreCommentsClicks = result;
		}
		if (!int.TryParse(MaxMessagesTextBox.Text.Trim(), out var result2) || result2 < 1)
		{
			P_1 = "\"Tối đa ... tin nhắn\" phải là 1 số nguyên >= 1.";
			return false;
		}
		if (!int.TryParse(MinDelayTextBox.Text.Trim(), out var result3) || result3 < 0)
		{
			P_1 = "\"Chờ từ\" (giây) phải là 1 số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(MaxDelayTextBox.Text.Trim(), out var result4) || result4 < result3)
		{
			P_1 = "\"đến\" (giây) phải là 1 số nguyên >= \"Chờ từ\".";
			return false;
		}
		P_0.Target = messagingTarget;
		P_0.PostLink = PostLinkTextBox.Text.Trim();
		P_0.Messages = list;
		P_0.MaxMessagesPerRun = result2;
		P_0.MinDelaySeconds = result3;
		P_0.MaxDelaySeconds = result4;
		return true;
	}

	public static MessagingSettings? Show(Window? owner, MessagingSettings initial)
	{
		MessagingSettingsWindow messagingSettingsWindow = new MessagingSettingsWindow(initial);
		if (owner != null)
		{
			messagingSettingsWindow.Owner = owner;
		}
		messagingSettingsWindow.ShowDialog();
		if (!messagingSettingsWindow.A)
		{
			return null;
		}
		messagingSettingsWindow.m_1665(out MessagingSettings result, out string _);
		return result;
	}
}
