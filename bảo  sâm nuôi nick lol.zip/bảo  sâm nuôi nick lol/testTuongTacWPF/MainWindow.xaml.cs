using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using A;
using Google.Apis.Sheets.v4;
using Microsoft.Win32;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Data;
using testTuongTacWPF.Licensing;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class MainWindow : Window, IComponentConnector, IStyleConnector
{
	private enum m_703
	{
		A,
		a,
		B
	}

	private struct m_704
	{
		public int A;

		public int a;
	}

	private struct m_705
	{
		public int A;

		public int a;

		public int B;

		public int b;
	}

	private struct m_706
	{
		public m_704 A;

		public m_704 a;

		public m_704 B;

		public m_704 b;

		public m_704 C;
	}

	private struct m_707
	{
		public int A;

		public m_705 m_864;

		public m_705 a;

		public int m_865;
	}

	internal sealed class PriorityTargetDisplay : INotifyPropertyChanged
	{
		[CompilerGenerated]
		private PropertyChangedEventHandler? m_871;

		[CompilerGenerated]
		private string m_872 = "";

		[CompilerGenerated]
		private string m_873 = "";

		private string _priority = "1";

		public string TargetId
		{
			[CompilerGenerated]
			get
			{
				return m_872;
			}
			[CompilerGenerated]
			set
			{
				m_872 = value;
			}
		}

		public string DisplayName
		{
			[CompilerGenerated]
			get
			{
				return m_873;
			}
			[CompilerGenerated]
			set
			{
				m_873 = value;
			}
		}

		public string Priority
		{
			get
			{
				return _priority;
			}
			set
			{
				if (!(_priority == value))
				{
					_priority = value;
					m_871?.Invoke(this, new PropertyChangedEventArgs("Priority"));
				}
			}
		}

		public event PropertyChangedEventHandler? PropertyChanged
		{
			[CompilerGenerated]
			add
			{
				PropertyChangedEventHandler propertyChangedEventHandler = m_871;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange(ref m_871, value2, propertyChangedEventHandler2);
				}
				while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				PropertyChangedEventHandler propertyChangedEventHandler = m_871;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange(ref m_871, value2, propertyChangedEventHandler2);
				}
				while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
			}
		}
	}

	[CompilerGenerated]
	private static class m_708
	{
		public static HwndSourceHook A;

		public static Func<CancellationToken, Task<(bool Success, string Message)>> m_874;

		public static Func<CancellationToken, Task<(bool Success, string Message)>> a;
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class m_709
	{
		public static readonly m_709 A = new m_709();

		public static Func<FacebookAccountRow, bool> m_875;

		public static Func<FacebookAccountRow, string> m_876;

		public static Func<IGrouping<string, FacebookAccountRow>, bool> m_877;

		public static Func<IGrouping<string, FacebookAccountRow>, string> m_878;

		public static Func<string, string> m_879;

		public static Func<string, bool> m_880;

		public static Func<string, string> a;

		public static Func<string, bool> m_881;

		public static Func<FacebookAccountRow, bool> m_882;

		public static Func<FacebookAccountRow, bool> B;

		public static Func<FacebookAccountRow, bool> b;

		public static Func<FacebookAccountRow, bool> C;

		public static Func<FacebookAccountRow, bool> c;

		public static Func<NickFolder, bool> m_883;

		public static Func<FacebookAccountRow, bool> D;

		public static Func<NickFolder, bool> m_884;

		public static Func<NickFolder, (int Id, string Name)> m_885;

		public static Func<(int Id, string Name), int> m_886;

		public static Func<NickFolder, bool> m_887;

		public static Func<FacebookAccountRow, bool> d;

		public static Func<NickFolder, bool> m_888;

		public static Func<NickFolder, bool> m_889;

		public static Func<FacebookAccountRow, bool> E;

		public static Func<ProfileRow, bool> m_890;

		public static Func<ProfileRow, string> m_891;

		public static Func<NickFolder, bool> m_892;

		public static Func<DataGridColumn, bool> m_893;

		public static Func<DataGridColumn, string> m_894;

		public static Func<string, bool> m_895;

		public static Func<DataGridColumn, int> m_896;

		public static Func<DataGridColumn, string> m_897;

		public static Func<string, bool> m_898;

		public static Func<(string Header, Func<FacebookAccountRow, string> Getter), string> m_899;

		public static Func<FacebookAccountRow, string> m_900;

		public static Func<PriorityTargetDisplay, bool> m_901;

		public static Func<PriorityTargetDisplay, string> m_902;

		public static Func<PriorityTargetDisplay, string> m_903;

		public static Func<CustomAiProvider, string> m_904;

		public static Func<PriorityTargetDisplay, bool> m_905;

		public static Func<PriorityTargetDisplay, bool> m_906;

		public static Func<PriorityTargetDisplay, string> m_907;

		public static Func<PriorityTargetDisplay, bool> m_908;

		public static Func<PriorityTargetDisplay, bool> m_909;

		public static Func<PriorityTargetDisplay, bool> m_910;

		public static Func<PriorityTargetDisplay, bool> m_911;

		public static Func<PriorityTargetDisplay, bool> m_912;

		public static Func<PriorityTargetDisplay, bool> m_913;

		public static Func<PriorityTargetDisplay, bool> e;

		public static Func<PriorityTargetDisplay, string> m_914;

		public static Func<FacebookAccountRow, bool> m_915;

		public static Func<PlatformAccountRow, bool> m_916;

		public static Func<PlatformAccountRow, bool> m_917;

		public static Func<PlatformAccountRow, bool> m_918;

		public static Func<PlatformAccountRow, bool> m_919;

		public static Func<FacebookAccountRow, AiVisionTestNickCandidate> m_920;

		public static Func<PlatformAccountRow, AiVisionTestNickCandidate> m_921;

		public static Func<PlatformAccountRow, AiVisionTestNickCandidate> m_922;

		public static Func<PlatformAccountRow, AiVisionTestNickCandidate> m_923;

		public static Func<PlatformAccountRow, AiVisionTestNickCandidate> m_924;

		public static Func<ScriptItem, bool> m_925;

		public static Func<ScriptItem, bool> m_926;

		public static Func<ScriptItem, bool> m_927;

		public static Func<FacebookAccountRow, bool> F;

		public static Func<FacebookAccountRow, string> m_928;

		public static Func<string, bool> m_929;

		public static Func<ScriptItem, bool> m_930;

		public static Func<FacebookAccountRow, bool> f;

		public static Func<FacebookAccountRow, bool> G;

		public static Func<ScriptItem, bool> m_931;

		public static Func<FacebookAccountRow, bool> g;

		public static Func<FacebookAccountRow, bool> H;

		public static Func<FacebookAccountRow, bool> h;

		public static Func<FacebookAccountRow, bool> I;

		public static Func<FacebookAccountRow, bool> i;

		public static Func<FacebookAccountRow, FacebookAccountRow> m_932;

		public static Func<FacebookAccountRow, string> m_933;

		public static Func<NickFolder, bool> m_934;

		public static Func<NickFolder, bool> m_935;

		public static Func<FacebookAccountRow, bool> J;

		public static Func<FacebookAccountRow, FacebookAccountRow> m_936;

		public static Func<FacebookAccountRow, string> m_937;

		public static Func<FacebookAccountRow, bool> j;

		public static Func<FacebookAccountRow, bool> K;

		public static Func<string, bool> m_938;

		public static Func<FacebookAccountRow, bool> k;

		public static Func<FacebookAccountRow, bool> L;

		public static Func<FacebookAccountRow, bool> l;

		public static Func<FacebookAccountRow, bool> M;

		public static Func<FacebookAccountRow, bool> m;

		public static Func<FacebookAccountRow, bool> N;

		public static Func<FacebookAccountRow, bool> n;

		public static Func<FacebookAccountRow, Task<(string Uid, string Code)>> m_939;

		public static Func<(string Uid, string Code), bool> m_940;

		public static Func<(string Uid, string Code), bool> m_941;

		public static Func<(string Uid, string Code), string> m_942;

		public static Func<(string Uid, string Code), string> m_943;

		public static Func<FacebookAccountRow, bool> O;

		public static Func<ProfileRow, bool> m_944;

		public static Func<ProfileRow, bool> m_945;

		public static Func<ProfileRow, bool> m_946;

		public static Func<ProfileRow, bool> m_947;

		public static Func<ProfileRow, bool> m_948;

		public static Func<ProfileRow, bool> m_949;

		public static Func<KatanaSessionResult, string> m_950;

		public static Func<ProfileRow, bool> m_951;

		public static Func<ProfileRow, bool> m_952;

		public static Func<ProfileRow, bool> m_953;

		public static Func<ProfileRow, bool> m_954;

		public static Func<KatanaSessionResult, string> m_955;

		public static Func<ProfileRow, bool> m_956;

		public static Func<ProfileRow, string> m_957;

		public static Action m_958;

		internal bool m_959(FacebookAccountRow P_0)
		{
			if (P_0.FolderId != -2)
			{
				return !string.IsNullOrWhiteSpace(P_0.Uid);
			}
			return false;
		}

		internal string m_960(FacebookAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal bool m_961(IGrouping<string, FacebookAccountRow> P_0)
		{
			return P_0.Count() > 1;
		}

		internal string m_962(IGrouping<string, FacebookAccountRow> P_0)
		{
			return P_0.Key;
		}

		internal string m_963(string P_0)
		{
			return P_0.Trim(new char[2] { '\r', ' ' });
		}

		internal bool m_964(string P_0)
		{
			return P_0.Length > 0;
		}

		internal string m_965(string P_0)
		{
			return P_0.Trim(new char[2] { '\r', ' ' });
		}

		internal bool m_966(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_967(FacebookAccountRow P_0)
		{
			return P_0.FolderId != -2;
		}

		internal bool m_968(FacebookAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_969(FacebookAccountRow P_0)
		{
			return string.Equals(P_0.TinhTrang, "LIVE", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_970(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.Proxy);
		}

		internal bool m_971(FacebookAccountRow P_0)
		{
			return P_0.ScriptId != 0;
		}

		internal bool m_972(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_973(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.ProfileChrome);
		}

		internal bool m_974(NickFolder P_0)
		{
			return P_0 != null;
		}

		internal (int Id, string Name) m_975(NickFolder P_0)
		{
			return (Id: P_0.Id, Name: P_0.Name);
		}

		internal int m_976((int Id, string Name) t)
		{
			return t.Id;
		}

		internal bool m_977(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_978(FacebookAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_979(NickFolder P_0)
		{
			if (P_0.Id != -2)
			{
				return P_0.Id != -1;
			}
			return false;
		}

		internal bool m_980(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_981(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.BrowserProfileId);
		}

		internal bool m_982(ProfileRow P_0)
		{
			return P_0.OS == "iOS";
		}

		internal string m_983(ProfileRow P_0)
		{
			return P_0.Name;
		}

		internal bool m_984(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_985(DataGridColumn P_0)
		{
			return P_0.Visibility != Visibility.Visible;
		}

		internal string m_986(DataGridColumn P_0)
		{
			return P_0.Header?.ToString() ?? "";
		}

		internal bool m_987(string P_0)
		{
			return P_0.Length > 0;
		}

		internal int m_988(DataGridColumn P_0)
		{
			return P_0.DisplayIndex;
		}

		internal string m_989(DataGridColumn P_0)
		{
			return P_0.Header?.ToString() ?? "";
		}

		internal bool m_990(string P_0)
		{
			return P_0.Length > 0;
		}

		internal string m_991((string Header, Func<FacebookAccountRow, string> Getter) f)
		{
			return f.Header;
		}

		internal string m_992(FacebookAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal bool m_993(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal);
		}

		internal string m_994(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.Substring("CliProxy:".Length);
		}

		internal string m_995(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId;
		}

		internal string m_996(CustomAiProvider P_0)
		{
			return P_0.Name;
		}

		internal bool m_997(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal);
		}

		internal bool m_998(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal);
		}

		internal string m_999(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.Substring("CliProxy:".Length);
		}

		internal bool m_1000(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal);
		}

		internal bool m_1001(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == "Claude";
		}

		internal bool m_1002(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == "Gemini";
		}

		internal bool m_1003(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == "HHTechApi";
		}

		internal bool m_1004(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == "VietApi";
		}

		internal bool m_1005(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == "Custom";
		}

		internal bool m_1006(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal);
		}

		internal string m_1007(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId.Substring("CliProxy:".Length);
		}

		internal bool m_1008(FacebookAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1009(PlatformAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1010(PlatformAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1011(PlatformAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1012(PlatformAccountRow P_0)
		{
			return P_0.IsSelected;
		}

		internal AiVisionTestNickCandidate m_1013(FacebookAccountRow P_0)
		{
			return new AiVisionTestNickCandidate
			{
				Uid = P_0.Uid,
				FolderId = P_0.FolderId,
				Variables = AiVisionVariables.BuildMap(P_0)
			};
		}

		internal AiVisionTestNickCandidate m_1014(PlatformAccountRow P_0)
		{
			return new AiVisionTestNickCandidate
			{
				Uid = P_0.Uid,
				FolderId = P_0.FolderId,
				Variables = AiVisionVariables.BuildMap(P_0)
			};
		}

		internal AiVisionTestNickCandidate m_1015(PlatformAccountRow P_0)
		{
			return new AiVisionTestNickCandidate
			{
				Uid = P_0.Uid,
				FolderId = P_0.FolderId,
				Variables = AiVisionVariables.BuildMap(P_0)
			};
		}

		internal AiVisionTestNickCandidate m_1016(PlatformAccountRow P_0)
		{
			return new AiVisionTestNickCandidate
			{
				Uid = P_0.Uid,
				FolderId = P_0.FolderId,
				Variables = AiVisionVariables.BuildMap(P_0)
			};
		}

		internal AiVisionTestNickCandidate m_1017(PlatformAccountRow P_0)
		{
			return new AiVisionTestNickCandidate
			{
				Uid = P_0.Uid,
				FolderId = P_0.FolderId,
				Variables = AiVisionVariables.BuildMap(P_0)
			};
		}

		internal bool m_1018(ScriptItem P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1019(ScriptItem P_0)
		{
			return P_0.CanManage;
		}

		internal bool m_1020(ScriptItem P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1021(FacebookAccountRow P_0)
		{
			return string.IsNullOrEmpty(P_0.Platform);
		}

		internal string m_1022(FacebookAccountRow P_0)
		{
			return P_0.Platform;
		}

		internal bool m_1023(string P_0)
		{
			return !string.IsNullOrEmpty(P_0);
		}

		internal bool m_1024(ScriptItem P_0)
		{
			return P_0.ChuDe == "Facebook";
		}

		internal bool m_1025(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.PhoneName);
		}

		internal bool m_1026(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.PhoneName);
		}

		internal bool m_1027(ScriptItem P_0)
		{
			return P_0.ChuDe == "Facebook";
		}

		internal bool m_1028(FacebookAccountRow P_0)
		{
			if (P_0.Platform == "Phone")
			{
				return string.IsNullOrWhiteSpace(P_0.PhoneName);
			}
			return false;
		}

		internal bool m_1029(FacebookAccountRow P_0)
		{
			if (P_0.Platform == "Phone")
			{
				return string.IsNullOrWhiteSpace(P_0.PhoneName);
			}
			return false;
		}

		internal bool m_1030(FacebookAccountRow P_0)
		{
			if (P_0.Platform == "Phone")
			{
				return !string.IsNullOrWhiteSpace(P_0.PhoneName);
			}
			return false;
		}

		internal bool m_1031(FacebookAccountRow P_0)
		{
			return P_0.Platform == "Chrome";
		}

		internal bool m_1032(FacebookAccountRow P_0)
		{
			return string.Equals(P_0.Platform, "Chrome", StringComparison.OrdinalIgnoreCase);
		}

		internal FacebookAccountRow m_1033(FacebookAccountRow P_0)
		{
			return P_0;
		}

		internal string m_1034(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang;
		}

		internal bool m_1035(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_1036(NickFolder P_0)
		{
			if (P_0.IsSystem)
			{
				return P_0.Id > 0;
			}
			return false;
		}

		internal bool m_1037(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.Uid);
		}

		internal FacebookAccountRow m_1038(FacebookAccountRow P_0)
		{
			return P_0;
		}

		internal string m_1039(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang;
		}

		internal bool m_1040(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "LIVE";
		}

		internal bool m_1041(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "DIE";
		}

		internal bool m_1042(string P_0)
		{
			return P_0.Contains("logged-out");
		}

		internal bool o(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "NOVERY";
		}

		internal bool P(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "LIVE";
		}

		internal bool p(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "CHECKPOINT";
		}

		internal bool Q(FacebookAccountRow P_0)
		{
			string tinhTrang = P_0.TinhTrang;
			if (tinhTrang == "Cookie die" || tinhTrang == "COOKIE DIE")
			{
				return true;
			}
			return false;
		}

		internal bool q(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "DIE";
		}

		internal bool R(FacebookAccountRow P_0)
		{
			return P_0.TinhTrang == "ERROR";
		}

		internal bool r(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.TwoFA);
		}

		internal Task<(string Uid, string Code)> S(FacebookAccountRow P_0)
		{
			return Task.Run(() => (Uid: P_0.Uid, Code: PlaywrightHumanHelpers.Get2fa(P_0.TwoFA)));
		}

		internal bool m_1043((string Uid, string Code) r)
		{
			return !string.IsNullOrEmpty(r.Code);
		}

		internal bool m_1044((string Uid, string Code) r)
		{
			return string.IsNullOrEmpty(r.Code);
		}

		internal string m_1045((string Uid, string Code) r)
		{
			return r.Uid + ": " + r.Code;
		}

		internal string m_1046((string Uid, string Code) f)
		{
			return f.Uid;
		}

		internal bool s(FacebookAccountRow P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0.Uid);
		}

		internal bool m_1047(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1048(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1049(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1050(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1051(ProfileRow P_0)
		{
			return !string.Equals(P_0.OS, "iOS", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_1052(ProfileRow P_0)
		{
			return string.Equals(P_0.OS, "iOS", StringComparison.OrdinalIgnoreCase);
		}

		internal string m_1053(KatanaSessionResult P_0)
		{
			return $"{P_0.Uid}|{P_0.Token}|{P_0.Cookie}";
		}

		internal bool m_1054(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1055(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal bool m_1056(ProfileRow P_0)
		{
			return !string.Equals(P_0.OS, "iOS", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_1057(ProfileRow P_0)
		{
			return string.Equals(P_0.OS, "iOS", StringComparison.OrdinalIgnoreCase);
		}

		internal string m_1058(KatanaSessionResult P_0)
		{
			return $"{P_0.Uid}|{P_0.Token}|{P_0.Cookie}";
		}

		internal bool m_1059(ProfileRow P_0)
		{
			return P_0.IsSelected;
		}

		internal string m_1060(ProfileRow P_0)
		{
			return P_0.Name;
		}

		internal void m_1061()
		{
			Application.Current.Shutdown();
		}

		internal string T(FacebookAccountRow P_0)
		{
			return P_0.PhoneName;
		}

		internal string t(FacebookAccountRow P_0)
		{
			return P_0.ScriptName;
		}

		internal string U(FacebookAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal string u(FacebookAccountRow P_0)
		{
			return P_0.Pass;
		}

		internal string V(FacebookAccountRow P_0)
		{
			return P_0.TwoFA;
		}

		internal string v(FacebookAccountRow P_0)
		{
			return P_0.Token;
		}

		internal string W(FacebookAccountRow P_0)
		{
			return P_0.Cookie;
		}

		internal string w(FacebookAccountRow P_0)
		{
			return P_0.Mail;
		}

		internal string X(FacebookAccountRow P_0)
		{
			return P_0.PassMail;
		}

		internal string x(FacebookAccountRow P_0)
		{
			return P_0.MailKhoiPhuc;
		}

		internal string Y(FacebookAccountRow P_0)
		{
			return P_0.PassMailKhoiPhuc;
		}

		internal string y(FacebookAccountRow P_0)
		{
			return P_0.BanBe;
		}

		internal string Z(FacebookAccountRow P_0)
		{
			return P_0.Nhom;
		}

		internal string z(FacebookAccountRow P_0)
		{
			return P_0.GioiTinh;
		}

		internal string aA(FacebookAccountRow P_0)
		{
			return P_0.Avatar;
		}

		internal string aa(FacebookAccountRow P_0)
		{
			return P_0.ProfileChrome;
		}

		internal string aB(FacebookAccountRow P_0)
		{
			return P_0.TenProfile;
		}

		internal string ab(FacebookAccountRow P_0)
		{
			return P_0.UserAgent;
		}

		internal string aC(FacebookAccountRow P_0)
		{
			return P_0.Proxy;
		}

		internal string ac(FacebookAccountRow P_0)
		{
			return P_0.TepCu;
		}

		internal string aD(FacebookAccountRow P_0)
		{
			return P_0.GhiChu;
		}

		internal string ad(FacebookAccountRow P_0)
		{
			return P_0.TuongTacCuoi;
		}

		internal string aE(FacebookAccountRow P_0)
		{
			return P_0.TrangThai;
		}

		internal void m_1062(FacebookAccountRow P_0, string P_1)
		{
			P_0.Pass = P_1;
		}

		internal void m_1063(FacebookAccountRow P_0, string P_1)
		{
			P_0.TwoFA = P_1;
		}

		internal void m_1064(FacebookAccountRow P_0, string P_1)
		{
			P_0.Token = P_1;
		}

		internal void m_1065(FacebookAccountRow P_0, string P_1)
		{
			P_0.Cookie = P_1;
		}

		internal void m_1066(FacebookAccountRow P_0, string P_1)
		{
			P_0.Mail = P_1;
		}

		internal void m_1067(FacebookAccountRow P_0, string P_1)
		{
			P_0.PassMail = P_1;
		}

		internal void m_1068(FacebookAccountRow P_0, string P_1)
		{
			P_0.MailKhoiPhuc = P_1;
		}

		internal void m_1069(FacebookAccountRow P_0, string P_1)
		{
			P_0.PassMailKhoiPhuc = P_1;
		}

		internal void m_1070(FacebookAccountRow P_0, string P_1)
		{
			P_0.BanBe = P_1;
		}

		internal void m_1071(FacebookAccountRow P_0, string P_1)
		{
			P_0.Nhom = P_1;
		}

		internal void m_1072(FacebookAccountRow P_0, string P_1)
		{
			P_0.GioiTinh = P_1;
		}

		internal void m_1073(FacebookAccountRow P_0, string P_1)
		{
			P_0.Proxy = P_1;
		}

		internal void m_1074(FacebookAccountRow P_0, string P_1)
		{
			P_0.GhiChu = P_1;
		}

		internal void m_1075(FacebookAccountRow P_0, string P_1)
		{
			P_0.TuongTacCuoi = P_1;
		}

		internal void m_1076(FacebookAccountRow P_0, string P_1)
		{
			P_0.TrangThai = P_1;
		}

		internal void m_1077(FacebookAccountRow P_0, string P_1)
		{
			P_0.PhoneName = P_1;
		}
	}

	[CompilerGenerated]
	private sealed class m_710
	{
		public MainWindow A;

		public List<(int Id, string Name)> m_1078;

		public Dictionary<int, List<FacebookAccountRow>> m_1079;

		internal NickFolder m_1080(int P_0)
		{
			return A.Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == P_0);
		}

		internal List<FacebookAccountRow> m_1081((int Id, string Name) t)
		{
			return A.Facebooks.Where((FacebookAccountRow P_0) => P_0.FolderId == t.Id).ToList();
		}

		internal async Task m_1082(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			foreach (var (key, folderName) in m_1078)
			{
				await GoogleSheetsSyncService.SyncFolderAsync(P_0, P_1.SpreadsheetId, folderName, GoogleSheetsSyncService.BuildRows(m_1079[key]), CancellationToken.None);
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_711
	{
		public int A;

		internal bool m_1090(NickFolder P_0)
		{
			return P_0.Id == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_712
	{
		public (int Id, string Name) A;

		internal bool m_1091(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}
	}

	[CompilerGenerated]
	private sealed class m_713
	{
		public NickFolder A;

		public Func<FacebookAccountRow, bool> m_1092;

		internal bool m_1093(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}

		internal bool a(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}
	}

	[CompilerGenerated]
	private sealed class m_714
	{
		public List<FacebookAccountRow> A;

		public MainWindow m_1094;
	}

	[CompilerGenerated]
	private sealed class m_715
	{
		public NickFolder A;

		public m_714 m_1095;

		internal void m_1096(object P_0, RoutedEventArgs P_1)
		{
			foreach (FacebookAccountRow item in m_1095.A)
			{
				item.FolderId = A.Id;
				item.IsSelected = false;
			}
			ICollectionView? val = m_1095.m_1094.m_501;
			if (val != null)
			{
				val.Refresh();
			}
			m_1095.m_1094.g();
			m_1095.m_1094.H();
			m_1095.m_1094.MoveFolderPopup.IsOpen = false;
		}
	}

	[CompilerGenerated]
	private sealed class m_716
	{
		public int A;

		internal bool m_1097(NickFolder P_0)
		{
			return P_0.Id == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_717
	{
		public string A;

		internal bool m_1098(CustomPlatformEntry P_0)
		{
			return P_0.Key == A;
		}

		internal bool a(CustomPlatformEntry P_0)
		{
			return P_0.Key == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_718
	{
		public string A;

		internal bool m_1099(CustomPlatformEntry P_0)
		{
			return P_0.Key == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_719
	{
		public TextBlock A;

		public PlatformAccountPage m_1100;

		public MainWindow m_1101;

		public CustomPlatformEntry m_1102;

		internal void m_1103(object? _, NotifyCollectionChangedEventArgs P_1)
		{
			A.Text = m_1100.Accounts.Count.ToString();
		}

		internal void m_1104(object P_0, RoutedEventArgs P_1)
		{
			m_1101.m_606(m_1102.Key);
		}
	}

	[CompilerGenerated]
	private sealed class m_720
	{
		public CustomPlatformEntry A;

		internal bool m_1105(CustomPlatformEntry P_0)
		{
			return P_0.Key == A.Key;
		}
	}

	[CompilerGenerated]
	private sealed class m_721
	{
		public string A;

		public MainWindow m_1106;

		internal void m_1107(object P_0, RoutedEventArgs P_1)
		{
			m_1106.m_614(A);
		}
	}

	[CompilerGenerated]
	private sealed class m_722
	{
		public TextBlock A;

		public TextBox m_1108;

		internal void m_1109()
		{
			A.Visibility = ((!string.IsNullOrEmpty(m_1108.Text)) ? Visibility.Collapsed : Visibility.Visible);
		}

		internal void m_1110(object P_0, TextChangedEventArgs P_1)
		{
			m_1109();
		}
	}

	[CompilerGenerated]
	private sealed class m_723
	{
		public int A;

		internal bool m_1111(NickFolder P_0)
		{
			return P_0.Id == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_724
	{
		public GoogleSheetsSyncSettings A;

		public Func<SheetsService, GoogleSheetsSyncSettings, Task> m_1112;

		public MainWindow m_1113;

		internal async Task? m_1114()
		{
			_ = 1;
			try
			{
				using SheetsService arg = await GoogleSheetsSyncService.AuthorizeAsync(this.A, CancellationToken.None);
				await m_1112(arg, this.A);
			}
			catch (Exception ex)
			{
				Exception ex2 = ex;
				Exception A = ex2;
				((DispatcherObject)m_1113).Dispatcher.Invoke((Action)(() =>
				{
					CustomMessageBox.Show(m_1113, "Đồng bộ Google Sheets thất bại: " + A.Message, "Đồng bộ Google Sheets", NotifyType.Warning);
				}));
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_725
	{
		public Exception A;

		public m_724 m_1121;

		internal void m_1122()
		{
			CustomMessageBox.Show(m_1121.m_1113, "Đồng bộ Google Sheets thất bại: " + A.Message, "Đồng bộ Google Sheets", NotifyType.Warning);
		}
	}

	[CompilerGenerated]
	private sealed class m_726
	{
		public int A;

		public string m_1123;

		public List<FacebookAccountRow> m_1124;

		internal bool m_1125(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A;
		}

		internal Task m_1126(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			return GoogleSheetsSyncService.SyncFolderAsync(P_0, P_1.SpreadsheetId, m_1123, GoogleSheetsSyncService.BuildRows(m_1124), CancellationToken.None);
		}
	}

	[CompilerGenerated]
	private sealed class m_727
	{
		public string A;

		internal Task m_1127(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			return GoogleSheetsSyncService.DeleteFolderSheetAsync(P_0, P_1.SpreadsheetId, A, CancellationToken.None);
		}
	}

	[CompilerGenerated]
	private sealed class m_728
	{
		public string A;

		public string a;

		internal Task m_1128(SheetsService P_0, GoogleSheetsSyncSettings P_1)
		{
			return GoogleSheetsSyncService.RenameFolderSheetAsync(P_0, P_1.SpreadsheetId, A, a, CancellationToken.None);
		}
	}

	[CompilerGenerated]
	private sealed class m_729
	{
		public DataGridColumn A;

		public MainWindow m_1129;

		internal void m_1130(object P_0, RoutedEventArgs P_1)
		{
			A.Visibility = Visibility.Visible;
			m_1129.t();
		}

		internal void a(object P_0, RoutedEventArgs P_1)
		{
			A.Visibility = Visibility.Collapsed;
			m_1129.t();
		}
	}

	[CompilerGenerated]
	private sealed class m_730
	{
		public bool A;

		public UIElement m_1131;

		public Popup m_1132;

		public MainWindow m_1133;

		internal void m_1134()
		{
			if (A && m_1131 != null)
			{
				m_1132.Placement = PlacementMode.Bottom;
				m_1132.PlacementTarget = m_1131;
			}
			else
			{
				m_1132.Placement = PlacementMode.Center;
				m_1132.PlacementTarget = m_1133;
			}
			m_1132.IsOpen = true;
		}
	}

	[CompilerGenerated]
	private sealed class m_731
	{
		public string A;

		internal bool m_1135(DataGridColumn P_0)
		{
			return (P_0.Header?.ToString() ?? "") == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_732
	{
		public FacebookAccountRow A;

		public MainWindow m_1136;

		internal string m_1137(string P_0)
		{
			return m_535.First(((string Header, Func<FacebookAccountRow, string> Getter) tuple) => tuple.Header == P_0).Getter(A);
		}

		internal bool m_1138((string Header, Func<FacebookAccountRow, string> Getter) f)
		{
			return m_1136.m_536.Contains(f.Header);
		}
	}

	[CompilerGenerated]
	private sealed class m_733
	{
		public string A;

		internal bool m_1139((string Header, Func<FacebookAccountRow, string> Getter) f)
		{
			return f.Header == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_734
	{
		public FacebookAccountRow A;

		internal string m_1140((string Header, Func<FacebookAccountRow, string> Getter) f)
		{
			return f.Getter(A);
		}
	}

	[CompilerGenerated]
	private sealed class m_735
	{
		public string A;

		internal bool m_1141(FacebookAccountRow P_0)
		{
			return P_0.Uid == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_736
	{
		public string A;

		internal bool m_1142(CustomAiProvider P_0)
		{
			return P_0.Name == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_737
	{
		public string A;

		internal bool m_1143(CustomAiProvider P_0)
		{
			return string.Equals(P_0.Name, A, StringComparison.OrdinalIgnoreCase);
		}
	}

	[CompilerGenerated]
	private sealed class m_738
	{
		public string A;

		internal bool m_1144(CustomAiProvider P_0)
		{
			return P_0.Name == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_739
	{
		public string A;

		internal bool m_1145(CustomAiProvider P_0)
		{
			return P_0.Name == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_740
	{
		public string A;

		internal bool m_1146(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == "CliProxy:" + A;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct m_741
	{
		public Brush A;

		public Brush a;
	}

	[CompilerGenerated]
	private sealed class m_742
	{
		public string A;

		internal bool m_1147(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_743
	{
		public string A;

		internal bool m_1148(PriorityTargetDisplay P_0)
		{
			return P_0.TargetId == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_744
	{
		public int? A;

		public List<AiVisionFlowStep> m_1149;

		public int m_1150;

		public MainWindow m_1151;

		internal void m_1152(int P_0, AiVisionFlowStep? P_1)
		{
			if (A != P_0)
			{
				A = P_0;
				m_1149 = new List<AiVisionFlowStep>();
				m_1150 = 0;
			}
			if (P_1 != null)
			{
				m_1149.Add(P_1);
			}
			else
			{
				m_1150++;
			}
		}

		internal void m_1153(string P_0)
		{
			m_1151.m_658(P_0, false);
		}
	}

	[CompilerGenerated]
	private sealed class m_745
	{
		public AiVisionStepLog A;

		public MainWindow m_1154;

		internal void m_1155()
		{
			A.TimeLabel = m_657(A, m_1154.m_496);
			m_1154.m_496.Add(A);
			m_1154.PhoneAiLogScrollViewer.ScrollToBottom();
		}
	}

	[CompilerGenerated]
	private sealed class m_746
	{
		public string A;

		internal bool m_1156(ProfileRow P_0)
		{
			return P_0.Name == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_747
	{
		public string A;

		internal bool m_1157(ProfileRow P_0)
		{
			return P_0.Name == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_748
	{
		public int? A;

		public List<AiVisionFlowStep> m_1158;

		public int m_1159;

		internal void m_1160(int P_0, AiVisionFlowStep? P_1)
		{
			if (A != P_0)
			{
				A = P_0;
				m_1158 = new List<AiVisionFlowStep>();
				m_1159 = 0;
			}
			if (P_1 != null)
			{
				m_1158.Add(P_1);
			}
			else
			{
				m_1159++;
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_749
	{
		public AiVisionStepLog A;

		public MainWindow m_1161;

		internal void m_1162()
		{
			A.TimeLabel = m_657(A, m_1161.m_499);
			m_1161.m_499.Add(A);
			m_1161.ChromeAiLogScrollViewer.ScrollToBottom();
		}
	}

	[CompilerGenerated]
	private sealed class m_750
	{
		public ScriptItem A;

		public Func<FacebookAccountRow, bool> m_1163;

		internal bool m_1164(FacebookAccountRow P_0)
		{
			return P_0.ScriptId == A.Id;
		}
	}

	[CompilerGenerated]
	private sealed class m_751
	{
		public List<FacebookAccountRow> A;

		public MainWindow m_1165;
	}

	[CompilerGenerated]
	private sealed class m_752
	{
		public ProfileRow A;

		public m_751 m_1166;

		internal void m_1167(object P_0, RoutedEventArgs P_1)
		{
			foreach (FacebookAccountRow item in m_1166.A)
			{
				item.PhoneName = A.Name;
				item.ProfileChrome = "";
			}
			m_1166.m_1165.AttachPhonePopup.IsOpen = false;
			CustomMessageBox.Show(m_1166.m_1165, $"Đã gắn máy \"{A.Name}\" cho {m_1166.A.Count} nick.", "Gắn Phone");
		}
	}

	[CompilerGenerated]
	private sealed class m_753
	{
		public MainWindow A;

		public List<FacebookAccountRow> m_1168;

		internal async Task? m_1169()
		{
			try
			{
				string A = (await AdbController.ListDevicesAsync()).FirstOrDefault() ?? "";
				if (string.IsNullOrEmpty(A))
				{
					return;
				}
				((DispatcherObject)this.A).Dispatcher.Invoke((Action)(() =>
				{
					foreach (FacebookAccountRow item in m_1168)
					{
						if (string.IsNullOrWhiteSpace(item.PhoneName))
						{
							item.PhoneName = A;
						}
					}
				}));
			}
			catch
			{
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_754
	{
		public string A;

		public m_753 m_1175;

		internal void m_1176()
		{
			foreach (FacebookAccountRow item in m_1175.m_1168)
			{
				if (string.IsNullOrWhiteSpace(item.PhoneName))
				{
					item.PhoneName = A;
				}
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_755
	{
		public MainWindow A;

		public ScriptItem m_1177;

		internal void m_1178(object P_0, RoutedEventArgs P_1)
		{
			A.m_673(m_1177);
		}
	}

	[CompilerGenerated]
	private sealed class m_756
	{
		public MainWindow A;

		public CancellationToken m_1179;

		public List<FacebookAccountRow> m_1180;

		internal bool m_1181(FacebookAccountRow P_0)
		{
			if (!string.IsNullOrEmpty(P_0.Platform) && P_0.ScriptId > 0)
			{
				return m_675(A.Scripts.FirstOrDefault((ScriptItem scriptItem) => scriptItem.Id == P_0.ScriptId), P_0.Platform);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_757
	{
		public FacebookAccountRow A;

		internal bool m_1182(ScriptItem P_0)
		{
			return P_0.Id == A.ScriptId;
		}
	}

	[CompilerGenerated]
	private sealed class m_758
	{
		public AiVisionStepLog A;

		public m_772 m_1183;

		internal string m_1184()
		{
			return m_1183.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_759
	{
		public string A;

		public m_772 m_1185;

		internal string m_1186()
		{
			return m_1185.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_760
	{
		public AiVisionStepLog A;

		public m_772 m_1187;

		internal string m_1188()
		{
			return m_1187.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_761
	{
		public AiVisionStepLog A;

		public m_772 m_1189;

		internal string m_1190()
		{
			return m_1189.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_762
	{
		public string A;

		public m_772 m_1191;

		internal string m_1192()
		{
			return m_1191.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_763
	{
		public AiVisionStepLog A;

		public m_772 m_1193;

		internal string m_1194()
		{
			return m_1193.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_764
	{
		public string A;

		public m_772 m_1195;

		internal string m_1196()
		{
			return m_1195.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_765
	{
		public AiVisionStepLog A;

		public m_772 m_1197;

		internal string m_1198()
		{
			return m_1197.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_766
	{
		public string A;

		public m_772 m_1199;

		internal string m_1200()
		{
			return m_1199.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_767
	{
		public AiVisionStepLog A;

		public m_772 m_1201;

		internal string m_1202()
		{
			return m_1201.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_768
	{
		public SemaphoreSlim A;

		public Dictionary<FacebookAccountRow, string> m_1203;

		public int m_1204;

		public string m_1205;

		public m_756 m_1206;

		internal async Task m_1207(FacebookAccountRow P_0)
		{
			try
			{
				await this.A.WaitAsync(m_1206.m_1179);
				try
				{
					if (m_1206.m_1179.IsCancellationRequested)
					{
						P_0.TrangThai = "Đã dừng.";
						return;
					}
					ScriptItem scriptItem = m_1206.A.Scripts.FirstOrDefault((ScriptItem scriptItem2) => scriptItem2.Id == P_0.ScriptId && m_675(scriptItem2, P_0.Platform));
					if (scriptItem == null)
					{
						P_0.TrangThai = "Chưa gắn kịch bản " + P_0.Platform + " cho nick này.";
						return;
					}
					AiVisionFlowDocument aiVisionFlowDocument = AiVisionFlowStore.Deserialize(scriptItem.AiVisionFlowJson);
					List<AiVisionFlowStep> steps = aiVisionFlowDocument.Steps;
					bool flag = true;
					if (scriptItem.IsSystem && scriptItem.Name == "Đăng nhập")
					{
						LoginResult loginResult = await LoginRunnerFactory.GetRunner(P_0.Platform, "Katana", (string text) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}).LoginAsync(P_0, m_1206.m_1179);
						m_581(P_0, loginResult.TrangThai);
						await m_676(P_0, loginResult.TinhTrang, loginResult.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Tạo Page")
					{
						PageCreationSettings pageSettings = PageCreationSettings.FromJson(P_0.PageCreationSettingsJson);
						AiVisionRunResult aiVisionRunResult = ((!(P_0.Platform == "Phone") && !(P_0.Platform == "Android")) ? (await FacebookPageCreationRunner.RunAsync(P_0, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179, pageSettings, m_1206.m_1180.IndexOf(P_0))) : (await FacebookKatanaPageCreationService.RunAsync(P_0, (string text) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1206.m_1179, pageSettings, m_1206.m_1180.IndexOf(P_0))));
						m_581(P_0, aiVisionRunResult.Message);
						await m_676(P_0, aiVisionRunResult.TinhTrang, aiVisionRunResult.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Tạo BM")
					{
						BmCreationSettings bmSettings = BmCreationSettings.FromJson(P_0.BmCreationSettingsJson);
						AiVisionRunResult aiVisionRunResult2 = await FacebookBmCreationRunner.RunAsync(P_0, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179, bmSettings, m_1206.m_1180.IndexOf(P_0));
						m_581(P_0, aiVisionRunResult2.Message);
						await m_676(P_0, aiVisionRunResult2.TinhTrang, aiVisionRunResult2.Success, m_1203[P_0]);
					}
					else if (P_0.Platform == "Phone" && !scriptItem.IsSystem)
					{
						if (steps.Count == 0)
						{
							P_0.TrangThai = "Kịch bản \"" + scriptItem.Name + "\" chưa có bước nào.";
							return;
						}
						if (!string.IsNullOrWhiteSpace(P_0.PhoneName))
						{
							await PhoneInitialSetupService.EnsureInitialSetupAsync(P_0.PhoneName, scriptItem.Platform ?? "All", (string text) =>
							{
								((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
							}, m_1206.m_1179);
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = "Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)..."));
							await AdbController.EnsureEnglishLanguageAsync(P_0.PhoneName, m_1206.m_1179);
						}
						Dictionary<string, string> variables = AiVisionVariables.BuildMap(P_0);
						await AiVisionVariables.ResolveVerifyVariablesAsync(variables, steps, m_1206.m_1179);
						AiVisionRunResult aiVisionRunResult3 = await PhoneAiVisionRunner.RunFlowAsync(DeviceControllerFactory.Resolve(m_1206.A.Profiles, P_0.PhoneName), steps, variables, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179);
						m_581(P_0, aiVisionRunResult3.Message);
						await m_676(P_0, aiVisionRunResult3.TinhTrang, aiVisionRunResult3.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Nuôi nick")
					{
						FeedBrowsingSettings settings = FeedBrowsingSettings.FromJson(P_0.FeedBrowsingSettingsJson);
						IReadOnlyCollection<FacebookAccountRow> sessionNicks = m_1206.m_1180.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform == "Chrome" && facebookAccountRow.ScriptId == P_0.ScriptId).ToList();
						AiVisionRunResult aiVisionRunResult4 = await FacebookFeedBrowsingRunner.RunAsync(P_0, settings, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179, sessionNicks);
						m_581(P_0, aiVisionRunResult4.Message);
						await m_676(P_0, aiVisionRunResult4.TinhTrang, aiVisionRunResult4.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Spam nhóm")
					{
						GroupSpamSettings settings2 = GroupSpamSettings.FromJson(P_0.GroupSpamSettingsJson);
						AiVisionRunResult aiVisionRunResult5 = ((!(P_0.Platform == "Phone") && !(P_0.Platform == "Android")) ? (await FacebookGroupSpamRunner.RunAsync(P_0, settings2, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179)) : (await FacebookKatanaPhoneInteractionService.SpamGroupAsync(P_0, settings2, (string text) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1206.m_1179)));
						m_581(P_0, aiVisionRunResult5.Message);
						await m_676(P_0, aiVisionRunResult5.TinhTrang, aiVisionRunResult5.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Nhắn tin")
					{
						MessagingSettings settings3 = MessagingSettings.FromJson(P_0.MessagingSettingsJson);
						IReadOnlyCollection<FacebookAccountRow> sessionNicks2 = m_1206.m_1180.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform == "Chrome" && facebookAccountRow.ScriptId == P_0.ScriptId).ToList();
						AiVisionRunResult aiVisionRunResult6 = await FacebookMessagingRunner.RunAsync(P_0, settings3, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179, sessionNicks2);
						m_581(P_0, aiVisionRunResult6.Message);
						await m_676(P_0, aiVisionRunResult6.TinhTrang, aiVisionRunResult6.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Kết bạn")
					{
						FriendRequestSettings settings4 = FriendRequestSettings.FromJson(P_0.FriendRequestSettingsJson);
						AiVisionRunResult aiVisionRunResult7 = ((!(P_0.Platform == "Phone") && !(P_0.Platform == "Android")) ? (await FacebookFriendRequestRunner.RunAsync(P_0, settings4, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179)) : (await FacebookKatanaPhoneInteractionService.SendFriendRequestsAsync(P_0, settings4, (string text) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1206.m_1179)));
						m_581(P_0, aiVisionRunResult7.Message);
						await m_676(P_0, aiVisionRunResult7.TinhTrang, aiVisionRunResult7.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Nuôi bài viết")
					{
						PostBoostSettings settings5 = PostBoostSettings.FromJson(P_0.PostBoostSettingsJson);
						AiVisionRunResult aiVisionRunResult8 = ((!(P_0.Platform == "Phone") && !(P_0.Platform == "Android")) ? (await FacebookPostBoostRunner.RunAsync(P_0, settings5, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179)) : (await FacebookKatanaPhoneInteractionService.BoostPostAsync(P_0, settings5, (string text) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1206.m_1179)));
						m_581(P_0, aiVisionRunResult8.Message);
						await m_676(P_0, aiVisionRunResult8.TinhTrang, aiVisionRunResult8.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Đăng bài viết")
					{
						PostCreationSettings settings6 = PostCreationSettings.FromJson(P_0.PostCreationSettingsJson);
						AiVisionRunResult aiVisionRunResult9 = ((!(P_0.Platform == "Phone") && !(P_0.Platform == "Android")) ? (await FacebookPostCreationRunner.RunAsync(P_0, settings6, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179)) : (await FacebookKatanaPhoneInteractionService.PostToWallAsync(P_0, settings6, (string text) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
						}, m_1206.m_1179)));
						m_581(P_0, aiVisionRunResult9.Message);
						await m_676(P_0, aiVisionRunResult9.TinhTrang, aiVisionRunResult9.Success, m_1203[P_0]);
					}
					else if (scriptItem.IsSystem && scriptItem.Name == "Đăng bài trên page")
					{
						PagePostSettings settings7 = PagePostSettings.FromJson(P_0.PagePostSettingsJson);
						AiVisionRunResult aiVisionRunResult10 = await FacebookPagePostRunner.RunAsync(P_0, settings7, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179);
						m_581(P_0, aiVisionRunResult10.Message);
						await m_676(P_0, aiVisionRunResult10.TinhTrang, aiVisionRunResult10.Success, m_1203[P_0]);
					}
					else if (steps.Count > 0)
					{
						Dictionary<string, string> variables = AiVisionVariables.BuildMap(P_0);
						await AiVisionVariables.ResolveVerifyVariablesAsync(variables, steps, m_1206.m_1179);
						AiVisionRunResult aiVisionRunResult11 = await ChromeAiVisionRunner.RunFlowForNickAsync(P_0, steps, variables, (AiVisionStepLog aiVisionStepLog) =>
						{
							((DispatcherObject)m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
						}, m_1206.m_1179);
						m_581(P_0, aiVisionRunResult11.Message);
						await m_676(P_0, aiVisionRunResult11.TinhTrang, aiVisionRunResult11.Success, m_1203[P_0]);
					}
					else
					{
						HashSet<int> A = FacebookAccountDatabase.LoadActionIdsForFolder(scriptItem.Id);
						int value = m_1206.A.Actions.Count((InteractionAction interactionAction) => A.Contains(interactionAction.Id));
						P_0.TrangThai = $"Đang chạy: {scriptItem.Name} ({value} hành động) trên Chrome";
						flag = false;
					}
					if (flag)
					{
						P_0.TuongTacCuoi = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
					}
				}
				finally
				{
					this.A.Release();
				}
			}
			catch (OperationCanceledException)
			{
				P_0.TrangThai = "Đã dừng.";
				await m_676(P_0, "", false, m_1203[P_0]);
			}
			catch (Exception ex2)
			{
				m_581(P_0, "Lỗi kịch bản: " + ex2.Message);
				await m_676(P_0, "", false, m_1203[P_0]);
			}
			finally
			{
				Interlocked.Increment(ref m_1204);
				m_1206.A.RunScriptButtonText.Text = $"Đang chạy kịch bản... ({m_1204}/{m_1206.m_1180.Count}){m_1205}";
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_769
	{
		public AiVisionStepLog A;

		public m_772 m_1221;

		internal string m_1222()
		{
			return m_1221.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_770
	{
		public AiVisionStepLog A;

		public m_772 m_1223;

		internal string m_1224()
		{
			return m_1223.A.TrangThai = A.FlowStepLabel + A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_771
	{
		public HashSet<int> A;

		internal bool m_1225(InteractionAction P_0)
		{
			return A.Contains(P_0.Id);
		}
	}

	[CompilerGenerated]
	private sealed class m_772
	{
		public FacebookAccountRow A;

		public m_768 m_1226;

		public Func<ScriptItem, bool> m_1227;

		public Action<string> m_1228;

		public Action<string> a;

		public Action<AiVisionStepLog> m_1229;

		public Action<AiVisionStepLog> m_1230;

		public Action<string> B;

		public Func<string> m_1231;

		public Action<AiVisionStepLog> m_1232;

		public Func<FacebookAccountRow, bool> m_1233;

		public Action<AiVisionStepLog> b;

		public Action<string> m_1234;

		public Action<AiVisionStepLog> C;

		public Func<FacebookAccountRow, bool> m_1235;

		public Action<AiVisionStepLog> c;

		public Action<string> m_1236;

		public Action<AiVisionStepLog> D;

		public Action<string> m_1237;

		public Action<AiVisionStepLog> d;

		public Action<string> m_1238;

		public Action<AiVisionStepLog> E;

		public Action<AiVisionStepLog> e;

		public Action<AiVisionStepLog> F;

		internal bool m_1239(ScriptItem P_0)
		{
			if (P_0.Id == A.ScriptId)
			{
				return m_675(P_0, A.Platform);
			}
			return false;
		}

		internal void m_1240(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void m_1241(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void m_1242(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1243(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1244(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal string m_1245()
		{
			return A.TrangThai = "Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...";
		}

		internal void m_1246(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.FlowStepLabel + P_0.ActionSummary));
		}

		internal bool m_1247(FacebookAccountRow P_0)
		{
			if (P_0.Platform == "Chrome")
			{
				return P_0.ScriptId == A.ScriptId;
			}
			return false;
		}

		internal void m_1248(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1249(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void m_1250(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal bool m_1251(FacebookAccountRow P_0)
		{
			if (P_0.Platform == "Chrome")
			{
				return P_0.ScriptId == A.ScriptId;
			}
			return false;
		}

		internal void m_1252(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1253(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void m_1254(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1255(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void m_1256(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1257(string P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}

		internal void m_1258(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1259(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.ActionSummary));
		}

		internal void m_1260(AiVisionStepLog P_0)
		{
			((DispatcherObject)m_1226.m_1206.A).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0.FlowStepLabel + P_0.ActionSummary));
		}
	}

	[CompilerGenerated]
	private sealed class m_773
	{
		public string A;

		public m_772 m_1261;

		internal string m_1262()
		{
			return m_1261.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_774
	{
		public string A;

		public m_772 m_1263;

		internal string m_1264()
		{
			return m_1263.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_775
	{
		public AiVisionStepLog A;

		public m_772 m_1265;

		internal string m_1266()
		{
			return m_1265.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_776
	{
		public AiVisionStepLog A;

		public m_772 m_1267;

		internal string m_1268()
		{
			return m_1267.A.TrangThai = A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_777
	{
		public string A;

		public m_772 m_1269;

		internal string m_1270()
		{
			return m_1269.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_778
	{
		public AiVisionStepLog A;

		public m_772 m_1271;

		internal string m_1272()
		{
			return m_1271.A.TrangThai = A.FlowStepLabel + A.ActionSummary;
		}
	}

	[CompilerGenerated]
	private sealed class m_779
	{
		public CancellationToken A;

		public string m_1273;

		public string a;

		public MainWindow m_1274;

		public SemaphoreSlim m_1275;

		internal async Task m_1276(FacebookAccountRow P_0)
		{
			await m_1275.WaitAsync(A);
			try
			{
				P_0.TrangThai = "Đang đăng nhập...";
				P_0.TinhTrang = "";
				LoginResult loginResult = await LoginRunnerFactory.GetRunner(m_1273, a, (string text) =>
				{
					((DispatcherObject)m_1274).Dispatcher.Invoke<string>((Func<string>)(() => P_0.TrangThai = text));
				}).LoginAsync(P_0, A);
				P_0.TinhTrang = loginResult.TinhTrang;
				m_581(P_0, loginResult.TrangThai);
			}
			catch (OperationCanceledException)
			{
				P_0.TrangThai = "Đã dừng.";
			}
			catch (Exception ex2)
			{
				P_0.TinhTrang = "ERROR";
				m_581(P_0, "Lỗi đăng nhập: " + ex2.Message);
			}
			finally
			{
				m_1275.Release();
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_780
	{
		public FacebookAccountRow A;

		public m_779 m_1284;

		internal void m_1285(string P_0)
		{
			((DispatcherObject)m_1284.m_1274).Dispatcher.Invoke<string>((Func<string>)(() => A.TrangThai = P_0));
		}
	}

	[CompilerGenerated]
	private sealed class m_781
	{
		public string A;

		public m_780 m_1286;

		internal string m_1287()
		{
			return m_1286.A.TrangThai = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_782
	{
		public FacebookAccountRow A;

		internal bool m_1288(NickFolder P_0)
		{
			return P_0.Id == A.FolderId;
		}
	}

	[CompilerGenerated]
	private sealed class m_783
	{
		public FacebookExportItem A;

		internal bool m_1289(NickFolder P_0)
		{
			if (P_0.Id > 0)
			{
				return P_0.Name == A.FolderName;
			}
			return false;
		}

		internal bool m_1290(ScriptItem P_0)
		{
			return P_0.Name == A.ScriptFolderName;
		}
	}

	[CompilerGenerated]
	private sealed class m_784
	{
		public KeyValuePair<string, List<FacebookAccountRow>> A;

		internal bool m_1291(NickFolder P_0)
		{
			if (P_0.Id > 0)
			{
				return P_0.Name == A.Key;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_785
	{
		public FacebookAccountRow A;

		internal bool m_1292(ScriptItem P_0)
		{
			return P_0.Name == A.ScriptName;
		}
	}

	[CompilerGenerated]
	private sealed class m_786
	{
		public SemaphoreSlim A;

		public Dictionary<FacebookAccountRow, string> m_1293;

		public int m_1294;

		public MainWindow m_1295;

		public List<FacebookAccountRow> m_1296;

		internal async Task m_1297(FacebookAccountRow P_0)
		{
			await A.WaitAsync();
			try
			{
				string text = await K(P_0.Uid);
				P_0.TinhTrang = ((text != "") ? text : m_1293[P_0]);
			}
			finally
			{
				A.Release();
				Interlocked.Increment(ref m_1294);
				m_1295.CheckLiveButtonText.Text = $"Đang kiểm tra... ({m_1294}/{m_1296.Count})";
			}
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct m_787
	{
		public string A;
	}

	[CompilerGenerated]
	private sealed class m_788
	{
		public SemaphoreSlim A;

		public MainWindow m_1304;

		public int m_1305;

		public List<FacebookAccountRow> m_1306;

		internal async Task m_1307(FacebookAccountRow P_0)
		{
			await this.A.WaitAsync();
			try
			{
				(string, string) tuple = await m_677(P_0);
				string item = tuple.Item1;
				string item2 = tuple.Item2;
				P_0.TinhTrang = item;
				P_0.TrangThai = item2;
				((DispatcherObject)m_1304).Dispatcher.Invoke((Action)m_1304.h);
			}
			catch (Exception ex)
			{
				P_0.TinhTrang = "ERROR";
				P_0.TrangThai = "Lỗi: " + ex.Message;
			}
			finally
			{
				this.A.Release();
				int A = Interlocked.Increment(ref m_1305);
				((DispatcherObject)m_1304).Dispatcher.Invoke((Action)(() =>
				{
					m_1304.CheckNoveryButtonText.Text = $"Đang check... ({A}/{m_1306.Count})";
				}));
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_789
	{
		public int A;

		public m_788 m_1314;

		internal void m_1315()
		{
			m_1314.m_1304.CheckNoveryButtonText.Text = $"Đang check... ({A}/{m_1314.m_1306.Count})";
		}
	}

	[CompilerGenerated]
	private sealed class m_790
	{
		public FacebookAccountRow A;

		internal (string Uid, string Code) m_1316()
		{
			return (Uid: A.Uid, Code: PlaywrightHumanHelpers.Get2fa(A.TwoFA));
		}
	}

	[CompilerGenerated]
	private sealed class m_791
	{
		public SemaphoreSlim A;

		public int m_1317;

		public int a;

		public MainWindow m_1318;

		public List<FacebookAccountRow> m_1319;

		internal async Task m_1320(FacebookAccountRow P_0)
		{
			await A.WaitAsync();
			try
			{
				(string, string, string)? tuple = await k(P_0.Uid);
				if (!tuple.HasValue)
				{
					P_0.TrangThai = "Không lấy được thông tin (UID sai hoặc bị chặn).";
					return;
				}
				P_0.HoTen = tuple.Value.Item1;
				P_0.GioiTinh = tuple.Value.Item2;
				P_0.Avatar = tuple.Value.Item3;
				P_0.TrangThai = "Đã check xong họ tên/avatar/giới tính.";
				Interlocked.Increment(ref m_1317);
			}
			catch (Exception ex)
			{
				P_0.TrangThai = "Lỗi kết nối: " + ex.Message;
			}
			finally
			{
				A.Release();
				Interlocked.Increment(ref a);
				m_1318.CheckProfileInfoButtonText.Text = $"Đang check... ({a}/{m_1319.Count})";
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_792
	{
		public SemaphoreSlim A;

		public CancellationToken m_1327;

		public MainWindow m_1328;

		public int m_1329;

		public int a;

		public List<ProfileRow> m_1330;

		public Func<string> m_1331;

		internal async Task m_1332(ProfileRow P_0)
		{
			await this.A.WaitAsync(m_1327);
			try
			{
				await PhoneInitialSetupService.RunAsync(P_0.Name, (string text) =>
				{
					((DispatcherObject)m_1328).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = text));
				}, m_1327);
			}
			catch (OperationCanceledException)
			{
				((DispatcherObject)m_1328).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đã dừng."));
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				Exception A = ex3;
				Interlocked.Increment(ref m_1329);
				((DispatcherObject)m_1328).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Lỗi: " + A.Message));
			}
			finally
			{
				this.A.Release();
				Interlocked.Increment(ref a);
				((DispatcherObject)m_1328).Dispatcher.Invoke<string>((Func<string>)(() => m_1328.InitialSetupButtonText.Text = $"Đang cài đặt... ({a}/{m_1330.Count})"));
			}
		}

		internal string m_1333()
		{
			return m_1328.InitialSetupButtonText.Text = $"Đang cài đặt... ({a}/{m_1330.Count})";
		}
	}

	[CompilerGenerated]
	private sealed class m_793
	{
		public ProfileRow A;

		public m_792 m_1340;

		internal void m_1341(string P_0)
		{
			((DispatcherObject)m_1340.m_1328).Dispatcher.Invoke<string>((Func<string>)(() => A.Status = P_0));
		}

		internal string m_1342()
		{
			return A.Status = "Đã dừng.";
		}
	}

	[CompilerGenerated]
	private sealed class m_794
	{
		public string A;

		public m_793 m_1343;

		internal string m_1344()
		{
			return m_1343.A.Status = A;
		}
	}

	[CompilerGenerated]
	private sealed class m_795
	{
		public Exception A;

		public m_793 m_1345;

		internal string m_1346()
		{
			return m_1345.A.Status = "Lỗi: " + A.Message;
		}
	}

	[CompilerGenerated]
	private sealed class m_796
	{
		public SemaphoreSlim A;

		public CancellationToken m_1347;

		public MainWindow m_1348;

		public string m_1349;

		public int m_1350;

		public int a;

		public List<ProfileRow> m_1351;

		public Func<string> m_1352;

		internal async Task m_1353(ProfileRow P_0)
		{
			await this.A.WaitAsync(m_1347);
			try
			{
				((DispatcherObject)m_1348).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đang cài app..."));
				await AdbController.InstallApkAsync(P_0.Name, m_1349, m_1347);
				((DispatcherObject)m_1348).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đã cài app xong."));
			}
			catch (OperationCanceledException)
			{
				((DispatcherObject)m_1348).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đã dừng."));
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				Exception A = ex3;
				Interlocked.Increment(ref m_1350);
				((DispatcherObject)m_1348).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Lỗi: " + A.Message));
			}
			finally
			{
				this.A.Release();
				Interlocked.Increment(ref a);
				((DispatcherObject)m_1348).Dispatcher.Invoke<string>((Func<string>)(() => m_1348.InstallApkButtonText.Text = $"Đang cài đặt... ({a}/{m_1351.Count})"));
			}
		}

		internal string m_1354()
		{
			return m_1348.InstallApkButtonText.Text = $"Đang cài đặt... ({a}/{m_1351.Count})";
		}
	}

	[CompilerGenerated]
	private sealed class m_797
	{
		public ProfileRow A;

		internal string m_1361()
		{
			return A.Status = "Đang cài app...";
		}

		internal string a()
		{
			return A.Status = "Đã cài app xong.";
		}

		internal string B()
		{
			return A.Status = "Đã dừng.";
		}
	}

	[CompilerGenerated]
	private sealed class m_798
	{
		public Exception A;

		public m_797 m_1362;

		internal string m_1363()
		{
			return m_1362.A.Status = "Lỗi: " + A.Message;
		}
	}

	[CompilerGenerated]
	private sealed class m_799
	{
		public SemaphoreSlim A;

		public CancellationToken m_1364;

		public MainWindow m_1365;

		public object m_1366;

		public List<KatanaSessionResult> m_1367;

		public int m_1368;

		public int a;

		public List<ProfileRow> m_1369;

		public Func<string> m_1370;

		internal async Task m_1371(ProfileRow P_0)
		{
			await this.A.WaitAsync(m_1364);
			try
			{
				((DispatcherObject)m_1365).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đang lấy Cookie/Token Katana..."));
				KatanaSessionResult A = await AdbController.GetKatanaTokenAndCookieAsync(P_0.Name, m_1364);
				if (!A.Success)
				{
					KatanaSessionResult katanaSessionResult = await AdbController.GetFbLiteTokenAndCookieAsync(P_0.Name, m_1364);
					if (katanaSessionResult.Success)
					{
						A = katanaSessionResult;
					}
				}
				if (A.Success)
				{
					((DispatcherObject)m_1365).Dispatcher.Invoke((Action)(() =>
					{
						ProfileRow profileRow = P_0;
						string status = ((!string.IsNullOrEmpty(A.Uid)) ? ("Lấy thành công: " + A.Uid) : ((!string.IsNullOrEmpty(A.Token)) ? "Lấy thành công Token" : "Lấy thành công"));
						profileRow.Status = status;
						FacebookAccountRow facebookAccountRow = m_1365.Facebooks.FirstOrDefault((FacebookAccountRow facebookAccountRow2) => (!string.IsNullOrEmpty(A.Uid) && facebookAccountRow2.Uid == A.Uid) || facebookAccountRow2.PhoneName == P_0.Name);
						if (facebookAccountRow != null)
						{
							if (!string.IsNullOrEmpty(A.Uid))
							{
								facebookAccountRow.Uid = A.Uid;
							}
							if (!string.IsNullOrEmpty(A.Token))
							{
								facebookAccountRow.Token = A.Token;
							}
							if (!string.IsNullOrEmpty(A.Cookie))
							{
								facebookAccountRow.Cookie = A.Cookie;
							}
						}
					}));
					lock (m_1366)
					{
						m_1367.Add(A);
					}
				}
				else
				{
					Interlocked.Increment(ref m_1368);
					((DispatcherObject)m_1365).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Lỗi: " + A.ErrorMessage));
				}
			}
			catch (OperationCanceledException)
			{
				((DispatcherObject)m_1365).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đã dừng."));
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				Exception A2 = ex3;
				Interlocked.Increment(ref m_1368);
				((DispatcherObject)m_1365).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Lỗi: " + A2.Message));
			}
			finally
			{
				this.A.Release();
				Interlocked.Increment(ref a);
				((DispatcherObject)m_1365).Dispatcher.Invoke<string>((Func<string>)(() => m_1365.GetKatanaTokenButtonText.Text = $"Đang lấy... ({a}/{m_1369.Count})"));
			}
		}

		internal string m_1372()
		{
			return m_1365.GetKatanaTokenButtonText.Text = $"Đang lấy... ({a}/{m_1369.Count})";
		}
	}

	[CompilerGenerated]
	private sealed class m_800
	{
		public ProfileRow A;

		public m_799 m_1381;

		internal string m_1382()
		{
			return A.Status = "Đang lấy Cookie/Token Katana...";
		}

		internal string a()
		{
			return A.Status = "Đã dừng.";
		}
	}

	[CompilerGenerated]
	private sealed class m_801
	{
		public KatanaSessionResult A;

		public m_800 m_1383;

		public Func<FacebookAccountRow, bool> m_1384;

		internal void m_1385()
		{
			ProfileRow profileRow = m_1383.A;
			string status;
			if (string.IsNullOrEmpty(A.Uid))
			{
				status = ((!string.IsNullOrEmpty(A.Token)) ? "Lấy thành công Token" : "Lấy thành công");
			}
			else
			{
				status = "Lấy thành công: " + A.Uid;
			}
			profileRow.Status = status;
			FacebookAccountRow facebookAccountRow = m_1383.m_1381.m_1365.Facebooks.FirstOrDefault((FacebookAccountRow P_0) => (!string.IsNullOrEmpty(A.Uid) && P_0.Uid == A.Uid) || P_0.PhoneName == m_1383.A.Name);
			if (facebookAccountRow != null)
			{
				if (!string.IsNullOrEmpty(A.Uid))
				{
					facebookAccountRow.Uid = A.Uid;
				}
				if (!string.IsNullOrEmpty(A.Token))
				{
					facebookAccountRow.Token = A.Token;
				}
				if (!string.IsNullOrEmpty(A.Cookie))
				{
					facebookAccountRow.Cookie = A.Cookie;
				}
			}
		}

		internal bool m_1386(FacebookAccountRow P_0)
		{
			if (string.IsNullOrEmpty(A.Uid) || !(P_0.Uid == A.Uid))
			{
				return P_0.PhoneName == m_1383.A.Name;
			}
			return true;
		}

		internal string a()
		{
			return m_1383.A.Status = "Lỗi: " + A.ErrorMessage;
		}
	}

	[CompilerGenerated]
	private sealed class m_802
	{
		public Exception A;

		public m_800 m_1387;

		internal string m_1388()
		{
			return m_1387.A.Status = "Lỗi: " + A.Message;
		}
	}

	[CompilerGenerated]
	private sealed class m_803
	{
		public SemaphoreSlim A;

		public CancellationToken m_1389;

		public MainWindow m_1390;

		public object m_1391;

		public List<KatanaSessionResult> m_1392;

		public int m_1393;

		public int a;

		public List<ProfileRow> m_1394;

		public Func<string> m_1395;

		internal async Task m_1396(ProfileRow P_0)
		{
			await this.A.WaitAsync(m_1389);
			try
			{
				((DispatcherObject)m_1390).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đang lấy Cookie/Token FB Lite..."));
				KatanaSessionResult A = await AdbController.GetFbLiteTokenAndCookieAsync(P_0.Name, m_1389);
				if (!A.Success)
				{
					KatanaSessionResult katanaSessionResult = await AdbController.GetKatanaTokenAndCookieAsync(P_0.Name, m_1389);
					if (katanaSessionResult.Success)
					{
						A = katanaSessionResult;
					}
				}
				if (A.Success)
				{
					((DispatcherObject)m_1390).Dispatcher.Invoke((Action)(() =>
					{
						ProfileRow profileRow = P_0;
						string status = ((!string.IsNullOrEmpty(A.Uid)) ? ("Lấy thành công: " + A.Uid) : ((!string.IsNullOrEmpty(A.Token)) ? "Lấy thành công Token" : "Lấy thành công"));
						profileRow.Status = status;
						FacebookAccountRow facebookAccountRow = m_1390.Facebooks.FirstOrDefault((FacebookAccountRow facebookAccountRow2) => (!string.IsNullOrEmpty(A.Uid) && facebookAccountRow2.Uid == A.Uid) || facebookAccountRow2.PhoneName == P_0.Name);
						if (facebookAccountRow != null)
						{
							if (!string.IsNullOrEmpty(A.Uid))
							{
								facebookAccountRow.Uid = A.Uid;
							}
							if (!string.IsNullOrEmpty(A.Token))
							{
								facebookAccountRow.Token = A.Token;
							}
							if (!string.IsNullOrEmpty(A.Cookie))
							{
								facebookAccountRow.Cookie = A.Cookie;
							}
						}
					}));
					lock (m_1391)
					{
						m_1392.Add(A);
					}
				}
				else
				{
					Interlocked.Increment(ref m_1393);
					((DispatcherObject)m_1390).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Lỗi: " + A.ErrorMessage));
				}
			}
			catch (OperationCanceledException)
			{
				((DispatcherObject)m_1390).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Đã dừng."));
			}
			catch (Exception ex2)
			{
				Exception ex3 = ex2;
				Exception A2 = ex3;
				Interlocked.Increment(ref m_1393);
				((DispatcherObject)m_1390).Dispatcher.Invoke<string>((Func<string>)(() => P_0.Status = "Lỗi: " + A2.Message));
			}
			finally
			{
				this.A.Release();
				Interlocked.Increment(ref a);
				((DispatcherObject)m_1390).Dispatcher.Invoke<string>((Func<string>)(() => m_1390.GetFbLiteTokenButtonText.Text = $"Đang lấy... ({a}/{m_1394.Count})"));
			}
		}

		internal string m_1397()
		{
			return m_1390.GetFbLiteTokenButtonText.Text = $"Đang lấy... ({a}/{m_1394.Count})";
		}
	}

	[CompilerGenerated]
	private sealed class m_804
	{
		public ProfileRow A;

		public m_803 m_1406;

		internal string m_1407()
		{
			return A.Status = "Đang lấy Cookie/Token FB Lite...";
		}

		internal string a()
		{
			return A.Status = "Đã dừng.";
		}
	}

	[CompilerGenerated]
	private sealed class m_805
	{
		public KatanaSessionResult A;

		public m_804 m_1408;

		public Func<FacebookAccountRow, bool> m_1409;

		internal void m_1410()
		{
			ProfileRow profileRow = m_1408.A;
			string status;
			if (string.IsNullOrEmpty(A.Uid))
			{
				status = ((!string.IsNullOrEmpty(A.Token)) ? "Lấy thành công Token" : "Lấy thành công");
			}
			else
			{
				status = "Lấy thành công: " + A.Uid;
			}
			profileRow.Status = status;
			FacebookAccountRow facebookAccountRow = m_1408.m_1406.m_1390.Facebooks.FirstOrDefault((FacebookAccountRow P_0) => (!string.IsNullOrEmpty(A.Uid) && P_0.Uid == A.Uid) || P_0.PhoneName == m_1408.A.Name);
			if (facebookAccountRow != null)
			{
				if (!string.IsNullOrEmpty(A.Uid))
				{
					facebookAccountRow.Uid = A.Uid;
				}
				if (!string.IsNullOrEmpty(A.Token))
				{
					facebookAccountRow.Token = A.Token;
				}
				if (!string.IsNullOrEmpty(A.Cookie))
				{
					facebookAccountRow.Cookie = A.Cookie;
				}
			}
		}

		internal bool m_1411(FacebookAccountRow P_0)
		{
			if (string.IsNullOrEmpty(A.Uid) || !(P_0.Uid == A.Uid))
			{
				return P_0.PhoneName == m_1408.A.Name;
			}
			return true;
		}

		internal string a()
		{
			return m_1408.A.Status = "Lỗi: " + A.ErrorMessage;
		}
	}

	[CompilerGenerated]
	private sealed class m_806
	{
		public Exception A;

		public m_804 m_1412;

		internal string m_1413()
		{
			return m_1412.A.Status = "Lỗi: " + A.Message;
		}
	}

	[CompilerGenerated]
	private sealed class m_807
	{
		public string A;

		public MainWindow m_1414;

		internal void m_1415()
		{
			new LicenseSettings().Save();
			CustomMessageBox.Show(m_1414, A, "Xác thực license", NotifyType.Warning);
			Application.Current.Shutdown();
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct m_808
	{
		public bool A;
	}

	[CompilerGenerated]
	private sealed class m_809
	{
		public NickFolder A;

		internal bool m_1416(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A.Id;
		}
	}

	private const string m_485 = "\ue922";

	private const string a = "\ue923";

	[CompilerGenerated]
	private readonly ObservableCollection<ProfileRow> m_486 = new ObservableCollection<ProfileRow>
	{
		new ProfileRow
		{
			Index = 1,
			Name = "Profile 1",
			ProfileGroup = "Default",
			OS = "Windows",
			Browser = "Chrome",
			Proxy = "Không proxy",
			Note = "",
			Status = "Chưa mở",
			LastOpened = "11/08 15:59",
			Tags = ""
		}
	};

	[CompilerGenerated]
	private readonly ObservableCollection<FacebookAccountRow> m_487 = new ObservableCollection<FacebookAccountRow>
	{
		new FacebookAccountRow
		{
			Index = 1,
			Uid = "1000000000",
			Mail = "example@gmail.com",
			TrangThai = "Chưa dùng"
		}
	};

	[CompilerGenerated]
	private readonly ObservableCollection<NickFolder> m_488 = new ObservableCollection<NickFolder>();

	[CompilerGenerated]
	private readonly ObservableCollection<ScriptItem> m_489 = new ObservableCollection<ScriptItem>();

	[CompilerGenerated]
	private readonly ObservableCollection<InteractionAction> m_490 = new ObservableCollection<InteractionAction>();

	private ScriptItem? m_491;

	private ICollectionView? m_492;

	private ICollectionView? m_493;

	private string B = "Android";

	private string b = "Facebook";

	private string C = "Android";

	private string c = "Facebook";

	private bool m_494;

	private readonly ObservableCollection<AiVisionFlowStep> m_495 = new ObservableCollection<AiVisionFlowStep>();

	private readonly ObservableCollection<AiVisionStepLog> m_496 = new ObservableCollection<AiVisionStepLog>();

	private CancellationTokenSource? m_497;

	private readonly ObservableCollection<AiVisionFlowStep> m_498 = new ObservableCollection<AiVisionFlowStep>();

	private readonly ObservableCollection<AiVisionStepLog> m_499 = new ObservableCollection<AiVisionStepLog>();

	private CancellationTokenSource? m_500;

	private ICollectionView? m_501;

	private int m_502 = -1;

	private bool m_503;

	private HashSet<string> m_504 = new HashSet<string>();

	private HashSet<string>? m_505;

	private static readonly (string Label, string Field)[] m_506 = new (string, string)[7]
	{
		("STT", "Index"),
		("UID", "Uid"),
		("Trạng thái", "TrangThai"),
		("Bạn bè", "BanBe"),
		("Nhóm", "Nhom"),
		("Tương tác cuối", "TuongTacCuoi"),
		("Ghi chú", "GhiChu")
	};

	private const double m_507 = 1100.0;

	private bool m_508;

	private readonly PlatformAccountPage m_509 = new PlatformAccountPage("Gmail", "Gmail");

	private readonly PlatformAccountPage m_510 = new PlatformAccountPage("TikTok", "TikTok");

	private readonly PlatformAccountPage m_511 = new PlatformAccountPage("Hotmail", "Hotmail");

	private readonly PlatformAccountPage m_512 = new PlatformAccountPage("Shopee", "Shopee");

	private readonly Dictionary<string, PlatformAccountPage> m_513 = new Dictionary<string, PlatformAccountPage>();

	private readonly Dictionary<string, Border> m_514 = new Dictionary<string, Border>();

	private readonly Dictionary<string, RadioButton> m_515 = new Dictionary<string, RadioButton>();

	private readonly Dictionary<string, TextBlock> m_516 = new Dictionary<string, TextBlock>();

	private bool m_517;

	private bool m_518;

	private static readonly Dictionary<string, (string Vi, string En)> m_519 = new Dictionary<string, (string, string)>
	{
		["TopBarTitle"] = ("IPHONE | IOS | ANDROID | CHROME | BOXPHONE | QUẢN LÝ ACCOUNTS | GMAIL | FACEBOOK | TIKTOK | 11.10.49", "GMAIL | FACEBOOK | TIKTOK | HOTMAIL Account Farming on: Boxphone Ldplayer Chrome Ver 11.10.49"),
		["NavFacebook"] = ("Quản Lý Facebook", "FB Accounts"),
		["NavPhone"] = ("Danh Sách Phone", "Phones"),
		["NavScripts"] = ("Tự động hóa AI", "Scripts"),
		["NavBaoSamSettings"] = ("Cài đặt BaoSam Browser", "BaoSam Browser Settings"),
		["BaoSamSettingsPageTitle"] = ("Cài đặt BaoSam Browser", "BaoSam Browser Settings"),
		["NavAiVisionSettings"] = ("Cài đặt AI Vision", "AI Vision Settings"),
		["FacebookPageTitle"] = ("Quản Lý Facebook", "Manage Facebook Accounts"),
		["PhonePageTitle"] = ("Quản lý phone", "Manage Phones"),
		["ScriptsPageTitle"] = ("Tự động hóa AI", "Scripts"),
		["AiVisionSettingsPageTitle"] = ("Cài đặt AI Vision", "AI Vision Settings"),
		["ScriptPlatformIPhone"] = ("Kịch bản iPhone", "iPhone Scripts"),
		["ScriptPlatformAndroid"] = ("Kịch bản Android", "Android Scripts"),
		["ScriptPlatformChrome"] = ("Kịch bản Chrome", "Chrome Scripts")
	};

	private string D = "";

	private DispatcherTimer? m_520;

	private DispatcherTimer? m_521;

	private readonly HashSet<int> m_522 = new HashSet<int>();

	private DispatcherTimer? m_523;

	private List<FacebookAccountRow> m_524 = new List<FacebookAccountRow>();

	private FacebookAccountRow? m_525;

	private const int m_526 = 2;

	private const double m_527 = 1400.0;

	private static readonly Brush[] m_528 = new Brush[6]
	{
		new SolidColorBrush(Color.FromRgb(139, 92, 246)),
		new SolidColorBrush(Color.FromRgb(6, 182, 212)),
		new SolidColorBrush(Color.FromRgb(245, 158, 11)),
		new SolidColorBrush(Color.FromRgb(34, 197, 94)),
		new SolidColorBrush(Color.FromRgb(236, 72, 153)),
		new SolidColorBrush(Color.FromRgb(100, 116, 139))
	};

	private static readonly string[] m_529 = new string[4] { "Gmail", "TikTok", "Shopee", "Hotmail" };

	private string d = "Mail";

	private IVerifyMailTestClient? m_530;

	private CancellationTokenSource? m_531;

	private IVerifyPhoneTestClient? m_532;

	private CancellationTokenSource? m_533;

	private static readonly string E = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "facebook_columns.json");

	private static readonly HashSet<string> m_534 = new HashSet<string> { "STT", "CHỌN", "PHONE", "KỊCH BẢN", "NỀN TẢNG", "UID", "PASS", "TRẠNG THÁI", "TÌNH TRẠNG" };

	private static readonly string e = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "facebook_column_order.json");

	private static readonly (string Header, Func<FacebookAccountRow, string> Getter)[] m_535 = new (string, Func<FacebookAccountRow, string>)[23]
	{
		("PHONE", (FacebookAccountRow P_0) => P_0.PhoneName),
		("KỊCH BẢN", (FacebookAccountRow P_0) => P_0.ScriptName),
		("UID", (FacebookAccountRow P_0) => P_0.Uid),
		("PASS", (FacebookAccountRow P_0) => P_0.Pass),
		("2FA", (FacebookAccountRow P_0) => P_0.TwoFA),
		("TOKEN", (FacebookAccountRow P_0) => P_0.Token),
		("COOKIE", (FacebookAccountRow P_0) => P_0.Cookie),
		("MAIL", (FacebookAccountRow P_0) => P_0.Mail),
		("PASS MAIL", (FacebookAccountRow P_0) => P_0.PassMail),
		("MAIL KHÔI PHỤC", (FacebookAccountRow P_0) => P_0.MailKhoiPhuc),
		("PASS MAIL KHÔI PHỤC", (FacebookAccountRow P_0) => P_0.PassMailKhoiPhuc),
		("BẠN BÈ", (FacebookAccountRow P_0) => P_0.BanBe),
		("NHÓM", (FacebookAccountRow P_0) => P_0.Nhom),
		("GIỚI TÍNH", (FacebookAccountRow P_0) => P_0.GioiTinh),
		("AVATAR", (FacebookAccountRow P_0) => P_0.Avatar),
		("PROFILE CHROME", (FacebookAccountRow P_0) => P_0.ProfileChrome),
		("TÊN PROFILE", (FacebookAccountRow P_0) => P_0.TenProfile),
		("USERAGENT", (FacebookAccountRow P_0) => P_0.UserAgent),
		("PROXY", (FacebookAccountRow P_0) => P_0.Proxy),
		("TỆP CŨ", (FacebookAccountRow P_0) => P_0.TepCu),
		("GHI CHÚ", (FacebookAccountRow P_0) => P_0.GhiChu),
		("TƯƠNG TÁC CUỐI", (FacebookAccountRow P_0) => P_0.TuongTacCuoi),
		("TRẠNG THÁI", (FacebookAccountRow P_0) => P_0.TrangThai)
	};

	private HashSet<string> m_536 = new HashSet<string> { "UID", "PASS" };

	private static readonly string F = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "facebook_copy_columns.json");

	private static readonly Dictionary<string, Action<FacebookAccountRow, string>> m_537 = new Dictionary<string, Action<FacebookAccountRow, string>>
	{
		["PASS"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.Pass = P_1;
		},
		["2FA"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.TwoFA = P_1;
		},
		["TOKEN"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.Token = P_1;
		},
		["COOKIE"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.Cookie = P_1;
		},
		["MAIL"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.Mail = P_1;
		},
		["PASS MAIL"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.PassMail = P_1;
		},
		["MAIL KHÔI PHỤC"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.MailKhoiPhuc = P_1;
		},
		["PASS MAIL KHÔI PHỤC"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.PassMailKhoiPhuc = P_1;
		},
		["BẠN BÈ"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.BanBe = P_1;
		},
		["NHÓM"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.Nhom = P_1;
		},
		["GIỚI TÍNH"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.GioiTinh = P_1;
		},
		["PROXY"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.Proxy = P_1;
		},
		["GHI CHÚ"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.GhiChu = P_1;
		},
		["TƯƠNG TÁC CUỐI"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.TuongTacCuoi = P_1;
		},
		["TRẠNG THÁI"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.TrangThai = P_1;
		},
		["PHONE"] = (FacebookAccountRow P_0, string P_1) =>
		{
			P_0.PhoneName = P_1;
		}
	};

	private bool m_538 = true;

	private List<CustomAiProvider> m_539 = new List<CustomAiProvider>();

	private readonly ObservableCollection<PriorityTargetDisplay> m_540 = new ObservableCollection<PriorityTargetDisplay>();

	private Point m_541;

	private string? f;

	private AiVisionTestNickSelection? m_542;

	private CancellationTokenSource? m_543;

	private static readonly HttpClient m_544 = new HttpClient();

	private bool m_545;

	private string G = "Facebook";

	private CancellationTokenSource? m_546;

	private CancellationTokenSource? m_547;

	private CancellationTokenSource? m_548;

	private CancellationTokenSource? m_549;

	public List<string> devices = new List<string>();

	private bool m_550;

	public ObservableCollection<ProfileRow> Profiles
	{
		[CompilerGenerated]
		get
		{
			return m_486;
		}
	}

	public ObservableCollection<FacebookAccountRow> Facebooks
	{
		[CompilerGenerated]
		get
		{
			return m_487;
		}
	}

	public ObservableCollection<NickFolder> Folders
	{
		[CompilerGenerated]
		get
		{
			return m_488;
		}
	}

	public ObservableCollection<ScriptItem> Scripts
	{
		[CompilerGenerated]
		get
		{
			return m_489;
		}
	}

	public ObservableCollection<InteractionAction> Actions
	{
		[CompilerGenerated]
		get
		{
			return m_490;
		}
	}

	public ObservableCollection<PlatformAccountRow> GmailAccounts => m_509.Accounts;

	public ObservableCollection<PlatformAccountRow> TikTokAccounts => m_510.Accounts;

	public ObservableCollection<PlatformAccountRow> HotmailAccounts => m_511.Accounts;

	public ObservableCollection<PlatformAccountRow> ShopeeAccounts => m_512.Accounts;

	private PlatformAccountPage? A
	{
		get
		{
			PlatformAccountPage value;
			return G switch
			{
				"Gmail" => m_509, 
				"TikTok" => m_510, 
				"Hotmail" => m_511, 
				"Shopee" => m_512, 
				_ => m_513.TryGetValue(G, out value) ? value : null, 
			};
		}
	}

	public MainWindow()
	{
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		App.m_277("MainWindow ctor: trước InitializeComponent");
		InitializeComponent();
		App.m_277("MainWindow ctor: InitializeComponent xong");
		DataContext = this;
		AiVisionPriorityListBox.ItemsSource = m_540;
		q();
		S();
		Scripts.CollectionChanged += delegate
		{
			ac();
		};
		double minWidth = MinWidth;
		Rect workArea = SystemParameters.WorkArea;
		Width = Math.Max(minWidth, workArea.Width * 0.85);
		double minHeight = MinHeight;
		workArea = SystemParameters.WorkArea;
		Height = Math.Max(minHeight, workArea.Height * 0.85);
		DesktopLicenseGuard.LicenseLost += (string P_0) =>
		{
			((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
			{
				new LicenseSettings().Save();
				CustomMessageBox.Show(this, P_0, "Xác thực license", NotifyType.Warning);
				Application.Current.Shutdown();
			}));
		};
		PhoneAiStepsItemsControl.ItemsSource = m_495;
		PhoneAiLogItemsControl.ItemsSource = m_496;
		x();
		App.m_277("MainWindow ctor: LoadAiVisionSettingsForm xong");
		ChromeAiStepsItemsControl.ItemsSource = m_498;
		ChromeAiLogItemsControl.ItemsSource = m_499;
		m_556(UiPreferences.Load().Language);
		ActionCatalogPanel.Visibility = Visibility.Collapsed;
		PhoneAiVisionPanel.Visibility = Visibility.Visible;
		ChromeAiVisionPanel.Visibility = Visibility.Collapsed;
		App.m_277("MainWindow ctor: bắt đầu load DB");
		FacebookAccountDatabase.EnsureCreated();
		App.m_277("MainWindow ctor: FacebookAccountDatabase.EnsureCreated xong");
		m_567();
		App.m_277("MainWindow ctor: SetupFacebookView xong");
		m_558();
		P();
		App.m_277("MainWindow ctor: SetupScriptViews xong");
		m_575();
		m_576();
		App.m_277("MainWindow ctor: LoadFoldersFromDatabase xong");
		m_562();
		App.m_277("MainWindow ctor: LoadActionsFromDatabase xong");
		m_563();
		App.m_277("MainWindow ctor: LoadScriptFoldersFromDatabase xong");
		I();
		App.m_277("MainWindow ctor: LoadFacebooksFromDatabase xong");
		GmailContentHost.Child = m_509;
		TikTokContentHost.Child = m_510;
		HotmailContentHost.Child = m_511;
		ShopeeContentHost.Child = m_512;
		App.m_277("MainWindow ctor: gắn 3 ContentHost xong");
		m_509.SetSharedCollections(Profiles, Scripts);
		m_510.SetSharedCollections(Profiles, Scripts);
		m_511.SetSharedCollections(Profiles, Scripts);
		m_512.SetSharedCollections(Profiles, Scripts);
		M();
		m();
		string username = LicenseSettings.Load().Username;
		FooterAccountText.Text = (string.IsNullOrWhiteSpace(username) ? "Tài khoản: -" : ("Tài khoản: " + username));
		m_551();
		if (m_517)
		{
			((DispatcherObject)this).Dispatcher.BeginInvoke((Delegate)new Action(m_553), (DispatcherPriority)6, Array.Empty<object>());
		}
		App.m_277("MainWindow ctor: SetSharedCollections xong (hết constructor)");
	}

	private void m_551()
	{
		m_703 obj = m_703.A;
		m_517 = obj == m_703.B;
		string text = obj switch
		{
			m_703.A => "PRO", 
			m_703.a => "FREE", 
			_ => "Unlock", 
		};
		Brush foreground = ((obj == m_703.A) ? new SolidColorBrush(Color.FromRgb(36, 28, 0)) : Brushes.White);
		Brush background = obj switch
		{
			m_703.A => (Brush)new SolidColorBrush(Color.FromRgb(234, 179, 8)), 
			m_703.a => new SolidColorBrush(Color.FromRgb(2, 132, 199)), 
			_ => new SolidColorBrush(Color.FromRgb(239, 68, 68)), 
		};
		Cursor cursor = (m_517 ? Cursors.Hand : Cursors.Arrow);
		string toolTip = (m_517 ? "Bản dùng thử đã hết hạn - bấm để xem cách mở khoá bản quyền" : null);
		if (BrandProBadgeText != null)
		{
			BrandProBadgeText.Text = text;
			BrandProBadgeText.Foreground = foreground;
		}
		if (BrandProBadgeImage != null)
		{
			BrandProBadgeImage.Background = background;
			BrandProBadgeImage.Cursor = cursor;
			BrandProBadgeImage.ToolTip = toolTip;
		}
		if (FooterProBadgeText != null)
		{
			FooterProBadgeText.Text = text;
			FooterProBadgeText.Foreground = foreground;
		}
		if (FooterProBadgeBorder != null)
		{
			FooterProBadgeBorder.Background = background;
			FooterProBadgeBorder.Cursor = cursor;
			FooterProBadgeBorder.ToolTip = toolTip;
		}
	}

	private void m_552(object P_0, MouseButtonEventArgs P_1)
	{
		if (m_517)
		{
			UnlockWindow unlockWindow = new UnlockWindow();
			unlockWindow.Owner = this;
			unlockWindow.ShowDialog();
		}
	}

	private void m_553()
	{
		if (m_518 || !m_517)
		{
			return;
		}
		m_518 = true;
		try
		{
			UnlockWindow unlockWindow = new UnlockWindow();
			unlockWindow.Owner = this;
			unlockWindow.ShowDialog();
		}
		catch
		{
		}
	}

	private void m_554(object P_0, RoutedEventArgs P_1)
	{
		UiPreferences uiPreferences = UiPreferences.Load();
		uiPreferences.Theme = ThemeManager.NextTheme(uiPreferences.Theme);
		uiPreferences.Save();
		ThemeManager.Apply(uiPreferences.Theme);
	}

	private void m_555(object P_0, MouseButtonEventArgs P_1)
	{
		UiPreferences uiPreferences = UiPreferences.Load();
		uiPreferences.Language = ((uiPreferences.Language == "EN") ? "VI" : "EN");
		uiPreferences.Save();
		m_556(uiPreferences.Language);
	}

	private void m_556(string P_0)
	{
		m_808 obj = default;
		obj.A = P_0 == "EN";
		LanguageLabelText.Text = (obj.A ? "EN" : "VI");
		m_557(m_692("TopBarTitle", ref obj));
		NavFacebookRadio.Content = m_692("NavFacebook", ref obj);
		NavPhoneRadio.Content = m_692("NavPhone", ref obj);
		NavScriptsRadio.Content = m_692("NavScripts", ref obj);
		NavBaoSamSettingsRadio.Content = m_692("NavBaoSamSettings", ref obj);
		NavAiVisionSettingsRadio.Content = m_692("NavAiVisionSettings", ref obj);
		FacebookPageTitleText.Text = m_692("FacebookPageTitle", ref obj);
		PhonePageTitleText.Text = m_692("PhonePageTitle", ref obj);
		ScriptsPageTitleText.Text = m_692("ScriptsPageTitle", ref obj);
		BaoSamSettingsPageTitleText.Text = m_692("BaoSamSettingsPageTitle", ref obj);
		AiVisionSettingsPageTitleText.Text = m_692("AiVisionSettingsPageTitle", ref obj);
		ScriptPlatformIPhoneRadio.Content = m_692("ScriptPlatformIPhone", ref obj);
		ScriptPlatformAndroidRadio.Content = m_692("ScriptPlatformAndroid", ref obj);
		ScriptPlatformChromeRadio.Content = m_692("ScriptPlatformChrome", ref obj);
	}

	private void m_557(string P_0)
	{
		D = P_0;
		double num = ((TopBarTitleScroll.ActualWidth > 0.0) ? TopBarTitleScroll.ActualWidth : ActualWidth);
		double fontSize = Math.Clamp(8.0 + num * 0.012, 10.0, 13.0);
		double num2 = Math.Clamp(num * 0.012, 6.0, 12.0);
		TopBarTitlePanel.Children.Clear();
		string[] array = P_0.Split(" | ", StringSplitOptions.RemoveEmptyEntries);
		for (int i = 0; i < array.Length; i++)
		{
			if (i > 0)
			{
				TopBarTitlePanel.Children.Add(new Border
				{
					Width = 1.0,
					Height = 18.0,
					Background = (Brush)FindResource("BrushBorder"),
					Margin = new Thickness(num2, 0.0, num2, 0.0),
					VerticalAlignment = VerticalAlignment.Center
				});
			}
			TopBarTitlePanel.Children.Add(new TextBlock
			{
				Text = array[i],
				FontWeight = FontWeights.Bold,
				FontSize = fontSize,
				VerticalAlignment = VerticalAlignment.Center
			});
		}
	}

	private void m_558()
	{
		m_492 = CollectionViewSource.GetDefaultView(Scripts);
		m_492.Filter = (object P_0) => P_0 is ScriptItem scriptItem && (scriptItem.Platform == B || (B == "Android" && scriptItem.Platform == "Phone")) && scriptItem.ChuDe == b && (string.IsNullOrWhiteSpace(ScriptFolderSearchBox.Text) || scriptItem.Name.Contains(ScriptFolderSearchBox.Text, StringComparison.OrdinalIgnoreCase));
		m_493 = CollectionViewSource.GetDefaultView(Actions);
		m_493.Filter = (object P_0) => P_0 is InteractionAction interactionAction && (interactionAction.Platform == B || (B == "Android" && interactionAction.Platform == "Phone")) && (string.IsNullOrWhiteSpace(ActionSearchBox.Text) || interactionAction.Name.Contains(ActionSearchBox.Text, StringComparison.OrdinalIgnoreCase));
	}

	private void m_559(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is RadioButton radioButton)
		{
			B = radioButton.Tag?.ToString() ?? "Android";
			m_491 = null;
			if (ScriptFolderGrid != null)
			{
				ScriptFolderGrid.SelectedItem = null;
			}
			ICollectionView? val = m_492;
			if (val != null)
			{
				val.Refresh();
			}
			ICollectionView? val2 = m_493;
			if (val2 != null)
			{
				val2.Refresh();
			}
			m_566();
			string text = B;
			bool flag = ((text == "iPhone" || text == "Android") ? true : false);
			bool flag2 = flag;
			if (PhoneAiVisionPanel != null)
			{
				PhoneAiVisionPanel.Visibility = ((!flag2) ? Visibility.Collapsed : Visibility.Visible);
			}
			if (ChromeModeAiVisionRadio != null && !flag2)
			{
				ChromeModeAiVisionRadio.IsChecked = true;
			}
			m_561();
			p();
			w();
			aa();
		}
	}

	private void m_560(object P_0, RoutedEventArgs P_1)
	{
		m_561();
	}

	private void m_561()
	{
		string text = B;
		bool flag = ((text == "iPhone" || text == "Android") ? true : false);
		bool flag2 = flag;
		bool flag3 = !flag2 && ((ChromeModeAiVisionRadio?.IsChecked == true));
		if (ActionCatalogPanel != null)
		{
			ActionCatalogPanel.Visibility = ((flag2 || flag3) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (ChromeAiVisionPanel != null)
		{
			ChromeAiVisionPanel.Visibility = ((!flag3) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void m_562()
	{
		Actions.Clear();
		foreach (InteractionAction item in FacebookAccountDatabase.LoadActions())
		{
			Actions.Add(item);
		}
		m_565();
	}

	private void m_563()
	{
		Scripts.Clear();
		foreach (ScriptItem item in FacebookAccountDatabase.LoadScriptFolders())
		{
			Scripts.Add(item);
		}
		m_564();
		m_566();
	}

	private void m_564()
	{
		int num = 1;
		foreach (ScriptItem script in Scripts)
		{
			script.Index = num++;
		}
	}

	private void m_565()
	{
		int num = 1;
		foreach (InteractionAction action in Actions)
		{
			action.Index = num++;
		}
	}

	private void m_566()
	{
		HashSet<int> hashSet = ((m_491 != null) ? FacebookAccountDatabase.LoadActionIdsForFolder(m_491.Id) : new HashSet<int>());
		foreach (InteractionAction action in Actions)
		{
			action.IsSelected = hashSet.Contains(action.Id);
		}
	}

	private void m_567()
	{
		m_501 = CollectionViewSource.GetDefaultView(Facebooks);
		m_501.Filter = m_568;
	}

	private bool m_568(object P_0)
	{
		if (!(P_0 is FacebookAccountRow facebookAccountRow))
		{
			return false;
		}
		if (!((m_502 == -1) ? (facebookAccountRow.FolderId != -2) : (facebookAccountRow.FolderId == m_502)))
		{
			return false;
		}
		if (m_505 != null)
		{
			return m_505.Contains(facebookAccountRow.Uid);
		}
		if (m_503)
		{
			if (!string.IsNullOrWhiteSpace(facebookAccountRow.Uid))
			{
				return m_504.Contains(facebookAccountRow.Uid);
			}
			return false;
		}
		return true;
	}

	private void m_569()
	{
		m_504 = (from P_0 in Facebooks
			where P_0.FolderId != -2 && !string.IsNullOrWhiteSpace(P_0.Uid)
			group P_0 by P_0.Uid into P_0
			where P_0.Count() > 1
			select P_0.Key).ToHashSet();
	}

	private void m_570(object P_0, RoutedEventArgs P_1)
	{
		m_503 = !m_503;
		if (m_503)
		{
			m_569();
			if (FolderListBox.SelectedItem is NickFolder { Id: not -1 })
			{
				FolderListBox.SelectedIndex = 0;
			}
		}
		DuplicateFilterButtonText.Text = (m_503 ? "Lọc trùng ✓" : "Lọc trùng");
		DuplicateFilterButton.Background = (m_503 ? ((Brush)FindResource("BrushAccentSoft")) : ((Brush)FindResource("BrushCard")));
		ICollectionView? val = m_501;
		if (val != null)
		{
			val.Refresh();
		}
		H();
		if (m_503 && m_504.Count == 0)
		{
			CustomMessageBox.Show(this, "Không tìm thấy UID nào trùng nhau.", "Lọc trùng");
		}
	}

	private void m_571(object P_0, RoutedEventArgs P_1)
	{
		m_638(BulkSearchPopup, P_0, BulkSearchButton);
	}

	private void m_572(object P_0, TextChangedEventArgs P_1)
	{
		int value = (from text in BulkSearchTextBox.Text.Split('\n')
			select text.Trim(new char[2] { '\r', ' ' })).Count((string text) => text.Length > 0);
		BulkSearchCountText.Text = $"{value} UID";
	}

	private void m_573(object P_0, RoutedEventArgs P_1)
	{
		HashSet<string> hashSet = (from text in BulkSearchTextBox.Text.Split('\n')
			select text.Trim(new char[2] { '\r', ' ' }) into text
			where text.Length > 0
			select text).ToHashSet();
		if (hashSet.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa nhập UID nào.", "Tìm nhiều UID", NotifyType.Warning);
			return;
		}
		m_505 = hashSet;
		if (FolderListBox.SelectedItem is NickFolder { Id: not -1 })
		{
			FolderListBox.SelectedIndex = 0;
		}
		BulkSearchButtonText.Text = $"Tìm nhiều UID ✓ ({hashSet.Count})";
		BulkSearchButton.Background = (Brush)FindResource("BrushAccentSoft");
		BulkSearchPopup.IsOpen = false;
		ICollectionView? val = m_501;
		if (val != null)
		{
			val.Refresh();
		}
		H();
		int value = ((IEnumerable)m_501)?.Cast<FacebookAccountRow>().Count() ?? 0;
		CustomMessageBox.Show(this, $"Tìm thấy {value}/{hashSet.Count} UID trong danh sách.", "Tìm nhiều UID");
	}

	private void m_574(object P_0, RoutedEventArgs P_1)
	{
		m_505 = null;
		BulkSearchTextBox.Clear();
		BulkSearchButtonText.Text = "Tìm nhiều UID";
		BulkSearchButton.Background = (Brush)FindResource("BrushCard");
		BulkSearchPopup.IsOpen = false;
		ICollectionView? val = m_501;
		if (val != null)
		{
			val.Refresh();
		}
		H();
	}

	private void m_575()
	{
		(string, string)[] array = m_506;
		for (int i = 0; i < array.Length; i++)
		{
			var (content, tag) = array[i];
			SortFieldCombo.Items.Add(new ComboBoxItem
			{
				Content = content,
				Tag = tag
			});
		}
		SortFieldCombo.SelectedIndex = 0;
	}

	private void m_576()
	{
		Folders.Clear();
		Folders.Add(new NickFolder
		{
			Id = -1,
			Name = "Tất cả",
			IsSystem = true
		});
		foreach (NickFolder item in FacebookAccountDatabase.LoadFolders())
		{
			Folders.Add(item);
		}
		Folders.Add(new NickFolder
		{
			Id = -2,
			Name = "Đã xóa",
			IsSystem = true
		});
		m_607(Folders, "Facebook");
	}

	private void g()
	{
		foreach (NickFolder A in Folders)
		{
			A.Count = ((A.Id == -1) ? Facebooks.Count((FacebookAccountRow P_0) => P_0.FolderId != -2) : Facebooks.Count((FacebookAccountRow P_0) => P_0.FolderId == A.Id));
		}
	}

	private void H()
	{
		if (m_501 != null)
		{
			int num = ((IEnumerable)m_501).Cast<FacebookAccountRow>().Count();
			int num2 = ((IEnumerable)m_501).Cast<FacebookAccountRow>().Count((FacebookAccountRow P_0) => P_0.IsSelected);
			string text = (FolderListBox.SelectedItem as NickFolder)?.Name ?? "";
			FacebookCountText.Text = ((text.Length > 0) ? $"{num} nick trong \"{text}\"" : $"{num} nick");
			FacebookSelectedCountText.Text = $"{num2} đã chọn";
			m_577(num, num2);
		}
	}

	private void m_577(int P_0, int P_1)
	{
		if (StatTotalText == null)
		{
			return;
		}
		try
		{
			List<FacebookAccountRow> source = ((IEnumerable)m_501).Cast<FacebookAccountRow>().ToList();
			int num = source.Count((FacebookAccountRow facebookAccountRow) => string.Equals(facebookAccountRow.TinhTrang, "LIVE", StringComparison.OrdinalIgnoreCase));
			int num2 = source.Count((FacebookAccountRow facebookAccountRow) => !string.IsNullOrWhiteSpace(facebookAccountRow.Proxy));
			int num3 = source.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.ScriptId != 0);
			StatTotalText.Text = P_0.ToString();
			StatTotalSubText.Text = ((P_1 > 0) ? $"{P_1} đã chọn" : "tất cả nick");
			StatLiveText.Text = num.ToString();
			StatLiveSubText.Text = ((P_0 > 0) ? $"{num * 100 / P_0}% tổng số" : "0% tổng số");
			StatProxyText.Text = ((P_0 > 0) ? $"{num2 * 100 / P_0}%" : "0%");
			StatProxySubText.Text = $"{num2}/{P_0} nick";
			StatScriptText.Text = num3.ToString();
			StatScriptSubText.Text = ((num3 > 0) ? "nick đã gắn kịch bản" : "chưa gắn kịch bản");
		}
		catch
		{
		}
	}

	private void h()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Expected Obj, but got Unknown
		if (m_520 == null)
		{
			m_520 = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(200L)
			};
			m_520.Tick += delegate
			{
				m_520.Stop();
				H();
			};
		}
		m_520.Stop();
		m_520.Start();
	}

	private void I()
	{
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		List<FacebookAccountRow> list = FacebookAccountDatabase.LoadAll();
		ICollectionView? val = m_501;
		Predicate<object> filter = ((val != null) ? val.Filter : null);
		List<SortDescription> list2 = ((m_501 != null) ? new List<SortDescription>((IEnumerable<SortDescription>)m_501.SortDescriptions) : null);
		if (m_501 != null)
		{
			m_501.Filter = null;
			((Collection<SortDescription>)(object)m_501.SortDescriptions).Clear();
		}
		Facebooks.CollectionChanged -= m_584;
		try
		{
			if (list.Count > 0)
			{
				Facebooks.Clear();
				foreach (FacebookAccountRow item in list)
				{
					item.PropertyChanged += m_585;
					Facebooks.Add(item);
				}
			}
			else
			{
				int folderId = Folders.FirstOrDefault((NickFolder P_0) => P_0.IsSystem && P_0.Id > 0)?.Id ?? 0;
				foreach (FacebookAccountRow facebook in Facebooks)
				{
					facebook.FolderId = folderId;
					facebook.PropertyChanged += m_585;
				}
				K();
			}
		}
		finally
		{
			Facebooks.CollectionChanged += m_584;
		}
		if (m_501 != null)
		{
			m_501.Filter = filter;
			if (list2 != null)
			{
				foreach (SortDescription item2 in list2)
				{
					((Collection<SortDescription>)(object)m_501.SortDescriptions).Add(item2);
				}
			}
			m_501.Refresh();
		}
		g();
		H();
	}

	private void m_578(object P_0, RoutedEventArgs P_1)
	{
		I();
	}

	private async void m_579(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Mở Chrome", NotifyType.Warning);
			return;
		}
		List<FacebookAccountRow> list2 = list.Where((FacebookAccountRow facebookAccountRow) => !string.IsNullOrWhiteSpace(facebookAccountRow.ProfileChrome)).ToList();
		if (list2.Count == 0)
		{
			CustomMessageBox.Show(this, "Các nick đã chọn chưa gắn Chrome. Bấm \"Gắn Chrome\" cho nick trước.", "Mở Chrome", NotifyType.Warning);
			return;
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			CustomMessageBox.Show(this, $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.", "Mở Chrome", NotifyType.Warning);
			return;
		}
		int num = 0;
		foreach (FacebookAccountRow item in list2)
		{
			try
			{
				await global::A.F.A(client, settings, item);
				num++;
			}
			catch (Exception ex)
			{
				item.TrangThai = "Không mở được Chrome: " + ex.Message;
			}
		}
		if (num == 0)
		{
			CustomMessageBox.Show(this, "Không mở được Chrome cho nick nào - xem cột Trạng thái.", "Mở Chrome", NotifyType.Warning);
		}
	}

	private void m_580(object P_0, RoutedEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = false;
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			list = Facebooks.ToList();
		}
		if (list.Count == 0)
		{
			return;
		}
		foreach (FacebookAccountRow item in list)
		{
			item.TrangThai = "";
			item.TinhTrang = "";
		}
	}

	private static void m_581(FacebookAccountRow P_0, string P_1)
	{
		P_0.TrangThai = m_582(P_1);
		P_0.TrangThaiChiTiet = P_1 ?? "";
	}

	private static string m_582(string P_0)
	{
		if (string.IsNullOrEmpty(P_0))
		{
			return P_0 ?? "";
		}
		if (P_0.Contains("Call log:") || (P_0.Contains("Timeout") && P_0.Contains("exceeded")))
		{
			return "Dừng chrome sớm hơn dự tính";
		}
		return P_0;
	}

	private void m_583(IEnumerable<FacebookAccountRow> P_0)
	{
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		ICollectionView? val = m_501;
		Predicate<object> filter = ((val != null) ? val.Filter : null);
		List<SortDescription> list = ((m_501 != null) ? new List<SortDescription>((IEnumerable<SortDescription>)m_501.SortDescriptions) : null);
		if (m_501 != null)
		{
			m_501.Filter = null;
			((Collection<SortDescription>)(object)m_501.SortDescriptions).Clear();
		}
		Facebooks.CollectionChanged -= m_584;
		try
		{
			foreach (FacebookAccountRow item in P_0)
			{
				item.PropertyChanged += m_585;
				Facebooks.Add(item);
			}
		}
		finally
		{
			Facebooks.CollectionChanged += m_584;
		}
		if (m_501 == null)
		{
			return;
		}
		m_501.Filter = filter;
		if (list != null)
		{
			foreach (SortDescription item2 in list)
			{
				((Collection<SortDescription>)(object)m_501.SortDescriptions).Add(item2);
			}
		}
		m_501.Refresh();
	}

	private void m_584(object? sender, NotifyCollectionChangedEventArgs P_1)
	{
		if (P_1.NewItems != null)
		{
			foreach (FacebookAccountRow newItem in P_1.NewItems)
			{
				newItem.PropertyChanged += m_585;
			}
		}
		if (P_1.OldItems != null)
		{
			foreach (FacebookAccountRow oldItem in P_1.OldItems)
			{
				oldItem.PropertyChanged -= m_585;
			}
		}
		if (m_503)
		{
			m_569();
			ICollectionView? val = m_501;
			if (val != null)
			{
				val.Refresh();
			}
		}
		g();
		H();
		i();
		if (P_1.NewItems == null)
		{
			return;
		}
		foreach (FacebookAccountRow newItem2 in P_1.NewItems)
		{
			m_586(newItem2.FolderId);
		}
	}

	private void m_585(object? sender, PropertyChangedEventArgs P_1)
	{
		if (P_1.PropertyName == "IsSelected")
		{
			h();
			return;
		}
		if (m_503 && P_1.PropertyName == "Uid")
		{
			m_569();
			ICollectionView? val = m_501;
			if (val != null)
			{
				val.Refresh();
			}
		}
		i();
		if (sender is FacebookAccountRow facebookAccountRow)
		{
			m_586(facebookAccountRow.FolderId);
		}
	}

	private void i()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Expected Obj, but got Unknown
		if (m_521 == null)
		{
			m_521 = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(700L)
			};
			m_521.Tick += delegate
			{
				m_521.Stop();
				K();
			};
		}
		m_521.Stop();
		m_521.Start();
	}

	private void J()
	{
		if (m_521 != null && m_521.IsEnabled)
		{
			m_521.Stop();
			K();
		}
	}

	private void m_586(int P_0)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Expected Obj, but got Unknown
		GoogleSheetsSyncSettings googleSheetsSyncSettings = GoogleSheetsSyncSettings.Load();
		if (!m_633(googleSheetsSyncSettings))
		{
			return;
		}
		m_522.Add(P_0);
		if (m_523 == null)
		{
			m_523 = new DispatcherTimer
			{
				Interval = TimeSpan.FromSeconds(10L)
			};
			m_523.Tick += delegate
			{
				m_523.Stop();
				j();
			};
		}
		m_523.Stop();
		m_523.Start();
	}

	private void j()
	{
		if (m_522.Count == 0)
		{
			return;
		}
		List<(int Id, string Name)> m_1078 = (from P_0 in m_522
			select Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == P_0) into P_0
			where P_0 != null
			select (Id: P_0.Id, Name: P_0.Name)).ToList();
		m_522.Clear();
		if (m_1078.Count == 0)
		{
			return;
		}
		Dictionary<int, List<FacebookAccountRow>> m_1079 = m_1078.ToDictionary(((int Id, string Name) t) => t.Id, ((int Id, string Name) t) => Facebooks.Where((FacebookAccountRow P_0) => P_0.FolderId == t.Id).ToList());
		m_634(async (SheetsService P_0, GoogleSheetsSyncSettings P_1) =>
		{
			foreach (var (key, folderName) in m_1078)
			{
				await GoogleSheetsSyncService.SyncFolderAsync(P_0, P_1.SpreadsheetId, folderName, GoogleSheetsSyncService.BuildRows(m_1079[key]), CancellationToken.None);
			}
		});
	}

	private void K()
	{
		try
		{
			FacebookAccountDatabase.SaveAll(Facebooks);
		}
		catch
		{
		}
	}

	private void m_587(object P_0, RoutedEventArgs P_1)
	{
		PlatformAccountPage platformAccountPage = A;
		if (platformAccountPage != null)
		{
			platformAccountPage.AddFolder();
			return;
		}
		string text = PromptDialog.Show(this, "Tạo thư mục", "Tên thư mục:");
		if (string.IsNullOrWhiteSpace(text))
		{
			return;
		}
		try
		{
			NickFolder item = FacebookAccountDatabase.CreateFolder(text.Trim());
			Folders.Insert(Folders.Count - 1, item);
			g();
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể tạo thư mục: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void m_588(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as MenuItem)?.DataContext is NickFolder nickFolder)
		{
			m_590(nickFolder);
		}
	}

	private void m_589(object P_0, RoutedEventArgs P_1)
	{
		if (!(FolderListBox.SelectedItem is NickFolder nickFolder))
		{
			CustomMessageBox.Show(this, "Chọn 1 thư mục trước.", "Đổi tên thư mục", NotifyType.Warning);
			return;
		}
		PlatformAccountPage platformAccountPage = A;
		if (platformAccountPage != null)
		{
			platformAccountPage.RenameFolder(nickFolder);
		}
		else
		{
			m_590(nickFolder);
		}
	}

	private void m_590(NickFolder P_0)
	{
		if (!P_0.CanManage)
		{
			return;
		}
		string text = PromptDialog.Show(this, "Đổi tên thư mục", "Tên thư mục:", P_0.Name);
		if (string.IsNullOrWhiteSpace(text) || text.Trim() == P_0.Name)
		{
			return;
		}
		string name = P_0.Name;
		try
		{
			FacebookAccountDatabase.RenameFolder(P_0.Id, text.Trim());
			P_0.Name = text.Trim();
			H();
			m_636(name, P_0.Name);
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể đổi tên: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void g(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as MenuItem)?.DataContext is NickFolder nickFolder)
		{
			m_591(nickFolder);
		}
	}

	private void H(object P_0, RoutedEventArgs P_1)
	{
		if (!(FolderListBox.SelectedItem is NickFolder nickFolder))
		{
			CustomMessageBox.Show(this, "Chọn 1 thư mục trước.", "Xóa thư mục", NotifyType.Warning);
			return;
		}
		PlatformAccountPage platformAccountPage = A;
		if (platformAccountPage != null)
		{
			if (platformAccountPage.DeleteFolder(nickFolder))
			{
				FolderListBox.SelectedIndex = 0;
			}
		}
		else
		{
			m_591(nickFolder);
		}
	}

	private void m_591(NickFolder P_0)
	{
		if (!P_0.CanManage)
		{
			return;
		}
		int num = Facebooks.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.FolderId == P_0.Id);
		string message = ((num > 0) ? $"Thư mục \"{P_0.Name}\" đang có {num} nick. Xóa thư mục sẽ chuyển các nick này về \"{"Mặc định"}\". Tiếp tục?" : ("Xóa thư mục \"" + P_0.Name + "\"?"));
		if (!CustomMessageBox.Confirm(this, message, "Xóa thư mục"))
		{
			return;
		}
		try
		{
			int folderId = Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.IsSystem && nickFolder.Id > 0)?.Id ?? (-1);
			foreach (FacebookAccountRow item in Facebooks.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.FolderId == P_0.Id))
			{
				item.FolderId = folderId;
			}
			if (m_502 == P_0.Id)
			{
				FolderListBox.SelectedIndex = 0;
			}
			FacebookAccountDatabase.DeleteFolder(P_0.Id);
			Folders.Remove(P_0);
			g();
			H();
			H(P_0.Name);
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể xóa thư mục: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void m_592(object P_0, SelectionChangedEventArgs P_1)
	{
		if (!(FolderListBox.SelectedItem is NickFolder nickFolder))
		{
			return;
		}
		UiPreferences uiPreferences = UiPreferences.Load();
		uiPreferences.LastSelectedFolderId[G] = nickFolder.Id;
		uiPreferences.Save();
		PlatformAccountPage platformAccountPage = A;
		if (platformAccountPage != null)
		{
			platformAccountPage.SelectFolder(nickFolder);
			return;
		}
		foreach (FacebookAccountRow facebook in Facebooks)
		{
			facebook.IsSelected = false;
		}
		m_502 = nickFolder.Id;
		ICollectionView? val = m_501;
		if (val != null)
		{
			val.Refresh();
		}
		bool flag = nickFolder.Id == -2;
		RestoreButton.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		DeleteButtonText.Text = (flag ? "Xóa vĩnh viễn" : "Xóa");
		MoveFolderButton.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		H();
	}

	private void h(object P_0, RoutedEventArgs P_1)
	{
		m_638(SortPopup, P_0, SortButton);
	}

	private void I(object P_0, RoutedEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = false;
		GoogleSheetsSyncWindow googleSheetsSyncWindow = new GoogleSheetsSyncWindow();
		googleSheetsSyncWindow.Owner = this;
		googleSheetsSyncWindow.ShowDialog();
	}

	private void m_593(object P_0, SelectionChangedEventArgs P_1)
	{
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (m_501 != null && SortFieldCombo.SelectedItem != null && SortDirectionCombo.SelectedItem != null)
		{
			string text = ((SortFieldCombo.SelectedItem as ComboBoxItem)?.Tag as string) ?? "Index";
			bool flag = (SortDirectionCombo.SelectedItem as ComboBoxItem)?.Content as string == "Giảm dần";
			((Collection<SortDescription>)(object)m_501.SortDescriptions).Clear();
			((Collection<SortDescription>)(object)m_501.SortDescriptions).Add(new SortDescription(text, flag ? ListSortDirection.Descending : ListSortDirection.Ascending));
		}
	}

	private void k()
	{
		m_524 = FacebookGrid.SelectedItems.Cast<FacebookAccountRow>().ToList();
	}

	private List<FacebookAccountRow> L()
	{
		List<FacebookAccountRow> list = Facebooks.Where((FacebookAccountRow P_0) => P_0.IsSelected).ToList();
		if (list.Count > 0)
		{
			return list;
		}
		List<FacebookAccountRow> list2 = FacebookGrid.SelectedItems.Cast<FacebookAccountRow>().ToList();
		if (list2.Count > 0)
		{
			return list2;
		}
		if (m_524.Count > 0)
		{
			List<FacebookAccountRow> list3 = m_524.Where((FacebookAccountRow P_0) => Facebooks.Contains(P_0)).ToList();
			if (list3.Count > 0)
			{
				return list3;
			}
		}
		if (m_525 != null && Facebooks.Contains(m_525))
		{
			return new List<FacebookAccountRow> { m_525 };
		}
		return new List<FacebookAccountRow>();
	}

	private void i(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> A = L();
		if (A.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Chuyển thư mục", NotifyType.Warning);
			return;
		}
		MoveFolderPanel.Children.Clear();
		foreach (NickFolder A2 in Folders.Where((NickFolder nickFolder) => nickFolder.Id != -2 && nickFolder.Id != -1))
		{
			Button button = new Button
			{
				Style = (Style)FindResource("OutlineButtonStyle"),
				Content = A2.Name,
				Margin = new Thickness(2.0),
				HorizontalContentAlignment = HorizontalAlignment.Left
			};
			button.Click += delegate
			{
				foreach (FacebookAccountRow item in A)
				{
					item.FolderId = A2.Id;
					item.IsSelected = false;
				}
				ICollectionView? val = m_501;
				if (val != null)
				{
					val.Refresh();
				}
				g();
				H();
				MoveFolderPopup.IsOpen = false;
			};
			MoveFolderPanel.Children.Add(button);
		}
		m_638(MoveFolderPopup, P_0, MoveFolderButton);
	}

	private void J(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Xóa", NotifyType.Warning);
			return;
		}
		if (m_502 == -2)
		{
			foreach (FacebookAccountRow item in list)
			{
				Facebooks.Remove(item);
			}
			ICollectionView? val = m_501;
			if (val != null)
			{
				val.Refresh();
			}
			g();
			H();
			CustomMessageBox.Show(this, $"Đã xóa vĩnh viễn {list.Count} nick.", "Xóa vĩnh viễn");
			return;
		}
		foreach (FacebookAccountRow item2 in list)
		{
			item2.FolderId = -2;
			item2.IsSelected = false;
		}
		ICollectionView? val2 = m_501;
		if (val2 != null)
		{
			val2.Refresh();
		}
		g();
		H();
		CustomMessageBox.Show(this, $"Đã chuyển {list.Count} nick vào Đã xóa.", "Xóa");
	}

	private void j(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Khôi phục", NotifyType.Warning);
			return;
		}
		int folderId = Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.IsSystem && nickFolder.Id > 0)?.Id ?? (-1);
		foreach (FacebookAccountRow item in list)
		{
			item.FolderId = folderId;
			item.IsSelected = false;
		}
		ICollectionView? val = m_501;
		if (val != null)
		{
			val.Refresh();
		}
		g();
		H();
		CustomMessageBox.Show(this, $"Đã khôi phục {list.Count} nick.", "Khôi phục");
	}

	private void K(object P_0, RoutedEventArgs P_1)
	{
		if (m_501 == null)
		{
			return;
		}
		bool isSelected = ((P_0 as CheckBox)?.IsChecked == true);
		foreach (FacebookAccountRow item in ((IEnumerable)m_501).Cast<FacebookAccountRow>())
		{
			item.IsSelected = isSelected;
		}
	}

	private void k(object P_0, RoutedEventArgs P_1)
	{
		foreach (FacebookAccountRow item in FacebookGrid.SelectedItems.Cast<FacebookAccountRow>().ToList())
		{
			item.IsSelected = true;
		}
	}

	private void L(object P_0, RoutedEventArgs P_1)
	{
		foreach (FacebookAccountRow item in FacebookGrid.SelectedItems.Cast<FacebookAccountRow>().ToList())
		{
			item.IsSelected = false;
		}
	}

	private void l(object P_0, RoutedEventArgs P_1)
	{
		if (m_501 == null)
		{
			return;
		}
		foreach (FacebookAccountRow item in ((IEnumerable)m_501).Cast<FacebookAccountRow>())
		{
			item.IsSelected = true;
		}
	}

	private void M(object P_0, RoutedEventArgs P_1)
	{
		if (m_501 == null)
		{
			return;
		}
		foreach (FacebookAccountRow item in ((IEnumerable)m_501).Cast<FacebookAccountRow>())
		{
			item.IsSelected = false;
		}
	}

	private async void m(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = (from facebookAccountRow in L()
			where !string.IsNullOrWhiteSpace(facebookAccountRow.BrowserProfileId)
			select facebookAccountRow).ToList();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào có profile trình duyệt đang lưu.", "Reset profile", NotifyType.Warning);
			return;
		}
		IAntidetectBrowserClient client = BrowserEngineFactory.CreateActiveClient().Client;
		foreach (FacebookAccountRow item in list)
		{
			await client.StopProfileAsync(item.BrowserProfileId);
			await client.DeleteProfileAsync(item.BrowserProfileId, hard: true);
			item.BrowserProfileId = "";
		}
		CustomMessageBox.Show(this, $"Đã reset profile trình duyệt cho {list.Count} nick. Bấm Đăng nhập lại để tạo profile mới.", "Reset profile");
	}

	private void N(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is FacebookAccountRow facebookAccountRow)
		{
			new TextDetailWindow(this, "Trạng thái - UID " + facebookAccountRow.Uid, facebookAccountRow, "TrangThai", "TrangThaiChiTiet").Show();
		}
	}

	private void n(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is FacebookAccountRow facebookAccountRow)
		{
			new TextDetailWindow(this, "Kịch bản - UID " + facebookAccountRow.Uid, facebookAccountRow, "ScriptName").Show();
		}
	}

	private void m_594(object P_0, MouseButtonEventArgs P_1)
	{
		object originalSource = P_1.OriginalSource;
		DependencyObject val = (DependencyObject)((originalSource is DependencyObject) ? originalSource : null);
		while (val != null && !(val is DataGridRow) && !(val is CheckBox))
		{
			val = VisualTreeHelper.GetParent(val);
		}
		if (!(val is CheckBox))
		{
			while (val != null && !(val is DataGridRow))
			{
				val = VisualTreeHelper.GetParent(val);
			}
			if (val is DataGridRow { Item: FacebookAccountRow item })
			{
				item.IsSelected = !item.IsSelected;
			}
		}
	}

	private static ScrollViewer? m_595(DependencyObject P_0)
	{
		int childrenCount = VisualTreeHelper.GetChildrenCount(P_0);
		for (int i = 0; i < childrenCount; i++)
		{
			DependencyObject child = VisualTreeHelper.GetChild(P_0, i);
			if (child is ScrollViewer result)
			{
				return result;
			}
			ScrollViewer scrollViewer = m_595(child);
			if (scrollViewer != null)
			{
				return scrollViewer;
			}
		}
		return null;
	}

	private void O(object P_0, RoutedEventArgs P_1)
	{
		m_595((DependencyObject)(object)FacebookGrid)?.PageLeft();
	}

	private void o(object P_0, RoutedEventArgs P_1)
	{
		m_595((DependencyObject)(object)FacebookGrid)?.PageRight();
	}

	private void m_596(object P_0, ContextMenuEventArgs P_1)
	{
		k();
		object originalSource = P_1.OriginalSource;
		m_525 = m_598<DataGridRow>((DependencyObject?)((originalSource is DependencyObject) ? originalSource : null))?.Item as FacebookAccountRow;
		bool flag = !string.IsNullOrWhiteSpace(m_525?.TinhTrang);
		SelectSameTinhTrangMenuItem.Header = (flag ? ("Chọn nick cùng TÌNH TRẠNG \"" + m_597(m_525.TinhTrang) + "\"") : "Chọn nick cùng TÌNH TRẠNG");
		SelectSameTinhTrangMenuItem.IsEnabled = flag;
		bool flag2 = !string.IsNullOrWhiteSpace(m_525?.TrangThai);
		SelectSameTrangThaiMenuItem.Header = (flag2 ? ("Chọn nick cùng TRẠNG THÁI \"" + m_597(m_525.TrangThai) + "\"") : "Chọn nick cùng TRẠNG THÁI");
		SelectSameTrangThaiMenuItem.IsEnabled = flag2;
	}

	private static string m_597(string P_0, int P_1 = 40)
	{
		if (P_0.Length <= P_1)
		{
			return P_0;
		}
		return P_0.Substring(0, P_1).TrimEnd() + "...";
	}

	private static gm_484? m_598<gm_484>(DependencyObject? P_0) where gm_484 : DependencyObject
	{
		while (P_0 != null && !(P_0 is gm_484))
		{
			P_0 = VisualTreeHelper.GetParent(P_0);
		}
		return (gm_484)(object)((P_0 is gm_484) ? P_0 : null);
	}

	private void P(object P_0, RoutedEventArgs P_1)
	{
		if (m_525 == null)
		{
			return;
		}
		string tinhTrang = m_525.TinhTrang;
		foreach (FacebookAccountRow facebook in Facebooks)
		{
			facebook.IsSelected = facebook.TinhTrang == tinhTrang;
		}
	}

	private void p(object P_0, RoutedEventArgs P_1)
	{
		if (m_525 == null)
		{
			return;
		}
		string trangThai = m_525.TrangThai;
		foreach (FacebookAccountRow facebook in Facebooks)
		{
			facebook.IsSelected = facebook.TrangThai == trangThai;
		}
	}

	protected override void OnSourceInitialized(EventArgs e)
	{
		base.OnSourceInitialized(e);
		if (PresentationSource.FromVisual(this) is HwndSource hwndSource)
		{
			hwndSource.AddHook(m_599);
		}
	}

	private static nint m_599(nint P_0, int P_1, nint P_2, nint P_3, ref bool P_4)
	{
		if (P_1 == 36)
		{
			m_600(P_0, P_3);
			P_4 = true;
		}
		return IntPtr.Zero;
	}

	private static void m_600(nint P_0, nint P_1)
	{
		m_706 structure = Marshal.PtrToStructure<m_706>(P_1);
		nint num = m_601(P_0, 2);
		if (num != IntPtr.Zero)
		{
			m_707 obj = new m_707
			{
				A = Marshal.SizeOf<m_707>()
			};
			m_602(num, ref obj);
			m_705 obj2 = obj.a;
			m_705 obj3 = obj.m_864;
			structure.B.A = obj2.A - obj3.A;
			structure.B.a = obj2.a - obj3.a;
			structure.a.A = obj2.B - obj2.A;
			structure.a.a = obj2.b - obj2.a;
		}
		Marshal.StructureToPtr(structure, P_1, fDeleteOld: true);
	}

	[DllImport("user32.dll", EntryPoint = "MonitorFromWindow")]
	private static extern nint m_601(nint P_0, int P_1);

	[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "GetMonitorInfo")]
	private static extern bool m_602(nint P_0, ref m_707 P_1);

	private async void Q(object P_0, RoutedEventArgs P_1)
	{
		m_683(ActualWidth < 1100.0);
		aE();
		MaximizeButton.Content = ((WindowState == WindowState.Maximized) ? "\ue923" : "\ue922");
		if (D.Length > 0)
		{
			m_557(D);
		}
		m_605(ActualWidth);
		U();
		V();
		W();
		await af();
	}

	private void m_603(object P_0, CancelEventArgs P_1)
	{
		J();
		m_509.FlushSave();
		m_510.FlushSave();
		m_511.FlushSave();
		m_512.FlushSave();
		foreach (PlatformAccountPage value in m_513.Values)
		{
			value.FlushSave();
		}
	}

	private void m_604(object P_0, SizeChangedEventArgs P_1)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		Size newSize = P_1.NewSize;
		m_683(newSize.Width < 1100.0);
		aE();
		if (D.Length > 0)
		{
			m_557(D);
		}
		newSize = P_1.NewSize;
		m_605(newSize.Width);
	}

	private void m_605(double P_0)
	{
		double num = Math.Clamp(P_0 / 1400.0, 0.68, 1.0);
		BrandLogoImage.Width = 67.0 * num;
		BrandLogoImage.Height = 67.0 * num;
		BrandTitleText.FontSize = 15.0 * num;
		BrandSubtitleText.FontSize = 13.5 * num;
		BrandProBadgeImage.Height = 26.0 * num;
	}

	private void q(object P_0, RoutedEventArgs P_1)
	{
		m_683(!m_508);
	}

	private void m_606(string P_0)
	{
		if (PhoneContent == null || FacebookContent == null || ScriptContent == null || BaoSamSettingsContent == null || AiVisionSettingsContent == null || VerifyMailSettingsContent == null || VerifyPhoneSettingsContent == null || GmailContentHost == null || TikTokContentHost == null || HotmailContentHost == null || ShopeeContentHost == null || SidebarFolderPanel == null)
		{
			return;
		}
		PhoneContent.Visibility = ((!(P_0 == "Phone")) ? Visibility.Collapsed : Visibility.Visible);
		FacebookContent.Visibility = ((!(P_0 == "Facebook")) ? Visibility.Collapsed : Visibility.Visible);
		ScriptContent.Visibility = ((!(P_0 == "Scripts")) ? Visibility.Collapsed : Visibility.Visible);
		BaoSamSettingsContent.Visibility = ((!(P_0 == "BaoSamSettings")) ? Visibility.Collapsed : Visibility.Visible);
		AiVisionSettingsContent.Visibility = ((!(P_0 == "AiVisionSettings")) ? Visibility.Collapsed : Visibility.Visible);
		VerifyMailSettingsContent.Visibility = ((!(P_0 == "VerifyMailSettings")) ? Visibility.Collapsed : Visibility.Visible);
		VerifyPhoneSettingsContent.Visibility = ((!(P_0 == "VerifyPhoneSettings")) ? Visibility.Collapsed : Visibility.Visible);
		GmailContentHost.Visibility = ((!(P_0 == "Gmail")) ? Visibility.Collapsed : Visibility.Visible);
		TikTokContentHost.Visibility = ((!(P_0 == "TikTok")) ? Visibility.Collapsed : Visibility.Visible);
		HotmailContentHost.Visibility = ((!(P_0 == "Hotmail")) ? Visibility.Collapsed : Visibility.Visible);
		ShopeeContentHost.Visibility = ((!(P_0 == "Shopee")) ? Visibility.Collapsed : Visibility.Visible);
		foreach (KeyValuePair<string, Border> item in m_514)
		{
			item.Value.Visibility = ((!(P_0 == item.Key)) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (G != "Scripts" && !string.IsNullOrEmpty(G))
		{
			c = G;
		}
		G = P_0;
		ObservableCollection<NickFolder> observableCollection = P_0 switch
		{
			"Facebook" => Folders, 
			"Gmail" => m_509.Folders, 
			"TikTok" => m_510.Folders, 
			"Hotmail" => m_511.Folders, 
			"Shopee" => m_512.Folders, 
			_ => m_513.TryGetValue(P_0, out PlatformAccountPage value) ? value.Folders : null, 
		};
		if (observableCollection != null)
		{
			FolderListBox.ItemsSource = observableCollection;
			m_607(observableCollection, P_0);
		}
		ae();
	}

	private void m_607(ObservableCollection<NickFolder> P_0, string P_1)
	{
		NickFolder nickFolder = null;
		if (UiPreferences.Load().LastSelectedFolderId.TryGetValue(P_1, out var A))
		{
			nickFolder = P_0.FirstOrDefault((NickFolder nickFolder2) => nickFolder2.Id == A);
		}
		FolderListBox.SelectedItem = nickFolder ?? ((P_0.Count > 0) ? P_0[0] : null);
	}

	private void R(object P_0, RoutedEventArgs P_1)
	{
		m_606("Phone");
	}

	private void r(object P_0, RoutedEventArgs P_1)
	{
		m_606("Facebook");
	}

	private void S(object P_0, RoutedEventArgs P_1)
	{
		m_606("Gmail");
	}

	private void s(object P_0, RoutedEventArgs P_1)
	{
		m_606("TikTok");
	}

	private void T(object P_0, RoutedEventArgs P_1)
	{
		m_606("Hotmail");
	}

	private void t(object P_0, RoutedEventArgs P_1)
	{
		m_606("Shopee");
	}

	private void M()
	{
		foreach (CustomPlatformEntry customPlatform in UiPreferences.Load().CustomPlatforms)
		{
			m_609(customPlatform, false);
		}
	}

	private (RadioButton Radio, TextBlock LabelText, string DefaultLabel)? m_608(string P_0)
	{
		return P_0 switch
		{
			"Gmail" => ((RadioButton Radio, TextBlock LabelText, string DefaultLabel)?)(NavGmailRadio, GmailNavLabelText, "Quản Lý Gmail"), 
			"TikTok" => (NavTikTokRadio, TikTokNavLabelText, "Quản Lý TikTok"), 
			"Shopee" => (NavShopeeRadio, ShopeeNavLabelText, "Quản Lý Shopee"), 
			"Hotmail" => (NavHotmailRadio, HotmailNavLabelText, "Quản Lý Hotmail"), 
			_ => null, 
		};
	}

	private void m()
	{
		UiPreferences uiPreferences = UiPreferences.Load();
		string[] array = m_529;
		foreach (string text in array)
		{
			(RadioButton, TextBlock, string)? tuple = m_608(text);
			if (!tuple.HasValue)
			{
				continue;
			}
			(RadioButton, TextBlock, string) valueOrDefault = tuple.GetValueOrDefault();
			var (radioButton, _, _) = valueOrDefault;
			if (radioButton == null)
			{
				continue;
			}
			TextBlock item = valueOrDefault.Item2;
			if (item == null)
			{
				continue;
			}
			string item2 = valueOrDefault.Item3;
			if (item2 != null)
			{
				if (uiPreferences.HiddenBuiltInPlatforms.Contains(text))
				{
					radioButton.Visibility = Visibility.Collapsed;
				}
				if (uiPreferences.RenamedBuiltInPlatforms.TryGetValue(text, out string value) && !string.IsNullOrWhiteSpace(value))
				{
					item.Text = value;
				}
				else
				{
					item.Text = item2;
				}
			}
		}
		N();
	}

	private void N()
	{
		bool flag = m_529.Any((string P_0) =>
		{
			(RadioButton, TextBlock, string)? tuple = m_608(P_0);
			return tuple.HasValue && tuple.GetValueOrDefault().Item1.Visibility == Visibility.Collapsed;
		});
		RestoreBuiltInPlatformButton.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void U(object P_0, RoutedEventArgs P_1)
	{
		ContextMenu contextMenu = new ContextMenu
		{
			Style = (Style)FindResource("AppContextMenuStyle"),
			PlacementTarget = RestoreBuiltInPlatformButton
		};
		string[] array = m_529;
		foreach (string text in array)
		{
			(RadioButton, TextBlock, string)? tuple = m_608(text);
			if (!tuple.HasValue)
			{
				continue;
			}
			(RadioButton, TextBlock, string) valueOrDefault = tuple.GetValueOrDefault();
			var (radioButton, _, _) = valueOrDefault;
			if (radioButton != null)
			{
				TextBlock item = valueOrDefault.Item2;
				if (item != null && radioButton.Visibility == Visibility.Collapsed)
				{
					MenuItem menuItem = new MenuItem
					{
						Header = item.Text,
						Tag = text
					};
					menuItem.Click += u;
					contextMenu.Items.Add(menuItem);
				}
			}
		}
		if (contextMenu.Items.Count != 0)
		{
			contextMenu.IsOpen = true;
		}
	}

	private void u(object P_0, RoutedEventArgs P_1)
	{
		if (!(P_0 is MenuItem { Tag: string tag }))
		{
			return;
		}
		(RadioButton, TextBlock, string)? tuple = m_608(tag);
		if (tuple.HasValue)
		{
			RadioButton item = tuple.GetValueOrDefault().Item1;
			if (item != null)
			{
				item.Visibility = Visibility.Visible;
				UiPreferences uiPreferences = UiPreferences.Load();
				uiPreferences.HiddenBuiltInPlatforms.Remove(tag);
				uiPreferences.Save();
				N();
			}
		}
	}

	private void n()
	{
		bool flag = m_529.Contains(G);
		bool flag2 = m_513.ContainsKey(G);
		bool isEnabled = flag | flag2;
		EditAccountTabButton.IsEnabled = isEnabled;
		DeleteAccountTabButton.IsEnabled = isEnabled;
	}

	private void V(object P_0, RoutedEventArgs P_1)
	{
		string A = G;
		(RadioButton, TextBlock, string)? tuple = m_608(A);
		if (tuple.HasValue)
		{
			TextBlock item = tuple.GetValueOrDefault().Item2;
			if (item != null)
			{
				string text = PromptDialog.Show(this, "Đổi tên mục", "Tên mới:", item.Text);
				if (!string.IsNullOrWhiteSpace(text) && !(text.Trim() == item.Text))
				{
					item.Text = text.Trim();
					UiPreferences uiPreferences = UiPreferences.Load();
					uiPreferences.RenamedBuiltInPlatforms[A] = text.Trim();
					uiPreferences.Save();
				}
				return;
			}
		}
		CustomPlatformEntry customPlatformEntry = UiPreferences.Load().CustomPlatforms.FirstOrDefault((CustomPlatformEntry customPlatformEntry3) => customPlatformEntry3.Key == A);
		if (customPlatformEntry == null || !m_516.TryGetValue(A, out TextBlock value))
		{
			return;
		}
		string text2 = PromptDialog.Show(this, "Đổi tên mục", "Tên mới:", customPlatformEntry.Label);
		if (!string.IsNullOrWhiteSpace(text2) && !(text2.Trim() == customPlatformEntry.Label))
		{
			customPlatformEntry.Label = text2.Trim();
			value.Text = "Quản Lý " + customPlatformEntry.Label;
			UiPreferences uiPreferences2 = UiPreferences.Load();
			CustomPlatformEntry customPlatformEntry2 = uiPreferences2.CustomPlatforms.FirstOrDefault((CustomPlatformEntry customPlatformEntry3) => customPlatformEntry3.Key == A);
			if (customPlatformEntry2 != null)
			{
				customPlatformEntry2.Label = customPlatformEntry.Label;
			}
			uiPreferences2.Save();
		}
	}

	private void v(object P_0, RoutedEventArgs P_1)
	{
		string A = G;
		(RadioButton, TextBlock, string)? tuple = m_608(A);
		if (tuple.HasValue)
		{
			(RadioButton, TextBlock, string) valueOrDefault = tuple.GetValueOrDefault();
			var (radioButton, _, _) = valueOrDefault;
			if (radioButton != null)
			{
				TextBlock item = valueOrDefault.Item2;
				if (item != null)
				{
					if (CustomMessageBox.Confirm(this, "Ẩn mục \"" + item.Text + "\" khỏi sidebar? Dữ liệu nick KHÔNG bị xoá - bấm nút khôi phục cạnh \"Sửa\" ở trên để hiện lại bất cứ lúc nào.", "Ẩn mục"))
					{
						NavFacebookRadio.IsChecked = true;
						radioButton.Visibility = Visibility.Collapsed;
						UiPreferences uiPreferences = UiPreferences.Load();
						if (!uiPreferences.HiddenBuiltInPlatforms.Contains(A))
						{
							uiPreferences.HiddenBuiltInPlatforms.Add(A);
						}
						uiPreferences.Save();
						N();
					}
					return;
				}
			}
		}
		CustomPlatformEntry customPlatformEntry = UiPreferences.Load().CustomPlatforms.FirstOrDefault((CustomPlatformEntry customPlatformEntry2) => customPlatformEntry2.Key == A);
		if (customPlatformEntry != null)
		{
			m_611(customPlatformEntry);
		}
	}

	private void W(object P_0, RoutedEventArgs P_1)
	{
		string text = PromptDialog.Show(this, "Thêm mục mới", "Tên mục (VD: Zalo, Lazada, Instagram...):");
		if (!string.IsNullOrWhiteSpace(text))
		{
			CustomPlatformEntry customPlatformEntry = new CustomPlatformEntry
			{
				Key = "Custom" + Guid.NewGuid().ToString("N").Substring(0, 8),
				Label = text.Trim()
			};
			UiPreferences uiPreferences = UiPreferences.Load();
			uiPreferences.CustomPlatforms.Add(customPlatformEntry);
			uiPreferences.Save();
			m_609(customPlatformEntry, true);
		}
	}

	private void m_609(CustomPlatformEntry P_0, bool P_1)
	{
		PlatformAccountPage platformAccountPage = new PlatformAccountPage(P_0.Key, P_0.Label);
		platformAccountPage.SetSharedCollections(Profiles, Scripts);
		Border border = new Border
		{
			Margin = new Thickness(28.0, 22.0, 28.0, 20.0),
			Visibility = Visibility.Collapsed,
			Child = platformAccountPage
		};
		Grid.SetRow(border, 1);
		Grid.SetColumn(border, 1);
		RootLayoutGrid.Children.Add(border);
		Brush brush = m_528[m_513.Count % m_528.Length];
		var (radioButton, value) = m_610(P_0, platformAccountPage, brush);
		AccountNavPanel.Children.Add(radioButton);
		m_513[P_0.Key] = platformAccountPage;
		m_514[P_0.Key] = border;
		m_515[P_0.Key] = radioButton;
		m_516[P_0.Key] = value;
		if (P_1)
		{
			radioButton.IsChecked = true;
		}
	}

	private (RadioButton Radio, TextBlock LabelText) m_610(CustomPlatformEntry P_0, PlatformAccountPage P_1, Brush P_2)
	{
		TextBlock textBlock = new TextBlock
		{
			Text = "Quản Lý " + P_0.Label,
			TextTrimming = TextTrimming.CharacterEllipsis,
			VerticalAlignment = VerticalAlignment.Center
		};
		Grid.SetColumn(textBlock, 0);
		TextBlock A = new TextBlock
		{
			Text = P_1.Accounts.Count.ToString(),
			Style = (Style)FindResource("SidebarCountBadgeTextStyle")
		};
		Border border = new Border
		{
			Style = (Style)FindResource("SidebarCountBadgeStyle"),
			Margin = new Thickness(6.0, 0.0, 0.0, 0.0),
			VerticalAlignment = VerticalAlignment.Center,
			Child = A
		};
		border.SetResourceReference(UIElement.VisibilityProperty, "SidebarTextVisibility");
		Grid.SetColumn(border, 1);
		P_1.Accounts.CollectionChanged += delegate
		{
			A.Text = P_1.Accounts.Count.ToString();
		};
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(1.0, GridUnitType.Star)
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		grid.Children.Add(textBlock);
		grid.Children.Add(border);
		RadioButton radioButton = new RadioButton
		{
			Style = (Style)FindResource("NavItemStyle"),
			Content = grid
		};
		if (P_0.Label.Contains("Facebook", StringComparison.OrdinalIgnoreCase))
		{
			NavIcon.SetLogoKey((DependencyObject)(object)radioButton, "Facebook");
		}
		else if (P_0.Label.Contains("Gmail", StringComparison.OrdinalIgnoreCase) || P_0.Label.Contains("Google", StringComparison.OrdinalIgnoreCase))
		{
			NavIcon.SetLogoKey((DependencyObject)(object)radioButton, "Gmail");
		}
		else if (P_0.Label.Contains("TikTok", StringComparison.OrdinalIgnoreCase))
		{
			NavIcon.SetLogoKey((DependencyObject)(object)radioButton, "TikTok");
		}
		else if (P_0.Label.Contains("Hotmail", StringComparison.OrdinalIgnoreCase) || P_0.Label.Contains("Outlook", StringComparison.OrdinalIgnoreCase))
		{
			NavIcon.SetLogoKey((DependencyObject)(object)radioButton, "Hotmail");
		}
		else if (P_0.Label.Contains("Shopee", StringComparison.OrdinalIgnoreCase))
		{
			NavIcon.SetLogoKey((DependencyObject)(object)radioButton, "Shopee");
		}
		NavIcon.SetGlyph((DependencyObject)(object)radioButton, "\ue7c3");
		NavIcon.SetAccentColor((DependencyObject)(object)radioButton, P_2);
		radioButton.Checked += delegate
		{
			m_606(P_0.Key);
		};
		return (Radio: radioButton, LabelText: textBlock);
	}

	private void m_611(CustomPlatformEntry P_0)
	{
		if (CustomMessageBox.Confirm(this, "Xóa mục \"" + P_0.Label + "\"? Toàn bộ nick trong mục này sẽ bị xóa vĩnh viễn, không thể khôi phục.", "Xóa mục"))
		{
			if (G == P_0.Key)
			{
				NavFacebookRadio.IsChecked = true;
			}
			if (m_513.TryGetValue(P_0.Key, out PlatformAccountPage value))
			{
				value.DeleteAllDataPermanently();
				m_513.Remove(P_0.Key);
			}
			if (m_514.TryGetValue(P_0.Key, out Border value2))
			{
				RootLayoutGrid.Children.Remove(value2);
				m_514.Remove(P_0.Key);
			}
			if (m_515.TryGetValue(P_0.Key, out RadioButton value3))
			{
				AccountNavPanel.Children.Remove(value3);
				m_515.Remove(P_0.Key);
			}
			UiPreferences uiPreferences = UiPreferences.Load();
			uiPreferences.CustomPlatforms.RemoveAll((CustomPlatformEntry customPlatformEntry) => customPlatformEntry.Key == P_0.Key);
			uiPreferences.Save();
		}
	}

	private void w(object P_0, RoutedEventArgs P_1)
	{
		m_606("Scripts");
		if (ScriptPlatformOverlay != null)
		{
			ScriptPlatformOverlay.Visibility = Visibility.Visible;
		}
	}

	private void X(object P_0, RoutedEventArgs P_1)
	{
		if (ScriptPlatformOverlay != null)
		{
			ScriptPlatformOverlay.Visibility = Visibility.Visible;
		}
	}

	private void x(object P_0, RoutedEventArgs P_1)
	{
		m_612("iPhone");
	}

	private void Y(object P_0, RoutedEventArgs P_1)
	{
		m_612("Android");
	}

	private void y(object P_0, RoutedEventArgs P_1)
	{
		m_612("Chrome");
	}

	private void m_612(string P_0)
	{
		C = P_0;
		m_494 = true;
		ScriptPlatformOverlay.Visibility = Visibility.Collapsed;
		o();
	}

	private void Z(object P_0, RoutedEventArgs P_1)
	{
		ScriptPlatformOverlay.Visibility = Visibility.Collapsed;
		O();
	}

	private void z(object P_0, RoutedEventArgs P_1)
	{
		ScriptTopicOverlay.Visibility = Visibility.Collapsed;
		if (m_494)
		{
			ScriptPlatformOverlay.Visibility = Visibility.Visible;
		}
	}

	private void O()
	{
		switch (c)
		{
		case "Facebook":
			NavFacebookRadio.IsChecked = true;
			return;
		case "Gmail":
			NavGmailRadio.IsChecked = true;
			return;
		case "TikTok":
			NavTikTokRadio.IsChecked = true;
			return;
		case "Shopee":
			NavShopeeRadio.IsChecked = true;
			return;
		case "Hotmail":
			NavHotmailRadio.IsChecked = true;
			return;
		case "Phone":
			NavPhoneRadio.IsChecked = true;
			return;
		case "BaoSamSettings":
			NavBaoSamSettingsRadio.IsChecked = true;
			return;
		case "AiVisionSettings":
			NavAiVisionSettingsRadio.IsChecked = true;
			return;
		case "VerifyMailSettings":
		case "VerifyPhoneSettings":
			NavVerifySettingsRadio.IsChecked = true;
			return;
		}
		if (m_515.TryGetValue(c, out RadioButton value))
		{
			value.IsChecked = true;
		}
		else
		{
			NavFacebookRadio.IsChecked = true;
		}
	}

	private void m_613(object P_0, MouseButtonEventArgs P_1)
	{
		m_494 = false;
		o();
	}

	private void o()
	{
		ScriptTopicPanel.Children.Clear();
		UiPreferences uiPreferences = UiPreferences.Load();
		List<(string, string, string, string)> list = new List<(string, string, string, string)> { ("Facebook", "Nuôi Nick Facebook", "\ue774", "#1877F2") };
		if (!uiPreferences.HiddenBuiltInPlatforms.Contains("Gmail"))
		{
			string item;
			if (!uiPreferences.RenamedBuiltInPlatforms.TryGetValue("Gmail", out string value) || string.IsNullOrWhiteSpace(value))
			{
				item = "Nuôi Nick Gmail";
			}
			else
			{
				item = (value.StartsWith("Quản Lý ", StringComparison.OrdinalIgnoreCase) ? ("Nuôi Nick " + value.Substring(8)) : value);
			}
			list.Add(("Gmail", item, "\ue715", "#EA4335"));
		}
		if (!uiPreferences.HiddenBuiltInPlatforms.Contains("TikTok"))
		{
			string item2;
			if (!uiPreferences.RenamedBuiltInPlatforms.TryGetValue("TikTok", out string value2) || string.IsNullOrWhiteSpace(value2))
			{
				item2 = "Nuôi Nick TikTok";
			}
			else
			{
				item2 = (value2.StartsWith("Quản Lý ", StringComparison.OrdinalIgnoreCase) ? ("Nuôi Nick " + value2.Substring(8)) : value2);
			}
			list.Add(("TikTok", item2, "\ue714", "#EC4899"));
		}
		if (!uiPreferences.HiddenBuiltInPlatforms.Contains("Hotmail"))
		{
			string item3;
			if (!uiPreferences.RenamedBuiltInPlatforms.TryGetValue("Hotmail", out string value3) || string.IsNullOrWhiteSpace(value3))
			{
				item3 = "Nuôi Nick Hotmail";
			}
			else
			{
				item3 = (value3.StartsWith("Quản Lý ", StringComparison.OrdinalIgnoreCase) ? ("Nuôi Nick " + value3.Substring(8)) : value3);
			}
			list.Add(("Hotmail", item3, "\ue715", "#0078D4"));
		}
		if (!uiPreferences.HiddenBuiltInPlatforms.Contains("Shopee"))
		{
			string item4;
			if (!uiPreferences.RenamedBuiltInPlatforms.TryGetValue("Shopee", out string value4) || string.IsNullOrWhiteSpace(value4))
			{
				item4 = "Nuôi Nick Shopee";
			}
			else
			{
				item4 = (value4.StartsWith("Quản Lý ", StringComparison.OrdinalIgnoreCase) ? ("Nuôi Nick " + value4.Substring(8)) : value4);
			}
			list.Add(("Shopee", item4, "\ue719", "#EE4D2D"));
		}
		foreach (CustomPlatformEntry customPlatform in uiPreferences.CustomPlatforms)
		{
			string text = customPlatform.Label;
			if (!text.StartsWith("Nuôi Nick", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Quản Lý", StringComparison.OrdinalIgnoreCase))
			{
				text = "Nuôi Nick " + text;
			}
			else if (text.StartsWith("Quản Lý ", StringComparison.OrdinalIgnoreCase))
			{
				text = "Nuôi Nick " + text.Substring(8);
			}
			list.Add((customPlatform.Key, text, "\ue7c3", "#8C6FF7"));
		}
		foreach (var item9 in list)
		{
			string item5 = item9.Item1;
			string item6 = item9.Item2;
			string item7 = item9.Item3;
			string item8 = item9.Item4;
			Color color = (Color)ColorConverter.ConvertFromString(item8);
			StackPanel stackPanel = new StackPanel
			{
				VerticalAlignment = VerticalAlignment.Center
			};
			stackPanel.Children.Add(new Border
			{
				Width = 60.0,
				Height = 60.0,
				CornerRadius = new CornerRadius(18.0),
				HorizontalAlignment = HorizontalAlignment.Center,
				Background = new SolidColorBrush(color)
				{
					Opacity = 0.2
				},
				BorderBrush = new SolidColorBrush(color),
				BorderThickness = new Thickness(1.0),
				Child = new TextBlock
				{
					Text = item7,
					FontFamily = (FontFamily)FindResource("IconFont"),
					FontSize = 28.0,
					Foreground = new SolidColorBrush(color),
					HorizontalAlignment = HorizontalAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center
				}
			});
			stackPanel.Children.Add(new TextBlock
			{
				Text = item6,
				FontSize = 17.0,
				FontWeight = FontWeights.Bold,
				Foreground = (Brush)FindResource("BrushTextPrimary"),
				HorizontalAlignment = HorizontalAlignment.Center,
				Margin = new Thickness(0.0, 16.0, 0.0, 0.0)
			});
			Button button = new Button
			{
				Style = (Style)FindResource("PlatformCardButtonStyle"),
				Width = 240.0,
				Height = 190.0,
				Margin = new Thickness(0.0, 0.0, 18.0, 18.0),
				Background = new SolidColorBrush(color)
				{
					Opacity = 0.1
				},
				Content = stackPanel
			};
			string A = item5;
			button.Click += delegate
			{
				m_614(A);
			};
			ScriptTopicPanel.Children.Add(button);
		}
		ScriptTopicOverlay.Visibility = Visibility.Visible;
	}

	private void m_614(string P_0)
	{
		b = P_0;
		P();
		ScriptTopicOverlay.Visibility = Visibility.Collapsed;
		m_615(C);
	}

	private void P()
	{
		if (ScriptChuDeText != null)
		{
			ScriptChuDeText.Text = "Chủ đề: " + b;
		}
	}

	private void m_615(string P_0)
	{
		ScriptPlatformIPhoneRadio.Visibility = ((!(P_0 == "iPhone")) ? Visibility.Collapsed : Visibility.Visible);
		ScriptPlatformAndroidRadio.Visibility = ((!(P_0 == "Android")) ? Visibility.Collapsed : Visibility.Visible);
		ScriptPlatformChromeRadio.Visibility = ((!(P_0 == "Chrome")) ? Visibility.Collapsed : Visibility.Visible);
		RadioButton radioButton;
		if (P_0 == "iPhone")
		{
			radioButton = ScriptPlatformIPhoneRadio;
		}
		else
		{
			radioButton = ((!(P_0 == "Chrome")) ? ScriptPlatformAndroidRadio : ScriptPlatformChromeRadio);
		}
		RadioButton radioButton2 = radioButton;
		if (radioButton2.IsChecked == true)
		{
			m_559(radioButton2, new RoutedEventArgs());
		}
		else
		{
			radioButton2.IsChecked = true;
		}
	}

	private void p()
	{
		Q();
	}

	private async Task Q()
	{
		if (PhoneAiDeviceCombo != null)
		{
			string text = PhoneAiDeviceCombo.SelectedItem as string;
			List<string> list = ((!(B == "iPhone")) ? (await GetConnectedDevices()) : (from P_0 in Profiles
				where P_0.OS == "iOS"
				select P_0.Name).ToList());
			List<string> list2 = list;
			PhoneAiDeviceCombo.ItemsSource = list2;
			PhoneAiDeviceCombo.SelectedItem = ((text != null && list2.Contains(text)) ? text : list2.FirstOrDefault());
		}
	}

	private void aA(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://toolregclone.com",
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không mở được trình duyệt: " + ex.Message + "\nTự vào: https://toolregclone.com", "Tải BaoSam Browser", NotifyType.Warning);
		}
	}

	private void aa(object P_0, RoutedEventArgs P_1)
	{
		m_606("BaoSamSettings");
		aD();
	}

	private void aB(object P_0, RoutedEventArgs P_1)
	{
		m_606("AiVisionSettings");
		x();
	}

	private void ab(object P_0, RoutedEventArgs P_1)
	{
		m_616(d);
	}

	private void aC(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is RadioButton radioButton && (string)radioButton.Tag == "Phone")
		{
			m_616("Phone");
		}
		else
		{
			m_616("Mail");
		}
	}

	private void m_616(string P_0)
	{
		d = ((P_0 == "Phone") ? "Phone" : "Mail");
		if (d == "Phone")
		{
			m_606("VerifyPhoneSettings");
			s();
		}
		else
		{
			m_606("VerifyMailSettings");
			R();
		}
		if (VerifyMailSubTabMail != null)
		{
			bool flag = d == "Mail";
			VerifyMailSubTabMail.IsChecked = flag;
			VerifyMailSubTabPhone.IsChecked = !flag;
			VerifyPhoneSubTabMail.IsChecked = flag;
			VerifyPhoneSubTabPhone.IsChecked = !flag;
		}
	}

	private void ac(object P_0, RoutedEventArgs P_1)
	{
		m_617("https://drive.google.com/drive/folders/1dWr_En-Jer9byCptzRx4h5BM2VGfel-7");
	}

	private void m_617(string P_0)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = P_0,
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không mở được trình duyệt: " + ex.Message + "\nTự vào: " + P_0, "Mở link", NotifyType.Warning);
		}
	}

	private void q()
	{
		m_618(VerifyMailProxyTextBox, VerifyMailProxyPlaceholder);
		m_618(VerifyMailDongVanApiKeyTextBox, VerifyMailDongVanApiKeyPlaceholder);
		m_618(VerifyMailDongVanFolderIdTextBox, VerifyMailDongVanFolderIdPlaceholder);
		m_618(VerifyMailOtpTextBox, VerifyMailOtpPlaceholder);
	}

	private static void m_618(TextBox P_0, TextBlock P_1)
	{
		m_722 CS_0024_003C_003E8__locals5 = new m_722();
		CS_0024_003C_003E8__locals5.A = P_1;
		CS_0024_003C_003E8__locals5.m_1108 = P_0;
		CS_0024_003C_003E8__locals5.m_1109();
		CS_0024_003C_003E8__locals5.m_1108.TextChanged += delegate
		{
			CS_0024_003C_003E8__locals5.m_1109();
		};
	}

	private void R()
	{
		VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
		m_628(verifyMailSettings.Provider);
		VerifyMailProxyTextBox.Text = verifyMailSettings.Proxy;
		VerifyMailDongVanApiKeyTextBox.Text = verifyMailSettings.DongVanApiKey;
		VerifyMailDongVanFolderIdTextBox.Text = verifyMailSettings.DongVanFolderId;
		string randomMailStyle = verifyMailSettings.RandomMailStyle;
		RadioButton radioButton;
		if (randomMailStyle == "FromName")
		{
			radioButton = VerifyMailRandomStyleFromNameRadio;
		}
		else
		{
			radioButton = ((!(randomMailStyle == "NameYear")) ? VerifyMailRandomStyleRandomStringRadio : VerifyMailRandomStyleNameYearRadio);
		}
		radioButton.IsChecked = true;
		VerifyMailRandomLowerCheckBox.IsChecked = verifyMailSettings.RandomMailLower;
		VerifyMailRandomDigitsCheckBox.IsChecked = verifyMailSettings.RandomMailDigits;
		VerifyMailRandomMinLengthTextBox.Text = verifyMailSettings.RandomMailMinLength.ToString();
		VerifyMailRandomMaxLengthTextBox.Text = verifyMailSettings.RandomMailMaxLength.ToString();
		VerifyMailRandomDotSeparatorCheckBox.IsChecked = verifyMailSettings.RandomMailDotSeparator;
		VerifyMailRandomAddSuffixCheckBox.IsChecked = verifyMailSettings.RandomMailAddSuffix;
		VerifyMailRandomBirthYearMinTextBox.Text = verifyMailSettings.RandomMailBirthYearMin.ToString();
		VerifyMailRandomBirthYearMaxTextBox.Text = verifyMailSettings.RandomMailBirthYearMax.ToString();
		VerifyMailRandomDomainTextBox.Text = verifyMailSettings.RandomMailDomain;
		r();
	}

	private void r()
	{
		bool valueOrDefault = VerifyMailRandomStyleRandomStringRadio.IsChecked == true;
		bool valueOrDefault2 = VerifyMailRandomStyleNameYearRadio.IsChecked == true;
		VerifyMailRandomStringOptionsPanel.Visibility = ((!valueOrDefault) ? Visibility.Collapsed : Visibility.Visible);
		VerifyMailRandomFromNameOptionsPanel.Visibility = (valueOrDefault ? Visibility.Collapsed : Visibility.Visible);
		VerifyMailRandomBirthYearPanel.Visibility = ((!valueOrDefault2) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void aD(object P_0, RoutedEventArgs P_1)
	{
		if (VerifyMailRandomStringOptionsPanel != null)
		{
			r();
			ad(P_0, P_1);
		}
	}

	private void ad(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
		VerifyMailSettings verifyMailSettings2 = verifyMailSettings;
		string randomMailStyle;
		if (VerifyMailRandomStyleFromNameRadio.IsChecked == true)
		{
			randomMailStyle = "FromName";
		}
		else
		{
			randomMailStyle = ((VerifyMailRandomStyleNameYearRadio.IsChecked == true) ? "NameYear" : "RandomString");
		}
		verifyMailSettings2.RandomMailStyle = randomMailStyle;
		verifyMailSettings.RandomMailLower = VerifyMailRandomLowerCheckBox.IsChecked == true;
		verifyMailSettings.RandomMailDigits = VerifyMailRandomDigitsCheckBox.IsChecked == true;
		if (int.TryParse(VerifyMailRandomMinLengthTextBox.Text.Trim(), out var result))
		{
			verifyMailSettings.RandomMailMinLength = result;
		}
		if (int.TryParse(VerifyMailRandomMaxLengthTextBox.Text.Trim(), out var result2))
		{
			verifyMailSettings.RandomMailMaxLength = result2;
		}
		verifyMailSettings.RandomMailDotSeparator = VerifyMailRandomDotSeparatorCheckBox.IsChecked == true;
		verifyMailSettings.RandomMailAddSuffix = VerifyMailRandomAddSuffixCheckBox.IsChecked == true;
		if (int.TryParse(VerifyMailRandomBirthYearMinTextBox.Text.Trim(), out var result3))
		{
			verifyMailSettings.RandomMailBirthYearMin = result3;
		}
		if (int.TryParse(VerifyMailRandomBirthYearMaxTextBox.Text.Trim(), out var result4))
		{
			verifyMailSettings.RandomMailBirthYearMax = result4;
		}
		verifyMailSettings.RandomMailDomain = VerifyMailRandomDomainTextBox.Text.Trim();
		verifyMailSettings.Save();
	}

	private void aE(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailRandomPreviewTextBox.Text = VerifyMailSettings.Load().BuildRandomMailPreview();
	}

	private void ae(object P_0, RoutedEventArgs P_1)
	{
		m_645(VerifyMailRandomPreviewTextBox.Text, "Mail vừa sinh");
	}

	private void aF(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
		verifyMailSettings.Proxy = VerifyMailProxyTextBox.Text.Trim();
		verifyMailSettings.Save();
	}

	private void af(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
		verifyMailSettings.DongVanApiKey = VerifyMailDongVanApiKeyTextBox.Text.Trim();
		verifyMailSettings.Save();
	}

	private void aG(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
		verifyMailSettings.DongVanFolderId = VerifyMailDongVanFolderIdTextBox.Text.Trim();
		verifyMailSettings.Save();
	}

	private void m_619(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("TenMinuteMail");
	}

	private void m_620(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("TempMailOrg");
	}

	private void m_621(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("Tmailor");
	}

	private void m_622(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("TempMail100");
	}

	private void m_623(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("TempMailIo");
	}

	private void m_624(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("TemporaryMail");
	}

	private void m_625(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("DongVanFb");
	}

	private void m_626(object P_0, MouseButtonEventArgs P_1)
	{
		m_627("Random");
	}

	private void m_627(string P_0)
	{
		VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
		verifyMailSettings.Provider = P_0;
		verifyMailSettings.Save();
		m_628(P_0);
	}

	private void m_628(string P_0)
	{
		(string, Border, UIElement)[] array = new (string, Border, UIElement)[8]
		{
			("TenMinuteMail", VerifyMailProviderTenMinuteMailCard, VerifyMailProviderTenMinuteMailCheck),
			("TempMailOrg", VerifyMailProviderTempMailOrgCard, VerifyMailProviderTempMailOrgCheck),
			("Tmailor", VerifyMailProviderTmailorCard, VerifyMailProviderTmailorCheck),
			("TempMail100", VerifyMailProviderTempMail100Card, VerifyMailProviderTempMail100Check),
			("TempMailIo", VerifyMailProviderTempMailIoCard, VerifyMailProviderTempMailIoCheck),
			("TemporaryMail", VerifyMailProviderTemporaryMailCard, VerifyMailProviderTemporaryMailCheck),
			("DongVanFb", VerifyMailProviderDongVanFbCard, VerifyMailProviderDongVanFbCheck),
			("Random", VerifyMailProviderRandomCard, VerifyMailProviderRandomCheck)
		};
		VerifyMailDongVanFieldsPanel.Visibility = ((!(P_0 == "DongVanFb")) ? Visibility.Collapsed : Visibility.Visible);
		(string, Border, UIElement)[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			(string, Border, UIElement) tuple = array2[i];
			string item = tuple.Item1;
			Border item2 = tuple.Item2;
			UIElement item3 = tuple.Item3;
			bool flag = item == P_0;
			item2.BorderBrush = (Brush)FindResource(flag ? "BrushAccent" : "BrushBorder");
			item3.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private async void ag(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailTryGetMailButton.IsEnabled = false;
		VerifyMailTryGetOtpButton.IsEnabled = false;
		VerifyMailCancelGetMailButton.Visibility = Visibility.Visible;
		VerifyMailCancelGetMailButton.IsEnabled = true;
		VerifyMailOtpTextBox.Text = "";
		m_629("Đang lấy địa chỉ mail...", null);
		if (m_530 is IAsyncDisposable asyncDisposable)
		{
			await asyncDisposable.DisposeAsync();
		}
		m_530 = null;
		m_531 = new CancellationTokenSource();
		CancellationToken token = m_531.Token;
		try
		{
			VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
			IVerifyMailTestClient verifyMailTestClient = verifyMailSettings.CreateClient();
			string text = await verifyMailTestClient.GetNewMailAddressAsync(token);
			m_530 = verifyMailTestClient;
			VerifyMailAddressTextBox.Text = text;
			m_629("✓ Đã lấy được địa chỉ mail: " + text, true);
		}
		catch (OperationCanceledException)
		{
			m_629("Đã huỷ lấy mail.", false);
		}
		catch (Exception ex2)
		{
			m_629("✗ Lỗi khi lấy mail: " + ex2.Message, false);
		}
		finally
		{
			VerifyMailTryGetMailButton.IsEnabled = true;
			VerifyMailTryGetOtpButton.IsEnabled = true;
			VerifyMailCancelGetMailButton.Visibility = Visibility.Collapsed;
			m_531.Dispose();
			m_531 = null;
		}
	}

	private void aH(object P_0, RoutedEventArgs P_1)
	{
		VerifyMailCancelGetMailButton.IsEnabled = false;
		m_629("Đang huỷ...", null);
		m_531?.Cancel();
	}

	private async void ah(object P_0, RoutedEventArgs P_1)
	{
		if (m_530 == null)
		{
			m_629("✗ Chưa có địa chỉ mail nào - bấm \"Thử lấy mail\" trước.", false);
			return;
		}
		VerifyMailTryGetOtpButton.IsEnabled = false;
		m_629("Đang kiểm tra hộp thư...", null);
		try
		{
			string text = await m_530.TryGetOtpAsync();
			if (text != null)
			{
				VerifyMailOtpTextBox.Text = text;
				m_629("✓ Tìm thấy mã: " + text, true);
				CustomMessageBox.Show(this, "Tìm thấy mã OTP: " + text, "Thử lấy OTP");
			}
			else
			{
				VerifyMailOtpTextBox.Text = "";
				m_629("Chưa có mail mới trong hộp thư - thử lại sau vài giây.", false);
			}
		}
		catch (Exception ex)
		{
			m_629("✗ Lỗi khi đọc OTP: " + ex.Message, false);
		}
		finally
		{
			VerifyMailTryGetOtpButton.IsEnabled = true;
		}
	}

	private void aI(object P_0, RoutedEventArgs P_1)
	{
		m_645(VerifyMailOtpTextBox.Text, "Mã OTP");
	}

	private void ai(object P_0, RoutedEventArgs P_1)
	{
		m_645(VerifyMailAddressTextBox.Text, "Địa chỉ mail");
	}

	private void m_629(string P_0, bool? P_1)
	{
		VerifyMailStatusText.Visibility = Visibility.Visible;
		VerifyMailStatusText.Text = P_0;
		TextBlock verifyMailStatusText = VerifyMailStatusText;
		Brush foreground;
		if (P_1.HasValue)
		{
			foreground = ((P_1 != true) ? new SolidColorBrush(Color.FromRgb(239, 68, 68)) : ((Brush)FindResource("BrushGreen")));
		}
		else
		{
			foreground = (Brush)FindResource("BrushTextSecondary");
		}
		verifyMailStatusText.Foreground = foreground;
	}

	private void S()
	{
		m_618(VerifyPhoneCountryTextBox, VerifyPhoneCountryPlaceholder);
		m_618(VerifyPhoneFunOtpApiKeyTextBox, VerifyPhoneFunOtpApiKeyPlaceholder);
		m_618(VerifyPhoneFunOtpServiceTextBox, VerifyPhoneFunOtpServicePlaceholder);
		m_618(VerifyPhoneOtpTextBox, VerifyPhoneOtpPlaceholder);
	}

	private void s()
	{
		VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
		g(verifyPhoneSettings.Provider);
		VerifyPhoneCountryTextBox.Text = verifyPhoneSettings.Country;
		VerifyPhoneFunOtpApiKeyTextBox.Text = verifyPhoneSettings.FunOtpApiKey;
		VerifyPhoneFunOtpServiceTextBox.Text = verifyPhoneSettings.FunOtpService;
		VerifyPhoneRandomInternationalCheckBox.IsChecked = verifyPhoneSettings.RandomInternationalFormat;
		VerifyPhoneRandomViettelCheckBox.IsChecked = verifyPhoneSettings.RandomViettel;
		VerifyPhoneRandomMobifoneCheckBox.IsChecked = verifyPhoneSettings.RandomMobifone;
		VerifyPhoneRandomVinaphoneCheckBox.IsChecked = verifyPhoneSettings.RandomVinaphone;
		VerifyPhoneRandomVietnamobileCheckBox.IsChecked = verifyPhoneSettings.RandomVietnamobile;
		VerifyPhoneRandomGmobileCheckBox.IsChecked = verifyPhoneSettings.RandomGmobile;
		VerifyPhoneRandomCustomPrefixTextBox.Text = verifyPhoneSettings.RandomCustomPrefixes;
	}

	private void aJ(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
		verifyPhoneSettings.RandomInternationalFormat = VerifyPhoneRandomInternationalCheckBox.IsChecked == true;
		verifyPhoneSettings.RandomViettel = VerifyPhoneRandomViettelCheckBox.IsChecked == true;
		verifyPhoneSettings.RandomMobifone = VerifyPhoneRandomMobifoneCheckBox.IsChecked == true;
		verifyPhoneSettings.RandomVinaphone = VerifyPhoneRandomVinaphoneCheckBox.IsChecked == true;
		verifyPhoneSettings.RandomVietnamobile = VerifyPhoneRandomVietnamobileCheckBox.IsChecked == true;
		verifyPhoneSettings.RandomGmobile = VerifyPhoneRandomGmobileCheckBox.IsChecked == true;
		verifyPhoneSettings.RandomCustomPrefixes = VerifyPhoneRandomCustomPrefixTextBox.Text.Trim();
		verifyPhoneSettings.Save();
	}

	private void aj(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneRandomPreviewTextBox.Text = VerifyPhoneSettings.Load().BuildRandomPhonePreview();
	}

	private void aK(object P_0, RoutedEventArgs P_1)
	{
		m_645(VerifyPhoneRandomPreviewTextBox.Text, "Số điện thoại vừa sinh");
	}

	private void ak(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
		verifyPhoneSettings.Country = VerifyPhoneCountryTextBox.Text.Trim();
		verifyPhoneSettings.Save();
	}

	private void aL(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
		verifyPhoneSettings.FunOtpApiKey = VerifyPhoneFunOtpApiKeyTextBox.Text.Trim();
		verifyPhoneSettings.Save();
	}

	private void al(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
		verifyPhoneSettings.FunOtpService = VerifyPhoneFunOtpServiceTextBox.Text.Trim();
		verifyPhoneSettings.Save();
	}

	private void m_630(object P_0, MouseButtonEventArgs P_1)
	{
		m_631("FunOtp");
	}

	private void g(object P_0, MouseButtonEventArgs P_1)
	{
		m_631("Random");
	}

	private void m_631(string P_0)
	{
		VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
		verifyPhoneSettings.Provider = P_0;
		verifyPhoneSettings.Save();
		g(P_0);
	}

	private void g(string P_0)
	{
		(string, Border, UIElement)[] array = new (string, Border, UIElement)[2]
		{
			("FunOtp", VerifyPhoneProviderFunOtpCard, VerifyPhoneProviderFunOtpCheck),
			("Random", VerifyPhoneProviderRandomCard, VerifyPhoneProviderRandomCheck)
		};
		for (int i = 0; i < array.Length; i++)
		{
			(string, Border, UIElement) tuple = array[i];
			string item = tuple.Item1;
			Border item2 = tuple.Item2;
			UIElement item3 = tuple.Item3;
			bool flag = item == P_0;
			item2.BorderBrush = (Brush)FindResource(flag ? "BrushAccent" : "BrushBorder");
			item3.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private async void aM(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneTryGetNumberButton.IsEnabled = false;
		VerifyPhoneTryGetOtpButton.IsEnabled = false;
		VerifyPhoneCancelGetNumberButton.Visibility = Visibility.Visible;
		VerifyPhoneCancelGetNumberButton.IsEnabled = true;
		VerifyPhoneOtpTextBox.Text = "";
		m_632("Đang mua số điện thoại...", null);
		m_532 = null;
		m_533 = new CancellationTokenSource();
		CancellationToken token = m_533.Token;
		try
		{
			VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
			IVerifyPhoneTestClient verifyPhoneTestClient = verifyPhoneSettings.CreateClient();
			string text = await verifyPhoneTestClient.GetNewPhoneNumberAsync(token);
			m_532 = verifyPhoneTestClient;
			VerifyPhoneNumberTextBox.Text = text;
			m_632("✓ Đã mua được số: " + text, true);
		}
		catch (OperationCanceledException)
		{
			m_632("Đã huỷ lấy số.", false);
		}
		catch (Exception ex2)
		{
			m_632("✗ Lỗi khi lấy số: " + ex2.Message, false);
		}
		finally
		{
			VerifyPhoneTryGetNumberButton.IsEnabled = true;
			VerifyPhoneTryGetOtpButton.IsEnabled = true;
			VerifyPhoneCancelGetNumberButton.Visibility = Visibility.Collapsed;
			m_533.Dispose();
			m_533 = null;
		}
	}

	private void am(object P_0, RoutedEventArgs P_1)
	{
		VerifyPhoneCancelGetNumberButton.IsEnabled = false;
		m_632("Đang huỷ...", null);
		m_533?.Cancel();
	}

	private async void aN(object P_0, RoutedEventArgs P_1)
	{
		if (m_532 == null)
		{
			m_632("✗ Chưa có số điện thoại nào - bấm \"Thử lấy số\" trước.", false);
			return;
		}
		VerifyPhoneTryGetOtpButton.IsEnabled = false;
		m_632("Đang kiểm tra tin nhắn...", null);
		try
		{
			string text = await m_532.TryGetOtpAsync();
			if (text != null)
			{
				VerifyPhoneOtpTextBox.Text = text;
				m_632("✓ Tìm thấy mã: " + text, true);
				CustomMessageBox.Show(this, "Tìm thấy mã OTP: " + text, "Thử lấy OTP");
			}
			else
			{
				VerifyPhoneOtpTextBox.Text = "";
				m_632("Chưa có tin nhắn mới - thử lại sau vài giây.", false);
			}
		}
		catch (Exception ex)
		{
			m_632("✗ Lỗi khi đọc OTP: " + ex.Message, false);
		}
		finally
		{
			VerifyPhoneTryGetOtpButton.IsEnabled = true;
		}
	}

	private void an(object P_0, RoutedEventArgs P_1)
	{
		m_645(VerifyPhoneOtpTextBox.Text, "Mã OTP");
	}

	private void aO(object P_0, RoutedEventArgs P_1)
	{
		m_645(VerifyPhoneNumberTextBox.Text, "Số điện thoại");
	}

	private void m_632(string P_0, bool? P_1)
	{
		VerifyPhoneStatusText.Visibility = Visibility.Visible;
		VerifyPhoneStatusText.Text = P_0;
		TextBlock verifyPhoneStatusText = VerifyPhoneStatusText;
		Brush foreground;
		if (P_1.HasValue)
		{
			foreground = ((P_1 != true) ? new SolidColorBrush(Color.FromRgb(239, 68, 68)) : ((Brush)FindResource("BrushGreen")));
		}
		else
		{
			foreground = (Brush)FindResource("BrushTextSecondary");
		}
		verifyPhoneStatusText.Foreground = foreground;
	}

	private void ao(object P_0, RoutedEventArgs P_1)
	{
		ImportFacebookWindow importFacebookWindow = new ImportFacebookWindow
		{
			Owner = this
		};
		if (importFacebookWindow.ShowDialog() != true)
		{
			return;
		}
		bool flag = m_502 == -1 || m_502 == -2;
		int A = ((!flag) ? m_502 : (Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.IsSystem && nickFolder.Id > 0)?.Id ?? (-1)));
		int num = Facebooks.Count + 1;
		foreach (FacebookAccountRow importedAccount in importFacebookWindow.ImportedAccounts)
		{
			importedAccount.Index = num++;
			importedAccount.FolderId = A;
		}
		m_583(importFacebookWindow.ImportedAccounts);
		T();
		g();
		H();
		string text = Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == A)?.Name;
		if (text != null)
		{
			m_635(A, text);
		}
	}

	private bool m_633(GoogleSheetsSyncSettings P_0)
	{
		if (P_0.Enabled && !string.IsNullOrWhiteSpace(P_0.SpreadsheetId) && !string.IsNullOrWhiteSpace(P_0.ClientId))
		{
			return !string.IsNullOrWhiteSpace(P_0.ClientSecret);
		}
		return false;
	}

	private void m_634(Func<SheetsService, GoogleSheetsSyncSettings, Task> P_0)
	{
		GoogleSheetsSyncSettings A = GoogleSheetsSyncSettings.Load();
		if (!m_633(A))
		{
			return;
		}
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				using SheetsService arg = await GoogleSheetsSyncService.AuthorizeAsync(A, CancellationToken.None);
				await P_0(arg, A);
			}
			catch (Exception ex)
			{
				Exception ex2 = ex;
				Exception A2 = ex2;
				((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
				{
					CustomMessageBox.Show(this, "Đồng bộ Google Sheets thất bại: " + A2.Message, "Đồng bộ Google Sheets", NotifyType.Warning);
				}));
			}
		});
	}

	private void m_635(int P_0, string P_1)
	{
		List<FacebookAccountRow> m_1124 = Facebooks.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.FolderId == P_0).ToList();
		m_634((SheetsService service, GoogleSheetsSyncSettings googleSheetsSyncSettings) => GoogleSheetsSyncService.SyncFolderAsync(service, googleSheetsSyncSettings.SpreadsheetId, P_1, GoogleSheetsSyncService.BuildRows(m_1124), CancellationToken.None));
	}

	private void H(string P_0)
	{
		m_634((SheetsService service, GoogleSheetsSyncSettings googleSheetsSyncSettings) => GoogleSheetsSyncService.DeleteFolderSheetAsync(service, googleSheetsSyncSettings.SpreadsheetId, P_0, CancellationToken.None));
	}

	private void m_636(string P_0, string P_1)
	{
		m_634((SheetsService service, GoogleSheetsSyncSettings googleSheetsSyncSettings) => GoogleSheetsSyncService.RenameFolderSheetAsync(service, googleSheetsSyncSettings.SpreadsheetId, P_0, P_1, CancellationToken.None));
	}

	private void T()
	{
		ICollectionView? val = m_501;
		if (val != null)
		{
			((Collection<SortDescription>)(object)val.SortDescriptions).Clear();
		}
		foreach (DataGridColumn column in FacebookGrid.Columns)
		{
			column.SortDirection = null;
		}
	}

	private void aP(object P_0, RoutedEventArgs P_1)
	{
		if (ColumnTogglePanel.Children.Count == 0)
		{
			foreach (DataGridColumn A in FacebookGrid.Columns)
			{
				CheckBox checkBox = new CheckBox
				{
					IsChecked = (A.Visibility == Visibility.Visible),
					VerticalAlignment = VerticalAlignment.Center
				};
				checkBox.Checked += delegate
				{
					A.Visibility = Visibility.Visible;
					t();
				};
				checkBox.Unchecked += delegate
				{
					A.Visibility = Visibility.Collapsed;
					t();
				};
				TextBlock element = new TextBlock
				{
					Text = A.Header?.ToString(),
					Margin = new Thickness(8.0, 0.0, 0.0, 0.0),
					VerticalAlignment = VerticalAlignment.Center
				};
				StackPanel stackPanel = new StackPanel
				{
					Orientation = Orientation.Horizontal,
					Margin = new Thickness(6.0, 4.0, 6.0, 4.0)
				};
				stackPanel.Children.Add(checkBox);
				stackPanel.Children.Add(element);
				ColumnTogglePanel.Children.Add(stackPanel);
			}
		}
		m_638(ColumnConfigPopup, P_0, ColumnConfigButton);
	}

	private static bool m_637(UIElement? P_0)
	{
		if (P_0 is FrameworkElement frameworkElement && P_0.IsVisible)
		{
			return frameworkElement.IsLoaded;
		}
		return false;
	}

	private void m_638(Popup popup, object? P_1, UIElement? P_2 = null)
	{
		bool A = P_1 != null && P_1 == P_2 && m_637(P_2);
		popup.IsOpen = false;
		((DispatcherObject)this).Dispatcher.BeginInvoke((Delegate)(Action)(() =>
		{
			if (A && P_2 != null)
			{
				popup.Placement = PlacementMode.Bottom;
				popup.PlacementTarget = P_2;
			}
			else
			{
				popup.Placement = PlacementMode.Center;
				popup.PlacementTarget = this;
			}
			popup.IsOpen = true;
		}), (DispatcherPriority)4, Array.Empty<object>());
	}

	private void t()
	{
		try
		{
			List<string> value = (from P_0 in FacebookGrid.Columns
				where P_0.Visibility != Visibility.Visible
				select P_0.Header?.ToString() ?? "" into P_0
				where P_0.Length > 0
				select P_0).ToList();
			Directory.CreateDirectory(Path.GetDirectoryName(E));
			File.WriteAllText(E, JsonSerializer.Serialize(value));
		}
		catch
		{
		}
	}

	private void U()
	{
		try
		{
			if (!File.Exists(E))
			{
				foreach (DataGridColumn column in FacebookGrid.Columns)
				{
					string item = column.Header?.ToString() ?? "";
					column.Visibility = ((!m_534.Contains(item)) ? Visibility.Collapsed : Visibility.Visible);
				}
				return;
			}
			List<string> list = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(E));
			if (list == null)
			{
				return;
			}
			foreach (DataGridColumn column2 in FacebookGrid.Columns)
			{
				string item2 = column2.Header?.ToString() ?? "";
				column2.Visibility = (list.Contains(item2) ? Visibility.Collapsed : Visibility.Visible);
			}
		}
		catch
		{
		}
	}

	private void m_639(object P_0, DataGridColumnEventArgs P_1)
	{
		u();
	}

	private void u()
	{
		try
		{
			List<string> value = (from P_0 in FacebookGrid.Columns
				orderby P_0.DisplayIndex
				select P_0.Header?.ToString() ?? "" into P_0
				where P_0.Length > 0
				select P_0).ToList();
			Directory.CreateDirectory(Path.GetDirectoryName(e));
			File.WriteAllText(e, JsonSerializer.Serialize(value));
		}
		catch
		{
		}
	}

	private static List<string> m_640(List<string> P_0)
	{
		UiPreferences uiPreferences = UiPreferences.Load();
		if (uiPreferences.HoTenColumnNextToPassV1)
		{
			return P_0;
		}
		uiPreferences.HoTenColumnNextToPassV1 = true;
		uiPreferences.Save();
		if (P_0.IndexOf("PASS") < 0 || !P_0.Remove("HỌ TÊN"))
		{
			return P_0;
		}
		P_0.Insert(P_0.IndexOf("PASS") + 1, "HỌ TÊN");
		try
		{
			File.WriteAllText(e, JsonSerializer.Serialize(P_0));
		}
		catch
		{
		}
		return P_0;
	}

	private void V()
	{
		try
		{
			if (!File.Exists(e))
			{
				return;
			}
			List<string> list = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(e));
			if (list == null || list.Count == 0)
			{
				return;
			}
			list = m_640(list);
			int num = 0;
			foreach (string A in list)
			{
				DataGridColumn dataGridColumn = FacebookGrid.Columns.FirstOrDefault((DataGridColumn P_0) => (P_0.Header?.ToString() ?? "") == A);
				if (dataGridColumn != null)
				{
					int val = FacebookGrid.Columns.Count - 1;
					dataGridColumn.DisplayIndex = Math.Min(num, val);
					num++;
				}
			}
		}
		catch
		{
		}
	}

	private void ap(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Copy", NotifyType.Warning);
			return;
		}
		FacebookAccountRow A = list[0];
		List<string> list2 = CopyColumnsWindow.Show(this, m_535.Select(((string Header, Func<FacebookAccountRow, string> Getter) tuple) => tuple.Header).ToArray(), m_536, list.Count, (string text) => m_535.First(((string Header, Func<FacebookAccountRow, string> Getter) tuple) => tuple.Header == text).Getter(A));
		if (list2 == null)
		{
			return;
		}
		m_536 = list2.ToHashSet();
		v();
		List<(string, Func<FacebookAccountRow, string>)> list3 = m_535.Where(((string Header, Func<FacebookAccountRow, string> Getter) tuple) => m_536.Contains(tuple.Header)).ToList();
		StringBuilder stringBuilder = new StringBuilder();
		foreach (FacebookAccountRow A2 in list)
		{
			stringBuilder.AppendLine(string.Join("|", list3.Select(((string Header, Func<FacebookAccountRow, string> Getter) tuple) => tuple.Getter(A2))));
		}
		try
		{
			Clipboard.SetText(stringBuilder.ToString());
			CustomMessageBox.Show(this, $"Đã copy {list.Count} nick ({list3.Count} cột) vào clipboard.", "Copy");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể copy: " + ex.Message, "Copy", NotifyType.Warning);
		}
	}

	private void v()
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(F));
			File.WriteAllText(F, JsonSerializer.Serialize(m_536.ToList()));
		}
		catch
		{
		}
	}

	private void W()
	{
		try
		{
			if (File.Exists(F))
			{
				List<string> list = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(F));
				if (list != null)
				{
					m_536 = list.ToHashSet();
				}
			}
		}
		catch
		{
		}
	}

	private void aQ(object P_0, RoutedEventArgs P_1)
	{
		BulkUpdateWindow bulkUpdateWindow = new BulkUpdateWindow(Facebooks.Select((FacebookAccountRow facebookAccountRow2) => facebookAccountRow2.Uid))
		{
			Owner = this
		};
		if (bulkUpdateWindow.ShowDialog() != true)
		{
			return;
		}
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		foreach (var entry in bulkUpdateWindow.Entries)
		{
			string A = entry.Uid;
			Dictionary<string, string> item = entry.Fields;
			FacebookAccountRow facebookAccountRow = Facebooks.FirstOrDefault((FacebookAccountRow facebookAccountRow2) => facebookAccountRow2.Uid == A);
			if (facebookAccountRow == null)
			{
				num3++;
				continue;
			}
			foreach (var (key, arg) in item)
			{
				if (m_537.TryGetValue(key, out Action<FacebookAccountRow, string> value))
				{
					value(facebookAccountRow, arg);
					num2++;
				}
			}
			num++;
		}
		string text3 = $"Đã cập nhật {num} nick ({num2} trường).";
		if (num3 > 0)
		{
			text3 += $"\n{num3} UID không tìm thấy trong danh sách.";
		}
		CustomMessageBox.Show(this, text3, "Cập nhật hàng loạt", (num3 > 0) ? NotifyType.Warning : NotifyType.Success);
	}

	private void aq(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào để gán proxy.", "Thêm Proxy", NotifyType.Warning);
			return;
		}
		AddProxyWindow addProxyWindow = new AddProxyWindow
		{
			Owner = this
		};
		if (addProxyWindow.ShowDialog() != true)
		{
			return;
		}
		List<string> parsedProxies = addProxyWindow.ParsedProxies;
		if (parsedProxies.Count != 0)
		{
			for (int i = 0; i < list.Count; i++)
			{
				list[i].Proxy = parsedProxies[i % parsedProxies.Count];
			}
			CustomMessageBox.Show(this, $"Đã gán proxy cho {list.Count} nick từ {parsedProxies.Count} proxy nhập vào.", "Thêm Proxy");
		}
	}

	private void aR(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào để xóa proxy.", "Xóa Proxy", NotifyType.Warning);
		}
		else
		{
			if (!CustomMessageBox.Confirm(this, $"Xóa proxy khỏi {list.Count} nick đã chọn?", "Xóa Proxy"))
			{
				return;
			}
			foreach (FacebookAccountRow item in list)
			{
				item.Proxy = "";
			}
			CustomMessageBox.Show(this, $"Đã xóa proxy khỏi {list.Count} nick.", "Xóa Proxy");
		}
	}

	private void ar(object P_0, RoutedEventArgs P_1)
	{
		string text = PromptDialog.Show(this, "Tạo thư mục kịch bản", "Tên thư mục kịch bản:");
		if (string.IsNullOrWhiteSpace(text))
		{
			return;
		}
		try
		{
			ScriptItem scriptItem = FacebookAccountDatabase.CreateScriptFolder(text.Trim(), B, b);
			Scripts.Add(scriptItem);
			m_564();
			ScriptFolderGrid.SelectedItem = scriptItem;
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể tạo thư mục kịch bản: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void m_641(object P_0, SelectionChangedEventArgs P_1)
	{
		m_491 = ScriptFolderGrid.SelectedItem as ScriptItem;
		m_566();
		w();
		aa();
	}

	private void w()
	{
		m_495.Clear();
		if (m_491 != null)
		{
			foreach (AiVisionFlowStep step in AiVisionFlowStore.Deserialize(m_491.AiVisionFlowJson).Steps)
			{
				m_495.Add(step);
			}
		}
		if (PhoneAiFolderNameText != null)
		{
			PhoneAiFolderNameText.Text = ((m_491 != null) ? ("Thư mục: " + m_491.Name) : "Chưa chọn thư mục kịch bản");
		}
		X();
	}

	private void X()
	{
		if (PhoneAiStepCountText != null && PhoneAiEmptyStepsText != null)
		{
			PhoneAiStepCountText.Text = $"{m_495.Count} bước";
			PhoneAiEmptyStepsText.Visibility = ((m_495.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void aS(object P_0, RoutedEventArgs P_1)
	{
		m_643(new AiVisionFlowStep
		{
			Type = AiVisionStepType.AiGoal
		});
	}

	private void m_642(object P_0, RoutedEventArgs P_1)
	{
		m_643(new AiVisionFlowStep
		{
			Type = AiVisionStepType.RandomWait
		});
	}

	private bool m_643(AiVisionFlowStep P_0)
	{
		if (m_491 == null)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào ở bên trái.", "Kịch bản AI Vision", NotifyType.Warning);
			return false;
		}
		m_495.Add(P_0);
		X();
		return true;
	}

	private void aT(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			int num = m_495.IndexOf(item);
			if (num > 0)
			{
				m_495.Move(num, num - 1);
			}
		}
	}

	private void at(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			int num = m_495.IndexOf(item);
			if (num >= 0 && num < m_495.Count - 1)
			{
				m_495.Move(num, num + 1);
			}
		}
	}

	private void aU(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			m_495.Remove(item);
			X();
		}
	}

	private void au(object P_0, RoutedEventArgs P_1)
	{
		NavAiVisionSettingsRadio.IsChecked = true;
	}

	private void x()
	{
		m_538 = true;
		AiVisionSettings aiVisionSettings = AiVisionSettings.Load();
		m_539 = aiVisionSettings.SavedCustomProviders;
		h(null);
		m_540.Clear();
		foreach (string priorityTarget in aiVisionSettings.PriorityTargets)
		{
			m_540.Add(new PriorityTargetDisplay
			{
				TargetId = priorityTarget,
				DisplayName = I(priorityTarget)
			});
		}
		z();
		aA();
		Z();
		AiVisionApiKeyBox.Password = aiVisionSettings.ApiKey;
		AiVisionModelTextBox.Text = aiVisionSettings.Model;
		AiVisionGoogleApiKeyBox.Password = aiVisionSettings.GoogleApiKey;
		AiVisionGoogleModelTextBox.Text = aiVisionSettings.GoogleModel;
		AiVisionHHTechApiKeyBox.Password = aiVisionSettings.HHTechApiKey;
		AiVisionHHTechModelTextBox.Text = aiVisionSettings.HHTechModel;
		AiVisionVietApiKeyBox.Password = aiVisionSettings.VietApiKey;
		AiVisionVietApiModelTextBox.Text = aiVisionSettings.VietApiModel;
		AiVisionCustomUrlTextBox.Text = aiVisionSettings.CustomApiUrl;
		AiVisionCustomApiKeyBox.Password = aiVisionSettings.CustomApiKey;
		AiVisionCustomModelTextBox.Text = aiVisionSettings.CustomModel;
		AiVisionCustomFormatAnthropicRadio.IsChecked = aiVisionSettings.CustomFormat == "Anthropic";
		AiVisionCustomFormatOpenAiRadio.IsChecked = aiVisionSettings.CustomFormat != "Anthropic";
		y();
		AiVisionStepDelayTextBox.Text = aiVisionSettings.StepDelayMs.ToString();
		AiVisionMaxConcurrentTextBox.Text = aiVisionSettings.MaxConcurrentDevices.ToString();
		AiVisionPoolRetryAttemptsTextBox.Text = aiVisionSettings.PoolMatchRetryAttempts.ToString();
		AiVisionPoolRetryDelayTextBox.Text = aiVisionSettings.PoolMatchRetryDelayMs.ToString();
		AiVisionSendScreenshotCheck.IsChecked = aiVisionSettings.SendScreenshot;
		m_538 = false;
		m_648(from P_0 in m_540
			where P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal)
			select P_0.TargetId.Substring("CliProxy:".Length));
	}

	private void Y()
	{
		int.TryParse(AiVisionStepDelayTextBox.Text, out var result);
		int.TryParse(AiVisionMaxConcurrentTextBox.Text, out var result2);
		int.TryParse(AiVisionPoolRetryAttemptsTextBox.Text, out var result3);
		int.TryParse(AiVisionPoolRetryDelayTextBox.Text, out var result4);
		int num = ((result4 < 0) ? 900 : result4);
		if (num > 0 && num <= 100)
		{
			num *= 1000;
		}
		AiVisionSettings aiVisionSettings = new AiVisionSettings();
		aiVisionSettings.Provider = ((m_540.Count > 0) ? m_540[0].TargetId : "Claude");
		aiVisionSettings.PriorityTargets = m_540.Select((PriorityTargetDisplay P_0) => P_0.TargetId).ToList();
		aiVisionSettings.ApiKey = AiVisionApiKeyBox.Password.Trim();
		aiVisionSettings.Model = (string.IsNullOrWhiteSpace(AiVisionModelTextBox.Text) ? "claude-sonnet-4-5" : AiVisionModelTextBox.Text.Trim());
		aiVisionSettings.GoogleApiKey = AiVisionGoogleApiKeyBox.Password.Trim();
		aiVisionSettings.GoogleModel = (string.IsNullOrWhiteSpace(AiVisionGoogleModelTextBox.Text) ? "gemini-flash-latest" : AiVisionGoogleModelTextBox.Text.Trim());
		aiVisionSettings.HHTechApiKey = AiVisionHHTechApiKeyBox.Password.Trim();
		aiVisionSettings.HHTechModel = (string.IsNullOrWhiteSpace(AiVisionHHTechModelTextBox.Text) ? "claude-sonnet-5" : AiVisionHHTechModelTextBox.Text.Trim());
		aiVisionSettings.VietApiKey = AiVisionVietApiKeyBox.Password.Trim();
		aiVisionSettings.VietApiModel = (string.IsNullOrWhiteSpace(AiVisionVietApiModelTextBox.Text) ? "kimi-k2.6" : AiVisionVietApiModelTextBox.Text.Trim());
		aiVisionSettings.CustomApiUrl = AiVisionCustomUrlTextBox.Text.Trim();
		aiVisionSettings.CustomApiKey = AiVisionCustomApiKeyBox.Password.Trim();
		aiVisionSettings.CustomModel = AiVisionCustomModelTextBox.Text.Trim();
		aiVisionSettings.CustomFormat = ((AiVisionCustomFormatAnthropicRadio.IsChecked == true) ? "Anthropic" : "OpenAI");
		aiVisionSettings.StepDelayMs = ((result < 0) ? 900 : result);
		aiVisionSettings.MaxConcurrentDevices = ((result2 < 1) ? 5 : result2);
		aiVisionSettings.PoolMatchRetryAttempts = ((result3 < 1) ? 4 : result3);
		aiVisionSettings.PoolMatchRetryDelayMs = num;
		aiVisionSettings.SendScreenshot = AiVisionSendScreenshotCheck.IsChecked == true;
		aiVisionSettings.SavedCustomProviders = m_539;
		aiVisionSettings.Save();
	}

	private void h(string? P_0)
	{
		AiVisionCustomSavedCombo.ItemsSource = m_539.Select((CustomAiProvider customAiProvider) => customAiProvider.Name).ToList();
		AiVisionCustomSavedCombo.SelectedItem = ((P_0 != null && m_539.Any((CustomAiProvider customAiProvider) => customAiProvider.Name == P_0)) ? P_0 : null);
	}

	private void aV(object P_0, RoutedEventArgs P_1)
	{
		string A = AiVisionCustomNameTextBox.Text.Trim();
		if (string.IsNullOrWhiteSpace(A))
		{
			CustomMessageBox.Show(this, "Đặt tên cho cấu hình trước khi lưu.", "Lưu cấu hình", NotifyType.Warning);
			return;
		}
		CustomAiProvider customAiProvider = new CustomAiProvider
		{
			Name = A,
			ApiUrl = AiVisionCustomUrlTextBox.Text.Trim(),
			ApiKey = AiVisionCustomApiKeyBox.Password.Trim(),
			Model = AiVisionCustomModelTextBox.Text.Trim(),
			Format = ((AiVisionCustomFormatAnthropicRadio.IsChecked == true) ? "Anthropic" : "OpenAI")
		};
		int num = m_539.FindIndex((CustomAiProvider customAiProvider2) => string.Equals(customAiProvider2.Name, A, StringComparison.OrdinalIgnoreCase));
		if (num >= 0)
		{
			m_539[num] = customAiProvider;
		}
		else
		{
			m_539.Add(customAiProvider);
		}
		Y();
		h(A);
		CustomMessageBox.Show(this, "Đã lưu cấu hình \"" + A + "\".", "Lưu cấu hình");
	}

	private void m_644(object P_0, SelectionChangedEventArgs P_1)
	{
		if (m_538)
		{
			return;
		}
		object selectedItem = AiVisionCustomSavedCombo.SelectedItem;
		string A = selectedItem as string;
		if (A != null)
		{
			CustomAiProvider customAiProvider = m_539.FirstOrDefault((CustomAiProvider customAiProvider2) => customAiProvider2.Name == A);
			if (customAiProvider != null)
			{
				AiVisionCustomNameTextBox.Text = customAiProvider.Name;
				AiVisionCustomUrlTextBox.Text = customAiProvider.ApiUrl;
				AiVisionCustomApiKeyBox.Password = customAiProvider.ApiKey;
				AiVisionCustomModelTextBox.Text = customAiProvider.Model;
				AiVisionCustomFormatAnthropicRadio.IsChecked = customAiProvider.Format == "Anthropic";
				AiVisionCustomFormatOpenAiRadio.IsChecked = customAiProvider.Format != "Anthropic";
				Y();
			}
		}
	}

	private void av(object P_0, RoutedEventArgs P_1)
	{
		object selectedItem = AiVisionCustomSavedCombo.SelectedItem;
		string A = selectedItem as string;
		if (A == null)
		{
			CustomMessageBox.Show(this, "Chưa chọn cấu hình nào để xoá.", "Xoá cấu hình", NotifyType.Warning);
		}
		else if (CustomMessageBox.Confirm(this, "Xoá cấu hình \"" + A + "\"?", "Xoá cấu hình"))
		{
			m_539.RemoveAll((CustomAiProvider customAiProvider) => customAiProvider.Name == A);
			Y();
			h(null);
		}
	}

	private void aW(object P_0, RoutedEventArgs P_1)
	{
		if (!m_538)
		{
			Y();
		}
	}

	private void aw(object P_0, RoutedEventArgs P_1)
	{
		if (!m_538)
		{
			Y();
		}
	}

	private void aX(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.Tag is string text)
		{
			string[] array = text.Split('|', 2);
			if (array.Length == 2)
			{
				CustomMessageBox.Show(this, array[1], array[0]);
			}
		}
	}

	private void H(object P_0, MouseButtonEventArgs P_1)
	{
		bool flag = AiVisionProviderSelectionPanel.Visibility != Visibility.Visible;
		AiVisionProviderSelectionPanel.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		AiVisionProviderToggleChevron.Text = (flag ? "\ue70e" : "\ue70d");
	}

	private async void ax(object P_0, RoutedEventArgs P_1)
	{
		await m_649("Claude", AiVisionApiKeyBox.Password, AiVisionModelTextBox.Text, AiVisionClaudeTestButton, AiVisionClaudeTestResultText);
	}

	private async void aY(object P_0, RoutedEventArgs P_1)
	{
		await m_649("HHTechApi", AiVisionHHTechApiKeyBox.Password, AiVisionHHTechModelTextBox.Text, AiVisionHHTechTestButton, AiVisionHHTechTestResultText);
	}

	private async void ay(object P_0, RoutedEventArgs P_1)
	{
		await m_649("Gemini", AiVisionGoogleApiKeyBox.Password, AiVisionGoogleModelTextBox.Text, AiVisionGeminiTestButton, AiVisionGeminiTestResultText);
	}

	private async void aZ(object P_0, RoutedEventArgs P_1)
	{
		await m_649("VietApi", AiVisionVietApiKeyBox.Password, AiVisionVietApiModelTextBox.Text, AiVisionVietApiTestButton, AiVisionVietApiTestResultText);
	}

	private async void az(object P_0, RoutedEventArgs P_1)
	{
		await m_649("Custom", AiVisionCustomApiKeyBox.Password, AiVisionCustomModelTextBox.Text, AiVisionCustomTestButton, AiVisionCustomTestResultText, AiVisionCustomUrlTextBox.Text.Trim(), (AiVisionCustomFormatAnthropicRadio.IsChecked == true) ? "Anthropic" : "OpenAI");
	}

	private async void BA(object P_0, RoutedEventArgs P_1)
	{
		string text = m_540.FirstOrDefault((PriorityTargetDisplay priorityTargetDisplay) => priorityTargetDisplay.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal))?.TargetId.Substring("CliProxy:".Length) ?? "";
		if (!(await m_649("GeminiAntigravity", CliProxyApiController.GetLocalApiKey(), text, AiVisionCliProxyTestButton, AiVisionCliProxyTestResultText)))
		{
			AiVisionCliProxyDetailsPanel.Visibility = Visibility.Collapsed;
			return;
		}
		string text2 = $"http://127.0.0.1:{8391}/v1";
		string localApiKey = CliProxyApiController.GetLocalApiKey();
		string value = (string.IsNullOrWhiteSpace(text) ? "<model>" : text);
		AiVisionCliProxyBaseUrlText.Text = text2;
		AiVisionCliProxyKeyText.Text = localApiKey;
		AiVisionCliProxyCurlText.Text = $"curl {text2}/chat/completions -H \"Authorization: Bearer {localApiKey}\" -H \"Content-Type: application/json\" -d \"{{\\\"model\\\":\\\"{value}\\\",\\\"messages\\\":[{{\\\"role\\\":\\\"user\\\",\\\"content\\\":\\\"hi\\\"}}]}}\"";
		AiVisionCliProxyDetailsPanel.Visibility = Visibility.Visible;
	}

	private void Ba(object P_0, RoutedEventArgs P_1)
	{
		m_645(AiVisionCliProxyBaseUrlText.Text, "Base URL");
	}

	private void BB(object P_0, RoutedEventArgs P_1)
	{
		m_645(AiVisionCliProxyKeyText.Text, "API Key");
	}

	private void Bb(object P_0, RoutedEventArgs P_1)
	{
		m_645(AiVisionCliProxyCurlText.Text, "Lệnh curl");
	}

	private void m_645(string P_0, string P_1)
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return;
		}
		try
		{
			Clipboard.SetText(P_0);
			CustomMessageBox.Show(this, "Đã copy " + P_1 + " vào clipboard.", P_1);
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không copy được: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void y()
	{
		AiVisionCliProxyAccountsPanel.Children.Clear();
		if (!CliProxyApiController.IsExeAvailable)
		{
			AiVisionCliProxyStatusText.Text = "⚠ Thiếu file cần thiết cho mục này trong thư mục cài đặt của app - liên hệ hỗ trợ.";
			AiVisionCliProxyStatusText.Foreground = (Brush)FindResource("BrushYellow");
			return;
		}
		List<string> list = CliProxyApiController.ListLoggedInAccounts();
		List<string> list2 = CliProxyApiController.ListClaudeAccounts();
		if (list.Count == 0 && list2.Count == 0)
		{
			AiVisionCliProxyStatusText.Text = "Chưa đăng nhập tài khoản nào - bấm \"Đăng nhập Google (Antigravity)\" hoặc \"Đăng nhập Claude\" bên trên.";
			AiVisionCliProxyStatusText.Foreground = (Brush)FindResource("BrushTextSecondary");
			return;
		}
		AiVisionCliProxyStatusText.Text = "✓ Đã đăng nhập:";
		AiVisionCliProxyStatusText.Foreground = (Brush)FindResource("BrushGreen");
		foreach (string item in list)
		{
			AiVisionCliProxyAccountsPanel.Children.Add(m_646("Google", item));
		}
		foreach (string item2 in list2)
		{
			AiVisionCliProxyAccountsPanel.Children.Add(m_646("Claude", item2));
		}
	}

	private Border m_646(string P_0, string P_1)
	{
		StackPanel stackPanel = new StackPanel
		{
			Orientation = Orientation.Horizontal
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = P_0 + ": " + P_1,
			FontSize = 11.5,
			Foreground = (Brush)FindResource("BrushTextPrimary"),
			VerticalAlignment = VerticalAlignment.Center
		});
		Button button = new Button
		{
			Content = "✕",
			Tag = (P_0, P_1),
			Background = Brushes.Transparent,
			BorderThickness = new Thickness(0.0),
			Foreground = (Brush)FindResource("BrushTextMuted"),
			FontSize = 11.0,
			Padding = new Thickness(6.0, 0.0, 0.0, 0.0),
			Cursor = Cursors.Hand,
			ToolTip = "Đăng xuất " + P_0 + ": " + P_1
		};
		button.Click += BC;
		stackPanel.Children.Add(button);
		return new Border
		{
			Background = (Brush)FindResource("BrushCard"),
			BorderBrush = (Brush)FindResource("BrushBorderLight"),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(10.0),
			Padding = new Thickness(10.0, 4.0, 6.0, 4.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0),
			Child = stackPanel
		};
	}

	private void BC(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.Tag is not System.ValueTuple<string, string> tuple)
		{
			return;
		}
		string text = tuple.Item1;
		string text2 = tuple.Item2;
		if (CustomMessageBox.Confirm(this, $"Đăng xuất tài khoản {text}: {text2}?", "Đăng xuất"))
		{
			if (!((text == "Google") ? CliProxyApiController.LogoutGoogleAccount(text2) : CliProxyApiController.LogoutClaudeAccount(text2)))
			{
				CustomMessageBox.Show(this, $"Không đăng xuất được tài khoản {text}: {text2}.", "Đăng xuất", NotifyType.Warning);
			}
			else
			{
				y();
			}
		}
	}

	private async void Bc(object P_0, RoutedEventArgs P_1)
	{
		await m_647(CliProxyApiController.LoginAntigravityAsync, AiVisionCliProxyLoginGoogleButton, "Đăng nhập Google (Antigravity)");
	}

	private async void BD(object P_0, RoutedEventArgs P_1)
	{
		await m_647(CliProxyApiController.LoginClaudeAsync, AiVisionCliProxyLoginClaudeButton, "Đăng nhập Claude");
	}

	private async Task m_647(Func<CancellationToken, Task<(bool Success, string Message)>> login, Button P_1, string P_2)
	{
		P_1.IsEnabled = false;
		AiVisionCliProxyStatusText.Text = "⏳ Đang mở trình duyệt để " + P_2 + " - hoàn tất đăng nhập trên trình duyệt rồi quay lại đây...";
		AiVisionCliProxyStatusText.Foreground = (Brush)FindResource("BrushTextSecondary");
		var (flag, message) = await login(CancellationToken.None);
		CustomMessageBox.Show(this, message, P_2, (!flag) ? NotifyType.Warning : NotifyType.Success);
		y();
		P_1.IsEnabled = true;
	}

	private void m_648(IEnumerable<string> P_0)
	{
		AiVisionCliProxyModelsPanel.Children.Clear();
		foreach (string A in P_0.Distinct())
		{
			ToggleButton toggleButton = new ToggleButton
			{
				Style = (Style)FindResource("ToggleChipStyle"),
				Content = A,
				Tag = A,
				Margin = new Thickness(0.0, 0.0, 8.0, 8.0),
				IsChecked = m_540.Any((PriorityTargetDisplay priorityTargetDisplay) => priorityTargetDisplay.TargetId == "CliProxy:" + A)
			};
			toggleButton.Checked += Bd;
			toggleButton.Unchecked += Bd;
			AiVisionCliProxyModelsPanel.Children.Add(toggleButton);
		}
	}

	private void Bd(object P_0, RoutedEventArgs P_1)
	{
		if (!m_538 && P_0 is ToggleButton { Tag: string tag } toggleButton)
		{
			string text = "CliProxy:" + tag;
			if (toggleButton.IsChecked == true)
			{
				m_650(text, true);
			}
			else
			{
				i(text);
			}
			Z();
			Y();
		}
	}

	private async void BE(object P_0, RoutedEventArgs P_1)
	{
		AiVisionCliProxyRefreshModelsButton.IsEnabled = false;
		AiVisionCliProxyStatusText.Text = "⏳ Đang lấy danh sách model từ server...";
		AiVisionCliProxyStatusText.Foreground = (Brush)FindResource("BrushTextSecondary");
		List<string> list = await CliProxyApiController.FetchAvailableModelsAsync(CancellationToken.None);
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, $"Không lấy được danh sách model. Kiểm tra: (1) đã đăng nhập ít nhất 1 tài khoản (Google hoặc Claude) chưa, (2) có tiến trình nào khác trên máy đang tự chiếm mất cổng {8391} không (mở Task Manager kiểm tra, có thì tắt hết rồi bấm lại).", "Làm mới danh sách model", NotifyType.Warning);
		}
		else
		{
			IEnumerable<string> second = from priorityTargetDisplay in m_540
				where priorityTargetDisplay.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal)
				select priorityTargetDisplay.TargetId.Substring("CliProxy:".Length);
			m_648(list.Union(second));
		}
		y();
		AiVisionCliProxyRefreshModelsButton.IsEnabled = true;
	}

	private async Task<bool> m_649(string P_0, string P_1, string P_2, Button P_3, TextBlock P_4, string? customUrl = null, string? customFormat = null)
	{
		P_3.IsEnabled = false;
		P_4.Visibility = Visibility.Visible;
		P_4.Text = "Đang kiểm tra...";
		P_4.Foreground = (Brush)FindResource("BrushTextSecondary");
		AiVisionTestResult aiVisionTestResult = await AiVisionClient.TestConnectionAsync(P_0, P_1, P_2, CancellationToken.None, customUrl, customFormat);
		if (aiVisionTestResult.Success)
		{
			P_4.Text = $"✓ Kết nối OK - {aiVisionTestResult.ElapsedSeconds:0.0}s ({aiVisionTestResult.Message})";
			P_4.Foreground = (Brush)FindResource("BrushGreen");
		}
		else
		{
			P_4.Text = $"✗ Lỗi ({aiVisionTestResult.ElapsedSeconds:0.0}s): {aiVisionTestResult.Message}";
			P_4.Foreground = new SolidColorBrush(Color.FromRgb(239, 68, 68));
		}
		P_3.IsEnabled = true;
		return aiVisionTestResult.Success;
	}

	private void Be(object P_0, RoutedEventArgs P_1)
	{
		if (!m_538 && P_0 is CheckBox { Tag: string tag, IsChecked: var isChecked })
		{
			if (isChecked == true)
			{
				m_650(tag);
			}
			else
			{
				i(tag);
			}
			Z();
			Y();
		}
	}

	private void Z()
	{
		if (AiVisionProviderGeminiRadio != null && AiVisionProviderHHTechRadio != null && AiVisionProviderVietApiRadio != null && AiVisionProviderCustomRadio != null && AiVisionClaudeCard != null && AiVisionGeminiCard != null && AiVisionHHTechCard != null && AiVisionVietApiCard != null && AiVisionCustomCard != null && AiVisionCliProxyCard != null)
		{
			m_741 obj = default;
			obj.A = (Brush)FindResource("BrushAccent");
			obj.a = (Brush)FindResource("BrushBorder");
			m_699(AiVisionClaudeCard, AiVisionProviderClaudeRadio, ref obj);
			m_699(AiVisionHHTechCard, AiVisionProviderHHTechRadio, ref obj);
			m_699(AiVisionGeminiCard, AiVisionProviderGeminiRadio, ref obj);
			m_699(AiVisionVietApiCard, AiVisionProviderVietApiRadio, ref obj);
			m_699(AiVisionCustomCard, AiVisionProviderCustomRadio, ref obj);
			bool flag = m_540.Any((PriorityTargetDisplay P_0) => P_0.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal));
			AiVisionCliProxyCard.BorderBrush = (flag ? obj.A : obj.a);
			AiVisionCliProxyCard.BorderThickness = (flag ? new Thickness(2.0) : new Thickness(1.0));
		}
	}

	private void z()
	{
		for (int i = 0; i < m_540.Count; i++)
		{
			m_540[i].Priority = (i + 1).ToString();
		}
		AiVisionPriorityEmptyHintText.Visibility = ((m_540.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private static string I(string P_0)
	{
		switch (P_0)
		{
		case "Claude":
			return "Claude";
		case "Gemini":
			return "Gemini";
		case "HHTechApi":
			return "HHTechAPI";
		case "VietApi":
			return "VietAPI";
		case "Custom":
			return "Tuỳ chỉnh (hiện tại)";
		default:
			if (P_0.StartsWith("Custom:", StringComparison.Ordinal))
			{
				return "Tuỳ chỉnh (" + P_0.Substring("Custom:".Length) + ")";
			}
			if (P_0.StartsWith("CliProxy:", StringComparison.Ordinal))
			{
				return "AI Đăng Nhập Trực Tiếp (" + P_0.Substring("CliProxy:".Length) + ")";
			}
			return P_0;
		}
	}

	private bool m_650(string P_0, bool P_1 = false)
	{
		if (m_540.Any((PriorityTargetDisplay priorityTargetDisplay) => priorityTargetDisplay.TargetId == P_0))
		{
			return false;
		}
		PriorityTargetDisplay item = new PriorityTargetDisplay
		{
			TargetId = P_0,
			DisplayName = I(P_0)
		};
		if (P_1)
		{
			m_540.Insert(0, item);
		}
		else
		{
			m_540.Add(item);
		}
		z();
		return true;
	}

	private bool i(string P_0)
	{
		PriorityTargetDisplay priorityTargetDisplay = m_540.FirstOrDefault((PriorityTargetDisplay priorityTargetDisplay2) => priorityTargetDisplay2.TargetId == P_0);
		if (priorityTargetDisplay == null)
		{
			return false;
		}
		m_540.Remove(priorityTargetDisplay);
		z();
		return true;
	}

	private void aA()
	{
		bool flag = m_538;
		m_538 = true;
		AiVisionProviderClaudeRadio.IsChecked = m_540.Any((PriorityTargetDisplay P_0) => P_0.TargetId == "Claude");
		AiVisionProviderGeminiRadio.IsChecked = m_540.Any((PriorityTargetDisplay P_0) => P_0.TargetId == "Gemini");
		AiVisionProviderHHTechRadio.IsChecked = m_540.Any((PriorityTargetDisplay P_0) => P_0.TargetId == "HHTechApi");
		AiVisionProviderVietApiRadio.IsChecked = m_540.Any((PriorityTargetDisplay P_0) => P_0.TargetId == "VietApi");
		AiVisionProviderCustomRadio.IsChecked = m_540.Any((PriorityTargetDisplay P_0) => P_0.TargetId == "Custom");
		m_538 = flag;
	}

	private void BF(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.Tag is string text)
		{
			i(text);
			aA();
			m_648(from priorityTargetDisplay in m_540
				where priorityTargetDisplay.TargetId.StartsWith("CliProxy:", StringComparison.Ordinal)
				select priorityTargetDisplay.TargetId.Substring("CliProxy:".Length));
			Z();
			Y();
		}
	}

	private void h(object P_0, MouseButtonEventArgs P_1)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		m_541 = P_1.GetPosition(null);
	}

	private void m_651(object P_0, MouseEventArgs P_1)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		if (P_1.LeftButton != MouseButtonState.Pressed)
		{
			return;
		}
		Point position = P_1.GetPosition(null);
		Vector val = m_541 - position;
		if (!(Math.Abs(val.X) <= SystemParameters.MinimumHorizontalDragDistance) || !(Math.Abs(val.Y) <= SystemParameters.MinimumVerticalDragDistance))
		{
			object originalSource = P_1.OriginalSource;
			ListBoxItem listBoxItem = m_598<ListBoxItem>((DependencyObject?)((originalSource is DependencyObject) ? originalSource : null));
			if (listBoxItem != null && AiVisionPriorityListBox.ItemContainerGenerator.ItemFromContainer((DependencyObject)(object)listBoxItem) is PriorityTargetDisplay data)
			{
				DragDrop.DoDragDrop((DependencyObject)(object)listBoxItem, data, DragDropEffects.Move);
			}
		}
	}

	private void m_652(object P_0, DragEventArgs P_1)
	{
		P_1.Effects = (P_1.Data.GetDataPresent(typeof(PriorityTargetDisplay)) ? DragDropEffects.Move : DragDropEffects.None);
		P_1.Handled = true;
	}

	private void m_653(object P_0, DragEventArgs P_1)
	{
		if (!P_1.Data.GetDataPresent(typeof(PriorityTargetDisplay)) || !(P_1.Data.GetData(typeof(PriorityTargetDisplay)) is PriorityTargetDisplay item))
		{
			return;
		}
		int num = m_540.IndexOf(item);
		if (num >= 0)
		{
			object originalSource = P_1.OriginalSource;
			ListBoxItem listBoxItem = m_598<ListBoxItem>((DependencyObject?)((originalSource is DependencyObject) ? originalSource : null));
			int num2 = ((listBoxItem != null && AiVisionPriorityListBox.ItemContainerGenerator.ItemFromContainer((DependencyObject)(object)listBoxItem) is PriorityTargetDisplay item2) ? m_540.IndexOf(item2) : (m_540.Count - 1));
			if (num2 >= 0 && num2 != num)
			{
				m_540.Move(num, num2);
				z();
				Y();
			}
		}
	}

	private void Bf(object P_0, RoutedEventArgs P_1)
	{
		if (!(AiVisionCustomSavedCombo.SelectedItem is string text))
		{
			CustomMessageBox.Show(this, "Chưa chọn cấu hình đã lưu nào ở ô bên trên.", "Thêm vào ưu tiên", NotifyType.Warning);
		}
		else if (!m_650("Custom:" + text))
		{
			CustomMessageBox.Show(this, "Cấu hình \"" + text + "\" đã có trong danh sách ưu tiên rồi.", "Thêm vào ưu tiên", NotifyType.Warning);
		}
		else
		{
			Y();
		}
	}

	private void BG(object P_0, RoutedEventArgs P_1)
	{
		if (m_491 == null)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào ở bên trái.", "Lưu kịch bản", NotifyType.Warning);
			return;
		}
		string text = AiVisionFlowStore.Serialize(m_495);
		FacebookAccountDatabase.SaveScriptFolderAiVisionFlow(m_491.Id, text);
		m_491.AiVisionFlowJson = text;
		m_658("Đã lưu kịch bản.", false);
	}

	private async void Bg(object P_0, RoutedEventArgs P_1)
	{
		await Q();
	}

	private async void BH(object P_0, RoutedEventArgs P_1)
	{
		await m_654(m_495.ToList(), 0);
	}

	private async void Bh(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			int num = m_495.IndexOf(item);
			if (num >= 0)
			{
				await m_654(new List<AiVisionFlowStep> { item }, num);
			}
		}
	}

	private async Task m_654(List<AiVisionFlowStep> P_0, int P_1)
	{
		Y();
		string text = PhoneAiDeviceCombo.SelectedItem as string;
		if (string.IsNullOrWhiteSpace(text))
		{
			m_658("Chưa chọn thiết bị.", true);
			return;
		}
		if (P_0.Count == 0)
		{
			m_658("Chưa có bước nào trong kịch bản.", true);
			return;
		}
		(IReadOnlyDictionary<string, string> Variables, string? NickLabel) tuple = aC();
		IReadOnlyDictionary<string, string> item = tuple.Variables;
		string item2 = tuple.NickLabel;
		Dictionary<string, string> variables = new Dictionary<string, string>(item);
		m_496.Clear();
		m_658((item2 != null) ? ("Đang chạy... (dùng dữ liệu nick " + item2 + " đã chọn)") : "Đang chạy...", false);
		PhoneAiRunButton.IsEnabled = false;
		PhoneAiStopButton.IsEnabled = true;
		m_497 = new CancellationTokenSource();
		await AiVisionVariables.ResolveVerifyVariablesAsync(variables, P_0, m_497.Token);
		int? A = null;
		List<AiVisionFlowStep> m_1149 = new List<AiVisionFlowStep>();
		int m_1150 = 0;
		bool flag = false;
		try
		{
			if (!string.IsNullOrWhiteSpace(text))
			{
				await PhoneInitialSetupService.EnsureInitialSetupAsync(text, m_491?.Platform ?? "All", (string text2) =>
				{
					m_658(text2, false);
				}, m_497.Token);
				m_658("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...", false);
				await AdbController.EnsureEnglishLanguageAsync(text, m_497.Token);
			}
			AiVisionRunResult aiVisionRunResult = await PhoneAiVisionRunner.RunFlowAsync(DeviceControllerFactory.Resolve(Profiles, text), P_0, variables, m_656, m_497.Token, (int num, AiVisionFlowStep? aiVisionFlowStep) =>
			{
				if (A != num)
				{
					A = num;
					m_1149 = new List<AiVisionFlowStep>();
					m_1150 = 0;
				}
				if (aiVisionFlowStep != null)
				{
					m_1149.Add(aiVisionFlowStep);
				}
				else
				{
					m_1150++;
				}
			});
			m_658(aiVisionRunResult.Message, !aiVisionRunResult.Success);
			flag = aiVisionRunResult.Success;
		}
		catch (OperationCanceledException)
		{
			m_658("Đã dừng theo yêu cầu.", true);
		}
		catch (Exception ex2)
		{
			m_658("Lỗi: " + ex2.Message, true);
		}
		finally
		{
			PhoneAiRunButton.IsEnabled = true;
			PhoneAiStopButton.IsEnabled = false;
			m_497?.Dispose();
			m_497 = null;
		}
		if (!flag && A.HasValue)
		{
			m_655(m_495, A.Value + P_1, m_1149, m_1150, X);
		}
	}

	private void m_655(ObservableCollection<AiVisionFlowStep> P_0, int? P_1, List<AiVisionFlowStep> P_2, int P_3, Action P_4)
	{
		if (!P_1.HasValue || P_2.Count == 0)
		{
			return;
		}
		int value = P_1.Value;
		if (value < 0 || value >= P_0.Count || !P_0[value].IsAiGoal)
		{
			return;
		}
		string value2 = ((P_3 > 0) ? $"\n\n(Lưu ý: {P_3} bước gõ phím/mở URL/chờ không ghi lại được - có thể cần bổ sung tay.)" : "");
		if (CustomMessageBox.Confirm(this, $"Đã ghi lại {P_2.Count} bước AI vừa thực hiện cho khối \"Mục tiêu AI\" ở bước {value + 1}. Thay khối đó bằng đúng các bước đã ghi (Nhấn/Kéo vuốt/Nhập văn bản) để tự sửa/hoàn thiện tay?{value2}", "Ghi lại thành bước"))
		{
			P_0.RemoveAt(value);
			for (int i = 0; i < P_2.Count; i++)
			{
				P_0.Insert(value + i, P_2[i]);
			}
			P_4();
		}
	}

	private void m_656(AiVisionStepLog P_0)
	{
		((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
		{
			P_0.TimeLabel = m_657(P_0, m_496);
			m_496.Add(P_0);
			PhoneAiLogScrollViewer.ScrollToBottom();
		}));
	}

	private static string m_657(AiVisionStepLog P_0, IReadOnlyList<AiVisionStepLog> P_1)
	{
		if (P_1.Count == 0)
		{
			return P_0.Timestamp.ToString("HH:mm:ss");
		}
		double totalSeconds = (P_0.Timestamp - P_1[P_1.Count - 1].Timestamp).TotalSeconds;
		return $"{P_0.Timestamp:HH:mm:ss} (+{totalSeconds:0.0}s)";
	}

	private void BI(object P_0, RoutedEventArgs P_1)
	{
		m_497?.Cancel();
	}

	private void Bi(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "ai_vision_debug");
			Directory.CreateDirectory(text);
			Process.Start(new ProcessStartInfo
			{
				FileName = text,
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không mở được thư mục: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void m_658(string P_0, bool P_1)
	{
		PhoneAiStatusText.Text = P_0;
		PhoneAiStatusText.Foreground = (P_1 ? new SolidColorBrush(Color.FromRgb(239, 68, 68)) : ((Brush)FindResource("BrushGreen")));
		PhoneAiStatusText.Visibility = (string.IsNullOrWhiteSpace(P_0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void aa()
	{
		m_498.Clear();
		if (m_491 != null && m_491.Platform == "Chrome")
		{
			foreach (AiVisionFlowStep step in AiVisionFlowStore.Deserialize(m_491.AiVisionFlowJson).Steps)
			{
				m_498.Add(step);
			}
		}
		if (ChromeAiFolderNameText != null)
		{
			ChromeAiFolderNameText.Text = ((m_491 != null && m_491.Platform == "Chrome") ? ("Thư mục: " + m_491.Name) : "Chưa chọn thư mục kịch bản");
		}
		aB();
	}

	private void aB()
	{
		if (ChromeAiStepCountText != null && ChromeAiEmptyStepsText != null)
		{
			ChromeAiStepCountText.Text = $"{m_498.Count} bước";
			ChromeAiEmptyStepsText.Visibility = ((m_498.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void BJ(object P_0, RoutedEventArgs P_1)
	{
		m_659(new AiVisionFlowStep
		{
			Type = AiVisionStepType.AiGoal
		});
	}

	private void Bj(object P_0, RoutedEventArgs P_1)
	{
		m_659(new AiVisionFlowStep
		{
			Type = AiVisionStepType.RandomWait
		});
	}

	private bool m_659(AiVisionFlowStep P_0)
	{
		if (m_491 == null)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào ở bên trái.", "Kịch bản AI Vision", NotifyType.Warning);
			return false;
		}
		m_498.Add(P_0);
		aB();
		return true;
	}

	private void BK(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			int num = m_498.IndexOf(item);
			if (num > 0)
			{
				m_498.Move(num, num - 1);
			}
		}
	}

	private void Bk(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			int num = m_498.IndexOf(item);
			if (num >= 0 && num < m_498.Count - 1)
			{
				m_498.Move(num, num + 1);
			}
		}
	}

	private void BL(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			m_498.Remove(item);
			aB();
		}
	}

	private void Bl(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is Button { Tag: string tag, DataContext: AiVisionFlowStep dataContext })
		{
			dataContext.Goal += tag;
		}
	}

	private void BM(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is Button { DataContext: AiVisionFlowStep dataContext })
		{
			string text = AiVisionFileVariableWindow.Show(this);
			if (text != null)
			{
				dataContext.Goal += text;
			}
		}
	}

	private void Bm(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is Button { Tag: string tag, DataContext: AiVisionFlowStep dataContext })
		{
			string text = AiVisionRandomVariableWindow.Show(this, tag);
			if (text != null)
			{
				dataContext.Goal += text;
			}
		}
	}

	private void BN(object P_0, RoutedEventArgs P_1)
	{
		m_660(new AiVisionFlowStep
		{
			Type = AiVisionStepType.Tap
		});
	}

	private void Bn(object P_0, RoutedEventArgs P_1)
	{
		m_660(new AiVisionFlowStep
		{
			Type = AiVisionStepType.Swipe
		});
	}

	private void BO(object P_0, RoutedEventArgs P_1)
	{
		m_660(new AiVisionFlowStep
		{
			Type = AiVisionStepType.Text
		});
	}

	private void m_660(AiVisionFlowStep P_0)
	{
		if (m_643(P_0))
		{
			m_661(P_0);
		}
	}

	private void Bo(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep aiVisionFlowStep)
		{
			m_661(aiVisionFlowStep);
		}
	}

	private void BP(object P_0, RoutedEventArgs P_1)
	{
		string A = PhoneAiDeviceCombo.SelectedItem as string;
		if (string.IsNullOrWhiteSpace(A))
		{
			CustomMessageBox.Show(this, "Chưa chọn thiết bị (mục \"Thiết bị (để chạy thử)\" bên trái).", "Ghi lại hành động", NotifyType.Warning);
			return;
		}
		IMarkStepsDeviceAdapter adapter;
		if (!(Profiles.FirstOrDefault((ProfileRow profileRow) => profileRow.Name == A)?.OS == "iOS"))
		{
			IMarkStepsDeviceAdapter markStepsDeviceAdapter = new PhoneMarkStepsAdapter(A);
			adapter = markStepsDeviceAdapter;
		}
		else
		{
			IMarkStepsDeviceAdapter markStepsDeviceAdapter = new IPhoneMarkStepsAdapter();
			adapter = markStepsDeviceAdapter;
		}
		AiVisionRecordActionsWindow aiVisionRecordActionsWindow = new AiVisionRecordActionsWindow(adapter, m_495)
		{
			Owner = this
		};
		if (aiVisionRecordActionsWindow.ShowDialog() != true || aiVisionRecordActionsWindow.RecordedSteps.Count <= 0)
		{
			return;
		}
		foreach (AiVisionFlowStep recordedStep in aiVisionRecordActionsWindow.RecordedSteps)
		{
			m_495.Add(recordedStep);
		}
		if (m_491 != null)
		{
			string text = AiVisionFlowStore.Serialize(m_495);
			FacebookAccountDatabase.SaveScriptFolderAiVisionFlow(m_491.Id, text);
			m_491.AiVisionFlowJson = text;
		}
		X();
		m_658($"Đã chèn {aiVisionRecordActionsWindow.RecordedSteps.Count} bước từ khối Ghi lại hành động vào kịch bản!", false);
	}

	private void m_661(AiVisionFlowStep P_0)
	{
		string A = PhoneAiDeviceCombo.SelectedItem as string;
		if (string.IsNullOrWhiteSpace(A))
		{
			CustomMessageBox.Show(this, "Chưa chọn thiết bị (mục \"Thiết bị (để chạy thử)\" bên trái).", "Đánh dấu bước", NotifyType.Warning);
			return;
		}
		IMarkStepsDeviceAdapter markStepsDeviceAdapter2;
		if (!(Profiles.FirstOrDefault((ProfileRow profileRow) => profileRow.Name == A)?.OS == "iOS"))
		{
			IMarkStepsDeviceAdapter markStepsDeviceAdapter = new PhoneMarkStepsAdapter(A);
			markStepsDeviceAdapter2 = markStepsDeviceAdapter;
		}
		else
		{
			IMarkStepsDeviceAdapter markStepsDeviceAdapter = new IPhoneMarkStepsAdapter();
			markStepsDeviceAdapter2 = markStepsDeviceAdapter;
		}
		IMarkStepsDeviceAdapter adapter = markStepsDeviceAdapter2;
		AiVisionMarkStepsWindow aiVisionMarkStepsWindow = new AiVisionMarkStepsWindow(P_0, adapter, m_495);
		aiVisionMarkStepsWindow.Owner = this;
		aiVisionMarkStepsWindow.ShowDialog();
	}

	private async void Bp(object P_0, RoutedEventArgs P_1)
	{
		m_667("Đang kết nối Chrome để ghi lại hành động...", false);
		try
		{
			ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
			if (!(await activeBrowserEngine.Client.CheckApiAliveAsync()))
			{
				CustomMessageBox.Show(this, $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}.", "Ghi lại hành động", NotifyType.Warning);
				return;
			}
			string profileId = await m_663(activeBrowserEngine.Client);
			AiVisionRecordActionsWindow aiVisionRecordActionsWindow = new AiVisionRecordActionsWindow(new ChromeMarkStepsAdapter(await ChromeAiVisionRunner.ConnectToTestProfileAsync(activeBrowserEngine.Client, profileId, CancellationToken.None)), m_498)
			{
				Owner = this
			};
			if (aiVisionRecordActionsWindow.ShowDialog() != true || aiVisionRecordActionsWindow.RecordedSteps.Count <= 0)
			{
				return;
			}
			foreach (AiVisionFlowStep recordedStep in aiVisionRecordActionsWindow.RecordedSteps)
			{
				m_498.Add(recordedStep);
			}
			if (m_491 != null)
			{
				string text = AiVisionFlowStore.Serialize(m_498);
				FacebookAccountDatabase.SaveScriptFolderAiVisionFlow(m_491.Id, text);
				m_491.AiVisionFlowJson = text;
			}
			aB();
			m_667($"Đã chèn {aiVisionRecordActionsWindow.RecordedSteps.Count} bước từ khối Ghi lại hành động vào kịch bản!", false);
		}
		catch (Exception ex)
		{
			m_667("Lỗi kết nối Chrome: " + ex.Message, true);
		}
		finally
		{
			m_667("", false);
		}
	}

	private void BQ(object P_0, RoutedEventArgs P_1)
	{
		m_662(new AiVisionFlowStep
		{
			Type = AiVisionStepType.Tap
		});
	}

	private void Bq(object P_0, RoutedEventArgs P_1)
	{
		ab();
	}

	private void BR(object P_0, RoutedEventArgs P_1)
	{
		m_662(new AiVisionFlowStep
		{
			Type = AiVisionStepType.Text
		});
	}

	private async Task m_662(AiVisionFlowStep P_0)
	{
		if (m_659(P_0))
		{
			await m_664(P_0);
		}
	}

	private async void Br(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep aiVisionFlowStep)
		{
			await m_664(aiVisionFlowStep);
		}
	}

	private async Task<string> m_663(IAntidetectBrowserClient P_0)
	{
		if (f != null)
		{
			return f;
		}
		string profileName = $"test_{DateTime.Now:yyyyMMddHHmmss}_{Guid.NewGuid().ToString("N").Substring(0, 6)}";
		f = (await P_0.CreateProfileAsync(profileName, "", "")).ProfileId;
		return f;
	}

	private async Task m_664(AiVisionFlowStep P_0)
	{
		m_667("Đang mở Chrome để đánh dấu...", false);
		try
		{
			ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
			if (!(await activeBrowserEngine.Client.CheckApiAliveAsync()))
			{
				CustomMessageBox.Show(this, $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API.", "Đánh dấu bước", NotifyType.Warning);
			}
			else
			{
				string profileId = await m_663(activeBrowserEngine.Client);
				AiVisionMarkStepsWindow aiVisionMarkStepsWindow = new AiVisionMarkStepsWindow(P_0, new ChromeMarkStepsAdapter(await ChromeAiVisionRunner.ConnectToTestProfileAsync(activeBrowserEngine.Client, profileId, CancellationToken.None)), m_498);
				aiVisionMarkStepsWindow.Owner = this;
				aiVisionMarkStepsWindow.ShowDialog();
			}
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Lỗi mở Chrome: " + ex.Message, "Đánh dấu bước", NotifyType.Warning);
		}
		finally
		{
			m_667("", false);
		}
	}

	private void ab()
	{
		string text = PromptDialog.Show(this, "Lăn chuột", "Số pixel cuộn (dương = xuống, âm = lên):", "300");
		if (!string.IsNullOrWhiteSpace(text))
		{
			if (!int.TryParse(text.Trim(), out var result))
			{
				CustomMessageBox.Show(this, "Giá trị không hợp lệ — nhập số nguyên, ví dụ 300 hoặc -300.", "Lăn chuột", NotifyType.Warning);
				return;
			}
			m_498.Add(new AiVisionFlowStep
			{
				Type = AiVisionStepType.Scroll,
				X = 0,
				Y = 0,
				X2 = 0,
				Y2 = result,
				IsMarkedComplete = true
			});
			aB();
		}
	}

	private void BS(object P_0, RoutedEventArgs P_1)
	{
		if (m_498.Count != 0 && CustomMessageBox.Confirm(this, "Xóa toàn bộ các bước trong danh sách?", "Xóa tất cả"))
		{
			m_498.Clear();
			aB();
		}
	}

	private void Bs(object P_0, RoutedEventArgs P_1)
	{
		if (m_491 == null)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào ở bên trái.", "Lưu kịch bản", NotifyType.Warning);
			return;
		}
		string text = AiVisionFlowStore.Serialize(m_498);
		FacebookAccountDatabase.SaveScriptFolderAiVisionFlow(m_491.Id, text);
		m_491.AiVisionFlowJson = text;
		m_667("Đã lưu kịch bản.", false);
	}

	private (IReadOnlyDictionary<string, string> Variables, string? NickLabel) aC()
	{
		if (m_542 != null)
		{
			return (Variables: m_542.Variables, NickLabel: m_542.Label);
		}
		FacebookAccountRow facebookAccountRow = Facebooks.FirstOrDefault((FacebookAccountRow P_0) => P_0.IsSelected);
		if (facebookAccountRow != null)
		{
			return (Variables: AiVisionVariables.BuildMap(facebookAccountRow), NickLabel: facebookAccountRow.Uid);
		}
		PlatformAccountRow platformAccountRow = m_509.Accounts.FirstOrDefault((PlatformAccountRow P_0) => P_0.IsSelected) ?? m_510.Accounts.FirstOrDefault((PlatformAccountRow P_0) => P_0.IsSelected) ?? m_511.Accounts.FirstOrDefault((PlatformAccountRow P_0) => P_0.IsSelected) ?? m_512.Accounts.FirstOrDefault((PlatformAccountRow P_0) => P_0.IsSelected);
		if (platformAccountRow != null)
		{
			return (Variables: AiVisionVariables.BuildMap(platformAccountRow), NickLabel: platformAccountRow.Uid);
		}
		return (Variables: new Dictionary<string, string>(), NickLabel: null);
	}

	private void BT(object P_0, RoutedEventArgs P_1)
	{
		List<AiVisionTestNickPlatform> platforms = new List<AiVisionTestNickPlatform>
		{
			new AiVisionTestNickPlatform
			{
				Label = "Facebook",
				Folders = Folders.ToList(),
				Nicks = Facebooks.Select((FacebookAccountRow facebookAccountRow) => new AiVisionTestNickCandidate
				{
					Uid = facebookAccountRow.Uid,
					FolderId = facebookAccountRow.FolderId,
					Variables = AiVisionVariables.BuildMap(facebookAccountRow)
				}).ToList()
			},
			new AiVisionTestNickPlatform
			{
				Label = "Gmail",
				Folders = m_509.Folders.ToList(),
				Nicks = m_509.Accounts.Select((PlatformAccountRow platformAccountRow) => new AiVisionTestNickCandidate
				{
					Uid = platformAccountRow.Uid,
					FolderId = platformAccountRow.FolderId,
					Variables = AiVisionVariables.BuildMap(platformAccountRow)
				}).ToList()
			},
			new AiVisionTestNickPlatform
			{
				Label = "TikTok",
				Folders = m_510.Folders.ToList(),
				Nicks = m_510.Accounts.Select((PlatformAccountRow platformAccountRow) => new AiVisionTestNickCandidate
				{
					Uid = platformAccountRow.Uid,
					FolderId = platformAccountRow.FolderId,
					Variables = AiVisionVariables.BuildMap(platformAccountRow)
				}).ToList()
			},
			new AiVisionTestNickPlatform
			{
				Label = "Hotmail",
				Folders = m_511.Folders.ToList(),
				Nicks = m_511.Accounts.Select((PlatformAccountRow platformAccountRow) => new AiVisionTestNickCandidate
				{
					Uid = platformAccountRow.Uid,
					FolderId = platformAccountRow.FolderId,
					Variables = AiVisionVariables.BuildMap(platformAccountRow)
				}).ToList()
			},
			new AiVisionTestNickPlatform
			{
				Label = "Shopee",
				Folders = m_512.Folders.ToList(),
				Nicks = m_512.Accounts.Select((PlatformAccountRow platformAccountRow) => new AiVisionTestNickCandidate
				{
					Uid = platformAccountRow.Uid,
					FolderId = platformAccountRow.FolderId,
					Variables = AiVisionVariables.BuildMap(platformAccountRow)
				}).ToList()
			}
		};
		AiVisionTestNickSelection aiVisionTestNickSelection = AiVisionPickTestNickWindow.Show(this, platforms);
		if (aiVisionTestNickSelection != null)
		{
			m_542 = aiVisionTestNickSelection;
			string text = "Nick chạy thử: " + aiVisionTestNickSelection.Label;
			PhoneAiTestNickText.Text = text;
			ChromeAiTestNickText.Text = text;
		}
	}

	private async void Bt(object P_0, RoutedEventArgs P_1)
	{
		await m_665(m_498.ToList(), 0);
	}

	private async void BU(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as FrameworkElement)?.DataContext is AiVisionFlowStep item)
		{
			int num = m_498.IndexOf(item);
			if (num >= 0)
			{
				await m_665(new List<AiVisionFlowStep> { item }, num);
			}
		}
	}

	private async Task m_665(List<AiVisionFlowStep> P_0, int P_1)
	{
		Y();
		if (P_0.Count == 0)
		{
			m_667("Chưa có bước nào trong kịch bản.", true);
			return;
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		if (!(await activeBrowserEngine.Client.CheckApiAliveAsync()))
		{
			m_667($"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API.", true);
			return;
		}
		string profileId = await m_663(activeBrowserEngine.Client);
		(IReadOnlyDictionary<string, string> Variables, string? NickLabel) tuple = aC();
		IReadOnlyDictionary<string, string> item = tuple.Variables;
		string item2 = tuple.NickLabel;
		Dictionary<string, string> variables = new Dictionary<string, string>(item);
		m_499.Clear();
		m_667((item2 != null) ? ("Đang chạy... (dùng dữ liệu nick " + item2 + " đã chọn)") : "Đang chạy...", false);
		ChromeAiRunButton.IsEnabled = false;
		ChromeAiStopButton.IsEnabled = true;
		m_500 = new CancellationTokenSource();
		await AiVisionVariables.ResolveVerifyVariablesAsync(variables, P_0, m_500.Token);
		int? A = null;
		List<AiVisionFlowStep> m_1158 = new List<AiVisionFlowStep>();
		int m_1159 = 0;
		bool flag = false;
		try
		{
			AiVisionRunResult aiVisionRunResult = await ChromeAiVisionRunner.RunFlowForProfileAsync(profileId, P_0, variables, m_666, m_500.Token, (int num, AiVisionFlowStep? aiVisionFlowStep) =>
			{
				if (A != num)
				{
					A = num;
					m_1158 = new List<AiVisionFlowStep>();
					m_1159 = 0;
				}
				if (aiVisionFlowStep != null)
				{
					m_1158.Add(aiVisionFlowStep);
				}
				else
				{
					m_1159++;
				}
			});
			m_667(aiVisionRunResult.Message, !aiVisionRunResult.Success);
			flag = aiVisionRunResult.Success;
		}
		catch (OperationCanceledException)
		{
			m_667("Đã dừng theo yêu cầu.", true);
		}
		catch (Exception ex2)
		{
			m_667("Lỗi: " + ex2.Message, true);
		}
		finally
		{
			ChromeAiRunButton.IsEnabled = true;
			ChromeAiStopButton.IsEnabled = false;
			m_500?.Dispose();
			m_500 = null;
		}
		if (!flag && A.HasValue)
		{
			m_655(m_498, A.Value + P_1, m_1158, m_1159, aB);
		}
	}

	private void m_666(AiVisionStepLog P_0)
	{
		((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
		{
			P_0.TimeLabel = m_657(P_0, m_499);
			m_499.Add(P_0);
			ChromeAiLogScrollViewer.ScrollToBottom();
		}));
	}

	private void Bu(object P_0, RoutedEventArgs P_1)
	{
		m_500?.Cancel();
	}

	private void m_667(string P_0, bool P_1)
	{
		ChromeAiStatusText.Text = P_0;
		ChromeAiStatusText.Foreground = (P_1 ? new SolidColorBrush(Color.FromRgb(239, 68, 68)) : ((Brush)FindResource("BrushGreen")));
		ChromeAiStatusText.Visibility = (string.IsNullOrWhiteSpace(P_0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void BV(object P_0, RoutedEventArgs P_1)
	{
		if (m_491 == null)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào.", "Đổi tên", NotifyType.Warning);
			return;
		}
		if (!m_491.CanManage)
		{
			CustomMessageBox.Show(this, "Thư mục kịch bản dựng sẵn không thể đổi tên.", "Đổi tên", NotifyType.Warning);
			return;
		}
		string text = PromptDialog.Show(this, "Đổi tên thư mục kịch bản", "Tên thư mục:", m_491.Name);
		if (string.IsNullOrWhiteSpace(text) || text.Trim() == m_491.Name)
		{
			return;
		}
		try
		{
			FacebookAccountDatabase.RenameScriptFolder(m_491.Id, text.Trim());
			m_491.Name = text.Trim();
			foreach (FacebookAccountRow item in Facebooks.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.ScriptId == m_491.Id))
			{
				item.ScriptName = m_491.Name;
			}
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể đổi tên: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void Bv(object P_0, RoutedEventArgs P_1)
	{
		List<ScriptItem> list = Scripts.Where((ScriptItem scriptItem) => scriptItem.IsSelected).ToList();
		if (list.Count == 0 && m_491 != null)
		{
			list.Add(m_491);
		}
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào.", "Xóa thư mục", NotifyType.Warning);
			return;
		}
		List<ScriptItem> list2 = list.Where((ScriptItem scriptItem) => scriptItem.CanManage).ToList();
		int num = list.Count - list2.Count;
		if (list2.Count == 0)
		{
			CustomMessageBox.Show(this, "Thư mục kịch bản dựng sẵn không thể xoá.", "Xóa thư mục", NotifyType.Warning);
			return;
		}
		string message = $"Xóa {list2.Count} thư mục kịch bản đã chọn? Các nick đang gắn thư mục này sẽ bị gỡ gắn." + ((num > 0) ? $"\n({num} thư mục dựng sẵn sẽ được giữ lại, không xoá được.)" : "");
		if (!CustomMessageBox.Confirm(this, message, "Xóa thư mục kịch bản"))
		{
			return;
		}
		try
		{
			foreach (ScriptItem A in list2)
			{
				FacebookAccountDatabase.DeleteScriptFolder(A.Id);
				foreach (FacebookAccountRow item in Facebooks.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.ScriptId == A.Id))
				{
					item.ScriptId = 0;
					item.ScriptName = "";
				}
				if (m_491 == A)
				{
					m_491 = null;
				}
				Scripts.Remove(A);
			}
			m_564();
			m_566();
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể xóa: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void BW(object P_0, RoutedEventArgs P_1)
	{
		m_638(ScriptExportImportPopup, P_0, ScriptExportImportButton);
	}

	private void Bw(object P_0, RoutedEventArgs P_1)
	{
		ScriptExportImportPopup.IsOpen = false;
		List<ScriptItem> list = Scripts.Where((ScriptItem scriptItem) => scriptItem.IsSelected).ToList();
		if (list.Count == 0 && m_491 != null)
		{
			list.Add(m_491);
		}
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn thư mục kịch bản nào để xuất.", "Xuất kịch bản", NotifyType.Warning);
			return;
		}
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Kịch bản BaoSamNuoi (*.zip)|*.zip",
			FileName = ((list.Count == 1) ? ("kichban_" + J(list[0].Name) + ".zip") : $"kichban_{list.Count}_muc_{DateTime.Now:yyyyMMdd_HHmmss}.zip")
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			using FileStream stream = new FileStream(saveFileDialog.FileName, FileMode.Create);
			using ZipArchive zipArchive = new ZipArchive(stream, ZipArchiveMode.Create);
			HashSet<string> hashSet = new HashSet<string>();
			foreach (ScriptItem item in list)
			{
				AiVisionFlowDocument aiVisionFlowDocument = AiVisionFlowStore.Deserialize(item.AiVisionFlowJson);
				ScriptExportDocument value = new ScriptExportDocument
				{
					Name = item.Name,
					Platform = item.Platform,
					Steps = aiVisionFlowDocument.Steps
				};
				string text = J(item.Name);
				if (string.IsNullOrWhiteSpace(text))
				{
					text = "kich_ban";
				}
				string text2 = text;
				int num = 2;
				while (!hashSet.Add(text2))
				{
					text2 = $"{text}_{num++}";
				}
				using Stream stream2 = zipArchive.CreateEntry(text2 + ".json", CompressionLevel.Optimal).Open();
				using StreamWriter streamWriter = new StreamWriter(stream2, Encoding.UTF8);
				streamWriter.Write(JsonSerializer.Serialize(value, new JsonSerializerOptions
				{
					WriteIndented = true
				}));
			}
			CustomMessageBox.Show(this, $"Đã xuất {list.Count} kịch bản ra file:\n{saveFileDialog.FileName}", "Xuất kịch bản");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể xuất kịch bản: " + ex.Message, "Xuất kịch bản", NotifyType.Warning);
		}
	}

	private void BX(object P_0, RoutedEventArgs P_1)
	{
		ScriptExportImportPopup.IsOpen = false;
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "Kịch bản BaoSamNuoi (*.zip)|*.zip|Tất cả file (*.*)|*.*"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			using FileStream stream = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read);
			using ZipArchive zipArchive = new ZipArchive(stream, ZipArchiveMode.Read);
			int num = 0;
			List<string> list = new List<string>();
			foreach (ZipArchiveEntry entry in zipArchive.Entries)
			{
				if (!entry.FullName.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				try
				{
					using Stream stream2 = entry.Open();
					using StreamReader streamReader = new StreamReader(stream2, Encoding.UTF8);
					ScriptExportDocument scriptExportDocument = JsonSerializer.Deserialize<ScriptExportDocument>(streamReader.ReadToEnd());
					if (scriptExportDocument == null || string.IsNullOrWhiteSpace(scriptExportDocument.Name))
					{
						list.Add(entry.Name + ": không đọc được dữ liệu hợp lệ");
						continue;
					}
					bool flag;
					switch (scriptExportDocument.Platform)
					{
					case "Android":
					case "iPhone":
					case "Chrome":
					case "Phone":
						flag = true;
						break;
					default:
						flag = false;
						break;
					}
					string platform = (flag ? scriptExportDocument.Platform : B);
					ScriptItem scriptItem = FacebookAccountDatabase.CreateScriptFolder(scriptExportDocument.Name, platform);
					string text = AiVisionFlowStore.Serialize(scriptExportDocument.Steps);
					FacebookAccountDatabase.SaveScriptFolderAiVisionFlow(scriptItem.Id, text);
					scriptItem.AiVisionFlowJson = text;
					Scripts.Add(scriptItem);
					num++;
				}
				catch (Exception ex)
				{
					list.Add(entry.Name + ": " + ex.Message);
				}
			}
			m_564();
			ICollectionView? val = m_492;
			if (val != null)
			{
				val.Refresh();
			}
			string text2 = $"Đã nhập {num} kịch bản.";
			if (list.Count > 0)
			{
				text2 = text2 + $"\n\n{list.Count} file lỗi:\n" + string.Join("\n", list);
			}
			CustomMessageBox.Show(this, text2, "Nhập kịch bản", (num <= 0) ? NotifyType.Warning : NotifyType.Success);
		}
		catch (Exception ex2)
		{
			CustomMessageBox.Show(this, "Không thể đọc file .zip: " + ex2.Message, "Nhập kịch bản", NotifyType.Warning);
		}
	}

	private static string J(string P_0)
	{
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			P_0 = P_0.Replace(oldChar, '_');
		}
		return P_0.Trim();
	}

	private void Bx(object P_0, RoutedEventArgs P_1)
	{
		m_563();
	}

	private void m_668(object P_0, TextChangedEventArgs P_1)
	{
		ICollectionView? val = m_492;
		if (val != null)
		{
			val.Refresh();
		}
	}

	private void BY(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as CheckBox)?.DataContext is InteractionAction interactionAction)
		{
			if (m_491 == null)
			{
				interactionAction.IsSelected = false;
				CustomMessageBox.Show(this, "Chọn 1 thư mục kịch bản ở bên trái trước.", "Gắn hành động", NotifyType.Warning);
			}
			else
			{
				FacebookAccountDatabase.SetActionInFolder(m_491.Id, interactionAction.Id, interactionAction.IsSelected);
			}
		}
	}

	private void By(object P_0, RoutedEventArgs P_1)
	{
		m_562();
		m_566();
	}

	private void m_669(object P_0, TextChangedEventArgs P_1)
	{
		ICollectionView? val = m_493;
		if (val != null)
		{
			val.Refresh();
		}
	}

	private void BZ(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> A = L();
		if (A.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Gắn Phone", NotifyType.Warning);
			return;
		}
		AttachPhonePanel.Children.Clear();
		if (Profiles.Count == 0)
		{
			AttachPhonePanel.Children.Add(new TextBlock
			{
				Text = "Chưa có phone nào.",
				Foreground = (Brush)FindResource("BrushTextMuted"),
				Margin = new Thickness(6.0)
			});
		}
		foreach (ProfileRow A2 in Profiles)
		{
			Button button = new Button
			{
				Style = (Style)FindResource("OutlineButtonStyle"),
				Content = A2.Name,
				Margin = new Thickness(2.0),
				HorizontalContentAlignment = HorizontalAlignment.Left
			};
			button.Click += delegate
			{
				foreach (FacebookAccountRow item in A)
				{
					item.PhoneName = A2.Name;
					item.ProfileChrome = "";
				}
				AttachPhonePopup.IsOpen = false;
				CustomMessageBox.Show(this, $"Đã gắn máy \"{A2.Name}\" cho {A.Count} nick.", "Gắn Phone");
			};
			AttachPhonePanel.Children.Add(button);
		}
		m_638(AttachPhonePopup, P_0, AttachPhoneButton);
	}

	private void Bz(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Gắn Chrome", NotifyType.Warning);
			return;
		}
		foreach (FacebookAccountRow item in list)
		{
			if (string.IsNullOrWhiteSpace(item.ProfileChrome))
			{
				item.ProfileChrome = ((!string.IsNullOrWhiteSpace(item.Uid)) ? item.Uid : $"GPM_{item.Index}_{DateTime.Now:HHmmss}");
			}
			item.PhoneName = "";
		}
		CustomMessageBox.Show(this, $"Đã gắn Chrome cho {list.Count} nick.", "Gắn Chrome");
	}

	private bool m_670(List<FacebookAccountRow> P_0, object? sender)
	{
		List<FacebookAccountRow> list = P_0.Where((FacebookAccountRow facebookAccountRow) => string.IsNullOrEmpty(facebookAccountRow.Platform)).ToList();
		if (list.Count == 0)
		{
			return false;
		}
		AttachPlatformPromptText.Text = ((list.Count == P_0.Count) ? $"{list.Count} nick đã chọn chưa gắn Phone hoặc Chrome. Chọn loại để gắn:" : $"{list.Count}/{P_0.Count} nick đã chọn chưa gắn Phone hoặc Chrome. Chọn loại để gắn:");
		AttachPlatformPromptPopup.PlacementTarget = this;
		AttachPlatformPromptPopup.Placement = PlacementMode.Center;
		AttachPlatformPromptPopup.HorizontalOffset = 0.0;
		AttachPlatformPromptPopup.VerticalOffset = 0.0;
		AttachPlatformPromptPopup.IsOpen = true;
		return true;
	}

	private void bA(object P_0, RoutedEventArgs P_1)
	{
		AttachPlatformPromptPopup.IsOpen = false;
		Bz(RunScriptButton, P_1);
	}

	private void ba(object P_0, RoutedEventArgs P_1)
	{
		AttachPlatformPromptPopup.IsOpen = false;
		BZ(RunScriptButton, P_1);
	}

	private static UIElement m_671(ScriptItem P_0)
	{
		string platform = P_0.Platform;
		(string, string) tuple;
		if (platform == "iPhone")
		{
			tuple = ("iPhone", "#9CA3AF");
		}
		else
		{
			tuple = ((!(platform == "Chrome")) ? ("Android", "#22C55E") : ("Chrome", "#4285F4"));
		}
		(string, string) tuple2 = tuple;
		string item = tuple2.Item1;
		string item2 = tuple2.Item2;
		StackPanel stackPanel = new StackPanel
		{
			Orientation = Orientation.Horizontal
		};
		if (P_0.IsSystem)
		{
			stackPanel.Children.Add(new TextBlock
			{
				Text = "\ue72e",
				FontFamily = (FontFamily)Application.Current.FindResource("IconFont"),
				FontSize = 11.0,
				Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#A78BFA")),
				VerticalAlignment = VerticalAlignment.Center,
				Margin = new Thickness(0.0, 0.0, 6.0, 0.0)
			});
		}
		stackPanel.Children.Add(new TextBlock
		{
			Text = P_0.Name,
			VerticalAlignment = VerticalAlignment.Center,
			Foreground = (P_0.IsSystem ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#A78BFA")) : Brushes.White),
			FontWeight = (P_0.IsSystem ? FontWeights.SemiBold : FontWeights.Normal)
		});
		if (P_0.IsSystem)
		{
			stackPanel.Children.Add(m_672("FB", "#8AB4F8", "#4285F4", "#0B2A4A"));
		}
		stackPanel.Children.Add(m_672(item, item2, item2, null));
		if (P_0.IsSystem)
		{
			stackPanel.Children.Add(m_672("Hệ thống", "#C4B5FD", "#A78BFA", "#1E1033"));
		}
		return stackPanel;
	}

	private static Border m_672(string P_0, string P_1, string P_2, string? background)
	{
		SolidColorBrush background2 = ((background != null) ? new SolidColorBrush((Color)ColorConverter.ConvertFromString(background)) : new SolidColorBrush((Color)ColorConverter.ConvertFromString(P_2))
		{
			Opacity = 0.18
		});
		return new Border
		{
			Background = background2,
			BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(P_2)),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(10.0),
			Padding = new Thickness(7.0, 1.0, 7.0, 1.0),
			Margin = new Thickness(6.0, 0.0, 0.0, 0.0),
			VerticalAlignment = VerticalAlignment.Center,
			Child = new TextBlock
			{
				Text = P_0,
				FontSize = 10.0,
				FontWeight = FontWeights.Bold,
				Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(P_1))
			}
		};
	}

	private void bB(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Gắn Kịch Bản", NotifyType.Warning);
		}
		else if (!m_670(list, (P_0 as FrameworkElement) ?? AttachScriptButton))
		{
			string text = list.Select((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform).ToHashSet().FirstOrDefault((string value) => !string.IsNullOrEmpty(value)) ?? "Chrome";
			if (text == "Phone")
			{
				text = "Android";
			}
			List<ScriptItem> scripts = Scripts.Where((ScriptItem scriptItem2) => scriptItem2.ChuDe == "Facebook").ToList();
			ScriptItem scriptItem = AttachScriptWindow.ShowFor(this, scripts, text, list.Count);
			if (scriptItem != null)
			{
				m_673(scriptItem);
			}
		}
	}

	private void m_673(ScriptItem P_0)
	{
		List<FacebookAccountRow> m_1168 = L();
		if (m_1168.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Gắn Kịch Bản", NotifyType.Warning);
		}
		else
		{
			if (m_670(m_1168, null))
			{
				return;
			}
			bool flag = P_0.Platform.Equals("Chrome", StringComparison.OrdinalIgnoreCase);
			bool flag2 = P_0.Platform.Equals("Phone", StringComparison.OrdinalIgnoreCase) || P_0.Platform.Equals("Android", StringComparison.OrdinalIgnoreCase);
			bool flag3 = P_0.Platform.Equals("iPhone", StringComparison.OrdinalIgnoreCase) || P_0.Platform.Equals("iOS", StringComparison.OrdinalIgnoreCase);
			if (flag)
			{
				foreach (FacebookAccountRow item in m_1168)
				{
					if (string.IsNullOrWhiteSpace(item.ProfileChrome))
					{
						item.ProfileChrome = ((!string.IsNullOrWhiteSpace(item.Uid)) ? item.Uid : $"BaoSamBrowser_{item.Index}_{DateTime.Now:HHmmss}");
					}
					item.PhoneName = "";
				}
			}
			else if (flag2 | flag3)
			{
				string text = m_1168.FirstOrDefault((FacebookAccountRow facebookAccountRow) => !string.IsNullOrWhiteSpace(facebookAccountRow.PhoneName))?.PhoneName ?? Facebooks.FirstOrDefault((FacebookAccountRow facebookAccountRow) => !string.IsNullOrWhiteSpace(facebookAccountRow.PhoneName))?.PhoneName ?? "";
				foreach (FacebookAccountRow item2 in m_1168)
				{
					if (string.IsNullOrWhiteSpace(item2.PhoneName) && !string.IsNullOrEmpty(text))
					{
						item2.PhoneName = text;
					}
					item2.ProfileChrome = "";
				}
				if (string.IsNullOrEmpty(text) & flag2)
				{
					Task.Run(async () =>
					{
						try
						{
							string A = (await AdbController.ListDevicesAsync()).FirstOrDefault() ?? "";
							if (!string.IsNullOrEmpty(A))
							{
								((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
								{
									foreach (FacebookAccountRow item3 in m_1168)
									{
										if (string.IsNullOrWhiteSpace(item3.PhoneName))
										{
											item3.PhoneName = A;
										}
									}
								}));
							}
						}
						catch
						{
						}
					});
				}
			}
			if (P_0.IsSystem && P_0.Name == "Nuôi nick")
			{
				FeedBrowsingSettings initial = FeedBrowsingSettings.FromJson(m_1168[0].FeedBrowsingSettingsJson);
				FeedBrowsingSettings feedBrowsingSettings = FeedBrowsingSettingsWindow.Show(this, initial);
				if (feedBrowsingSettings == null)
				{
					return;
				}
				string feedBrowsingSettingsJson = feedBrowsingSettings.ToJson();
				foreach (FacebookAccountRow item4 in m_1168)
				{
					item4.ScriptId = P_0.Id;
					item4.ScriptName = P_0.Name;
					item4.FeedBrowsingSettingsJson = feedBrowsingSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Spam nhóm")
			{
				GroupSpamSettings initial2 = GroupSpamSettings.FromJson(m_1168[0].GroupSpamSettingsJson);
				GroupSpamSettings groupSpamSettings = GroupSpamSettingsWindow.Show(this, initial2);
				if (groupSpamSettings == null)
				{
					return;
				}
				string groupSpamSettingsJson = groupSpamSettings.ToJson();
				foreach (FacebookAccountRow item5 in m_1168)
				{
					item5.ScriptId = P_0.Id;
					item5.ScriptName = P_0.Name;
					item5.GroupSpamSettingsJson = groupSpamSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Tạo Page")
			{
				PageCreationSettings initial3 = PageCreationSettings.FromJson(m_1168[0].PageCreationSettingsJson);
				PageCreationSettings pageCreationSettings = PageCreationSettingsWindow.Show(this, initial3);
				if (pageCreationSettings == null)
				{
					return;
				}
				string pageCreationSettingsJson = pageCreationSettings.ToJson();
				foreach (FacebookAccountRow item6 in m_1168)
				{
					item6.ScriptId = P_0.Id;
					item6.ScriptName = P_0.Name;
					item6.PageCreationSettingsJson = pageCreationSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Tạo BM")
			{
				BmCreationSettings initial4 = BmCreationSettings.FromJson(m_1168[0].BmCreationSettingsJson);
				BmCreationSettings bmCreationSettings = BmCreationSettingsWindow.Show(this, initial4);
				if (bmCreationSettings == null)
				{
					return;
				}
				string bmCreationSettingsJson = bmCreationSettings.ToJson();
				foreach (FacebookAccountRow item7 in m_1168)
				{
					item7.ScriptId = P_0.Id;
					item7.ScriptName = P_0.Name;
					item7.BmCreationSettingsJson = bmCreationSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Nhắn tin")
			{
				MessagingSettings initial5 = MessagingSettings.FromJson(m_1168[0].MessagingSettingsJson);
				MessagingSettings messagingSettings = MessagingSettingsWindow.Show(this, initial5);
				if (messagingSettings == null)
				{
					return;
				}
				string messagingSettingsJson = messagingSettings.ToJson();
				foreach (FacebookAccountRow item8 in m_1168)
				{
					item8.ScriptId = P_0.Id;
					item8.ScriptName = P_0.Name;
					item8.MessagingSettingsJson = messagingSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Kết bạn")
			{
				FriendRequestSettings initial6 = FriendRequestSettings.FromJson(m_1168[0].FriendRequestSettingsJson);
				FriendRequestSettings friendRequestSettings = FriendRequestSettingsWindow.Show(this, initial6);
				if (friendRequestSettings == null)
				{
					return;
				}
				string friendRequestSettingsJson = friendRequestSettings.ToJson();
				foreach (FacebookAccountRow item9 in m_1168)
				{
					item9.ScriptId = P_0.Id;
					item9.ScriptName = P_0.Name;
					item9.FriendRequestSettingsJson = friendRequestSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Nuôi bài viết")
			{
				PostBoostSettings initial7 = PostBoostSettings.FromJson(m_1168[0].PostBoostSettingsJson);
				PostBoostSettings postBoostSettings = PostBoostSettingsWindow.Show(this, initial7);
				if (postBoostSettings == null)
				{
					return;
				}
				string postBoostSettingsJson = postBoostSettings.ToJson();
				foreach (FacebookAccountRow item10 in m_1168)
				{
					item10.ScriptId = P_0.Id;
					item10.ScriptName = P_0.Name;
					item10.PostBoostSettingsJson = postBoostSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Đăng bài viết")
			{
				PostCreationSettings initial8 = PostCreationSettings.FromJson(m_1168[0].PostCreationSettingsJson);
				PostCreationSettings postCreationSettings = PostCreationSettingsWindow.Show(this, initial8);
				if (postCreationSettings == null)
				{
					return;
				}
				string postCreationSettingsJson = postCreationSettings.ToJson();
				foreach (FacebookAccountRow item11 in m_1168)
				{
					item11.ScriptId = P_0.Id;
					item11.ScriptName = P_0.Name;
					item11.PostCreationSettingsJson = postCreationSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			if (P_0.IsSystem && P_0.Name == "Đăng bài trên page")
			{
				PagePostSettings initial9 = PagePostSettings.FromJson(m_1168[0].PagePostSettingsJson);
				PagePostSettings pagePostSettings = PagePostSettingsWindow.Show(this, initial9);
				if (pagePostSettings == null)
				{
					return;
				}
				string pagePostSettingsJson = pagePostSettings.ToJson();
				foreach (FacebookAccountRow item12 in m_1168)
				{
					item12.ScriptId = P_0.Id;
					item12.ScriptName = P_0.Name;
					item12.PagePostSettingsJson = pagePostSettingsJson;
				}
				CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
				return;
			}
			foreach (FacebookAccountRow item13 in m_1168)
			{
				item13.ScriptId = P_0.Id;
				item13.ScriptName = P_0.Name;
			}
			CustomMessageBox.Show(this, $"Đã gắn kịch bản \"{P_0.Name}\" ({P_0.Platform}) cho {m_1168.Count} nick.", "Gắn Kịch Bản");
		}
	}

	private void ac()
	{
		if (ScriptCardsToolbarPanel == null)
		{
			return;
		}
		ScriptCardsToolbarPanel.Children.Clear();
		foreach (ScriptItem item in Scripts.Where((ScriptItem P_0) => P_0.ChuDe == "Facebook"))
		{
			ScriptCardsToolbarPanel.Children.Add(m_674(item));
		}
	}

	private Button m_674(ScriptItem P_0)
	{
		(string Glyph, string Accent, string Subtitle) tuple = AttachScriptWindow.m_296(P_0);
		string item = tuple.Glyph;
		string item2 = tuple.Accent;
		string item3 = tuple.Subtitle;
		Color color = (Color)ColorConverter.ConvertFromString(item2);
		FontFamily fontFamily = (FontFamily)FindResource("IconFont");
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(1.0, GridUnitType.Star)
		});
		Border element = new Border
		{
			Width = 4.0,
			Height = 26.0,
			CornerRadius = new CornerRadius(2.0),
			Background = new SolidColorBrush(color),
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(0.0, 0.0, 9.0, 0.0)
		};
		Grid.SetColumn(element, 0);
		grid.Children.Add(element);
		Border element2 = new Border
		{
			Width = 28.0,
			Height = 28.0,
			CornerRadius = new CornerRadius(8.0),
			Background = new SolidColorBrush(color)
			{
				Opacity = 0.18
			},
			VerticalAlignment = VerticalAlignment.Center,
			Child = new TextBlock
			{
				Text = item,
				FontFamily = fontFamily,
				FontSize = 15.0,
				Foreground = new SolidColorBrush(color),
				HorizontalAlignment = HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center
			}
		};
		Grid.SetColumn(element2, 1);
		grid.Children.Add(element2);
		TextBlock element3 = new TextBlock
		{
			Text = P_0.Name,
			FontSize = 12.5,
			FontWeight = FontWeights.SemiBold,
			VerticalAlignment = VerticalAlignment.Center,
			TextTrimming = TextTrimming.CharacterEllipsis
		};
		StackPanel stackPanel = new StackPanel
		{
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(9.0, 0.0, 0.0, 0.0)
		};
		stackPanel.Children.Add(j(P_0.Platform));
		stackPanel.Children.Add(element3);
		Grid.SetColumn(stackPanel, 2);
		grid.Children.Add(stackPanel);
		Button button = new Button();
		button.Style = (Style)FindResource("ScriptCardButtonStyle");
		button.Content = grid;
		button.Width = 224.0;
		button.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		button.Padding = new Thickness(10.0, 8.0, 12.0, 8.0);
		button.ToolTip = item3;
		button.Background = new SolidColorBrush(color)
		{
			Opacity = 0.09
		};
		button.BorderBrush = new SolidColorBrush(color)
		{
			Opacity = 0.55
		};
		button.Click += delegate
		{
			m_673(P_0);
		};
		return button;
	}

	private Border j(string P_0)
	{
		(string, string, string) tuple;
		if (P_0 == "iPhone")
		{
			tuple = ("iPhone", "#9CA3AF", "\ue8ea");
		}
		else
		{
			tuple = ((!(P_0 == "Chrome")) ? ("Android", "#22C55E", "\ue8ea") : ("Chrome", "#4285F4", "\ue774"));
		}
		(string, string, string) tuple2 = tuple;
		string item = tuple2.Item1;
		string item2 = tuple2.Item2;
		string item3 = tuple2.Item3;
		Color color = (Color)ColorConverter.ConvertFromString(item2);
		StackPanel stackPanel = new StackPanel
		{
			Orientation = Orientation.Horizontal
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = item3,
			FontFamily = (FontFamily)FindResource("IconFont"),
			FontSize = 9.0,
			Foreground = new SolidColorBrush(color),
			VerticalAlignment = VerticalAlignment.Center
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = item,
			FontSize = 9.5,
			FontWeight = FontWeights.Bold,
			Foreground = new SolidColorBrush(color),
			Margin = new Thickness(4.0, 0.0, 0.0, 0.0),
			VerticalAlignment = VerticalAlignment.Center
		});
		return new Border
		{
			Background = new SolidColorBrush(color)
			{
				Opacity = 0.16
			},
			BorderBrush = new SolidColorBrush(color)
			{
				Opacity = 0.7
			},
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(9.0),
			Padding = new Thickness(6.0, 1.0, 7.0, 1.0),
			HorizontalAlignment = HorizontalAlignment.Left,
			Margin = new Thickness(0.0, 0.0, 0.0, 3.0),
			Child = stackPanel
		};
	}

	private static bool m_675(ScriptItem? P_0, string? P_1)
	{
		if (P_0 == null || string.IsNullOrWhiteSpace(P_1))
		{
			return false;
		}
		if (string.Equals(P_0.Platform, P_1, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (string.Equals(P_1, "Phone", StringComparison.OrdinalIgnoreCase) && (string.Equals(P_0.Platform, "Android", StringComparison.OrdinalIgnoreCase) || string.Equals(P_0.Platform, "Phone", StringComparison.OrdinalIgnoreCase)))
		{
			return true;
		}
		return false;
	}

	private async void bb(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Chạy kịch bản", NotifyType.Warning);
			return;
		}
		if (list.Any((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform == "Phone" && string.IsNullOrWhiteSpace(facebookAccountRow.PhoneName)))
		{
			try
			{
				string text = (await AdbController.ListDevicesAsync(CancellationToken.None)).FirstOrDefault() ?? "";
				if (!string.IsNullOrEmpty(text))
				{
					foreach (FacebookAccountRow item in list.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform == "Phone" && string.IsNullOrWhiteSpace(facebookAccountRow.PhoneName)))
					{
						item.PhoneName = text;
					}
				}
			}
			catch
			{
			}
		}
		List<FacebookAccountRow> list2 = list.Where((FacebookAccountRow facebookAccountRow) => !string.IsNullOrEmpty(facebookAccountRow.Platform) && facebookAccountRow.ScriptId > 0 && m_675(Scripts.FirstOrDefault((ScriptItem scriptItem) => scriptItem.Id == facebookAccountRow.ScriptId), facebookAccountRow.Platform)).ToList();
		List<FacebookAccountRow> list3 = list.Except(list2).ToList();
		if (list2.Count == 0)
		{
			if (!m_670(list, RunScriptButton))
			{
				CustomMessageBox.Show(this, "Các nick đã chọn chưa gắn Kịch bản đúng nền tảng (Phone/Chrome đã gắn rồi). Bấm \"Gắn Kịch Bản\" hoặc chọn 1 thẻ kịch bản phía dưới.", "Chạy kịch bản", NotifyType.Warning);
			}
			return;
		}
		List<FacebookAccountRow> first = list2.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform == "Phone" && !string.IsNullOrWhiteSpace(facebookAccountRow.PhoneName)).ToList();
		List<FacebookAccountRow> second = list2.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.Platform == "Chrome").ToList();
		List<FacebookAccountRow> m_1180 = first.Concat(second).ToList();
		if (m_1180.Count == 0)
		{
			if (list3.Count > 0)
			{
				CustomMessageBox.Show(this, $"{list3.Count} nick bị bỏ qua vì chưa gắn đủ Phone/Chrome + Kịch bản đúng nền tảng.", "Chạy kịch bản", NotifyType.Warning);
			}
			return;
		}
		m_543 = new CancellationTokenSource();
		CancellationToken m_1181 = m_543.Token;
		RunScriptButton.IsEnabled = false;
		StopScriptButton.IsEnabled = true;
		StopScriptButton.Visibility = Visibility.Visible;
		RunScriptButtonText.Text = $"Đang chạy kịch bản... (0/{m_1180.Count})";
		BaoSamBrowserSettings baoSamBrowserSettings = BaoSamBrowserSettings.Load();
		bool repeatForever = baoSamBrowserSettings.RepeatForever;
		int num = Math.Max(0, baoSamBrowserSettings.RepeatDelaySeconds);
		int initialCount = (m_1180.Any((FacebookAccountRow facebookAccountRow) => string.Equals(facebookAccountRow.Platform, "Chrome", StringComparison.OrdinalIgnoreCase)) ? Math.Max(1, baoSamBrowserSettings.ThreadCount) : Math.Max(1, AiVisionSettings.Load().MaxConcurrentDevices));
		int num2 = 0;
		while (true)
		{
			num2++;
			string m_1205 = (repeatForever ? $" · vòng {num2}" : "");
			Dictionary<FacebookAccountRow, string> m_1206 = m_1180.ToDictionary((FacebookAccountRow result) => result, (FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang);
			foreach (FacebookAccountRow item2 in m_1180)
			{
				item2.TrangThai = "Đang chạy kịch bản...";
				item2.TinhTrang = "";
			}
			int m_1207 = 0;
			SemaphoreSlim A = new SemaphoreSlim(initialCount);
			try
			{
				await Task.WhenAll(((IEnumerable<FacebookAccountRow>)m_1180).Select((Func<FacebookAccountRow, Task>)(async (FacebookAccountRow facebookAccountRow) =>
				{
					try
					{
						await A.WaitAsync(m_1181);
						try
						{
							if (m_1181.IsCancellationRequested)
							{
								facebookAccountRow.TrangThai = "Đã dừng.";
								return;
							}
							ScriptItem scriptItem = Scripts.FirstOrDefault((ScriptItem scriptItem2) => scriptItem2.Id == facebookAccountRow.ScriptId && m_675(scriptItem2, facebookAccountRow.Platform));
							if (scriptItem == null)
							{
								facebookAccountRow.TrangThai = "Chưa gắn kịch bản " + facebookAccountRow.Platform + " cho nick này.";
								return;
							}
							AiVisionFlowDocument aiVisionFlowDocument = AiVisionFlowStore.Deserialize(scriptItem.AiVisionFlowJson);
							List<AiVisionFlowStep> steps = aiVisionFlowDocument.Steps;
							bool flag = true;
							if (scriptItem.IsSystem && scriptItem.Name == "Đăng nhập")
							{
								LoginResult loginResult = await LoginRunnerFactory.GetRunner(facebookAccountRow.Platform, "Katana", (string text2) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
								}).LoginAsync(facebookAccountRow, m_1181);
								m_581(facebookAccountRow, loginResult.TrangThai);
								await m_676(facebookAccountRow, loginResult.TinhTrang, loginResult.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Tạo Page")
							{
								PageCreationSettings pageSettings = PageCreationSettings.FromJson(facebookAccountRow.PageCreationSettingsJson);
								AiVisionRunResult aiVisionRunResult = ((!(facebookAccountRow.Platform == "Phone") && !(facebookAccountRow.Platform == "Android")) ? (await FacebookPageCreationRunner.RunAsync(facebookAccountRow, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181, pageSettings, m_1180.IndexOf(facebookAccountRow))) : (await FacebookKatanaPageCreationService.RunAsync(facebookAccountRow, (string text2) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
								}, m_1181, pageSettings, m_1180.IndexOf(facebookAccountRow))));
								m_581(facebookAccountRow, aiVisionRunResult.Message);
								await m_676(facebookAccountRow, aiVisionRunResult.TinhTrang, aiVisionRunResult.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Tạo BM")
							{
								BmCreationSettings bmSettings = BmCreationSettings.FromJson(facebookAccountRow.BmCreationSettingsJson);
								AiVisionRunResult aiVisionRunResult2 = await FacebookBmCreationRunner.RunAsync(facebookAccountRow, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181, bmSettings, m_1180.IndexOf(facebookAccountRow));
								m_581(facebookAccountRow, aiVisionRunResult2.Message);
								await m_676(facebookAccountRow, aiVisionRunResult2.TinhTrang, aiVisionRunResult2.Success, m_1206[facebookAccountRow]);
							}
							else if (facebookAccountRow.Platform == "Phone" && !scriptItem.IsSystem)
							{
								if (steps.Count == 0)
								{
									facebookAccountRow.TrangThai = "Kịch bản \"" + scriptItem.Name + "\" chưa có bước nào.";
									return;
								}
								if (!string.IsNullOrWhiteSpace(facebookAccountRow.PhoneName))
								{
									await PhoneInitialSetupService.EnsureInitialSetupAsync(facebookAccountRow.PhoneName, scriptItem.Platform ?? "All", (string text2) =>
									{
										((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
									}, m_1181);
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = "Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)..."));
									await AdbController.EnsureEnglishLanguageAsync(facebookAccountRow.PhoneName, m_1181);
								}
								Dictionary<string, string> variables = AiVisionVariables.BuildMap(facebookAccountRow);
								await AiVisionVariables.ResolveVerifyVariablesAsync(variables, steps, m_1181);
								AiVisionRunResult aiVisionRunResult3 = await PhoneAiVisionRunner.RunFlowAsync(DeviceControllerFactory.Resolve(Profiles, facebookAccountRow.PhoneName), steps, variables, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
								}, m_1181);
								m_581(facebookAccountRow, aiVisionRunResult3.Message);
								await m_676(facebookAccountRow, aiVisionRunResult3.TinhTrang, aiVisionRunResult3.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Nuôi nick")
							{
								FeedBrowsingSettings settings = FeedBrowsingSettings.FromJson(facebookAccountRow.FeedBrowsingSettingsJson);
								IReadOnlyCollection<FacebookAccountRow> sessionNicks = m_1180.Where((FacebookAccountRow facebookAccountRow2) => facebookAccountRow2.Platform == "Chrome" && facebookAccountRow2.ScriptId == facebookAccountRow.ScriptId).ToList();
								AiVisionRunResult aiVisionRunResult4 = await FacebookFeedBrowsingRunner.RunAsync(facebookAccountRow, settings, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181, sessionNicks);
								m_581(facebookAccountRow, aiVisionRunResult4.Message);
								await m_676(facebookAccountRow, aiVisionRunResult4.TinhTrang, aiVisionRunResult4.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Spam nhóm")
							{
								GroupSpamSettings settings2 = GroupSpamSettings.FromJson(facebookAccountRow.GroupSpamSettingsJson);
								AiVisionRunResult aiVisionRunResult5 = ((!(facebookAccountRow.Platform == "Phone") && !(facebookAccountRow.Platform == "Android")) ? (await FacebookGroupSpamRunner.RunAsync(facebookAccountRow, settings2, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181)) : (await FacebookKatanaPhoneInteractionService.SpamGroupAsync(facebookAccountRow, settings2, (string text2) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
								}, m_1181)));
								m_581(facebookAccountRow, aiVisionRunResult5.Message);
								await m_676(facebookAccountRow, aiVisionRunResult5.TinhTrang, aiVisionRunResult5.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Nhắn tin")
							{
								MessagingSettings settings3 = MessagingSettings.FromJson(facebookAccountRow.MessagingSettingsJson);
								IReadOnlyCollection<FacebookAccountRow> sessionNicks2 = m_1180.Where((FacebookAccountRow facebookAccountRow2) => facebookAccountRow2.Platform == "Chrome" && facebookAccountRow2.ScriptId == facebookAccountRow.ScriptId).ToList();
								AiVisionRunResult aiVisionRunResult6 = await FacebookMessagingRunner.RunAsync(facebookAccountRow, settings3, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181, sessionNicks2);
								m_581(facebookAccountRow, aiVisionRunResult6.Message);
								await m_676(facebookAccountRow, aiVisionRunResult6.TinhTrang, aiVisionRunResult6.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Kết bạn")
							{
								FriendRequestSettings settings4 = FriendRequestSettings.FromJson(facebookAccountRow.FriendRequestSettingsJson);
								AiVisionRunResult aiVisionRunResult7 = ((!(facebookAccountRow.Platform == "Phone") && !(facebookAccountRow.Platform == "Android")) ? (await FacebookFriendRequestRunner.RunAsync(facebookAccountRow, settings4, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181)) : (await FacebookKatanaPhoneInteractionService.SendFriendRequestsAsync(facebookAccountRow, settings4, (string text2) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
								}, m_1181)));
								m_581(facebookAccountRow, aiVisionRunResult7.Message);
								await m_676(facebookAccountRow, aiVisionRunResult7.TinhTrang, aiVisionRunResult7.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Nuôi bài viết")
							{
								PostBoostSettings settings5 = PostBoostSettings.FromJson(facebookAccountRow.PostBoostSettingsJson);
								AiVisionRunResult aiVisionRunResult8 = ((!(facebookAccountRow.Platform == "Phone") && !(facebookAccountRow.Platform == "Android")) ? (await FacebookPostBoostRunner.RunAsync(facebookAccountRow, settings5, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181)) : (await FacebookKatanaPhoneInteractionService.BoostPostAsync(facebookAccountRow, settings5, (string text2) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
								}, m_1181)));
								m_581(facebookAccountRow, aiVisionRunResult8.Message);
								await m_676(facebookAccountRow, aiVisionRunResult8.TinhTrang, aiVisionRunResult8.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Đăng bài viết")
							{
								PostCreationSettings settings6 = PostCreationSettings.FromJson(facebookAccountRow.PostCreationSettingsJson);
								AiVisionRunResult aiVisionRunResult9 = ((!(facebookAccountRow.Platform == "Phone") && !(facebookAccountRow.Platform == "Android")) ? (await FacebookPostCreationRunner.RunAsync(facebookAccountRow, settings6, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181)) : (await FacebookKatanaPhoneInteractionService.PostToWallAsync(facebookAccountRow, settings6, (string text2) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text2));
								}, m_1181)));
								m_581(facebookAccountRow, aiVisionRunResult9.Message);
								await m_676(facebookAccountRow, aiVisionRunResult9.TinhTrang, aiVisionRunResult9.Success, m_1206[facebookAccountRow]);
							}
							else if (scriptItem.IsSystem && scriptItem.Name == "Đăng bài trên page")
							{
								PagePostSettings settings7 = PagePostSettings.FromJson(facebookAccountRow.PagePostSettingsJson);
								AiVisionRunResult aiVisionRunResult10 = await FacebookPagePostRunner.RunAsync(facebookAccountRow, settings7, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.ActionSummary));
								}, m_1181);
								m_581(facebookAccountRow, aiVisionRunResult10.Message);
								await m_676(facebookAccountRow, aiVisionRunResult10.TinhTrang, aiVisionRunResult10.Success, m_1206[facebookAccountRow]);
							}
							else if (steps.Count > 0)
							{
								Dictionary<string, string> variables = AiVisionVariables.BuildMap(facebookAccountRow);
								await AiVisionVariables.ResolveVerifyVariablesAsync(variables, steps, m_1181);
								AiVisionRunResult aiVisionRunResult11 = await ChromeAiVisionRunner.RunFlowForNickAsync(facebookAccountRow, steps, variables, (AiVisionStepLog aiVisionStepLog) =>
								{
									((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = aiVisionStepLog.FlowStepLabel + aiVisionStepLog.ActionSummary));
								}, m_1181);
								m_581(facebookAccountRow, aiVisionRunResult11.Message);
								await m_676(facebookAccountRow, aiVisionRunResult11.TinhTrang, aiVisionRunResult11.Success, m_1206[facebookAccountRow]);
							}
							else
							{
								HashSet<int> A2 = FacebookAccountDatabase.LoadActionIdsForFolder(scriptItem.Id);
								int value = Actions.Count((InteractionAction interactionAction) => A2.Contains(interactionAction.Id));
								facebookAccountRow.TrangThai = $"Đang chạy: {scriptItem.Name} ({value} hành động) trên Chrome";
								flag = false;
							}
							if (flag)
							{
								facebookAccountRow.TuongTacCuoi = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
							}
						}
						finally
						{
							A.Release();
						}
					}
					catch (OperationCanceledException)
					{
						facebookAccountRow.TrangThai = "Đã dừng.";
						await m_676(facebookAccountRow, "", false, m_1206[facebookAccountRow]);
					}
					catch (Exception ex3)
					{
						m_581(facebookAccountRow, "Lỗi kịch bản: " + ex3.Message);
						await m_676(facebookAccountRow, "", false, m_1206[facebookAccountRow]);
					}
					finally
					{
						Interlocked.Increment(ref m_1207);
						RunScriptButtonText.Text = $"Đang chạy kịch bản... ({m_1207}/{m_1180.Count}){m_1205}";
					}
				})));
				if (!repeatForever || m_1181.IsCancellationRequested)
				{
					break;
				}
				if (num > 0)
				{
					try
					{
						RunScriptButtonText.Text = $"Nghỉ {num}s trước vòng {num2 + 1}...";
						await Task.Delay(TimeSpan.FromSeconds(num), m_1181);
					}
					catch (OperationCanceledException)
					{
						goto end_IL_051d;
					}
				}
				continue;
				end_IL_051d:;
			}
			finally
			{
				if (A != null)
				{
					((IDisposable)A).Dispose();
				}
			}
			break;
		}
		m_543.Dispose();
		m_543 = null;
		RunScriptButton.IsEnabled = true;
		StopScriptButton.Visibility = Visibility.Collapsed;
		RunScriptButtonText.Text = "Bắt Đầu Chạy Kịch Bản";
		if (list3.Count > 0)
		{
			CustomMessageBox.Show(this, $"{list3.Count} nick bị bỏ qua vì chưa gắn đủ Phone/Chrome + Kịch bản đúng nền tảng.", "Chạy kịch bản", NotifyType.Warning);
		}
	}

	private void bC(object P_0, RoutedEventArgs P_1)
	{
		m_543?.Cancel();
		StopScriptButton.IsEnabled = false;
	}

	private async void bc(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = L();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào.", "Đăng nhập", NotifyType.Warning);
			return;
		}
		SelectLoginPlatformDialog selectLoginPlatformDialog = new SelectLoginPlatformDialog(list.Count, this);
		if (selectLoginPlatformDialog.ShowDialog() != true)
		{
			return;
		}
		string m_1273 = selectLoginPlatformDialog.SelectedPlatform;
		string a2 = selectLoginPlatformDialog.SelectedPackageType;
		if (m_1273 == "Chrome")
		{
			foreach (FacebookAccountRow item in list)
			{
				if (string.IsNullOrWhiteSpace(item.ProfileChrome))
				{
					item.ProfileChrome = ((!string.IsNullOrWhiteSpace(item.Uid)) ? item.Uid : $"BaoSamBrowser_{item.Index}_{DateTime.Now:HHmmss}");
				}
			}
		}
		else if (m_1273 == "Phone" && selectLoginPlatformDialog.SelectedPhones.Count > 0)
		{
			for (int i = 0; i < list.Count; i++)
			{
				list[i].PhoneName = selectLoginPlatformDialog.SelectedPhones[i % selectLoginPlatformDialog.SelectedPhones.Count];
				list[i].ProfileChrome = "";
			}
		}
		m_543?.Cancel();
		m_543 = new CancellationTokenSource();
		CancellationToken A = m_543.Token;
		RunScriptButton.IsEnabled = false;
		StopScriptButton.IsEnabled = true;
		StopScriptButton.Visibility = Visibility.Visible;
		RunScriptButtonText.Text = "Đang đăng nhập...";
		try
		{
			int val = AiVisionSettings.Load().MaxConcurrentDevices;
			if (m_1273 == "Phone" && selectLoginPlatformDialog.SelectedPhones.Count > 0)
			{
				val = Math.Max(selectLoginPlatformDialog.SelectedPhones.Count, val);
			}
			int initialCount = Math.Max(1, val);
			SemaphoreSlim m_1275 = new SemaphoreSlim(initialCount);
			try
			{
				await Task.WhenAll(((IEnumerable<FacebookAccountRow>)list).Select((Func<FacebookAccountRow, Task>)(async (FacebookAccountRow facebookAccountRow) =>
				{
					await m_1275.WaitAsync(A);
					try
					{
						facebookAccountRow.TrangThai = "Đang đăng nhập...";
						facebookAccountRow.TinhTrang = "";
						LoginResult loginResult = await LoginRunnerFactory.GetRunner(m_1273, a2, (string text) =>
						{
							((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => facebookAccountRow.TrangThai = text));
						}).LoginAsync(facebookAccountRow, A);
						facebookAccountRow.TinhTrang = loginResult.TinhTrang;
						m_581(facebookAccountRow, loginResult.TrangThai);
					}
					catch (OperationCanceledException)
					{
						facebookAccountRow.TrangThai = "Đã dừng.";
					}
					catch (Exception ex2)
					{
						facebookAccountRow.TinhTrang = "ERROR";
						m_581(facebookAccountRow, "Lỗi đăng nhập: " + ex2.Message);
					}
					finally
					{
						m_1275.Release();
					}
				})));
			}
			finally
			{
				if (m_1275 != null)
				{
					((IDisposable)m_1275).Dispose();
				}
			}
		}
		finally
		{
			m_543?.Dispose();
			m_543 = null;
			RunScriptButton.IsEnabled = true;
			StopScriptButton.Visibility = Visibility.Collapsed;
			RunScriptButtonText.Text = "Bắt Đầu Chạy Kịch Bản";
		}
	}

	private void I(object P_0, MouseButtonEventArgs P_1)
	{
		QuickActionsPopup.IsOpen = true;
	}

	private void bD(object P_0, RoutedEventArgs P_1)
	{
		bool flag = FacebookToolbarWrapPanel.Visibility == Visibility.Visible;
		FacebookToolbarWrapPanel.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		ToolbarCollapseToggleIcon.Text = (flag ? "▽" : "△");
	}

	private void bd(object P_0, RoutedEventArgs P_1)
	{
		m_638(ExportImportFilePopup, P_0, ExportImportFileButton);
	}

	private void bE(object P_0, RoutedEventArgs P_1)
	{
		ExportImportFilePopup.IsOpen = false;
		if (Facebooks.Count == 0)
		{
			CustomMessageBox.Show(this, "Không có nick nào để xuất.", "Xuất file", NotifyType.Warning);
			return;
		}
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "BaoSamNuoi Nick Export (*.json)|*.json",
			FileName = $"nick_export_{DateTime.Now:yyyyMMdd_HHmmss}.json"
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			List<FacebookExportItem> list = Facebooks.Select((FacebookAccountRow facebookAccountRow) => new FacebookExportItem
			{
				FolderName = (Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == facebookAccountRow.FolderId)?.Name ?? ""),
				PhoneName = facebookAccountRow.PhoneName,
				ScriptFolderName = facebookAccountRow.ScriptName,
				Uid = facebookAccountRow.Uid,
				Pass = facebookAccountRow.Pass,
				TwoFA = facebookAccountRow.TwoFA,
				Token = facebookAccountRow.Token,
				Cookie = facebookAccountRow.Cookie,
				Mail = facebookAccountRow.Mail,
				PassMail = facebookAccountRow.PassMail,
				MailKhoiPhuc = facebookAccountRow.MailKhoiPhuc,
				PassMailKhoiPhuc = facebookAccountRow.PassMailKhoiPhuc,
				BanBe = facebookAccountRow.BanBe,
				Nhom = facebookAccountRow.Nhom,
				GioiTinh = facebookAccountRow.GioiTinh,
				Avatar = facebookAccountRow.Avatar,
				ProfileChrome = facebookAccountRow.ProfileChrome,
				TenProfile = facebookAccountRow.TenProfile,
				UserAgent = facebookAccountRow.UserAgent,
				Proxy = facebookAccountRow.Proxy,
				TepCu = facebookAccountRow.TepCu,
				GhiChu = facebookAccountRow.GhiChu,
				TuongTacCuoi = facebookAccountRow.TuongTacCuoi,
				TrangThai = facebookAccountRow.TrangThai,
				TinhTrang = facebookAccountRow.TinhTrang
			}).ToList();
			string contents = JsonSerializer.Serialize(list, new JsonSerializerOptions
			{
				WriteIndented = true
			});
			File.WriteAllText(saveFileDialog.FileName, contents);
			CustomMessageBox.Show(this, $"Đã xuất {list.Count} nick ra file:\n{saveFileDialog.FileName}", "Xuất file");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể xuất file: " + ex.Message, "Xuất file", NotifyType.Warning);
		}
	}

	private void be(object P_0, RoutedEventArgs P_1)
	{
		ExportImportFilePopup.IsOpen = false;
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "BaoSamNuoi Nick Export (*.json)|*.json|Tất cả file (*.*)|*.*"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			List<FacebookExportItem> list = JsonSerializer.Deserialize<List<FacebookExportItem>>(File.ReadAllText(openFileDialog.FileName));
			if (list == null || list.Count == 0)
			{
				CustomMessageBox.Show(this, "File không có dữ liệu hợp lệ.", "Nạp file", NotifyType.Warning);
				return;
			}
			int num = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.IsSystem && nickFolder3.Id > 0)?.Id ?? (-1);
			int num2 = Facebooks.Count + 1;
			List<FacebookAccountRow> list2 = new List<FacebookAccountRow>(list.Count);
			foreach (FacebookExportItem A in list)
			{
				int folderId = num;
				if (!string.IsNullOrWhiteSpace(A.FolderName))
				{
					NickFolder nickFolder = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.Id > 0 && nickFolder3.Name == A.FolderName);
					if (nickFolder == null)
					{
						try
						{
							NickFolder nickFolder2 = FacebookAccountDatabase.CreateFolder(A.FolderName);
							Folders.Insert(Folders.Count - 1, nickFolder2);
							nickFolder = nickFolder2;
						}
						catch
						{
						}
					}
					if (nickFolder != null)
					{
						folderId = nickFolder.Id;
					}
				}
				int scriptId = 0;
				string scriptName = "";
				if (!string.IsNullOrWhiteSpace(A.ScriptFolderName))
				{
					scriptId = Scripts.FirstOrDefault((ScriptItem scriptItem) => scriptItem.Name == A.ScriptFolderName)?.Id ?? 0;
					scriptName = A.ScriptFolderName;
				}
				list2.Add(new FacebookAccountRow
				{
					Index = num2++,
					FolderId = folderId,
					PhoneName = A.PhoneName,
					ScriptId = scriptId,
					ScriptName = scriptName,
					Uid = A.Uid,
					Pass = A.Pass,
					TwoFA = A.TwoFA,
					Token = A.Token,
					Cookie = A.Cookie,
					Mail = A.Mail,
					PassMail = A.PassMail,
					MailKhoiPhuc = A.MailKhoiPhuc,
					PassMailKhoiPhuc = A.PassMailKhoiPhuc,
					BanBe = A.BanBe,
					Nhom = A.Nhom,
					GioiTinh = A.GioiTinh,
					Avatar = A.Avatar,
					ProfileChrome = A.ProfileChrome,
					TenProfile = A.TenProfile,
					UserAgent = A.UserAgent,
					Proxy = A.Proxy,
					TepCu = A.TepCu,
					GhiChu = A.GhiChu,
					TuongTacCuoi = A.TuongTacCuoi,
					TrangThai = A.TrangThai,
					TinhTrang = A.TinhTrang
				});
			}
			m_583(list2);
			T();
			g();
			H();
			CustomMessageBox.Show(this, $"Đã nạp {list.Count} nick từ file.", "Nạp file");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể nạp file: " + ex.Message, "Nạp file", NotifyType.Warning);
		}
	}

	private async void bF(object P_0, RoutedEventArgs P_1)
	{
		ExportImportFilePopup.IsOpen = false;
		GoogleSheetsSyncSettings googleSheetsSyncSettings = GoogleSheetsSyncSettings.Load();
		if (string.IsNullOrWhiteSpace(googleSheetsSyncSettings.SpreadsheetId) || string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientId) || string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientSecret))
		{
			CustomMessageBox.Show(this, "Chưa cấu hình Google Trang tính. Vào \"Cài đặt > Cài đặt đồng bộ Google Sheets\" để thiết lập trước.", "Nạp từ Google Trang tính", NotifyType.Warning);
			return;
		}
		ExportImportFileButton.IsEnabled = false;
		try
		{
			using SheetsService service = await GoogleSheetsSyncService.AuthorizeAsync(googleSheetsSyncSettings, CancellationToken.None);
			Dictionary<string, List<FacebookAccountRow>> dictionary = await GoogleSheetsSyncService.ImportAllSheetsAsync(service, googleSheetsSyncSettings.SpreadsheetId, CancellationToken.None);
			int num = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.IsSystem && nickFolder3.Id > 0)?.Id ?? (-1);
			int num2 = Facebooks.Count + 1;
			int num3 = 0;
			int num4 = 0;
			List<FacebookAccountRow> list = new List<FacebookAccountRow>();
			foreach (KeyValuePair<string, List<FacebookAccountRow>> A in dictionary)
			{
				if (A.Value.Count == 0)
				{
					continue;
				}
				NickFolder nickFolder = Folders.FirstOrDefault((NickFolder nickFolder3) => nickFolder3.Id > 0 && nickFolder3.Name == A.Key);
				if (nickFolder == null)
				{
					try
					{
						NickFolder nickFolder2 = FacebookAccountDatabase.CreateFolder(A.Key);
						Folders.Insert(Folders.Count - 1, nickFolder2);
						nickFolder = nickFolder2;
					}
					catch
					{
					}
				}
				int folderId = nickFolder?.Id ?? num;
				num4++;
				foreach (FacebookAccountRow A2 in A.Value)
				{
					if (!string.IsNullOrWhiteSpace(A2.ScriptName))
					{
						ScriptItem scriptItem = Scripts.FirstOrDefault((ScriptItem scriptItem2) => scriptItem2.Name == A2.ScriptName);
						A2.ScriptId = scriptItem?.Id ?? 0;
					}
					A2.Index = num2++;
					A2.FolderId = folderId;
					list.Add(A2);
					num3++;
				}
			}
			m_583(list);
			T();
			g();
			H();
			if (num3 == 0)
			{
				CustomMessageBox.Show(this, "Không tìm thấy nick nào trong Google Trang tính.", "Nạp từ Google Trang tính", NotifyType.Warning);
				return;
			}
			CustomMessageBox.Show(this, $"Đã nạp {num3} nick từ {num4} trang tính (thư mục).", "Nạp từ Google Trang tính");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể nạp từ Google Trang tính: " + ex.Message, "Nạp từ Google Trang tính", NotifyType.Warning);
		}
		finally
		{
			ExportImportFileButton.IsEnabled = true;
		}
	}

	private static async Task m_676(FacebookAccountRow P_0, string? runnerTinhTrang, bool P_2, string P_3)
	{
		if (runnerTinhTrang == "LIVE" || runnerTinhTrang == "DIE")
		{
			P_0.TinhTrang = runnerTinhTrang;
			return;
		}
		if (P_2)
		{
			P_0.TinhTrang = "LIVE";
			return;
		}
		string text = await FacebookLiveChecker.CheckAsync(P_0.Uid);
		P_0.TinhTrang = ((text != "") ? text : P_3);
	}

	private static Task<string> K(string P_0)
	{
		return FacebookLiveChecker.CheckAsync(P_0);
	}

	private async void bf(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> m_1296 = (from facebookAccountRow in L()
			where !string.IsNullOrWhiteSpace(facebookAccountRow.Uid)
			select facebookAccountRow).ToList();
		if (m_1296.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào (hoặc UID trống).", "Check Live UID", NotifyType.Warning);
			return;
		}
		CheckLiveButton.IsEnabled = false;
		CheckLiveButtonText.Text = $"Đang kiểm tra... (0/{m_1296.Count})";
		Dictionary<FacebookAccountRow, string> m_1297 = m_1296.ToDictionary((FacebookAccountRow result) => result, (FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang);
		foreach (FacebookAccountRow item in m_1296)
		{
			item.TinhTrang = "Đang kiểm tra...";
		}
		int m_1298 = 0;
		SemaphoreSlim A = new SemaphoreSlim(500);
		try
		{
			await Task.WhenAll(((IEnumerable<FacebookAccountRow>)m_1296).Select((Func<FacebookAccountRow, Task>)(async (FacebookAccountRow facebookAccountRow) =>
			{
				await A.WaitAsync();
				try
				{
					string text2 = await K(facebookAccountRow.Uid);
					facebookAccountRow.TinhTrang = ((text2 != "") ? text2 : m_1297[facebookAccountRow]);
				}
				finally
				{
					A.Release();
					Interlocked.Increment(ref m_1298);
					CheckLiveButtonText.Text = $"Đang kiểm tra... ({m_1298}/{m_1296.Count})";
				}
			})));
			CheckLiveButton.IsEnabled = true;
			CheckLiveButtonText.Text = "Check Live UID";
			int num = m_1296.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "LIVE");
			int num2 = m_1296.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "DIE");
			int num3 = m_1296.Count - num - num2;
			string text = $"Đã kiểm tra {m_1296.Count} UID: {num} LIVE, {num2} DIE.";
			if (num3 > 0)
			{
				text += $"\n{num3} nick không kiểm tra được (mất mạng hoặc Facebook chặn tạm thời) - giữ nguyên tình trạng cũ, thử lại sau.";
			}
			CustomMessageBox.Show(this, text, "Check Live UID", (num3 > 0) ? NotifyType.Warning : NotifyType.Success);
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private static async Task<(string TinhTrang, string TrangThai)> m_677(FacebookAccountRow P_0, CancellationToken P_1 = default(CancellationToken))
	{
		string text = P_0.Cookie?.Trim() ?? "";
		string text2 = P_0.Uid?.Trim() ?? "";
		string text3 = P_0.Proxy?.Trim() ?? "";
		if (string.IsNullOrWhiteSpace(text2) && !string.IsNullOrWhiteSpace(text))
		{
			Match match = Regex.Match(text, "c_user=(\\d+)");
			if (match.Success)
			{
				P_0.Uid = match.Groups[1].Value;
				text2 = P_0.Uid;
			}
		}
		if (string.IsNullOrWhiteSpace(text))
		{
			if (!string.IsNullOrWhiteSpace(text2))
			{
				string text4 = await K(text2);
				if ((text4 == "LIVE" || text4 == "DIE") ? true : false)
				{
					return (TinhTrang: text4, TrangThai: "Không có Cookie (UID: " + text4 + ")");
				}
				return (TinhTrang: "ERROR", TrangThai: "Không có Cookie (Check UID không xác định)");
			}
			return (TinhTrang: "ERROR", TrangThai: "Trống cả Cookie lẫn UID");
		}
		if (!text.Contains("c_user=") && !text.Contains("xs="))
		{
			return (TinhTrang: "Cookie die", TrangThai: "DIE: Cookie die (thiếu c_user/xs)");
		}
		try
		{
			SocketsHttpHandler socketsHttpHandler = new SocketsHttpHandler
			{
				AllowAutoRedirect = false,
				ConnectTimeout = TimeSpan.FromSeconds(10L),
				PooledConnectionLifetime = TimeSpan.FromMinutes(2L)
			};
			if (!string.IsNullOrWhiteSpace(text3))
			{
				ProxyParseResult proxyParseResult = ProxyParser.Parse(text3);
				if (proxyParseResult.IsValid && !string.IsNullOrEmpty(proxyParseResult.Host))
				{
					string value = proxyParseResult.Scheme ?? "http";
					string value2;
					if (proxyParseResult.Host.StartsWith('['))
					{
						value2 = proxyParseResult.Host;
					}
					else
					{
						value2 = (proxyParseResult.Host.Contains(':') ? ("[" + proxyParseResult.Host + "]") : proxyParseResult.Host);
					}
					WebProxy webProxy = new WebProxy($"{value}://{value2}:{proxyParseResult.Port}");
					if (!string.IsNullOrEmpty(proxyParseResult.User))
					{
						webProxy.Credentials = new NetworkCredential(proxyParseResult.User, proxyParseResult.Pass ?? "");
					}
					socketsHttpHandler.Proxy = webProxy;
					socketsHttpHandler.UseProxy = true;
				}
			}
			using HttpClient httpClient = new HttpClient(socketsHttpHandler)
			{
				Timeout = TimeSpan.FromSeconds(15L)
			};
			m_787 obj = default;
			obj.A = text.Replace("\r", "").Replace("\n", "").Trim();
			int num = obj.A.IndexOf(';');
			if (num > 0)
			{
				string text5 = obj.A.Substring(0, num);
				if (text5.Contains('|'))
				{
					obj.A = obj.A.Substring(text5.LastIndexOf('|') + 1).Trim();
				}
			}
			using HttpRequestMessage request = m_702("https://www.facebook.com/confirmemail.php", false, ref obj);
			using HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(request, P_1);
			int statusCode = (int)httpResponseMessage.StatusCode;
			string text6 = httpResponseMessage.Headers.Location?.ToString() ?? "";
			string text7 = text6.ToLowerInvariant();
			int num2 = statusCode;
			if (((uint)(num2 - 301) <= 2u || (uint)(num2 - 307) <= 1u) ? true : false)
			{
				if (text7.Contains("confirmemail") || text7.Contains("confirm_email") || text7.Contains("confirm_contact") || text7.Contains("enter_code"))
				{
					return (TinhTrang: "NOVERY", TrangThai: "NOVERY: Chờ xác minh (" + text6 + ")");
				}
				if (text7.Contains("/checkpoint/") || text7.Contains("checkpoint") || text7.Contains("disabled") || text7.Contains("suspended") || text7.Contains("601051028565049") || text7.Contains("/282") || text7.Contains("/956"))
				{
					return (TinhTrang: "CHECKPOINT", TrangThai: "CHECKPOINT: Tài khoản bị khoá (" + text6 + ")");
				}
				if (text7.Contains("/login") || text7.Contains("login.php") || text7.Contains("recover"))
				{
					return (TinhTrang: "DIE", TrangThai: "DIE: Cookie die / Đã đăng xuất (" + text6 + ")");
				}
				return (TinhTrang: "LIVE", TrangThai: "LIVE: Đã verify (" + text6 + ")");
			}
			if (statusCode == 200)
			{
				if (httpResponseMessage.Headers.TryGetValues("set-login", out IEnumerable<string> values) && values.Any((string text12) => text12.Contains("logged-out")))
				{
					return (TinhTrang: "DIE", TrangThai: "DIE: Cookie die / Đã đăng xuất");
				}
				string text8 = (await httpResponseMessage.Content.ReadAsStringAsync(P_1)).ToLowerInvariant();
				if (text8.Contains("/checkpoint/") || text8.Contains("tài khoản của bạn đã bị") || text8.Contains("tài khoản bị vô hiệu hóa") || text8.Contains("account has been disabled"))
				{
					return (TinhTrang: "CHECKPOINT", TrangThai: "CHECKPOINT: Tài khoản bị khoá");
				}
				if (text8.Contains("enter_code") || text8.Contains("nhập mã xác nhận") || text8.Contains("xác nhận email"))
				{
					return (TinhTrang: "NOVERY", TrangThai: "NOVERY: Trang chờ xác nhận mã");
				}
				if (text8.Contains("name=\"login\"") || text8.Contains("login_form") || text8.Contains("isloggedouthomepage") || text8.Contains("\"actorid\":\"0\""))
				{
					return (TinhTrang: "DIE", TrangThai: "DIE: Cookie die / Hết hạn");
				}
				return (TinhTrang: "LIVE", TrangThai: "LIVE: Đã verify (Hoạt động bình thường)");
			}
			using HttpRequestMessage request2 = m_702("https://m.facebook.com/confirmemail.php", true, ref obj);
			using HttpResponseMessage httpResponseMessage2 = await httpClient.SendAsync(request2, P_1);
			int statusCode2 = (int)httpResponseMessage2.StatusCode;
			string text9 = httpResponseMessage2.Headers.Location?.ToString() ?? "";
			string text10 = text9.ToLowerInvariant();
			if (((uint)(statusCode2 - 301) <= 2u || (uint)(statusCode2 - 307) <= 1u) ? true : false)
			{
				if (text10.Contains("confirmemail") || text10.Contains("confirm_email") || text10.Contains("confirm_contact") || text10.Contains("enter_code"))
				{
					return (TinhTrang: "NOVERY", TrangThai: "NOVERY: Chờ xác minh (" + text9 + ")");
				}
				if (text10.Contains("/checkpoint/") || text10.Contains("checkpoint") || text10.Contains("disabled") || text10.Contains("suspended"))
				{
					return (TinhTrang: "CHECKPOINT", TrangThai: "CHECKPOINT: Tài khoản bị khoá (" + text9 + ")");
				}
				if (text10.Contains("/login") || text10.Contains("login.php") || text10.Contains("recover"))
				{
					return (TinhTrang: "DIE", TrangThai: "DIE: Cookie die / Đã đăng xuất (" + text9 + ")");
				}
				return (TinhTrang: "LIVE", TrangThai: "LIVE: Đã verify (" + text9 + ")");
			}
			if (statusCode2 == 200)
			{
				string text11 = (await httpResponseMessage2.Content.ReadAsStringAsync(P_1)).ToLowerInvariant();
				if (text11.Contains("enter_code") || text11.Contains("nhập mã"))
				{
					return (TinhTrang: "NOVERY", TrangThai: "NOVERY: Trang chờ xác nhận mã");
				}
				if (text11.Contains("login_form") || text11.Contains("name=\"login\""))
				{
					return (TinhTrang: "DIE", TrangThai: "DIE: Cookie die");
				}
				return (TinhTrang: "LIVE", TrangThai: "LIVE: Đã verify");
			}
			return (TinhTrang: "DIE", TrangThai: $"DIE: Cookie không phản hồi hợp lệ (HTTP {statusCode})");
		}
		catch (OperationCanceledException)
		{
			return (TinhTrang: "ERROR", TrangThai: "Đã dừng.");
		}
		catch (Exception ex2)
		{
			return (TinhTrang: "ERROR", TrangThai: "Lỗi kết nối: " + ex2.Message);
		}
	}

	private async void bG(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> m_1306 = L();
		if (m_1306.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn tài khoản nào để kiểm tra.", "Check tài khoản novery", NotifyType.Warning);
			return;
		}
		CheckNoveryButton.IsEnabled = false;
		CheckNoveryButtonText.Text = $"Đang check... (0/{m_1306.Count})";
		foreach (FacebookAccountRow item3 in m_1306)
		{
			item3.TrangThai = "Đang check novery...";
		}
		int m_1307 = 0;
		SemaphoreSlim A = new SemaphoreSlim(50);
		try
		{
			await Task.WhenAll(((IEnumerable<FacebookAccountRow>)m_1306).Select((Func<FacebookAccountRow, Task>)(async (FacebookAccountRow facebookAccountRow) =>
			{
				await A.WaitAsync();
				try
				{
					(string, string) tuple = await m_677(facebookAccountRow);
					string item = tuple.Item1;
					string item2 = tuple.Item2;
					facebookAccountRow.TinhTrang = item;
					facebookAccountRow.TrangThai = item2;
					((DispatcherObject)this).Dispatcher.Invoke((Action)h);
				}
				catch (Exception ex)
				{
					facebookAccountRow.TinhTrang = "ERROR";
					facebookAccountRow.TrangThai = "Lỗi: " + ex.Message;
				}
				finally
				{
					A.Release();
					int A2 = Interlocked.Increment(ref m_1307);
					((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
					{
						CheckNoveryButtonText.Text = $"Đang check... ({A2}/{m_1306.Count})";
					}));
				}
			})));
			CheckNoveryButton.IsEnabled = true;
			CheckNoveryButtonText.Text = "Check Novery";
			int value = m_1306.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "NOVERY");
			int value2 = m_1306.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "LIVE");
			int num = m_1306.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "CHECKPOINT");
			int num2 = m_1306.Count((FacebookAccountRow facebookAccountRow) =>
			{
				string tinhTrang = facebookAccountRow.TinhTrang;
				return (tinhTrang == "Cookie die" || tinhTrang == "COOKIE DIE") ? true : false;
			});
			int num3 = m_1306.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "DIE");
			int num4 = m_1306.Count((FacebookAccountRow facebookAccountRow) => facebookAccountRow.TinhTrang == "ERROR");
			CustomMessageBox.Show(this, $"Đã kiểm tra {m_1306.Count} tài khoản:\n• NOVERY: {value}\n• LIVE: {value2}\n• CHECKPOINT: {num}\n" + ((num2 > 0) ? $"• Cookie die: {num2}\n" : "") + $"• DIE: {num3}\n" + $"• LỖI: {num4}", "Check tài khoản novery", (num > 0 || num3 > 0 || num2 > 0 || num4 > 0) ? NotifyType.Warning : NotifyType.Success);
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private async void bg(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> list = (from facebookAccountRow in L()
			where !string.IsNullOrWhiteSpace(facebookAccountRow.TwoFA)
			select facebookAccountRow).ToList();
		if (list.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào có mã 2FA.", "Lấy mã 2FA", NotifyType.Warning);
			return;
		}
		GetTwoFaCodesButton.IsEnabled = false;
		GetTwoFaCodesButtonText.Text = "Đang lấy mã...";
		List<(string, string)> list2;
		try
		{
			list2 = (await Task.WhenAll(list.Select((FacebookAccountRow facebookAccountRow) => Task.Run(() => (Uid: facebookAccountRow.Uid, Code: PlaywrightHumanHelpers.Get2fa(facebookAccountRow.TwoFA)))))).ToList();
		}
		finally
		{
			GetTwoFaCodesButton.IsEnabled = true;
			GetTwoFaCodesButtonText.Text = "Lấy mã 2FA";
		}
		List<(string, string)> list3 = list2.Where(((string Uid, string Code) r) => !string.IsNullOrEmpty(r.Code)).ToList();
		List<(string, string)> list4 = list2.Where(((string Uid, string Code) r) => string.IsNullOrEmpty(r.Code)).ToList();
		if (list3.Count == 1 && list4.Count == 0)
		{
			try
			{
				Clipboard.SetText(list3[0].Item2);
			}
			catch
			{
			}
			CustomMessageBox.Show(this, $"Mã 2FA của {list3[0].Item1}: {list3[0].Item2}\n(đã copy vào clipboard)", "Lấy mã 2FA");
			return;
		}
		if (list3.Count > 0)
		{
			try
			{
				Clipboard.SetText(string.Join("\n", list3.Select(((string Uid, string Code) r) => r.Uid + ": " + r.Code)));
			}
			catch
			{
			}
		}
		string text = $"Lấy được {list3.Count}/{list2.Count} mã 2FA, đã copy vào clipboard.";
		if (list4.Count > 0)
		{
			text += $"\n{list4.Count} nick lỗi (sai định dạng mã 2FA): {string.Join(", ", list4.Select(((string Uid, string Code) tuple) => tuple.Uid))}";
		}
		CustomMessageBox.Show(this, text, "Lấy mã 2FA", (list4.Count > 0) ? NotifyType.Warning : NotifyType.Success);
	}

	private static async Task<(string HoTen, string GioiTinh, string Avatar)?> k(string P_0)
	{
		_ = 1;
		try
		{
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, "https://www.facebook.com/api/graphql/");
			httpRequestMessage.Headers.Add("Accept", "*/*");
			httpRequestMessage.Headers.Add("user-agent", "PostmanRuntime/7.44.0");
			string content = "av=0&__user=0&__a=1&__req=d&__hs=19636.HYP:comet_loggedout_pkg.2.1..0.0&dpr=1&__ccg=EXCELLENT&__rev=1009086898&__s=3ai6vg:qpbb2x:x37bfx&__hsi=7286826221441572666&__comet_req=15&lsd=AVr8nKD5yZc&jazoest=2937&__aaid=0&__spin_r=1009086898&__spin_b=trunk&__spin_t=1696596439&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=ProfileCometHeaderQuery&variables={\"scale\":1,\"selectedID\":\"" + P_0 + "\",\"selectedSpaceType\":\"community\",\"selectedTab\":\"" + P_0 + "\",\"shouldUseFXIMProfilePicEditor\":false,\"userID\":\"" + P_0 + "\"}&server_timestamps=true&doc_id=7079717428714436";
			httpRequestMessage.Content = new StringContent(content, Encoding.UTF8, "application/x-www-form-urlencoded");
			string text = await (await m_544.SendAsync(httpRequestMessage)).Content.ReadAsStringAsync();
			if (!text.Contains("name"))
			{
				return null;
			}
			string item = L(m_678(text, "User\",\"name\":\"", "\""));
			string text2 = m_678(text, "\"gender\":\"", "\"");
			string text3;
			if (text2 == "MALE")
			{
				text3 = "NAM GIỚI";
			}
			else
			{
				text3 = ((!(text2 == "FEMALE")) ? "KHÔNG RÕ" : "NỮ GIỚI");
			}
			string item2 = text3;
			string item3 = (text.Contains("2781666950760530985") ? "KHÔNG" : "CÓ");
			return (item, item2, item3);
		}
		catch
		{
			return null;
		}
	}

	private static string m_678(string P_0, string P_1, string P_2)
	{
		int num = P_0.IndexOf(P_1, StringComparison.Ordinal);
		if (num < 0)
		{
			return "";
		}
		num += P_1.Length;
		int num2 = P_0.IndexOf(P_2, num, StringComparison.Ordinal);
		if (num2 >= 0)
		{
			int num3 = num;
			return P_0.Substring(num3, num2 - num3);
		}
		return "";
	}

	private static string L(string P_0)
	{
		if (string.IsNullOrEmpty(P_0))
		{
			return P_0;
		}
		try
		{
			return JsonSerializer.Deserialize<string>("\"" + P_0 + "\"") ?? P_0;
		}
		catch
		{
			return P_0;
		}
	}

	private async void bH(object P_0, RoutedEventArgs P_1)
	{
		List<FacebookAccountRow> m_1319 = (from facebookAccountRow in L()
			where !string.IsNullOrWhiteSpace(facebookAccountRow.Uid)
			select facebookAccountRow).ToList();
		if (m_1319.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn nick nào (hoặc UID trống).", "Check Họ tên/Avatar/Giới tính", NotifyType.Warning);
			return;
		}
		CheckProfileInfoButton.IsEnabled = false;
		CheckProfileInfoButtonText.Text = $"Đang check... (0/{m_1319.Count})";
		foreach (FacebookAccountRow item in m_1319)
		{
			item.TrangThai = "Đang check họ tên/avatar/giới tính...";
		}
		int a2 = 0;
		int m_1320 = 0;
		SemaphoreSlim A = new SemaphoreSlim(500);
		try
		{
			await Task.WhenAll(((IEnumerable<FacebookAccountRow>)m_1319).Select((Func<FacebookAccountRow, Task>)(async (FacebookAccountRow facebookAccountRow) =>
			{
				await A.WaitAsync();
				try
				{
					(string, string, string)? tuple = await k(facebookAccountRow.Uid);
					if (!tuple.HasValue)
					{
						facebookAccountRow.TrangThai = "Không lấy được thông tin (UID sai hoặc bị chặn).";
					}
					else
					{
						facebookAccountRow.HoTen = tuple.Value.Item1;
						facebookAccountRow.GioiTinh = tuple.Value.Item2;
						facebookAccountRow.Avatar = tuple.Value.Item3;
						facebookAccountRow.TrangThai = "Đã check xong họ tên/avatar/giới tính.";
						Interlocked.Increment(ref m_1320);
					}
				}
				catch (Exception ex)
				{
					facebookAccountRow.TrangThai = "Lỗi kết nối: " + ex.Message;
				}
				finally
				{
					A.Release();
					Interlocked.Increment(ref a2);
					CheckProfileInfoButtonText.Text = $"Đang check... ({a2}/{m_1319.Count})";
				}
			})));
			CheckProfileInfoButton.IsEnabled = true;
			CheckProfileInfoButtonText.Text = "Check Họ tên/Avatar/Giới tính";
			CustomMessageBox.Show(this, $"Đã check {m_1319.Count} nick: {m_1320} thành công, {m_1319.Count - m_1320} lỗi.", "Check Họ tên/Avatar/Giới tính", (m_1320 != m_1319.Count) ? NotifyType.Warning : NotifyType.Success);
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private static void m_679(ComboBox P_0, int P_1)
	{
		P_0.SelectedItem = null;
		foreach (ComboBoxItem item in (IEnumerable)P_0.Items)
		{
			if (item.Tag?.ToString() == P_1.ToString())
			{
				P_0.SelectedItem = item;
				break;
			}
		}
		if (P_0.SelectedItem == null)
		{
			object obj = (P_0.SelectedItem = P_0.Items[0]);
		}
	}

	private static int m_680(ComboBox P_0, int P_1)
	{
		if (!int.TryParse((P_0.SelectedItem as ComboBoxItem)?.Tag?.ToString(), out var result))
		{
			return P_1;
		}
		return result;
	}

	private void aD()
	{
		m_545 = true;
		BaoSamBrowserSettings baoSamBrowserSettings = BaoSamBrowserSettings.Load();
		BaoSamApiUrlTextBox.Text = baoSamBrowserSettings.ApiUrl;
		BaoSamThreadCountTextBox.Text = baoSamBrowserSettings.ThreadCount.ToString();
		BaoSamAdditionArgsTextBox.Text = baoSamBrowserSettings.AdditionArgs;
		BaoSamUseCustomUserAgentCheck.IsChecked = baoSamBrowserSettings.UseCustomUserAgent;
		BaoSamCustomUserAgentTextBox.Text = baoSamBrowserSettings.CustomUserAgent;
		BaoSamCustomUserAgentTextBox.IsEnabled = baoSamBrowserSettings.UseCustomUserAgent;
		BaoSamStartupUrlsTextBox.Text = baoSamBrowserSettings.StartupUrls;
		m_679(BaoSamOsTypeCombo, baoSamBrowserSettings.OsType);
		m_679(BaoSamWebrtcModeCombo, baoSamBrowserSettings.WebrtcMode);
		m_679(BaoSamGeolocationModeCombo, baoSamBrowserSettings.GeolocationMode);
		m_679(BaoSamCanvasModeCombo, baoSamBrowserSettings.CanvasMode);
		m_679(BaoSamClientRectModeCombo, baoSamBrowserSettings.ClientRectMode);
		m_679(BaoSamWebglImageModeCombo, baoSamBrowserSettings.WebglImageMode);
		m_679(BaoSamWebglMetadataModeCombo, baoSamBrowserSettings.WebglMetadataMode);
		m_679(BaoSamAudioModeCombo, baoSamBrowserSettings.AudioMode);
		m_679(BaoSamFontModeCombo, baoSamBrowserSettings.FontMode);
		BaoSamIsMaskedMediaCheck.IsChecked = baoSamBrowserSettings.IsMaskedMedia;
		BaoSamTimezoneBaseOnIpCheck.IsChecked = baoSamBrowserSettings.TimezoneBaseOnIp;
		BaoSamTimezoneTextBox.Text = baoSamBrowserSettings.Timezone;
		BaoSamTimezoneTextBox.IsEnabled = !baoSamBrowserSettings.TimezoneBaseOnIp;
		BaoSamIsLanguageBaseOnIpCheck.IsChecked = baoSamBrowserSettings.IsLanguageBaseOnIp;
		BaoSamFixedLanguageTextBox.Text = baoSamBrowserSettings.FixedLanguage;
		BaoSamFixedLanguageTextBox.IsEnabled = !baoSamBrowserSettings.IsLanguageBaseOnIp;
		(baoSamBrowserSettings.LoginType switch
		{
			"CookieThenUidPass" => (ToggleButton)BaoSamLoginTypeCookieThenUidPassRadio, 
			"UidPass" => BaoSamLoginTypeUidPassRadio, 
			"MailPass" => BaoSamLoginTypeMailPassRadio, 
			_ => BaoSamLoginTypeCookieRadio, 
		}).IsChecked = true;
		BaoSamAutoCloseChromeCheck.IsChecked = baoSamBrowserSettings.AutoCloseChromeAfterLogin;
		BaoSamSaveNewCookieCheck.IsChecked = baoSamBrowserSettings.SaveNewCookieAfterLogin;
		BaoSamUseProxyCheck.IsChecked = baoSamBrowserSettings.UseProxy;
		BaoSamRepeatForeverCheck.IsChecked = baoSamBrowserSettings.RepeatForever;
		BaoSamRepeatDelayTextBox.Text = baoSamBrowserSettings.RepeatDelaySeconds.ToString();
		BaoSamStatusText.Text = "";
		BaoSamTestResultText.Visibility = Visibility.Collapsed;
		m_545 = false;
	}

	private void ad()
	{
		if (!m_545 && BaoSamTimezoneTextBox != null)
		{
			BaoSamBrowserSettings baoSamBrowserSettings = BaoSamBrowserSettings.Load();
			baoSamBrowserSettings.ApiUrl = BaoSamApiUrlTextBox.Text.Trim();
			baoSamBrowserSettings.ThreadCount = ((!int.TryParse(BaoSamThreadCountTextBox.Text.Trim(), out var result) || result <= 0) ? 1 : result);
			baoSamBrowserSettings.AdditionArgs = BaoSamAdditionArgsTextBox.Text.Trim();
			baoSamBrowserSettings.UseCustomUserAgent = BaoSamUseCustomUserAgentCheck.IsChecked == true;
			baoSamBrowserSettings.CustomUserAgent = BaoSamCustomUserAgentTextBox.Text.Trim();
			baoSamBrowserSettings.StartupUrls = BaoSamStartupUrlsTextBox.Text.Trim();
			baoSamBrowserSettings.OsType = m_680(BaoSamOsTypeCombo, 1);
			baoSamBrowserSettings.WebrtcMode = m_680(BaoSamWebrtcModeCombo, 1);
			baoSamBrowserSettings.GeolocationMode = m_680(BaoSamGeolocationModeCombo, 2);
			baoSamBrowserSettings.CanvasMode = m_680(BaoSamCanvasModeCombo, 1);
			baoSamBrowserSettings.ClientRectMode = m_680(BaoSamClientRectModeCombo, 1);
			baoSamBrowserSettings.WebglImageMode = m_680(BaoSamWebglImageModeCombo, 1);
			baoSamBrowserSettings.WebglMetadataMode = m_680(BaoSamWebglMetadataModeCombo, 1);
			baoSamBrowserSettings.AudioMode = m_680(BaoSamAudioModeCombo, 1);
			baoSamBrowserSettings.FontMode = m_680(BaoSamFontModeCombo, 1);
			baoSamBrowserSettings.IsMaskedMedia = BaoSamIsMaskedMediaCheck.IsChecked == true;
			baoSamBrowserSettings.TimezoneBaseOnIp = BaoSamTimezoneBaseOnIpCheck.IsChecked == true;
			baoSamBrowserSettings.Timezone = BaoSamTimezoneTextBox.Text.Trim();
			baoSamBrowserSettings.IsLanguageBaseOnIp = BaoSamIsLanguageBaseOnIpCheck.IsChecked == true;
			baoSamBrowserSettings.FixedLanguage = BaoSamFixedLanguageTextBox.Text.Trim();
			BaoSamBrowserSettings baoSamBrowserSettings2 = baoSamBrowserSettings;
			string loginType;
			if (BaoSamLoginTypeCookieThenUidPassRadio.IsChecked == true)
			{
				loginType = "CookieThenUidPass";
			}
			else if (BaoSamLoginTypeUidPassRadio.IsChecked == true)
			{
				loginType = "UidPass";
			}
			else
			{
				loginType = ((BaoSamLoginTypeMailPassRadio.IsChecked == true) ? "MailPass" : "Cookie");
			}
			baoSamBrowserSettings2.LoginType = loginType;
			baoSamBrowserSettings.AutoCloseChromeAfterLogin = BaoSamAutoCloseChromeCheck.IsChecked == true;
			baoSamBrowserSettings.SaveNewCookieAfterLogin = BaoSamSaveNewCookieCheck.IsChecked == true;
			baoSamBrowserSettings.UseProxy = BaoSamUseProxyCheck.IsChecked == true;
			baoSamBrowserSettings.RepeatForever = BaoSamRepeatForeverCheck.IsChecked == true;
			baoSamBrowserSettings.RepeatDelaySeconds = ((int.TryParse(BaoSamRepeatDelayTextBox.Text, out var result2) && result2 >= 0) ? result2 : 30);
			baoSamBrowserSettings.Save();
			BaoSamStatusText.Text = $"Đã tự động lưu lúc {DateTime.Now:HH:mm:ss}.";
		}
	}

	private void bh(object P_0, RoutedEventArgs P_1)
	{
		if (BaoSamCustomUserAgentTextBox != null)
		{
			BaoSamCustomUserAgentTextBox.IsEnabled = BaoSamUseCustomUserAgentCheck.IsChecked == true;
			ad();
		}
	}

	private void bI(object P_0, RoutedEventArgs P_1)
	{
		if (BaoSamTimezoneTextBox != null)
		{
			BaoSamTimezoneTextBox.IsEnabled = BaoSamTimezoneBaseOnIpCheck.IsChecked != true;
			ad();
		}
	}

	private void bi(object P_0, RoutedEventArgs P_1)
	{
		if (BaoSamFixedLanguageTextBox != null)
		{
			BaoSamFixedLanguageTextBox.IsEnabled = BaoSamIsLanguageBaseOnIpCheck.IsChecked != true;
			ad();
		}
	}

	private void bJ(object P_0, RoutedEventArgs P_1)
	{
		ad();
	}

	private void bj(object P_0, RoutedEventArgs P_1)
	{
		ad();
	}

	private void m_681(object P_0, SelectionChangedEventArgs P_1)
	{
		ad();
	}

	private async void bK(object P_0, RoutedEventArgs P_1)
	{
		ad();
		BaoSamBrowserSettings baoSamBrowserSettings = BaoSamBrowserSettings.Load();
		BaoSamTestButton.IsEnabled = false;
		BaoSamTestResultText.Visibility = Visibility.Visible;
		BaoSamTestResultText.Text = "Đang kiểm tra " + baoSamBrowserSettings.ApiUrl + "...";
		bool flag = await new BaoSamApiClient(baoSamBrowserSettings).CheckApiAliveAsync();
		BaoSamTestResultText.Text = (flag ? ("Kết nối được BaoSam Browser tại " + baoSamBrowserSettings.ApiUrl + ".") : ("Không kết nối được " + baoSamBrowserSettings.ApiUrl + ". Mở app BaoSam Browser, bật Local API và kiểm tra lại đúng cổng."));
		BaoSamTestButton.IsEnabled = true;
	}

	private void bk(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://toolregclone.com",
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể mở liên kết: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void bL(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://toolbanquyenbaosam.com",
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể mở liên kết: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void bl(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is FrameworkElement { ContextMenu: not null } frameworkElement)
		{
			frameworkElement.ContextMenu.PlacementTarget = frameworkElement;
			frameworkElement.ContextMenu.Placement = PlacementMode.Top;
			frameworkElement.ContextMenu.IsOpen = true;
		}
	}

	private void bM(object P_0, RoutedEventArgs P_1)
	{
		m_682("https://t.me/+cWEyauqERe5mNWI1", "Nhóm Telegram hỗ trợ (Nhóm 1)");
	}

	private void bm(object P_0, RoutedEventArgs P_1)
	{
		m_682("https://t.me/baosamteam", "Bảo Sâm Team (@baosamteam)");
	}

	private void m_682(string P_0, string P_1)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = P_0,
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không mở được nhóm Telegram: " + ex.Message + "\nTự vào: " + P_0, P_1, NotifyType.Warning);
		}
	}

	private void bN(object P_0, RoutedEventArgs P_1)
	{
		string username = LicenseSettings.Load().Username;
		string text = (string.IsNullOrWhiteSpace(username) ? "-" : username);
		string title;
		string text2;
		NotifyType type;
		if (!LicenseClient.HasVerifiedLicense)
		{
			title = "Chưa xác định được gói";
			text2 = "App chưa xác thực xong với máy chủ. Kiểm tra lại mạng rồi thử lại sau ít phút.";
			type = NotifyType.Warning;
		}
		else if (LicenseClient.IsPhoneAiPaid)
		{
			title = "Bản VIP (Pro)";
			text2 = "Tài khoản đã mua bản quyền - mở khoá vĩnh viễn, gồm cả AI Vision cho Phone.";
			type = NotifyType.Success;
		}
		else if (LicenseClient.IsPhoneAiTrialActive)
		{
			title = "Bản VIP vĩnh viễn (Đã Crack)";
			text2 = "Tài khoản đã được bẻ khoá vĩnh viễn, dùng không giới hạn ngày. Mở khoá tất cả các tính năng VIP.";
			type = NotifyType.Success;
		}
		else
		{
			title = "Bản VIP vĩnh viễn (Đã Crack)";
			text2 = "Tài khoản đã được bẻ khoá vĩnh viễn, dùng không giới hạn ngày. Mở khoá tất cả các tính năng VIP.";
			type = NotifyType.Warning;
		}
		CustomMessageBox.Show(this, "Tài khoản: " + text + "\n\n" + text2, title, type);
	}

	private void bn(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Clipboard.SetText(LicenseClient.GetHardwareId());
			CustomMessageBox.Show(this, "Đã copy mã kích hoạt máy vào clipboard. Gửi mã này cho admin để được kích hoạt.", "Mã kích hoạt");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không lấy được mã kích hoạt: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void bO(object P_0, RoutedEventArgs P_1)
	{
		if (CustomMessageBox.Confirm(this, "Đăng xuất tài khoản hiện tại?", "Đăng xuất"))
		{
			new LicenseSettings().Save();
			try
			{
				string fileName = Process.GetCurrentProcess().MainModule.FileName;
				Process.Start(new ProcessStartInfo
				{
					FileName = fileName,
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				CustomMessageBox.Show(this, "Không tự mở lại được tool, hãy tự mở lại thủ công: " + ex.Message, "Đăng xuất", NotifyType.Warning);
			}
			Application.Current.Shutdown();
		}
	}

	private void m_683(bool P_0)
	{
		if (m_508 != P_0)
		{
			m_508 = P_0;
			SidebarColumn.Width = new GridLength(P_0 ? 96 : 240);
			Resources["SidebarTextVisibility"] = (P_0 ? Visibility.Collapsed : Visibility.Visible);
			aE();
			ae();
		}
	}

	private void aE()
	{
	}

	private void ae()
	{
		if (SidebarFolderPanel != null)
		{
			bool flag;
			switch (G)
			{
			case "Facebook":
			case "Gmail":
			case "TikTok":
			case "Hotmail":
				flag = true;
				break;
			default:
				flag = false;
				break;
			}
			bool flag2 = flag;
			SidebarFolderPanel.Visibility = ((!flag2 || m_508) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void i(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.ClickCount == 2)
		{
			aF();
		}
		else if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void bo(object P_0, RoutedEventArgs P_1)
	{
		WindowState = WindowState.Minimized;
	}

	private void bP(object P_0, RoutedEventArgs P_1)
	{
		aF();
	}

	private void aF()
	{
		if (WindowState == WindowState.Maximized)
		{
			WindowState = WindowState.Normal;
			MaximizeButton.Content = "\ue922";
		}
		else
		{
			WindowState = WindowState.Maximized;
			MaximizeButton.Content = "\ue923";
		}
	}

	private void m_684(object P_0, EventArgs P_1)
	{
		MaximizeButton.Content = ((WindowState == WindowState.Maximized) ? "\ue923" : "\ue922");
		aE();
	}

	private void bp(object P_0, RoutedEventArgs P_1)
	{
		Close();
	}

	private async void bQ(object P_0, RoutedEventArgs P_1)
	{
		await af();
	}

	private async Task af()
	{
		List<string> list = await GetConnectedDevices();
		Profiles.Clear();
		int num = 1;
		foreach (string item in list)
		{
			Profiles.Add(new ProfileRow
			{
				Index = num++,
				Name = item,
				OS = "Android",
				Status = "Đã kết nối"
			});
		}
		if (!IPhoneController.IsToolAvailable)
		{
			return;
		}
		List<string> list2 = await IPhoneController.ListDevicesAsync();
		bool flag = list2.Count > 0;
		if (flag)
		{
			flag = await IPhoneController.IsWdaReadyAsync();
		}
		bool flag2 = flag;
		foreach (string item2 in list2)
		{
			Profiles.Add(new ProfileRow
			{
				Index = num++,
				Name = "iPhone (" + item2 + ")",
				OS = "iOS",
				Status = (flag2 ? "WebDriverAgent sẵn sàng" : "Đã cắm - chưa bật WebDriverAgent")
			});
		}
	}

	private void bq(object P_0, RoutedEventArgs P_1)
	{
		if (AndroidActionPanel != null && IPhoneActionPanel != null)
		{
			bool flag = (PhoneTabAndroidRadio?.IsChecked == true);
			AndroidActionPanel.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
			IPhoneActionPanel.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private async void bR(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> m_1330 = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		if (m_1330.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn máy nào (tick ở cột CHỌN MÁY).", "Cài đặt ban đầu", NotifyType.Warning);
			return;
		}
		m_546 = new CancellationTokenSource();
		CancellationToken m_1331 = m_546.Token;
		InitialSetupButton.IsEnabled = false;
		StopInitialSetupButton.Visibility = Visibility.Visible;
		StopInitialSetupButton.IsEnabled = true;
		InitialSetupButtonText.Text = $"Đang cài đặt... (0/{m_1330.Count})";
		int a2 = 0;
		int m_1332 = 0;
		SemaphoreSlim A = new SemaphoreSlim(3);
		try
		{
			await Task.WhenAll(((IEnumerable<ProfileRow>)m_1330).Select((Func<ProfileRow, Task>)(async (ProfileRow profileRow) =>
			{
				await A.WaitAsync(m_1331);
				try
				{
					await PhoneInitialSetupService.RunAsync(profileRow.Name, (string text) =>
					{
						((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = text));
					}, m_1331);
				}
				catch (OperationCanceledException)
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đã dừng."));
				}
				catch (Exception ex2)
				{
					Exception ex3 = ex2;
					Exception A2 = ex3;
					Interlocked.Increment(ref m_1332);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Lỗi: " + A2.Message));
				}
				finally
				{
					A.Release();
					Interlocked.Increment(ref a2);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => InitialSetupButtonText.Text = $"Đang cài đặt... ({a2}/{m_1330.Count})"));
				}
			})));
			m_546.Dispose();
			m_546 = null;
			InitialSetupButton.IsEnabled = true;
			StopInitialSetupButton.Visibility = Visibility.Collapsed;
			InitialSetupButtonText.Text = "Cài đặt";
			CustomMessageBox.Show(this, $"Đã cài đặt ban đầu xong {m_1330.Count} máy" + ((m_1332 > 0) ? $" ({m_1332} máy lỗi)." : "."), "Cài đặt ban đầu", (m_1332 > 0) ? NotifyType.Warning : NotifyType.Success);
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private void br(object P_0, RoutedEventArgs P_1)
	{
		m_546?.Cancel();
		StopInitialSetupButton.IsEnabled = false;
	}

	private async void bS(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> m_1351 = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		if (m_1351.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn máy nào (tick ở cột CHỌN MÁY).", "Cài đặt app apk", NotifyType.Warning);
			return;
		}
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "File cài đặt Android (*.apk)|*.apk|Tất cả file (*.*)|*.*"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		string m_1352 = openFileDialog.FileName;
		m_547 = new CancellationTokenSource();
		CancellationToken m_1353 = m_547.Token;
		InstallApkButton.IsEnabled = false;
		StopInstallApkButton.Visibility = Visibility.Visible;
		StopInstallApkButton.IsEnabled = true;
		InstallApkButtonText.Text = $"Đang cài đặt... (0/{m_1351.Count})";
		int a2 = 0;
		int m_1354 = 0;
		SemaphoreSlim A = new SemaphoreSlim(3);
		try
		{
			await Task.WhenAll(((IEnumerable<ProfileRow>)m_1351).Select((Func<ProfileRow, Task>)(async (ProfileRow profileRow) =>
			{
				await A.WaitAsync(m_1353);
				try
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đang cài app..."));
					await AdbController.InstallApkAsync(profileRow.Name, m_1352, m_1353);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đã cài app xong."));
				}
				catch (OperationCanceledException)
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đã dừng."));
				}
				catch (Exception ex2)
				{
					Exception ex3 = ex2;
					Exception A2 = ex3;
					Interlocked.Increment(ref m_1354);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Lỗi: " + A2.Message));
				}
				finally
				{
					A.Release();
					Interlocked.Increment(ref a2);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => InstallApkButtonText.Text = $"Đang cài đặt... ({a2}/{m_1351.Count})"));
				}
			})));
			m_547.Dispose();
			m_547 = null;
			InstallApkButton.IsEnabled = true;
			StopInstallApkButton.Visibility = Visibility.Collapsed;
			InstallApkButtonText.Text = "Cài APK";
			CustomMessageBox.Show(this, $"Đã cài {Path.GetFileName(m_1352)} xong cho {m_1351.Count} máy" + ((m_1354 > 0) ? $" ({m_1354} máy lỗi)." : "."), "Cài đặt app apk", (m_1354 > 0) ? NotifyType.Warning : NotifyType.Success);
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private void bs(object P_0, RoutedEventArgs P_1)
	{
		m_547?.Cancel();
		StopInstallApkButton.IsEnabled = false;
	}

	private async void bT(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> list = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		await m_685(list);
	}

	private async void bt(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> list = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		if (list.Count == 0 && ProfilesGrid.SelectedItem is ProfileRow item)
		{
			list = new List<ProfileRow> { item };
		}
		await m_685(list);
	}

	private void bU(object P_0, RoutedEventArgs P_1)
	{
		m_548?.Cancel();
		StopGetKatanaTokenButton.IsEnabled = false;
	}

	private async Task m_685(List<ProfileRow> P_0)
	{
		if (P_0.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn máy nào (tick ở cột CHỌN MÁY).", "Lấy Cookie/Token Katana", NotifyType.Warning);
			return;
		}
		List<ProfileRow> m_1369 = P_0.Where((ProfileRow profileRow) => !string.Equals(profileRow.OS, "iOS", StringComparison.OrdinalIgnoreCase)).ToList();
		foreach (ProfileRow item in P_0.Where((ProfileRow profileRow) => string.Equals(profileRow.OS, "iOS", StringComparison.OrdinalIgnoreCase)))
		{
			item.Status = "Bỏ qua (chỉ hỗ trợ Android root).";
		}
		if (m_1369.Count == 0)
		{
			CustomMessageBox.Show(this, "Tính năng lấy Cookie/Token Katana chỉ dành cho thiết bị Android (đã root).", "Lấy Cookie/Token Katana", NotifyType.Warning);
			return;
		}
		m_548 = new CancellationTokenSource();
		CancellationToken m_1370 = m_548.Token;
		GetKatanaTokenButton.IsEnabled = false;
		StopGetKatanaTokenButton.Visibility = Visibility.Visible;
		StopGetKatanaTokenButton.IsEnabled = true;
		GetKatanaTokenButtonText.Text = $"Đang lấy... (0/{m_1369.Count})";
		int a2 = 0;
		int m_1371 = 0;
		List<KatanaSessionResult> m_1372 = new List<KatanaSessionResult>();
		object m_1373 = new object();
		SemaphoreSlim A = new SemaphoreSlim(3);
		try
		{
			await Task.WhenAll(((IEnumerable<ProfileRow>)m_1369).Select((Func<ProfileRow, Task>)(async (ProfileRow profileRow) =>
			{
				await A.WaitAsync(m_1370);
				try
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đang lấy Cookie/Token Katana..."));
					KatanaSessionResult A2 = await AdbController.GetKatanaTokenAndCookieAsync(profileRow.Name, m_1370);
					if (!A2.Success)
					{
						KatanaSessionResult katanaSessionResult = await AdbController.GetFbLiteTokenAndCookieAsync(profileRow.Name, m_1370);
						if (katanaSessionResult.Success)
						{
							A2 = katanaSessionResult;
						}
					}
					if (A2.Success)
					{
						((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
						{
							ProfileRow profileRow2 = profileRow;
							string status = ((!string.IsNullOrEmpty(A2.Uid)) ? ("Lấy thành công: " + A2.Uid) : ((!string.IsNullOrEmpty(A2.Token)) ? "Lấy thành công Token" : "Lấy thành công"));
							profileRow2.Status = status;
							FacebookAccountRow facebookAccountRow = Facebooks.FirstOrDefault((FacebookAccountRow facebookAccountRow2) => (!string.IsNullOrEmpty(A2.Uid) && facebookAccountRow2.Uid == A2.Uid) || facebookAccountRow2.PhoneName == profileRow.Name);
							if (facebookAccountRow != null)
							{
								if (!string.IsNullOrEmpty(A2.Uid))
								{
									facebookAccountRow.Uid = A2.Uid;
								}
								if (!string.IsNullOrEmpty(A2.Token))
								{
									facebookAccountRow.Token = A2.Token;
								}
								if (!string.IsNullOrEmpty(A2.Cookie))
								{
									facebookAccountRow.Cookie = A2.Cookie;
								}
							}
						}));
						lock (m_1373)
						{
							m_1372.Add(A2);
						}
					}
					else
					{
						Interlocked.Increment(ref m_1371);
						((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Lỗi: " + A2.ErrorMessage));
					}
				}
				catch (OperationCanceledException)
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đã dừng."));
				}
				catch (Exception ex2)
				{
					Exception ex3 = ex2;
					Exception A3 = ex3;
					Interlocked.Increment(ref m_1371);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Lỗi: " + A3.Message));
				}
				finally
				{
					A.Release();
					Interlocked.Increment(ref a2);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => GetKatanaTokenButtonText.Text = $"Đang lấy... ({a2}/{m_1369.Count})"));
				}
			})));
			m_548.Dispose();
			m_548 = null;
			GetKatanaTokenButton.IsEnabled = true;
			StopGetKatanaTokenButton.Visibility = Visibility.Collapsed;
			GetKatanaTokenButtonText.Text = "Lấy Katana";
			if (m_1372.Count > 0)
			{
				try
				{
					string text = Path.Combine(AppContext.BaseDirectory, "dulieu");
					Directory.CreateDirectory(text);
					string path = Path.Combine(text, "TokenKatana.txt");
					List<string> list = m_1372.Select((KatanaSessionResult katanaSessionResult) => $"{katanaSessionResult.Uid}|{katanaSessionResult.Token}|{katanaSessionResult.Cookie}").ToList();
					File.AppendAllLines(path, list);
					Clipboard.SetText(string.Join(Environment.NewLine, list));
				}
				catch
				{
				}
				CustomMessageBox.Show(this, $"Đã lấy Cookie/Token Katana thành công {m_1372.Count}/{m_1369.Count} máy" + ((m_1371 > 0) ? $" ({m_1371} máy lỗi)." : ".\n") + "Kết quả đã được copy vào Clipboard và lưu vào dulieu/TokenKatana.txt", "Lấy Cookie/Token Katana", (m_1371 > 0) ? NotifyType.Warning : NotifyType.Success);
			}
			else
			{
				CustomMessageBox.Show(this, $"Không lấy được Cookie/Token Katana ({m_1371} máy lỗi / chưa root / chưa đăng nhập Katana).", "Lấy Cookie/Token Katana", NotifyType.Warning);
			}
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private async void bu(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> list = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		await m_686(list);
	}

	private async void bV(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> list = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		if (list.Count == 0 && ProfilesGrid.SelectedItem is ProfileRow item)
		{
			list = new List<ProfileRow> { item };
		}
		await m_686(list);
	}

	private void bv(object P_0, RoutedEventArgs P_1)
	{
		m_549?.Cancel();
		StopGetFbLiteTokenButton.IsEnabled = false;
	}

	private async Task m_686(List<ProfileRow> P_0)
	{
		if (P_0.Count == 0)
		{
			CustomMessageBox.Show(this, "Chưa chọn máy nào (tick ở cột CHỌN MÁY).", "Lấy Cookie/Token FB Lite", NotifyType.Warning);
			return;
		}
		List<ProfileRow> m_1394 = P_0.Where((ProfileRow profileRow) => !string.Equals(profileRow.OS, "iOS", StringComparison.OrdinalIgnoreCase)).ToList();
		foreach (ProfileRow item in P_0.Where((ProfileRow profileRow) => string.Equals(profileRow.OS, "iOS", StringComparison.OrdinalIgnoreCase)))
		{
			item.Status = "Bỏ qua (chỉ hỗ trợ Android root).";
		}
		if (m_1394.Count == 0)
		{
			CustomMessageBox.Show(this, "Tính năng lấy Cookie/Token FB Lite chỉ dành cho thiết bị Android (đã root).", "Lấy Cookie/Token FB Lite", NotifyType.Warning);
			return;
		}
		m_549 = new CancellationTokenSource();
		CancellationToken m_1395 = m_549.Token;
		GetFbLiteTokenButton.IsEnabled = false;
		StopGetFbLiteTokenButton.Visibility = Visibility.Visible;
		StopGetFbLiteTokenButton.IsEnabled = true;
		GetFbLiteTokenButtonText.Text = $"Đang lấy... (0/{m_1394.Count})";
		int a2 = 0;
		int m_1396 = 0;
		List<KatanaSessionResult> m_1397 = new List<KatanaSessionResult>();
		object m_1398 = new object();
		SemaphoreSlim A = new SemaphoreSlim(3);
		try
		{
			await Task.WhenAll(((IEnumerable<ProfileRow>)m_1394).Select((Func<ProfileRow, Task>)(async (ProfileRow profileRow) =>
			{
				await A.WaitAsync(m_1395);
				try
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đang lấy Cookie/Token FB Lite..."));
					KatanaSessionResult A2 = await AdbController.GetFbLiteTokenAndCookieAsync(profileRow.Name, m_1395);
					if (!A2.Success)
					{
						KatanaSessionResult katanaSessionResult = await AdbController.GetKatanaTokenAndCookieAsync(profileRow.Name, m_1395);
						if (katanaSessionResult.Success)
						{
							A2 = katanaSessionResult;
						}
					}
					if (A2.Success)
					{
						((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
						{
							ProfileRow profileRow2 = profileRow;
							string status = ((!string.IsNullOrEmpty(A2.Uid)) ? ("Lấy thành công: " + A2.Uid) : ((!string.IsNullOrEmpty(A2.Token)) ? "Lấy thành công Token" : "Lấy thành công"));
							profileRow2.Status = status;
							FacebookAccountRow facebookAccountRow = Facebooks.FirstOrDefault((FacebookAccountRow facebookAccountRow2) => (!string.IsNullOrEmpty(A2.Uid) && facebookAccountRow2.Uid == A2.Uid) || facebookAccountRow2.PhoneName == profileRow.Name);
							if (facebookAccountRow != null)
							{
								if (!string.IsNullOrEmpty(A2.Uid))
								{
									facebookAccountRow.Uid = A2.Uid;
								}
								if (!string.IsNullOrEmpty(A2.Token))
								{
									facebookAccountRow.Token = A2.Token;
								}
								if (!string.IsNullOrEmpty(A2.Cookie))
								{
									facebookAccountRow.Cookie = A2.Cookie;
								}
							}
						}));
						lock (m_1398)
						{
							m_1397.Add(A2);
						}
					}
					else
					{
						Interlocked.Increment(ref m_1396);
						((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Lỗi: " + A2.ErrorMessage));
					}
				}
				catch (OperationCanceledException)
				{
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Đã dừng."));
				}
				catch (Exception ex2)
				{
					Exception ex3 = ex2;
					Exception A3 = ex3;
					Interlocked.Increment(ref m_1396);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => profileRow.Status = "Lỗi: " + A3.Message));
				}
				finally
				{
					A.Release();
					Interlocked.Increment(ref a2);
					((DispatcherObject)this).Dispatcher.Invoke<string>((Func<string>)(() => GetFbLiteTokenButtonText.Text = $"Đang lấy... ({a2}/{m_1394.Count})"));
				}
			})));
			m_549.Dispose();
			m_549 = null;
			GetFbLiteTokenButton.IsEnabled = true;
			StopGetFbLiteTokenButton.Visibility = Visibility.Collapsed;
			GetFbLiteTokenButtonText.Text = "Lấy FB Lite";
			if (m_1397.Count > 0)
			{
				try
				{
					string text = Path.Combine(AppContext.BaseDirectory, "dulieu");
					Directory.CreateDirectory(text);
					string path = Path.Combine(text, "TokenFBLite.txt");
					List<string> list = m_1397.Select((KatanaSessionResult katanaSessionResult) => $"{katanaSessionResult.Uid}|{katanaSessionResult.Token}|{katanaSessionResult.Cookie}").ToList();
					File.AppendAllLines(path, list);
					Clipboard.SetText(string.Join(Environment.NewLine, list));
				}
				catch
				{
				}
				CustomMessageBox.Show(this, $"Đã lấy Cookie/Token FB Lite thành công {m_1397.Count}/{m_1394.Count} máy" + ((m_1396 > 0) ? $" ({m_1396} máy lỗi)." : ".\n") + "Kết quả đã được copy vào Clipboard và lưu vào dulieu/TokenFBLite.txt", "Lấy Cookie/Token FB Lite", (m_1396 > 0) ? NotifyType.Warning : NotifyType.Success);
			}
			else
			{
				CustomMessageBox.Show(this, $"Không lấy được Cookie/Token FB Lite ({m_1396} máy lỗi / chưa root / chưa đăng nhập FB Lite).", "Lấy Cookie/Token FB Lite", NotifyType.Warning);
			}
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private async void bW(object P_0, RoutedEventArgs P_1)
	{
		ResetAdbServerButton.IsEnabled = false;
		ResetAdbServerButtonText.Text = "Đang khởi động lại...";
		try
		{
			await AdbController.RestartServerAsync(CancellationToken.None);
			await af();
			CustomMessageBox.Show(this, $"Đã khởi động lại adb server - tìm thấy {Profiles.Count} máy.", "Reset server adb");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Lỗi khi khởi động lại adb server: " + ex.Message, "Reset server adb", NotifyType.Warning);
		}
		finally
		{
			ResetAdbServerButton.IsEnabled = true;
			ResetAdbServerButtonText.Text = "Reset ADB";
		}
	}

	private void bw(object P_0, RoutedEventArgs P_1)
	{
		IPhoneSetupWindow phoneSetupWindow = new IPhoneSetupWindow();
		phoneSetupWindow.Owner = this;
		phoneSetupWindow.ShowDialog();
	}

	private void bX(object P_0, RoutedEventArgs P_1)
	{
		foreach (ProfileRow item in ProfilesGrid.SelectedItems.Cast<ProfileRow>().ToList())
		{
			item.IsSelected = true;
		}
	}

	private void bx(object P_0, RoutedEventArgs P_1)
	{
		foreach (ProfileRow item in ProfilesGrid.SelectedItems.Cast<ProfileRow>().ToList())
		{
			item.IsSelected = false;
		}
	}

	private void bY(object P_0, RoutedEventArgs P_1)
	{
		foreach (ProfileRow profile in Profiles)
		{
			profile.IsSelected = true;
		}
	}

	private void m_687(object P_0, RoutedEventArgs P_1)
	{
		foreach (ProfileRow profile in Profiles)
		{
			profile.IsSelected = false;
		}
	}

	private void J(object P_0, MouseButtonEventArgs P_1)
	{
		object originalSource = P_1.OriginalSource;
		DependencyObject val = (DependencyObject)((originalSource is DependencyObject) ? originalSource : null);
		while (val != null && !(val is DataGridRow) && !(val is CheckBox))
		{
			val = VisualTreeHelper.GetParent(val);
		}
		if (!(val is CheckBox))
		{
			while (val != null && !(val is DataGridRow))
			{
				val = VisualTreeHelper.GetParent(val);
			}
			if (val is DataGridRow { Item: ProfileRow item })
			{
				item.IsSelected = !item.IsSelected;
			}
		}
	}

	private void bZ(object P_0, RoutedEventArgs P_1)
	{
		List<ProfileRow> list = Profiles.Where((ProfileRow profileRow) => profileRow.IsSelected).ToList();
		CustomMessageBox.Show(this, (list.Count == 0) ? "Chưa chọn máy nào." : ("Sẽ thao tác với máy: " + string.Join(", ", list.Select((ProfileRow profileRow) => profileRow.Name))), "Test Hàm");
	}

	public async Task<List<string>> GetConnectedDevices()
	{
		devices.Clear();
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = AdbController.AdbExePath,
			Arguments = "devices",
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			UseShellExecute = false,
			CreateNoWindow = true
		};
		try
		{
			using Process process = new Process();
			process.StartInfo = startInfo;
			process.Start();
			string text = process.StandardOutput.ReadToEnd();
			process.WaitForExit();
			string[] array = text.Split(new string[1] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < array.Length; i++)
			{
				Match match = Regex.Match(array[i], "^(?<device>\\S+)\\s+device$");
				if (match.Success)
				{
					string value = match.Groups["device"].Value;
					devices.Add(value);
				}
			}
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không thể chạy adb.exe: " + ex.Message, "Lỗi tìm phone", NotifyType.Warning);
		}
		return devices;
	}

	private void bz(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			string text = Environment.ProcessPath ?? Process.GetCurrentProcess().MainModule?.FileName;
			if (!string.IsNullOrEmpty(text))
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = text,
					UseShellExecute = true
				});
			}
			((DispatcherObject)Application.Current).Dispatcher.Invoke((Action)(() =>
			{
				Application.Current.Shutdown();
			}));
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "10.0.11.0")]
	internal Delegate m_688(Type P_0, string P_1)
	{
		return Delegate.CreateDelegate(P_0, this, P_1);
	}

	[CompilerGenerated]
	private void m_691(object? _, NotifyCollectionChangedEventArgs P_1)
	{
		ac();
	}

	[CompilerGenerated]
	private void l(string P_0)
	{
		((DispatcherObject)this).Dispatcher.Invoke((Action)(() =>
		{
			new LicenseSettings().Save();
			CustomMessageBox.Show(this, P_0, "Xác thực license", NotifyType.Warning);
			Application.Current.Shutdown();
		}));
	}

	[CompilerGenerated]
	internal static string m_692(string P_0, ref m_808 P_1)
	{
		if (!P_1.A)
		{
			return m_519[P_0].Vi;
		}
		return m_519[P_0].En;
	}

	[CompilerGenerated]
	private bool m_693(object P_0)
	{
		if (P_0 is ScriptItem scriptItem && (scriptItem.Platform == B || (B == "Android" && scriptItem.Platform == "Phone")) && scriptItem.ChuDe == b)
		{
			if (!string.IsNullOrWhiteSpace(ScriptFolderSearchBox.Text))
			{
				return scriptItem.Name.Contains(ScriptFolderSearchBox.Text, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
		return false;
	}

	[CompilerGenerated]
	private bool m_694(object P_0)
	{
		if (P_0 is InteractionAction interactionAction && (interactionAction.Platform == B || (B == "Android" && interactionAction.Platform == "Phone")))
		{
			if (!string.IsNullOrWhiteSpace(ActionSearchBox.Text))
			{
				return interactionAction.Name.Contains(ActionSearchBox.Text, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
		return false;
	}

	[CompilerGenerated]
	private void m_695(object? _, EventArgs P_1)
	{
		m_520.Stop();
		H();
	}

	[CompilerGenerated]
	private void m_696(object? _, EventArgs P_1)
	{
		m_521.Stop();
		K();
	}

	[CompilerGenerated]
	private void m_697(object? _, EventArgs P_1)
	{
		m_523.Stop();
		j();
	}

	[CompilerGenerated]
	private bool m_698(FacebookAccountRow P_0)
	{
		return Facebooks.Contains(P_0);
	}

	[CompilerGenerated]
	private bool M(string P_0)
	{
		(RadioButton, TextBlock, string)? tuple = m_608(P_0);
		if (!tuple.HasValue)
		{
			return false;
		}
		return tuple.GetValueOrDefault().Item1.Visibility == Visibility.Collapsed;
	}

	[CompilerGenerated]
	internal static void m_699(Border P_0, CheckBox P_1, ref m_741 P_2)
	{
		bool valueOrDefault = P_1.IsChecked == true;
		P_0.BorderBrush = (valueOrDefault ? P_2.A : P_2.a);
		P_0.BorderThickness = (valueOrDefault ? new Thickness(2.0) : new Thickness(1.0));
		P_1.Content = (valueOrDefault ? "✓ Đã bật" : "Bật");
	}

	[CompilerGenerated]
	private bool m_700(FacebookAccountRow P_0)
	{
		return P_0.ScriptId == m_491.Id;
	}

	[CompilerGenerated]
	private FacebookExportItem m_701(FacebookAccountRow P_0)
	{
		return new FacebookExportItem
		{
			FolderName = (Folders.FirstOrDefault((NickFolder nickFolder) => nickFolder.Id == P_0.FolderId)?.Name ?? ""),
			PhoneName = P_0.PhoneName,
			ScriptFolderName = P_0.ScriptName,
			Uid = P_0.Uid,
			Pass = P_0.Pass,
			TwoFA = P_0.TwoFA,
			Token = P_0.Token,
			Cookie = P_0.Cookie,
			Mail = P_0.Mail,
			PassMail = P_0.PassMail,
			MailKhoiPhuc = P_0.MailKhoiPhuc,
			PassMailKhoiPhuc = P_0.PassMailKhoiPhuc,
			BanBe = P_0.BanBe,
			Nhom = P_0.Nhom,
			GioiTinh = P_0.GioiTinh,
			Avatar = P_0.Avatar,
			ProfileChrome = P_0.ProfileChrome,
			TenProfile = P_0.TenProfile,
			UserAgent = P_0.UserAgent,
			Proxy = P_0.Proxy,
			TepCu = P_0.TepCu,
			GhiChu = P_0.GhiChu,
			TuongTacCuoi = P_0.TuongTacCuoi,
			TrangThai = P_0.TrangThai,
			TinhTrang = P_0.TinhTrang
		};
	}

	[CompilerGenerated]
	internal static HttpRequestMessage m_702(string P_0, [Optional] bool P_1, ref m_787 P_2)
	{
		HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, P_0);
		if (P_1)
		{
			httpRequestMessage.Headers.TryAddWithoutValidation("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
			httpRequestMessage.Headers.TryAddWithoutValidation("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			httpRequestMessage.Headers.TryAddWithoutValidation("Accept-Language", "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7");
		}
		else
		{
			httpRequestMessage.Headers.TryAddWithoutValidation("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
			httpRequestMessage.Headers.TryAddWithoutValidation("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8");
			httpRequestMessage.Headers.TryAddWithoutValidation("Accept-Language", "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-ch-ua", "\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-ch-ua-mobile", "?0");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-ch-ua-platform", "\"Windows\"");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-fetch-dest", "document");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-fetch-mode", "navigate");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-fetch-site", "none");
			httpRequestMessage.Headers.TryAddWithoutValidation("sec-fetch-user", "?1");
		}
		httpRequestMessage.Headers.TryAddWithoutValidation("upgrade-insecure-requests", "1");
		httpRequestMessage.Headers.TryAddWithoutValidation("Cookie", P_2.A);
		return httpRequestMessage;
	}
}
