using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;

namespace testTuongTacWPF;

public partial class AiVisionRandomVariableWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private AiVisionRandomVariableWindow(string P_0)
	{
		InitializeComponent();
		TypeSoRadio.IsChecked = P_0 == "So";
		TypeChuRadio.IsChecked = P_0 == "Chu";
		TypeSoChuRadio.IsChecked = P_0 == "SoChu";
	}

	private void m_172(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_173(object P_0, RoutedEventArgs P_1)
	{
		if (!int.TryParse(LengthTextBox.Text.Trim(), out var result) || result < 1)
		{
			ErrorText.Text = "Độ dài phải là 1 số nguyên dương.";
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void m_174(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	public static string? Show(Window? owner, string defaultType)
	{
		AiVisionRandomVariableWindow aiVisionRandomVariableWindow = new AiVisionRandomVariableWindow(defaultType);
		if (owner != null)
		{
			aiVisionRandomVariableWindow.Owner = owner;
		}
		aiVisionRandomVariableWindow.ShowDialog();
		if (!aiVisionRandomVariableWindow.A)
		{
			return null;
		}
		string value;
		if (aiVisionRandomVariableWindow.TypeChuRadio.IsChecked == true)
		{
			value = "Chu";
		}
		else
		{
			value = ((aiVisionRandomVariableWindow.TypeSoChuRadio.IsChecked == true) ? "SoChu" : "So");
		}
		int value2 = int.Parse(aiVisionRandomVariableWindow.LengthTextBox.Text.Trim());
		string text = aiVisionRandomVariableWindow.PrefixTextBox.Text;
		string text2 = aiVisionRandomVariableWindow.SuffixTextBox.Text;
		return $"{{{{Random|{value}|{value2}|{text}|{text2}}}}}";
	}
}
