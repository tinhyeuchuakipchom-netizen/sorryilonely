using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.Win32;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class AiVisionFileVariableWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private AiVisionFileVariableWindow()
	{
		InitializeComponent();
	}

	private void m_72(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_73(object P_0, RoutedEventArgs P_1)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "Text files (*.txt)|*.txt|Tất cả file (*.*)|*.*"
		};
		if (openFileDialog.ShowDialog() == true)
		{
			FilePathTextBox.Text = openFileDialog.FileName;
			ErrorText.Visibility = Visibility.Collapsed;
		}
	}

	private void m_74(object P_0, RoutedEventArgs P_1)
	{
		if (string.IsNullOrWhiteSpace(FilePathTextBox.Text))
		{
			ErrorText.Text = "Chưa chọn file.";
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	public static string? Show(Window? owner)
	{
		AiVisionFileVariableWindow aiVisionFileVariableWindow = new AiVisionFileVariableWindow();
		if (owner != null)
		{
			aiVisionFileVariableWindow.Owner = owner;
		}
		aiVisionFileVariableWindow.ShowDialog();
		if (!aiVisionFileVariableWindow.A)
		{
			return null;
		}
		return AiVisionFileVariables.BuildPlaceholder(aiVisionFileVariableWindow.FilePathTextBox.Text.Trim(), aiVisionFileVariableWindow.ModeRandomRadio.IsChecked == true, aiVisionFileVariableWindow.DeleteOnTakeCheck.IsChecked == true);
	}
}
