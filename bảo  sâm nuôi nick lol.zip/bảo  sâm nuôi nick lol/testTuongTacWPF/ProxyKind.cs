namespace testTuongTacWPF;

public enum ProxyKind
{
	Invalid,
	IPv4,
	Domain,
	IPv6Single,
	IPv6Range
}
