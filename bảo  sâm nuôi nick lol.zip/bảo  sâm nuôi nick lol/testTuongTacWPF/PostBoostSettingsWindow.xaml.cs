using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class PostBoostSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private PostBoostSettingsWindow(PostBoostSettings P_0)
	{
		InitializeComponent();
		PostLinksTextBox.Text = string.Join("\n", P_0.PostLinks);
		AutoLikeCheckBox.IsChecked = P_0.AutoLike;
		AutoCommentCheckBox.IsChecked = P_0.AutoComment;
		AutoShareCheckBox.IsChecked = P_0.AutoShare;
		CommentTextsTextBox.Text = string.Join("\n", P_0.CommentTexts);
		MinSpacingSecondsTextBox.Text = P_0.MinSpacingSeconds.ToString();
		MaxSpacingSecondsTextBox.Text = P_0.MaxSpacingSeconds.ToString();
		m_2085();
	}

	private void m_2083(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2084(object P_0, RoutedEventArgs P_1)
	{
		m_2085();
	}

	private void m_2085()
	{
		if (CommentTextsPanel != null)
		{
			CommentTextsPanel.Visibility = ((AutoCommentCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void m_2086(object P_0, RoutedEventArgs P_1)
	{
		if (!m_2087(out PostBoostSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_2087(out PostBoostSettings P_0, out string P_1)
	{
		P_0 = new PostBoostSettings();
		P_1 = "";
		List<string> list = PostLinksTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		if (list.Count == 0)
		{
			P_1 = "Chưa nhập link bài viết nào.";
			return false;
		}
		bool valueOrDefault = AutoLikeCheckBox.IsChecked == true;
		bool valueOrDefault2 = AutoCommentCheckBox.IsChecked == true;
		bool valueOrDefault3 = AutoShareCheckBox.IsChecked == true;
		if (!valueOrDefault && !valueOrDefault2 && !valueOrDefault3)
		{
			P_1 = "Chưa chọn hành động nào (Like/Bình luận/Chia sẻ).";
			return false;
		}
		if (!int.TryParse(MinSpacingSecondsTextBox.Text.Trim(), out var result) || result < 0)
		{
			P_1 = "\"Từ\" (giây) phải là 1 số nguyên >= 0.";
			return false;
		}
		if (!int.TryParse(MaxSpacingSecondsTextBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "\"Đến\" (giây) phải là 1 số nguyên >= \"Từ\".";
			return false;
		}
		P_0.PostLinks = list;
		P_0.AutoLike = valueOrDefault;
		P_0.AutoComment = valueOrDefault2;
		P_0.AutoShare = valueOrDefault3;
		P_0.CommentTexts = CommentTextsTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		P_0.MinSpacingSeconds = result;
		P_0.MaxSpacingSeconds = result2;
		return true;
	}

	public static PostBoostSettings? Show(Window? owner, PostBoostSettings initial)
	{
		PostBoostSettingsWindow postBoostSettingsWindow = new PostBoostSettingsWindow(initial);
		if (owner != null)
		{
			postBoostSettingsWindow.Owner = owner;
		}
		postBoostSettingsWindow.ShowDialog();
		if (!postBoostSettingsWindow.A)
		{
			return null;
		}
		postBoostSettingsWindow.m_2087(out PostBoostSettings result, out string _);
		return result;
	}
}
