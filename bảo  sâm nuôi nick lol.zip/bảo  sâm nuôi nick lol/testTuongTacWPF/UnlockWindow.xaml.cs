using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using testTuongTacWPF.Licensing;

namespace testTuongTacWPF;

public partial class UnlockWindow : Window, IComponentConnector
{
	[CompilerGenerated]
	private sealed class m_2202
	{
		public Application A;

		internal void m_2203()
		{
			if ((DateTime.Now - UnlockWindow.A).TotalSeconds < 2.0)
			{
				return;
			}
			UnlockWindow.A = DateTime.Now;
			try
			{
				UnlockWindow unlockWindow = new UnlockWindow();
				unlockWindow.Owner = A.MainWindow;
				unlockWindow.ShowDialog();
			}
			catch
			{
			}
		}
	}

	private static DateTime A = DateTime.MinValue;

	private bool m_2198;

	public UnlockWindow()
	{
		InitializeComponent();
	}

	public static void ShowExpiredNotice()
	{
		Application A = Application.Current;
		Application application = A;
		if (((application != null) ? ((DispatcherObject)application).Dispatcher : null) == null)
		{
			return;
		}
		((DispatcherObject)A).Dispatcher.BeginInvoke((Delegate)(Action)(() =>
		{
			if ((DateTime.Now - UnlockWindow.A).TotalSeconds < 2.0)
			{
				return;
			}
			UnlockWindow.A = DateTime.Now;
			try
			{
				UnlockWindow unlockWindow = new UnlockWindow();
				unlockWindow.Owner = A.MainWindow;
				unlockWindow.ShowDialog();
			}
			catch
			{
			}
		}), Array.Empty<object>());
	}

	private void m_2199(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.ButtonState == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void a(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_0 is FrameworkElement { Tag: string tag } && !string.IsNullOrWhiteSpace(tag))
		{
			try
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = tag,
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				CustomMessageBox.Show(this, "Không mở được liên kết: " + ex.Message + "\nTự vào: " + tag, "Lỗi", NotifyType.Warning);
			}
		}
	}

	private void m_2200(object P_0, RoutedEventArgs P_1)
	{
		try
		{
			Clipboard.SetText(LicenseClient.GetHardwareId());
			CustomMessageBox.Show(this, "Đã copy mã kích hoạt máy vào clipboard. Gửi mã này cho admin để được mở khoá bản quyền.", "Mã kích hoạt");
		}
		catch (Exception ex)
		{
			CustomMessageBox.Show(this, "Không lấy được mã kích hoạt: " + ex.Message, "Lỗi", NotifyType.Warning);
		}
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		Close();
	}
}
