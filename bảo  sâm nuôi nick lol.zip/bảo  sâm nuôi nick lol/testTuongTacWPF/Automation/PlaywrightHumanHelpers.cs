using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using OtpNet;

namespace testTuongTacWPF.Automation;

public static class PlaywrightHumanHelpers
{
	private static readonly Random A = new Random();

	public static int RandomDelay(int minMs, int maxMs)
	{
		return A.Next(minMs, maxMs);
	}

	public static async Task WithCancellationAsync(Task task, CancellationToken cancellationToken)
	{
		if (cancellationToken.CanBeCanceled && await Task.WhenAny(task, Task.Delay(-1, cancellationToken)) != task)
		{
			throw new OperationCanceledException(cancellationToken);
		}
		await task;
	}

	public static async Task<gm_6026> WithCancellationAsync<gm_6026>(Task<gm_6026> task, CancellationToken cancellationToken)
	{
		if (cancellationToken.CanBeCanceled && await Task.WhenAny(task, Task.Delay(-1, cancellationToken)) != task)
		{
			throw new OperationCanceledException(cancellationToken);
		}
		return await task;
	}

	public static async Task SlowMouseMoveAsync(IPage page, float x, float y)
	{
		await page.Mouse.MoveAsync(x, y, new MouseMoveOptions
		{
			Steps = 15
		});
	}

	public static async Task SlowTypeAsync(ILocator locator, string text)
	{
		if (!string.IsNullOrEmpty(text))
		{
			await locator.PressSequentiallyAsync(text, new LocatorPressSequentiallyOptions
			{
				Delay = RandomDelay(60, 140)
			});
		}
	}

	public static string Get2fa(string secret)
	{
		if (string.IsNullOrWhiteSpace(secret))
		{
			return "";
		}
		try
		{
			Totp totp = new Totp(Base32Encoding.ToBytes(Regex.Replace(secret, "\\s+", "")));
			string text = "";
			int num = 0;
			do
			{
				Thread.Sleep(500);
				text = totp.ComputeTotp();
				num++;
			}
			while (num < 60 && (text.Length != 6 || totp.RemainingSeconds() <= 5));
			return text;
		}
		catch
		{
			return "";
		}
	}

	public static async Task<bool> ClickFirstVisibleAsync(IPage page, AriaRole role, string[] names, int timeoutMs = 2000)
	{
		foreach (string name in names)
		{
			try
			{
				ILocator byRole = page.GetByRole(role, new PageGetByRoleOptions
				{
					Name = name
				});
				await byRole.WaitForAsync(new LocatorWaitForOptions
				{
					State = WaitForSelectorState.Visible,
					Timeout = timeoutMs
				});
				await byRole.ClickAsync();
				return true;
			}
			catch
			{
			}
		}
		return false;
	}

	public static async Task<bool> CheckFirstVisibleAsync(IPage page, AriaRole role, string[] names, int timeoutMs = 2000)
	{
		foreach (string name in names)
		{
			try
			{
				ILocator byRole = page.GetByRole(role, new PageGetByRoleOptions
				{
					Name = name
				});
				await byRole.WaitForAsync(new LocatorWaitForOptions
				{
					State = WaitForSelectorState.Visible,
					Timeout = timeoutMs
				});
				await byRole.CheckAsync();
				return true;
			}
			catch
			{
			}
		}
		return false;
	}

	public static async Task<bool> IsAnyVisibleAsync(IPage page, AriaRole role, string[] names, int timeoutMs = 2000)
	{
		foreach (string name in names)
		{
			try
			{
				await page.GetByRole(role, new PageGetByRoleOptions
				{
					Name = name
				}).WaitForAsync(new LocatorWaitForOptions
				{
					State = WaitForSelectorState.Visible,
					Timeout = timeoutMs
				});
				return true;
			}
			catch
			{
			}
		}
		return false;
	}
}
