using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace testTuongTacWPF.Automation;

public static class RandomFacebookIdentityGenerator
{
	private static readonly string[] A = new string[20]
	{
		"Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Huỳnh", "Phan", "Vũ", "Võ", "Đặng",
		"Bùi", "Đỗ", "Hồ", "Ngô", "Dương", "Lý", "Đinh", "Đoàn", "Trịnh", "Lâm"
	};

	private static readonly string[] a = new string[10] { "Văn", "Hữu", "Đức", "Minh", "Quốc", "Thành", "Công", "Xuân", "Đình", "Anh" };

	private static readonly string[] B = new string[10] { "Thị", "Ngọc", "Thu", "Kim", "Hồng", "Thanh", "Minh", "Diệu", "Bích", "Như" };

	private static readonly string[] b = new string[26]
	{
		"Anh", "Bảo", "Cường", "Dũng", "Đạt", "Đức", "Duy", "Hải", "Hoàng", "Huy",
		"Khang", "Khoa", "Kiên", "Long", "Minh", "Nam", "Phong", "Phúc", "Quân", "Sơn",
		"Tài", "Thắng", "Thịnh", "Tuấn", "Việt", "Vinh"
	};

	private static readonly string[] C = new string[25]
	{
		"An", "Anh", "Chi", "Diệp", "Giang", "Hà", "Hạnh", "Hoa", "Huyền", "Lan",
		"Linh", "Mai", "My", "Ngân", "Ngọc", "Nhi", "Nhung", "Phương", "Quỳnh", "Thảo",
		"Thư", "Trang", "Trâm", "Vy", "Yến"
	};

	private static readonly string[] c = new string[30]
	{
		"Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Wilson", "Anderson",
		"Taylor", "Thomas", "Moore", "Jackson", "Martin", "Lee", "Walker", "Hall", "Allen", "Young",
		"King", "Wright", "Scott", "Green", "Baker", "Adams", "Nelson", "Carter", "Mitchell", "Roberts"
	};

	private static readonly string[] D = new string[30]
	{
		"James", "John", "Robert", "Michael", "David", "William", "Richard", "Joseph", "Thomas", "Daniel",
		"Matthew", "Anthony", "Mark", "Steven", "Andrew", "Kevin", "Brian", "Eric", "Jason", "Ryan",
		"Adam", "Nathan", "Peter", "Henry", "Oliver", "Jack", "Ethan", "Lucas", "Noah", "Leo"
	};

	private static readonly string[] d = new string[30]
	{
		"Mary", "Jennifer", "Linda", "Patricia", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen",
		"Emily", "Emma", "Olivia", "Sophia", "Isabella", "Mia", "Charlotte", "Amelia", "Grace", "Chloe",
		"Hannah", "Laura", "Rachel", "Megan", "Alice", "Julia", "Anna", "Ella", "Lily", "Zoe"
	};

	private const string m_6114 = "abcdefghijklmnopqrstuvwxyz";

	private const string m_6115 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	private const string m_6116 = "0123456789";

	private const string m_6117 = "!@#$%^&*";

	public static readonly string[] ViettelPrefixes = new string[12]
	{
		"032", "033", "034", "035", "036", "037", "038", "039", "086", "096",
		"097", "098"
	};

	public static readonly string[] MobifonePrefixes = new string[8] { "070", "076", "077", "078", "079", "089", "090", "093" };

	public static readonly string[] VinaphonePrefixes = new string[8] { "081", "082", "083", "084", "085", "088", "091", "094" };

	public static readonly string[] VietnamobilePrefixes = new string[4] { "052", "056", "058", "092" };

	public static readonly string[] GmobilePrefixes = new string[2] { "059", "099" };

	public static string RandomGender()
	{
		if (Random.Shared.Next(2) != 0)
		{
			return "Nữ";
		}
		return "Nam";
	}

	public static string RandomFullName(string gender, bool includeMiddleName)
	{
		bool flag = gender == "Nữ";
		string text = A[Random.Shared.Next(A.Length)];
		string[] array = (flag ? C : b);
		string text2 = array[Random.Shared.Next(array.Length)];
		if (!includeMiddleName)
		{
			return text + " " + text2;
		}
		string[] array2 = (flag ? B : a);
		string value = array2[Random.Shared.Next(array2.Length)];
		return $"{text} {value} {text2}";
	}

	public static string RandomEnglishFullName(string gender)
	{
		string[] array = ((gender == "Nữ") ? d : D);
		string obj = array[Random.Shared.Next(array.Length)];
		string text = c[Random.Shared.Next(c.Length)];
		return obj + " " + text;
	}

	public static string RandomPassword(bool lower, bool upper, bool digits, bool special, int minLength, int maxLength)
	{
		List<string> list = new List<string>();
		if (lower)
		{
			list.Add("abcdefghijklmnopqrstuvwxyz");
		}
		if (upper)
		{
			list.Add("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
		}
		if (digits)
		{
			list.Add("0123456789");
		}
		if (special)
		{
			list.Add("!@#$%^&*");
		}
		if (list.Count == 0)
		{
			list.Add("abcdefghijklmnopqrstuvwxyz0123456789");
		}
		int num = Math.Max(list.Count, Random.Shared.Next(minLength, maxLength + 1));
		char[] array = new char[num];
		for (int i = 0; i < list.Count; i++)
		{
			array[i] = list[i][Random.Shared.Next(list[i].Length)];
		}
		string text = string.Concat(list);
		for (int j = list.Count; j < num; j++)
		{
			array[j] = text[Random.Shared.Next(text.Length)];
		}
		for (int num2 = array.Length - 1; num2 > 0; num2--)
		{
			int num3 = Random.Shared.Next(num2 + 1);
			ref char reference = ref array[num2];
			ref char reference2 = ref array[num3];
			char c = array[num3];
			char c2 = array[num2];
			reference = c;
			reference2 = c2;
		}
		return new string(array);
	}

	public static string RandomVietnamesePhoneNumber(IReadOnlyList<string> prefixPool, bool internationalFormat)
	{
		IReadOnlyList<string> readOnlyList;
		if (prefixPool.Count <= 0)
		{
			IReadOnlyList<string> viettelPrefixes = ViettelPrefixes;
			readOnlyList = viettelPrefixes;
		}
		else
		{
			readOnlyList = prefixPool;
		}
		IReadOnlyList<string> readOnlyList2 = readOnlyList;
		string text = readOnlyList2[Random.Shared.Next(readOnlyList2.Count)];
		char[] array = new char[Math.Max(0, 10 - text.Length)];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = "0123456789"[Random.Shared.Next("0123456789".Length)];
		}
		string text2 = text + new string(array);
		if (!internationalFormat)
		{
			return text2;
		}
		return "+84" + text2.Substring(1);
	}

	public static string RandomEmailAddress(bool lower, bool digits, int minLength, int maxLength, string domain)
	{
		List<string> list = new List<string>();
		if (lower)
		{
			list.Add("abcdefghijklmnopqrstuvwxyz");
		}
		if (digits)
		{
			list.Add("0123456789");
		}
		if (list.Count == 0)
		{
			list.Add("abcdefghijklmnopqrstuvwxyz");
		}
		string text = string.Concat(list);
		int num = Random.Shared.Next(minLength, maxLength + 1);
		char[] array = new char[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = text[Random.Shared.Next(text.Length)];
		}
		string text2 = (string.IsNullOrWhiteSpace(domain) ? "gmail.com" : domain.Trim());
		return new string(array) + "@" + text2;
	}

	public static string RandomEmailFromName(string fullName, bool dotSeparator, bool addRandomSuffix, int? birthYear, string domain)
	{
		string[] value = m_6118(fullName).ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
		string text = string.Join(dotSeparator ? "." : "", value);
		if (birthYear.HasValue)
		{
			text += birthYear.Value;
		}
		if (addRandomSuffix)
		{
			text += Random.Shared.Next(10, 1000);
		}
		string text2 = (string.IsNullOrWhiteSpace(domain) ? "gmail.com" : domain.Trim());
		return text + "@" + text2;
	}

	private static string m_6118(string P_0)
	{
		string text = P_0.Normalize(NormalizationForm.FormD);
		StringBuilder stringBuilder = new StringBuilder(text.Length);
		string text2 = text;
		foreach (char c in text2)
		{
			if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString().Replace('đ', 'd').Replace('Đ', 'D')
			.Normalize(NormalizationForm.FormC);
	}
}
