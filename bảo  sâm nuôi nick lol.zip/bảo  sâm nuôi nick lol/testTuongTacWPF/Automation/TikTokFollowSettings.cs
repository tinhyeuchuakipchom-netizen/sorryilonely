using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class TikTokFollowSettings
{
	[CompilerGenerated]
	private int A = 5;

	[CompilerGenerated]
	private int a = 10;

	[CompilerGenerated]
	private int B = 3;

	[CompilerGenerated]
	private int b = 7;

	[CompilerGenerated]
	private string m_6295 = "Feed";

	[CompilerGenerated]
	private List<string> m_6296 = new List<string>();

	public int MinCount
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxCount
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MinDelaySec
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MaxDelaySec
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string FollowMode
	{
		[CompilerGenerated]
		get
		{
			return m_6295;
		}
		[CompilerGenerated]
		set
		{
			m_6295 = value;
		}
	}

	public List<string> TargetUsernames
	{
		[CompilerGenerated]
		get
		{
			return m_6296;
		}
		[CompilerGenerated]
		set
		{
			m_6296 = value;
		}
	}

	public int PickCount()
	{
		if (MinCount < MaxCount)
		{
			return Random.Shared.Next(MinCount, MaxCount + 1);
		}
		return MinCount;
	}

	public int PickDelaySec()
	{
		if (MinDelaySec < MaxDelaySec)
		{
			return Random.Shared.Next(MinDelaySec, MaxDelaySec + 1);
		}
		return MinDelaySec;
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static TikTokFollowSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new TikTokFollowSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<TikTokFollowSettings>(json) ?? new TikTokFollowSettings();
		}
		catch
		{
			return new TikTokFollowSettings();
		}
	}
}
