using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class GeminiInlineData
{
	[CompilerGenerated]
	private string A = "image/png";

	[CompilerGenerated]
	private string a = "";

	[JsonPropertyName("mime_type")]
	public string MimeType
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("data")]
	public string Data
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
