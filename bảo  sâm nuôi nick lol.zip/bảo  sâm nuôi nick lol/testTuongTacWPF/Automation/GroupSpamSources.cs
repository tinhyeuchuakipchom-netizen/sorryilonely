namespace testTuongTacWPF.Automation;

public static class GroupSpamSources
{
	public const string InputLinks = "InputLinks";

	public const string ExistingInAccount = "ExistingInAccount";

	public const string SearchAndJoin = "SearchAndJoin";
}
