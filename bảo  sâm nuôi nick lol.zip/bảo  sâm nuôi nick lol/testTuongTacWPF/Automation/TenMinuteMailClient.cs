using System;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;

namespace testTuongTacWPF.Automation;

public class TenMinuteMailClient : IVerifyMailTestClient
{
	private const string A = "https://10minutemail.net";

	private readonly HttpClient m_6255;

	public TenMinuteMailClient()
	{
		HttpClientHandler handler = new HttpClientHandler
		{
			CookieContainer = new CookieContainer(),
			UseCookies = true
		};
		m_6255 = new HttpClient(handler)
		{
			Timeout = TimeSpan.FromSeconds(30L)
		};
		m_6255.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) FastBoxPhone/1.0");
	}

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		Match match = Regex.Match(await m_6255.GetStringAsync("https://10minutemail.net/?lang=en", ct), "id=\"fe_text\"[^>]*value=\"([^\"]*)\"");
		if (!match.Success || string.IsNullOrWhiteSpace(match.Groups[1].Value))
		{
			throw new InvalidOperationException("Không đọc được địa chỉ mail từ 10minutemail.net (có thể site đã đổi giao diện).");
		}
		return WebUtility.HtmlDecode(match.Groups[1].Value);
	}

	public async Task<string?> TryGetOtpAsync()
	{
		string input = await m_6255.GetStringAsync("https://10minutemail.net/?lang=en");
		string text = null;
		DateTime? dateTime = null;
		foreach (Match item in Regex.Matches(input, "<tr.*?</tr>", RegexOptions.Singleline))
		{
			Match match2 = Regex.Match(item.Value, "readmail\\.html\\?mid=([a-zA-Z0-9_-]+)");
			if (match2.Success && !(match2.Groups[1].Value == "welcome"))
			{
				Match match3 = Regex.Match(item.Value, "title=\"([^\"]+)\"");
				DateTime? dateTime2 = ((match3.Success && DateTime.TryParse(match3.Groups[1].Value, out var result)) ? new DateTime?(result) : ((DateTime?)null));
				if (text == null || (dateTime2.HasValue && (!dateTime.HasValue || dateTime2 > dateTime)))
				{
					text = match2.Groups[1].Value;
					dateTime = dateTime2;
				}
			}
		}
		if (text == null)
		{
			return null;
		}
		string text2 = await m_6255.GetStringAsync("https://10minutemail.net/readmail.html?mid=" + text);
		Match match4 = Regex.Match(text2, "<div class=\"mailinhtml\">(.*?)</div>\\s*<div style=\"clear:both;\"", RegexOptions.Singleline);
		return f.A(WebUtility.HtmlDecode(Regex.Replace(match4.Success ? match4.Groups[1].Value : text2, "<[^>]+>", " ")));
	}
}
