using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public interface IMarkStepsDeviceAdapter
{
	bool SupportsLiveRecording => false;

	Task<byte[]> CaptureScreenshotAsync(CancellationToken cancellationToken);

	Task<List<UiElement>> DumpElementsAsync(CancellationToken cancellationToken);

	Task TapAsync(int x, int y, CancellationToken cancellationToken);

	Task SwipeAsync(int x1, int y1, int x2, int y2, CancellationToken cancellationToken);

	Task TypeTextAsync(string text, CancellationToken cancellationToken);

	Task<(int X, int Y)> ToDeviceCoordinatesAsync(int pixelX, int pixelY, CancellationToken cancellationToken)
	{
		return Task.FromResult((pixelX, pixelY));
	}

	Task StartLiveRecordingAsync(Action<LiveRecordedAction> onActionCaptured, CancellationToken cancellationToken)
	{
		return Task.CompletedTask;
	}

	Task StopLiveRecordingAsync(CancellationToken cancellationToken)
	{
		return Task.CompletedTask;
	}
}
