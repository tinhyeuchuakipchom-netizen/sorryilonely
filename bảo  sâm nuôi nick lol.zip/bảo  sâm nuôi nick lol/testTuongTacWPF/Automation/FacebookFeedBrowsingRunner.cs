using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookFeedBrowsingRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_4079
	{
		public static readonly m_4079 A = new m_4079();

		public static Func<string, bool> m_4084;

		public static Func<string, string> m_4085;

		internal bool m_4086(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string a(string P_0)
		{
			return P_0.Trim();
		}
	}

	[CompilerGenerated]
	private sealed class m_4080
	{
		public Action<string, string> A;

		public string m_4087;

		public IPage m_4088;

		public CancellationToken m_4089;

		public Action<string> m_4090;

		public Func<Task> m_4091;

		public Func<Task> a;

		public Action<string> m_4092;

		internal void m_4093(string P_0)
		{
			A(P_0, m_4087);
		}

		internal Task m_4094()
		{
			return m_4068(m_4088, A, m_4089);
		}

		internal Task m_4095()
		{
			return C(m_4088, A, m_4089);
		}

		internal void m_4096(string P_0)
		{
			A(P_0, m_4087);
		}
	}

	[CompilerGenerated]
	private sealed class m_4081
	{
		public string A;

		public m_4080 m_4097;
	}

	[CompilerGenerated]
	private sealed class m_4082
	{
		public string A;

		public List<string> m_4098;

		public m_4081 m_4099;

		internal Task m_4100()
		{
			return FacebookPagePostRunner.PostSingleToPageAsync(m_4099.m_4097.m_4088, m_4099.A, A, m_4098, (string P_0) =>
			{
				m_4099.m_4097.A(P_0, m_4099.m_4097.m_4087);
			}, m_4099.m_4097.m_4089);
		}
	}

	[CompilerGenerated]
	private sealed class m_4083
	{
		public Action<AiVisionStepLog> A;

		public CancellationToken m_4101;

		public FeedBrowsingSettings m_4102;

		public FacebookAccountRow m_4103;

		public IReadOnlyCollection<FacebookAccountRow> m_4104;

		public int m_4105;

		public Action<string> m_4106;

		internal void m_4107(string P_0, string P_1)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_4105++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = P_1
			});
		}

		internal void m_4108(string P_0)
		{
			m_4107(P_0, "Nuôi nick - Tạo Page");
		}
	}

	[CompilerGenerated]
	private sealed class c
	{
		public IPage A;

		public FriendRequestSettings m_4109;

		public int m_4110;

		public HashSet<string> m_4111;

		public bool m_4112;

		public m_4083 m_4113;

		public Func<Task> m_4114;

		public Func<Task> a;

		public Func<Task> B;

		public Func<Task> b;

		public Func<Task> C;

		public Func<Task> m_4115;

		public Func<Task> D;

		public Func<Task> d;

		public Func<Task> E;

		internal Task m_4116()
		{
			return m_4068(A, (string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4113.m_4101);
		}

		internal Task m_4117()
		{
			return m_4069(A, m_4113.m_4102, (string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4113.m_4101);
		}

		internal Task m_4118()
		{
			return m_4070(A, (string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4113.m_4101);
		}

		internal async Task m_4119()
		{
			await FacebookFriendRequestActions.ConfirmIncomingRequestsAsync(A, m_4109.MaxConfirmsPerRun, (string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4113.m_4101);
			await FacebookFeedBrowsingRunner.b(A, (Action<string, string>)((string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}), m_4113.m_4101);
		}

		internal async Task m_4120()
		{
			int num = m_4110;
			m_4110 = num + await m_4072(A, m_4113.m_4103, m_4111, (string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4113.m_4101);
		}

		internal Task m_4121()
		{
			return FacebookFeedBrowsingRunner.B(A, (Action<string, string>)((string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}), m_4113.m_4101);
		}

		internal async Task m_4122()
		{
			if (await FacebookMessagingRunner.RunOnPageAsync(A, m_4113.m_4103, m_4113.m_4102.Messaging ?? new MessagingSettings(), m_4113.m_4104, (string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4113.m_4101) == 0)
			{
				m_4113.m_4107("[Bỏ qua] Không có người nhận tin nhắn phù hợp.", "Nuôi nick - Nhắn tin");
			}
			if ((m_4113.m_4102.Messaging ?? new MessagingSettings()).Target == MessagingTarget.PostCommenters)
			{
				await FacebookFeedBrowsingRunner.b(A, (Action<string, string>)((string P_0, string P_1) =>
				{
					m_4113.A(new AiVisionStepLog
					{
						FlowStepIndex = m_4113.m_4105++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = P_1
					});
				}), m_4113.m_4101);
			}
		}

		internal async Task m_4123()
		{
			if ((bool)(await FacebookPageCreationRunner.CreateSinglePageOnPageAsync(A, m_4113.m_4102.PageCreation ?? new PageCreationSettings(), m_4113.m_4103.Index, (string P_0) =>
			{
				m_4113.m_4107(P_0, "Nuôi nick - Tạo Page");
			}, m_4113.m_4101)))
			{
				m_4112 = true;
			}
			await FacebookFeedBrowsingRunner.b(A, (Action<string, string>)((string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}), m_4113.m_4101);
		}

		internal Task m_4124()
		{
			return FacebookFeedBrowsingRunner.C(A, (Action<string, string>)((string P_0, string P_1) =>
			{
				m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}), m_4113.m_4101);
		}
	}

	[CompilerGenerated]
	private sealed class D
	{
		public string A;

		public c m_4144;

		internal async Task m_4145()
		{
			int num = m_4144.m_4110;
			int num2 = await m_4071(m_4144.A, m_4144.m_4113.m_4103, A, m_4144.m_4111, (string P_0, string P_1) =>
			{
				m_4144.m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4144.m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4144.m_4113.m_4101);
			m_4144.m_4110 = num + num2;
		}
	}

	[CompilerGenerated]
	private sealed class d
	{
		public string A;

		public List<string> m_4150;

		public c m_4151;

		internal Task m_4152()
		{
			return FacebookPostCreationRunner.PostSingleAsync(m_4151.A, "Đăng bài", A, m_4150, m_4151.m_4113.m_4102.Post.Audience, (string P_0, string P_1) =>
			{
				m_4151.m_4113.A(new AiVisionStepLog
				{
					FlowStepIndex = m_4151.m_4113.m_4105++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = P_1
				});
			}, m_4151.m_4113.m_4101);
		}
	}

	private const string A = "https://www.facebook.com/?locale=en_US";

	private const string a = "https://www.facebook.com/reels/?locale=en_US";

	private const int m_4066 = 5000;

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, FeedBrowsingSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, IReadOnlyCollection<FacebookAccountRow>? sessionNicks = null)
	{
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		int m_4105 = 0;
		AiVisionRunResult result;
		try
		{
			_ = 23;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await global::A.F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await global::A.F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage A = page;
				m_4083 obj = default;
				obj.m_4107("Đang đăng nhập...", "Lướt bảng tin");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, A, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					onStep(new AiVisionStepLog
					{
						FlowStepIndex = m_4105++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = P_1
					});
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để lướt bảng tin: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					HashSet<string> m_4111 = FacebookFriendRequestActions.LoadSentUids(nick);
					int m_4112 = 0;
					bool flag = false;
					bool m_4113 = false;
					FriendRequestSettings m_4114 = settings.FriendRequest;
					Queue<string> queue = new Queue<string>();
					if (settings.AutoAddFriend && m_4114.Action == FriendRequestAction.SendRequests && m_4114.Source != FriendRequestSource.GroupPosters)
					{
						foreach (string item2 in FacebookFriendRequestActions.LoadTargetsFromList(nick, m_4114))
						{
							queue.Enqueue(item2);
						}
					}
					int num2 = settings.PickDurationMinutes();
					DateTime dateTime = DateTime.UtcNow.AddMinutes(num2);
					obj.m_4107($"Đang lướt bảng tin trong {num2} phút...", "Lướt bảng tin");
					await A.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
					{
						Timeout = 30000f,
						WaitUntil = WaitUntilState.DOMContentLoaded
					});
					await Task.Delay(2000, cancellationToken);
					while (DateTime.UtcNow < dateTime)
					{
						cancellationToken.ThrowIfCancellationRequested();
						await A.Mouse.WheelAsync(0f, Random.Shared.Next(400, 900));
						await Task.Delay(Random.Shared.Next(1500, 4500), cancellationToken);
						bool flag2 = true;
						if (settings.AutoLike && settings.RollChance(settings.LikeChancePercent))
						{
							bool flag3 = flag2;
							flag2 = flag3 & await m_4075("Like bài viết", (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, () => m_4068(A, (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken));
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoComment && settings.RollChance(settings.CommentChancePercent))
						{
							bool flag3 = flag2;
							flag2 = flag3 & await m_4075("Bình luận bài viết", (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, () => m_4069(A, settings, (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken));
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.ViewOtherProfiles && settings.RollChance(settings.ViewOtherProfilesChancePercent))
						{
							bool flag3 = flag2;
							flag2 = flag3 & await m_4075("Xem trang cá nhân người đăng", (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, () => m_4070(A, (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken));
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoAddFriend && settings.RollChance(settings.AddFriendChancePercent))
						{
							if (m_4114.Action == FriendRequestAction.ConfirmIncoming)
							{
								if (!flag)
								{
									flag = true;
									bool flag3 = flag2;
									flag2 = flag3 & await m_4075("Xác nhận lời mời kết bạn", (string P_0, string P_1) =>
									{
										onStep(new AiVisionStepLog
										{
											FlowStepIndex = m_4105++,
											SubStep = 1,
											ActionSummary = P_0,
											Reason = P_1
										});
									}, async () =>
									{
										await FacebookFriendRequestActions.ConfirmIncomingRequestsAsync(A, m_4114.MaxConfirmsPerRun, (string P_0, string P_1) =>
										{
											onStep(new AiVisionStepLog
											{
												FlowStepIndex = m_4105++,
												SubStep = 1,
												ActionSummary = P_0,
												Reason = P_1
											});
										}, cancellationToken);
										await b(A, (string P_0, string P_1) =>
										{
											onStep(new AiVisionStepLog
											{
												FlowStepIndex = m_4105++,
												SubStep = 1,
												ActionSummary = P_0,
												Reason = P_1
											});
										}, cancellationToken);
									});
								}
							}
							else if (m_4112 < m_4114.MaxRequestsPerRun)
							{
								if (m_4114.Source == FriendRequestSource.GroupPosters)
								{
									bool flag3 = flag2;
									flag2 = flag3 & await m_4075("Kết bạn với người đăng bài", (string P_0, string P_1) =>
									{
										onStep(new AiVisionStepLog
										{
											FlowStepIndex = m_4105++,
											SubStep = 1,
											ActionSummary = P_0,
											Reason = P_1
										});
									}, async () =>
									{
										int num3 = m_4112;
										m_4112 = num3 + await m_4072(A, nick, m_4111, (string P_0, string P_1) =>
										{
											onStep(new AiVisionStepLog
											{
												FlowStepIndex = m_4105++,
												SubStep = 1,
												ActionSummary = P_0,
												Reason = P_1
											});
										}, cancellationToken);
									});
								}
								else if (queue.Count > 0)
								{
									string A2 = queue.Dequeue();
									bool flag3 = flag2;
									flag2 = flag3 & await m_4075("Kết bạn theo danh sách", (string P_0, string P_1) =>
									{
										onStep(new AiVisionStepLog
										{
											FlowStepIndex = m_4105++,
											SubStep = 1,
											ActionSummary = P_0,
											Reason = P_1
										});
									}, async () =>
									{
										int num3 = m_4112;
										int num4 = await m_4071(A, nick, A2, m_4111, (string P_0, string P_1) =>
										{
											onStep(new AiVisionStepLog
											{
												FlowStepIndex = m_4105++,
												SubStep = 1,
												ActionSummary = P_0,
												Reason = P_1
											});
										}, cancellationToken);
										m_4112 = num3 + num4;
									});
								}
							}
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.ViewComments && settings.RollChance(settings.ViewCommentsChancePercent))
						{
							bool flag3 = flag2;
							flag2 = flag3 & await m_4075("Xem bình luận", (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, () => B(A, (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken));
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoMessage && settings.RollChance(settings.MessageChancePercent))
						{
							bool flag3 = flag2;
							flag2 = flag3 & await m_4075("Nhắn tin", (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, async () =>
							{
								if (await FacebookMessagingRunner.RunOnPageAsync(A, nick, settings.Messaging ?? new MessagingSettings(), sessionNicks, (string P_0, string P_1) =>
								{
									onStep(new AiVisionStepLog
									{
										FlowStepIndex = m_4105++,
										SubStep = 1,
										ActionSummary = P_0,
										Reason = P_1
									});
								}, cancellationToken) == 0)
								{
									obj.m_4107("[Bỏ qua] Không có người nhận tin nhắn phù hợp.", "Nuôi nick - Nhắn tin");
								}
								if ((settings.Messaging ?? new MessagingSettings()).Target == MessagingTarget.PostCommenters)
								{
									await b(A, (string P_0, string P_1) =>
									{
										onStep(new AiVisionStepLog
										{
											FlowStepIndex = m_4105++,
											SubStep = 1,
											ActionSummary = P_0,
											Reason = P_1
										});
									}, cancellationToken);
								}
							});
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoPost && settings.RollChance(settings.PostChancePercent))
						{
							string A3 = settings.Post.PickContent();
							List<string> m_4150 = settings.Post.PickMediaFiles();
							if (!string.IsNullOrWhiteSpace(A3) || m_4150.Count > 0)
							{
								bool flag3 = flag2;
								flag2 = flag3 & await m_4075("Đăng bài viết", (string P_0, string P_1) =>
								{
									onStep(new AiVisionStepLog
									{
										FlowStepIndex = m_4105++,
										SubStep = 1,
										ActionSummary = P_0,
										Reason = P_1
									});
								}, () => FacebookPostCreationRunner.PostSingleAsync(A, "Đăng bài", A3, m_4150, settings.Post.Audience, (string P_0, string P_1) =>
								{
									onStep(new AiVisionStepLog
									{
										FlowStepIndex = m_4105++,
										SubStep = 1,
										ActionSummary = P_0,
										Reason = P_1
									});
								}, cancellationToken));
							}
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoCreatePage && !m_4113 && settings.RollChance(settings.CreatePageChancePercent))
						{
							bool flag3 = flag2;
							flag2 = flag3 & await m_4075("Tạo Page", (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, async () =>
							{
								if ((bool)(await FacebookPageCreationRunner.CreateSinglePageOnPageAsync(A, settings.PageCreation ?? new PageCreationSettings(), nick.Index, (string P_0) =>
								{
									obj.m_4107(P_0, "Nuôi nick - Tạo Page");
								}, cancellationToken)))
								{
									m_4113 = true;
								}
								await b(A, (string P_0, string P_1) =>
								{
									onStep(new AiVisionStepLog
									{
										FlowStepIndex = m_4105++,
										SubStep = 1,
										ActionSummary = P_0,
										Reason = P_1
									});
								}, cancellationToken);
							});
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (!flag2)
						{
							await b(A, (string P_0, string P_1) =>
							{
								onStep(new AiVisionStepLog
								{
									FlowStepIndex = m_4105++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken);
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (!settings.WatchReels || Random.Shared.Next(0, 100) >= 12)
						{
							continue;
						}
						await m_4075("Xem Reels", (string P_0, string P_1) =>
						{
							onStep(new AiVisionStepLog
							{
								FlowStepIndex = m_4105++,
								SubStep = 1,
								ActionSummary = P_0,
								Reason = P_1
							});
						}, () => C(A, (string P_0, string P_1) =>
						{
							onStep(new AiVisionStepLog
							{
								FlowStepIndex = m_4105++,
								SubStep = 1,
								ActionSummary = P_0,
								Reason = P_1
							});
						}, cancellationToken));
					}
					if (settings.AutoFarmPage)
					{
						await m_4078(A, settings.PageFarming ?? new PageFarmingSettings(), (string P_0, string P_1) =>
						{
							onStep(new AiVisionStepLog
							{
								FlowStepIndex = m_4105++,
								SubStep = 1,
								ActionSummary = P_0,
								Reason = P_1
							});
						}, cancellationToken);
					}
					if (settings2.SaveNewCookieAfterLogin)
					{
						await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
					}
					result = new AiVisionRunResult
					{
						Success = true,
						Message = $"Đã lướt bảng tin xong ({num2} phút)" + (settings.AutoFarmPage ? " và nuôi các Page thành công." : "."),
						TinhTrang = "LIVE"
					};
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex2),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static async Task<ILocator?> m_4067(IPage P_0, string P_1)
	{
		ILocator locator = P_0.Locator(P_1);
		int num = await locator.CountAsync();
		int num2 = P_0.ViewportSize?.Height ?? 800;
		for (int l = 0; l < num; l++)
		{
			ILocator locator2 = locator.Nth(l);
			if (await locator2.IsVisibleAsync())
			{
				LocatorBoundingBoxResult locatorBoundingBoxResult = await locator2.BoundingBoxAsync();
				if (locatorBoundingBoxResult != null && locatorBoundingBoxResult.Y + locatorBoundingBoxResult.Height > 0f && locatorBoundingBoxResult.Y < (float)num2)
				{
					return locator2;
				}
			}
		}
		return null;
	}

	private static async Task m_4068(IPage P_0, Action<string, string> P_1, CancellationToken P_2)
	{
		ILocator locator = await m_4067(P_0, "[aria-label='Like']");
		if (locator == null)
		{
			P_1("[Bỏ qua] Không thấy nút Like nào trong khung nhìn.", "Lướt bảng tin - Like");
			return;
		}
		await locator.ClickAsync(new LocatorClickOptions
		{
			Timeout = 5000f
		});
		await Task.Delay(Random.Shared.Next(500, 1200), P_2);
		P_1("Đã Like 1 bài viết.", "Lướt bảng tin - Like");
	}

	private static async Task m_4069(IPage P_0, FeedBrowsingSettings P_1, Action<string, string> P_2, CancellationToken P_3)
	{
		string text = P_1.PickCommentText();
		if (text != null)
		{
			ILocator locator = await m_4067(P_0, "[aria-label$=' comment'], [aria-label$=' comments'], [aria-label='Leave a comment']");
			if (locator == null)
			{
				P_2("[Bỏ qua] Không thấy nút bình luận nào trong khung nhìn.", "Lướt bảng tin - Bình luận");
				return;
			}
			await locator.ClickAsync(new LocatorClickOptions
			{
				Timeout = 5000f
			});
			await Task.Delay(Random.Shared.Next(800, 1500), P_3);
			await P_0.Keyboard.TypeAsync(text, new KeyboardTypeOptions
			{
				Delay = Random.Shared.Next(60, 140)
			});
			await Task.Delay(500, P_3);
			await P_0.Keyboard.PressAsync("Enter");
			await Task.Delay(1000, P_3);
			P_2("Đã bình luận: \"" + text + "\"", "Lướt bảng tin - Bình luận");
		}
	}

	private static async Task m_4070(IPage P_0, Action<string, string> P_1, CancellationToken P_2)
	{
		ILocator locator = await m_4067(P_0, "[aria-label^='Actions for this post by ']");
		if (locator == null)
		{
			P_1("[Bỏ qua] Không xác định được người đăng bài viết trong khung nhìn.", "Lướt bảng tin - Xem trang cá nhân");
			return;
		}
		string text = (await locator.GetAttributeAsync("aria-label"))?.Replace("Actions for this post by ", "").Trim() ?? "";
		if (string.IsNullOrEmpty(text))
		{
			P_1("[Bỏ qua] Không đọc được tên người đăng bài viết.", "Lướt bảng tin - Xem trang cá nhân");
			return;
		}
		ILocator locator2 = locator.Locator("xpath=preceding::a[contains(., " + m_4077(text) + ")][1]");
		if (await locator2.CountAsync() == 0)
		{
			P_1("[Bỏ qua] Không tìm thấy link trang cá nhân của \"" + text + "\".", "Lướt bảng tin - Xem trang cá nhân");
			return;
		}
		string url = P_0.Url;
		await locator2.First.ClickAsync(new LocatorClickOptions
		{
			Timeout = 5000f
		});
		await Task.Delay(2000, P_2);
		if (P_0.Url == url)
		{
			P_1("[Bỏ qua] Không mở được trang cá nhân người đăng bài.", "Lướt bảng tin - Xem trang cá nhân");
			return;
		}
		P_1("Đang xem trang cá nhân \"" + text + "\"...", "Lướt bảng tin - Xem trang cá nhân");
		await m_4076(P_0, P_2);
	}

	private static async Task<int> m_4071(IPage P_0, FacebookAccountRow P_1, string P_2, HashSet<string> P_3, Action<string, string> P_4, CancellationToken P_5)
	{
		if (P_3.Contains(P_2))
		{
			return 0;
		}
		FriendRequestOutcome friendRequestOutcome = await FacebookFriendRequestActions.TrySendToUidAsync(P_0, P_2, P_5);
		if (friendRequestOutcome != FriendRequestOutcome.Error)
		{
			P_3.Add(P_2);
			FacebookFriendRequestActions.SaveSentUids(P_1, P_3);
		}
		int result = 0;
		switch (friendRequestOutcome)
		{
		case FriendRequestOutcome.Sent:
			result = 1;
			P_4("Đã gửi lời mời kết bạn tới " + P_2 + ".", "Lướt bảng tin - Kết bạn");
			break;
		case FriendRequestOutcome.AlreadyFriend:
			P_4("[Bỏ qua] " + P_2 + " đã là bạn bè.", "Lướt bảng tin - Kết bạn");
			break;
		case FriendRequestOutcome.AlreadyRequested:
			P_4("[Bỏ qua] " + P_2 + " đã được gửi lời mời từ trước.", "Lướt bảng tin - Kết bạn");
			break;
		case FriendRequestOutcome.NoButton:
			P_4("[Bỏ qua] " + P_2 + " không có nút Kết bạn.", "Lướt bảng tin - Kết bạn");
			break;
		default:
			P_4("[Bỏ qua] Không mở được trang cá nhân của " + P_2 + ".", "Lướt bảng tin - Kết bạn");
			break;
		}
		await b(P_0, P_4, P_5);
		return result;
	}

	private static async Task<int> m_4072(IPage P_0, FacebookAccountRow P_1, HashSet<string> P_2, Action<string, string> P_3, CancellationToken P_4)
	{
		ILocator locator = await m_4067(P_0, "[aria-label^='Actions for this post by ']");
		if (locator == null)
		{
			P_3("[Bỏ qua] Không xác định được người đăng bài viết trong khung nhìn.", "Lướt bảng tin - Kết bạn");
			return 0;
		}
		string text = (await locator.GetAttributeAsync("aria-label"))?.Replace("Actions for this post by ", "").Trim() ?? "";
		if (string.IsNullOrEmpty(text))
		{
			P_3("[Bỏ qua] Không đọc được tên người đăng bài viết.", "Lướt bảng tin - Kết bạn");
			return 0;
		}
		ILocator locator2 = locator.Locator("xpath=preceding::a[contains(., " + m_4077(text) + ")][1]");
		if (await locator2.CountAsync() == 0)
		{
			P_3("[Bỏ qua] Không tìm thấy link trang cá nhân của \"" + text + "\".", "Lướt bảng tin - Kết bạn");
			return 0;
		}
		string url = P_0.Url;
		await locator2.First.ClickAsync(new LocatorClickOptions
		{
			Timeout = 5000f
		});
		await Task.Delay(Random.Shared.Next(2500, 4000), P_4);
		if (P_0.Url == url)
		{
			P_3("[Bỏ qua] Không mở được trang cá nhân người đăng bài.", "Lướt bảng tin - Kết bạn");
			return 0;
		}
		string item = m_4073(P_0.Url);
		int result = 0;
		if (P_2.Contains(item))
		{
			P_3("[Bỏ qua] Đã từng gửi lời mời cho \"" + text + "\" trước đó.", "Lướt bảng tin - Kết bạn");
		}
		else
		{
			FriendRequestOutcome friendRequestOutcome = await FacebookFriendRequestActions.TrySendOnCurrentProfileAsync(P_0, P_4);
			if (friendRequestOutcome != FriendRequestOutcome.Error)
			{
				P_2.Add(item);
				FacebookFriendRequestActions.SaveSentUids(P_1, P_2);
			}
			switch (friendRequestOutcome)
			{
			case FriendRequestOutcome.Sent:
				result = 1;
				P_3("Đã gửi lời mời kết bạn tới \"" + text + "\".", "Lướt bảng tin - Kết bạn");
				break;
			case FriendRequestOutcome.AlreadyFriend:
				P_3("[Bỏ qua] \"" + text + "\" đã là bạn bè.", "Lướt bảng tin - Kết bạn");
				break;
			case FriendRequestOutcome.AlreadyRequested:
				P_3("[Bỏ qua] \"" + text + "\" đã được gửi lời mời từ trước.", "Lướt bảng tin - Kết bạn");
				break;
			default:
				P_3("[Bỏ qua] Trang của \"" + text + "\" không có nút Kết bạn.", "Lướt bảng tin - Kết bạn");
				break;
			}
		}
		await m_4076(P_0, P_4);
		return result;
	}

	private static string m_4073(string P_0)
	{
		try
		{
			Uri uri = new Uri(P_0);
			string text = uri.AbsolutePath.TrimEnd('/');
			if (text.EndsWith("/profile.php", StringComparison.OrdinalIgnoreCase))
			{
				Match match = Regex.Match(uri.Query, "[?&]id=(\\d+)");
				if (match.Success)
				{
					return match.Groups[1].Value;
				}
			}
			return text.TrimStart('/');
		}
		catch (UriFormatException)
		{
			return P_0;
		}
	}

	private static async Task B(IPage P_0, Action<string, string> P_1, CancellationToken P_2)
	{
		ILocator locator = await m_4067(P_0, "[aria-label$=' comment'], [aria-label$=' comments'], [aria-label='Leave a comment']");
		if (locator == null)
		{
			P_1("[Bỏ qua] Không thấy nút/bong bóng bình luận nào trong khung nhìn.", "Lướt bảng tin - Xem bình luận");
			return;
		}
		await locator.ClickAsync(new LocatorClickOptions
		{
			Timeout = 5000f
		});
		await Task.Delay(Random.Shared.Next(1500, 3000), P_2);
		P_1("Đang xem bình luận...", "Lướt bảng tin - Xem bình luận");
		try
		{
			int num = Random.Shared.Next(2, 5);
			for (int l = 0; l < num; l++)
			{
				P_2.ThrowIfCancellationRequested();
				await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(150, 350));
				await Task.Delay(Random.Shared.Next(1200, 2500), P_2);
			}
			ILocator locator2 = P_0.Locator("article[aria-label^='Comment by '] a[href*='facebook.com/']:not([href*='/posts/'])");
			if (await locator2.CountAsync() == 0)
			{
				P_1("[Bỏ qua] Bài viết chưa có bình luận nào rõ tên người bình luận.", "Lướt bảng tin - Xem bình luận");
				return;
			}
			string url = P_0.Url;
			await locator2.First.ClickAsync(new LocatorClickOptions
			{
				Timeout = 5000f
			});
			await Task.Delay(2000, P_2);
			if (P_0.Url == url)
			{
				P_1("[Bỏ qua] Không mở được trang cá nhân người bình luận.", "Lướt bảng tin - Xem bình luận");
				return;
			}
			P_1("Đang xem trang cá nhân người bình luận...", "Lướt bảng tin - Xem bình luận");
			await m_4076(P_0, P_2);
		}
		finally
		{
			await m_4074(P_0, P_2);
		}
	}

	private static async Task m_4074(IPage P_0, CancellationToken P_1)
	{
		ILocator locator = P_0.Locator("[role='dialog'] [aria-label='Close'][role='button']");
		if (await locator.CountAsync() == 0 || !(await locator.First.IsVisibleAsync()))
		{
			return;
		}
		await P_0.Keyboard.PressAsync("Escape");
		await Task.Delay(500, P_1);
		if (await locator.CountAsync() != 0)
		{
			try
			{
				await locator.First.ClickAsync(new LocatorClickOptions
				{
					Force = true,
					Timeout = 5000f
				});
			}
			catch (OperationCanceledException)
			{
				throw;
			}
			catch
			{
			}
			await Task.Delay(800, P_1);
		}
	}

	private static async Task<bool> m_4075(string P_0, Action<string, string> P_1, Func<Task> P_2)
	{
		try
		{
			await P_2();
			return true;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			string text = ex2.Message.Split('\n')[0].Trim();
			P_1("[Bỏ qua] " + P_0 + ": " + text, "Lướt bảng tin");
			return false;
		}
	}

	private static async Task b(IPage P_0, Action<string, string> P_1, CancellationToken P_2)
	{
		_ = 1;
		try
		{
			P_1("Về lại bảng tin để chạy tiếp...", "Lướt bảng tin");
			await P_0.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(1500, P_2);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
		}
	}

	private static async Task m_4076(IPage P_0, CancellationToken P_1)
	{
		int num = Random.Shared.Next(2, 5);
		for (int l = 0; l < num; l++)
		{
			P_1.ThrowIfCancellationRequested();
			await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(400, 800));
			await Task.Delay(Random.Shared.Next(1500, 3500), P_1);
		}
		P_1.ThrowIfCancellationRequested();
		try
		{
			await P_0.GoBackAsync(new PageGoBackOptions
			{
				Timeout = 15000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		catch
		{
			await P_0.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		await Task.Delay(1500, P_1);
	}

	private static async Task C(IPage P_0, Action<string, string> P_1, CancellationToken P_2)
	{
		P_1("Đang ghé xem Reels...", "Lướt bảng tin - Xem Reels");
		try
		{
			await P_0.GotoAsync("https://www.facebook.com/reels/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(2000, P_2);
			int num = Random.Shared.Next(2, 5);
			for (int l = 0; l < num; l++)
			{
				P_2.ThrowIfCancellationRequested();
				await Task.Delay(Random.Shared.Next(4000, 9000), P_2);
				await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(600, 1000));
				await Task.Delay(500, P_2);
			}
		}
		finally
		{
			await P_0.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(1500, P_2);
		}
	}

	private static string m_4077(string P_0)
	{
		if (!P_0.Contains('\''))
		{
			return "'" + P_0 + "'";
		}
		string[] value = P_0.Split('\'');
		return "concat('" + string.Join("', \"'\", '", value) + "')";
	}

	private static async Task m_4078(IPage P_0, PageFarmingSettings P_1, Action<string, string> P_2, CancellationToken P_3)
	{
		string m_4087 = "Nuôi Page";
		P_2("Bắt đầu quy trình Nuôi Trang (Page)...", m_4087);
		List<string> list = P_1.TargetPageNames?.Where((string value) => !string.IsNullOrWhiteSpace(value)).Select((string text) => text.Trim()).Distinct(StringComparer.OrdinalIgnoreCase)
			.ToList() ?? new List<string>();
		if (list.Count == 0)
		{
			P_2("Quét danh sách các Page đang quản lý từ tài khoản...", m_4087);
			list = await FacebookPagePostRunner.ScanPagesFromProfileMenuAsync(P_0, P_3);
		}
		if (P_1.MaxPages > 0 && list.Count > P_1.MaxPages)
		{
			list = list.Take(P_1.MaxPages).ToList();
		}
		if (list.Count == 0)
		{
			P_2("[Bỏ qua] Không tìm thấy Page nào trên tài khoản để nuôi.", m_4087);
			return;
		}
		P_2($"Tìm thấy {list.Count} Page để nuôi.", m_4087);
		for (int num = 0; num < list.Count; num++)
		{
			P_3.ThrowIfCancellationRequested();
			string A = list[num];
			P_2($"[{num + 1}/{list.Count}] Đang chuyển sang Page \"{A}\"...", m_4087);
			if (!(await FacebookPagePostRunner.SwitchToPageAsync(P_0, A, (string arg) =>
			{
				P_2(arg, m_4087);
			}, P_3)))
			{
				P_2("[Bỏ qua] Không chuyển được sang Page \"" + A + "\", chuyển sang Page kế tiếp.", m_4087);
				continue;
			}
			await Task.Delay(2500, P_3);
			int num2 = P_1.PickDurationMinutes();
			DateTime dateTime = DateTime.UtcNow.AddMinutes(num2);
			P_2($"[{A}] Lướt bảng tin Page trong {num2} phút...", m_4087);
			while (DateTime.UtcNow < dateTime)
			{
				P_3.ThrowIfCancellationRequested();
				await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(400, 900));
				await Task.Delay(Random.Shared.Next(1500, 4500), P_3);
				if (P_1.AutoLike && P_1.RollChance(P_1.LikeChancePercent))
				{
					await m_4075("Like bài viết trên Page", P_2, () => m_4068(P_0, P_2, P_3));
				}
				if (P_1.WatchReels && Random.Shared.Next(0, 100) < 15)
				{
					await m_4075("Xem Reels trên Page", P_2, () => C(P_0, P_2, P_3));
				}
			}
			if (P_1.AutoPost)
			{
				PostCreationSettings postCreationSettings = P_1.Post ?? new PostCreationSettings();
				int num3 = Math.Max(1, P_1.PostsPerPage);
				for (int num4 = 0; num4 < num3; num4++)
				{
					P_3.ThrowIfCancellationRequested();
					string A2 = postCreationSettings.PickContent();
					List<string> m_4098 = postCreationSettings.PickMediaFiles();
					if (string.IsNullOrWhiteSpace(A2) && m_4098.Count <= 0)
					{
						continue;
					}
					P_2($"[{A}] Đang đăng bài [{num4 + 1}/{num3}] lên Page...", m_4087);
					await m_4075("Đăng bài lên Page", P_2, () => FacebookPagePostRunner.PostSingleToPageAsync(P_0, A, A2, m_4098, (string arg) =>
					{
						P_2(arg, m_4087);
					}, P_3));
					if (num4 < num3 - 1)
					{
						int num5 = postCreationSettings.PickSpacingSeconds();
						P_2($"[{A}] Chờ {num5}s trước bài tiếp theo...", m_4087);
						await Task.Delay(num5 * 1000, P_3);
					}
				}
			}
			if (num < list.Count - 1 && P_1.PageSwitchDelaySeconds > 0)
			{
				P_2($"Chờ {P_1.PageSwitchDelaySeconds}s trước khi chuyển sang Page tiếp theo...", m_4087);
				await Task.Delay(P_1.PageSwitchDelaySeconds * 1000, P_3);
			}
		}
		P_2("Hoàn thành nuôi các Page!", m_4087);
	}
}
