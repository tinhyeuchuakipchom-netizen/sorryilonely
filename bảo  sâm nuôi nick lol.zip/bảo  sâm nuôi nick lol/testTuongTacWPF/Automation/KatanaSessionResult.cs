using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class KatanaSessionResult
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private string m_2829 = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string C = "";

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Uid
	{
		[CompilerGenerated]
		get
		{
			return m_2829;
		}
		[CompilerGenerated]
		set
		{
			m_2829 = value;
		}
	}

	public string Token
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Cookie
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string RawText
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string ErrorMessage
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public string FormattedResult => $"{Uid}|{Token}|{Cookie}";
}
