using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookPostBoostRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5174
	{
		public static readonly m_5174 A = new m_5174();

		public static Func<string, bool> m_5178;

		internal bool m_5179(string P_0)
		{
			return P_0.Contains("facebook.com", StringComparison.OrdinalIgnoreCase);
		}
	}

	[CompilerGenerated]
	private sealed class m_5175
	{
		public Action<AiVisionStepLog> A;

		public int m_5180;

		internal void m_5181(string P_0, string P_1)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_5180++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = P_1
			});
		}
	}

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, PostBoostSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		m_5175 CS_0024_003C_003E8__locals12 = new m_5175();
		CS_0024_003C_003E8__locals12.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		List<string> list = settings.PostLinks.Where((string P_0) => P_0.Contains("facebook.com", StringComparison.OrdinalIgnoreCase)).Distinct().ToList();
		if (list.Count == 0)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Chưa cấu hình link bài viết hợp lệ nào.",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		CS_0024_003C_003E8__locals12.m_5180 = 0;
		HashSet<string> hashSet = A(nick);
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		AiVisionRunResult result;
		try
		{
			_ = 12;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals12.m_5181("Đang đăng nhập...", "Nuôi bài viết");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals12.A(new AiVisionStepLog
					{
						FlowStepIndex = CS_0024_003C_003E8__locals12.m_5180++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = P_1
					});
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để nuôi bài viết: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					CS_0024_003C_003E8__locals12.m_5181($"Đang xử lý {list.Count} bài viết...", "Nuôi bài viết");
					foreach (string item2 in list)
					{
						cancellationToken.ThrowIfCancellationRequested();
						CS_0024_003C_003E8__locals12.m_5181("Đang mở bài viết: " + item2, "Nuôi bài viết");
						try
						{
							await page2.GotoAsync(FacebookUrls.WithEnglishLocale(item2), new PageGotoOptions
							{
								Timeout = 30000f,
								WaitUntil = WaitUntilState.DOMContentLoaded
							});
						}
						catch (Exception ex) when (!(ex is OperationCanceledException))
						{
							CS_0024_003C_003E8__locals12.m_5181("[Bỏ qua] Không mở được bài viết: " + ex.Message, "Nuôi bài viết");
							continue;
						}
						await Task.Delay(Random.Shared.Next(2000, 3500), cancellationToken);
						bool flag = false;
						if (settings.AutoLike && !hashSet.Contains(item2 + "|Like"))
						{
							bool flag2 = await A(page2, cancellationToken);
							hashSet.Add(item2 + "|Like");
							if (flag2)
							{
								num++;
								flag = true;
								CS_0024_003C_003E8__locals12.m_5181("Đã Like bài viết.", "Nuôi bài viết - Like");
							}
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoComment && !hashSet.Contains(item2 + "|Comment"))
						{
							string text = settings.PickCommentText();
							if (text != null)
							{
								bool flag3 = await A(page2, text, cancellationToken);
								hashSet.Add(item2 + "|Comment");
								if (flag3)
								{
									num2++;
									flag = true;
									CS_0024_003C_003E8__locals12.m_5181("Đã bình luận: \"" + text + "\"", "Nuôi bài viết - Bình luận");
								}
							}
						}
						cancellationToken.ThrowIfCancellationRequested();
						if (settings.AutoShare && !hashSet.Contains(item2 + "|Share"))
						{
							bool flag4 = await B(page2, cancellationToken);
							hashSet.Add(item2 + "|Share");
							if (flag4)
							{
								num3++;
								flag = true;
								CS_0024_003C_003E8__locals12.m_5181("Đã chia sẻ bài viết.", "Nuôi bài viết - Chia sẻ");
							}
						}
						if (!flag)
						{
							CS_0024_003C_003E8__locals12.m_5181("[Bỏ qua] Bài này đã xử lý xong từ lượt chạy trước (hoặc không thực hiện được hành động nào).", "Nuôi bài viết");
						}
						await Task.Delay(TimeSpan.FromSeconds(settings.PickSpacingSeconds()), cancellationToken);
					}
					if (settings2.SaveNewCookieAfterLogin)
					{
						await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
					}
					result = new AiVisionRunResult
					{
						Success = true,
						Message = $"Đã nuôi {list.Count} bài viết xong (Like {num}, bình luận {num2}, chia sẻ {num3}).",
						TinhTrang = "LIVE"
					};
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex3)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex3),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			A(nick, hashSet);
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static async Task<bool> A(IPage P_0, CancellationToken P_1)
	{
		if (await P_0.Locator("[aria-label='Remove Like']").CountAsync() > 0)
		{
			return false;
		}
		ILocator first = P_0.Locator("[aria-label='Like']").First;
		if (await first.CountAsync() == 0)
		{
			return false;
		}
		await A(first, P_1);
		await Task.Delay(Random.Shared.Next(500, 1200), P_1);
		return true;
	}

	private static async Task A(ILocator P_0, CancellationToken P_1)
	{
		await P_0.ScrollIntoViewIfNeededAsync();
		await Task.Delay(400, P_1);
		try
		{
			await P_0.ClickAsync(new LocatorClickOptions
			{
				Timeout = 8000f
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			await P_0.ClickAsync(new LocatorClickOptions
			{
				Force = true,
				Timeout = 5000f
			});
		}
	}

	private static async Task<bool> A(IPage P_0, string P_1, CancellationToken P_2)
	{
		ILocator first = P_0.Locator("[aria-label$=' comment'], [aria-label$=' comments'], [aria-label='Leave a comment']").First;
		if (await first.CountAsync() == 0)
		{
			return false;
		}
		await A(first, P_2);
		await Task.Delay(Random.Shared.Next(1200, 2200), P_2);
		if (await a(P_0, P_2))
		{
			return false;
		}
		await P_0.Keyboard.TypeAsync(P_1, new KeyboardTypeOptions
		{
			Delay = Random.Shared.Next(60, 140)
		});
		await Task.Delay(500, P_2);
		await P_0.Keyboard.PressAsync("Enter");
		await Task.Delay(1000, P_2);
		return true;
	}

	private static async Task<bool> a(IPage P_0, CancellationToken P_1)
	{
		ILocator locator = P_0.Locator("[contenteditable='true'][aria-label]");
		if (await locator.CountAsync() == 0)
		{
			return false;
		}
		string text = await locator.First.GetAttributeAsync("aria-label");
		if (string.IsNullOrWhiteSpace(text))
		{
			return false;
		}
		int num = text.LastIndexOf(" as ", StringComparison.Ordinal);
		if (num < 0)
		{
			return false;
		}
		string text2 = text.Substring(num + 4).Trim();
		if (text2.Length == 0)
		{
			return false;
		}
		ILocator locator2 = P_0.Locator("[role='dialog']");
		ILocator locator3 = ((await locator2.CountAsync() > 0) ? locator2.Locator("article[aria-label^='Comment by ']") : P_0.Locator("article[aria-label^='Comment by ']"));
		int num2 = await locator3.CountAsync();
		for (int i = 0; i < num2; i++)
		{
			P_1.ThrowIfCancellationRequested();
			string text3 = await locator3.Nth(i).GetAttributeAsync("aria-label");
			if (!string.IsNullOrEmpty(text3) && (text3.StartsWith("Comment by ", StringComparison.Ordinal) ? text3.Substring("Comment by ".Length) : text3).Contains(text2, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private static async Task<bool> B(IPage P_0, CancellationToken P_1)
	{
		ILocator first = P_0.Locator("[aria-label='Send this to friends or post it on your profile.']").First;
		if (await first.CountAsync() == 0)
		{
			return false;
		}
		await A(first, P_1);
		await Task.Delay(Random.Shared.Next(1200, 2200), P_1);
		ILocator first2 = P_0.Locator("[role='dialog'] [aria-label='Share now']").First;
		if (await first2.CountAsync() == 0)
		{
			await b(P_0, P_1);
			return false;
		}
		await A(first2, P_1);
		await Task.Delay(2000, P_1);
		await b(P_0, P_1);
		return true;
	}

	private static async Task b(IPage P_0, CancellationToken P_1)
	{
		ILocator locator = P_0.Locator("[role='dialog'] [aria-label='Close'][role='button']");
		if (await locator.CountAsync() != 0 && await locator.First.IsVisibleAsync())
		{
			await A(locator.First, P_1);
			await Task.Delay(800, P_1);
		}
	}

	private static HashSet<string> A(FacebookAccountRow P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0.PostBoostDoneActionsJson))
		{
			return new HashSet<string>();
		}
		try
		{
			List<string> list = JsonSerializer.Deserialize<List<string>>(P_0.PostBoostDoneActionsJson);
			return (list == null) ? new HashSet<string>() : new HashSet<string>(list);
		}
		catch (JsonException)
		{
			return new HashSet<string>();
		}
	}

	private static void A(FacebookAccountRow P_0, HashSet<string> P_1)
	{
		P_0.PostBoostDoneActionsJson = JsonSerializer.Serialize(P_1.ToList());
	}
}
