using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class RegistrationChannelSettings
{
	[CompilerGenerated]
	private string A = "Mail";

	private static readonly string a = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "registration_channel_settings.json");

	public string Channel
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public static RegistrationChannelSettings Load()
	{
		try
		{
			if (!File.Exists(a))
			{
				return new RegistrationChannelSettings();
			}
			return JsonSerializer.Deserialize<RegistrationChannelSettings>(File.ReadAllText(a)) ?? new RegistrationChannelSettings();
		}
		catch
		{
			return new RegistrationChannelSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(a));
		File.WriteAllText(a, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
