using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class AiVisionTestResult
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private double m_2906;

	[CompilerGenerated]
	private string m_2907 = "";

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public double ElapsedSeconds
	{
		[CompilerGenerated]
		get
		{
			return m_2906;
		}
		[CompilerGenerated]
		set
		{
			m_2906 = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return m_2907;
		}
		[CompilerGenerated]
		set
		{
			m_2907 = value;
		}
	}
}
