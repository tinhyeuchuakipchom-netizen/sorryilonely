namespace testTuongTacWPF.Automation;

public interface IChromeEngineSettings
{
	string LoginType { get; }

	bool SaveNewCookieAfterLogin { get; }

	bool AutoCloseChromeAfterLogin { get; }

	bool UseProxy { get; }
}
