using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class IPhoneDeviceController : IDeviceController
{
	public async Task<byte[]> ScreenshotAsync(CancellationToken cancellationToken)
	{
		byte[] array = await IPhoneController.ScreenshotAsync();
		if (array == null || array.Length == 0)
		{
			throw new InvalidOperationException("Không chụp được màn hình iPhone (kiểm tra WebDriverAgent còn chạy không).");
		}
		return array;
	}

	public async Task<(int Width, int Height)> GetScreenSizeAsync(CancellationToken cancellationToken)
	{
		(int, int)? tuple = await IPhoneController.GetScreenSizeAsync();
		if (!tuple.HasValue)
		{
			throw new InvalidOperationException("Không đọc được kích thước màn hình iPhone (kiểm tra WebDriverAgent còn chạy không).");
		}
		return tuple.Value;
	}

	public Task<List<UiElement>> DumpUiElementsAsync(CancellationToken cancellationToken)
	{
		return IPhoneController.DumpUiElementsAsync();
	}

	public async Task TapAsync(int x, int y, CancellationToken cancellationToken)
	{
		if (!(await IPhoneController.TapAsync(x, y)))
		{
			throw new InvalidOperationException($"Không gửi được thao tác chạm ({x},{y}) tới iPhone.");
		}
	}

	public async Task SwipeAsync(int x1, int y1, int x2, int y2, int durationMs, CancellationToken cancellationToken)
	{
		if (!(await IPhoneController.SwipeAsync(x1, y1, x2, y2, (double)durationMs / 1000.0)))
		{
			throw new InvalidOperationException($"Không gửi được thao tác vuốt ({x1},{y1})→({x2},{y2}) tới iPhone.");
		}
	}

	public async Task InputTextAsync(string text, CancellationToken cancellationToken)
	{
		if (!(await IPhoneController.TypeTextReplacingAsync(text)))
		{
			throw new InvalidOperationException("Không gõ được chữ vào iPhone (có thể chưa ô nào đang nhận focus).");
		}
	}

	public async Task KeyEventAsync(string keycode, CancellationToken cancellationToken)
	{
		await IPhoneController.KeyEventAsync(keycode);
	}
}
