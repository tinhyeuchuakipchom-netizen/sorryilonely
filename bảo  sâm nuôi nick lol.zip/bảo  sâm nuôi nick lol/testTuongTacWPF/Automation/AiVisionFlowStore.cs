using System.Collections.Generic;
using System.Text.Json;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class AiVisionFlowStore
{
	public static AiVisionFlowDocument Deserialize(string json)
	{
		try
		{
			if (string.IsNullOrWhiteSpace(json))
			{
				return new AiVisionFlowDocument();
			}
			if (json.TrimStart().StartsWith("["))
			{
				AiVisionFlowStep[] array = JsonSerializer.Deserialize<AiVisionFlowStep[]>(json);
				return new AiVisionFlowDocument
				{
					Steps = ((array != null) ? new List<AiVisionFlowStep>(array) : new List<AiVisionFlowStep>())
				};
			}
			return JsonSerializer.Deserialize<AiVisionFlowDocument>(json) ?? new AiVisionFlowDocument();
		}
		catch
		{
			return new AiVisionFlowDocument();
		}
	}

	public static string Serialize(IEnumerable<AiVisionFlowStep> steps)
	{
		return JsonSerializer.Serialize(new AiVisionFlowDocument
		{
			Steps = new List<AiVisionFlowStep>(steps)
		}, new JsonSerializerOptions
		{
			WriteIndented = true
		});
	}
}
