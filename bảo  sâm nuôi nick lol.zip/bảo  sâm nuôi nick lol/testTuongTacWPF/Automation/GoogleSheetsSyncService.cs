using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Util.Store;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class GoogleSheetsSyncService
{
	[CompilerGenerated]
	private sealed class m_5508
	{
		public string A;

		internal bool m_5510(Sheet P_0)
		{
			return P_0.Properties.Title == A;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct m_5509
	{
		public IList<object> A;
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct B
	{
		public IList<object> A;
	}

	private static readonly string A = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "google_sheets_token");

	private static readonly string[] m_5501 = new string[1] { SheetsService.Scope.Spreadsheets };

	private static readonly string[] a = new string[22]
	{
		"STT", "UID", "MẬT KHẨU", "2FA", "TOKEN", "COOKIE", "MAIL", "MẬT KHẨU MAIL", "MAIL KHÔI PHỤC", "BẠN BÈ",
		"NHÓM", "HỌ TÊN", "GIỚI TÍNH", "AVATAR", "PROXY", "GHI CHÚ", "TƯƠNG TÁC CUỐI", "TRẠNG THÁI", "TÌNH TRẠNG", "NỀN TẢNG",
		"PHONE", "KỊCH BẢN"
	};

	public static bool IsSignedIn
	{
		get
		{
			if (Directory.Exists(A))
			{
				return Directory.EnumerateFileSystemEntries(A).Any();
			}
			return false;
		}
	}

	public static string ExtractSpreadsheetId(string urlOrId)
	{
		if (string.IsNullOrWhiteSpace(urlOrId))
		{
			return "";
		}
		Match match = Regex.Match(urlOrId, "/d/([a-zA-Z0-9_-]+)");
		if (!match.Success)
		{
			return urlOrId.Trim();
		}
		return match.Groups[1].Value;
	}

	public static void SignOut()
	{
		try
		{
			if (Directory.Exists(A))
			{
				Directory.Delete(A, recursive: true);
			}
		}
		catch
		{
		}
	}

	public static async Task<SheetsService> AuthorizeAsync(GoogleSheetsSyncSettings settings, CancellationToken cancellationToken)
	{
		if (string.IsNullOrWhiteSpace(settings.ClientId) || string.IsNullOrWhiteSpace(settings.ClientSecret))
		{
			throw new InvalidOperationException("Chưa nhập Client ID/Client Secret của Google OAuth.");
		}
		UserCredential httpClientInitializer = await GoogleWebAuthorizationBroker.AuthorizeAsync(new ClientSecrets
		{
			ClientId = settings.ClientId,
			ClientSecret = settings.ClientSecret
		}, m_5501, "user", cancellationToken, new FileDataStore(A, fullPath: true));
		return new SheetsService(new BaseClientService.Initializer
		{
			HttpClientInitializer = httpClientInitializer,
			ApplicationName = "FastBoxPhone"
		});
	}

	public static async Task SyncFolderAsync(SheetsService service, string spreadsheetId, string folderName, IReadOnlyList<IList<object>> rowValues, CancellationToken cancellationToken)
	{
		string text = m_5505(folderName);
		await m_5503(service, spreadsheetId, text, cancellationToken);
		await m_5504(service, spreadsheetId, text, rowValues, cancellationToken);
	}

	public static List<IList<object>> BuildRows(IReadOnlyList<FacebookAccountRow> rows)
	{
		List<IList<object>> list = new List<IList<object>>();
		int num = 1;
		foreach (FacebookAccountRow row in rows)
		{
			list.Add(new List<object>
			{
				num++,
				row.Uid,
				row.Pass,
				row.TwoFA,
				row.Token,
				row.Cookie,
				row.Mail,
				row.PassMail,
				row.MailKhoiPhuc,
				row.BanBe,
				row.Nhom,
				row.HoTen,
				row.GioiTinh,
				row.Avatar,
				row.Proxy,
				row.GhiChu,
				row.TuongTacCuoi,
				row.TrangThai,
				row.TinhTrang,
				row.Platform,
				row.PhoneName,
				row.ScriptName
			});
		}
		return list;
	}

	public static List<IList<object>> BuildRows(IReadOnlyList<PlatformAccountRow> rows)
	{
		List<IList<object>> list = new List<IList<object>>();
		int num = 1;
		foreach (PlatformAccountRow row in rows)
		{
			list.Add(new List<object>
			{
				num++,
				row.Uid,
				row.Pass,
				row.TwoFA,
				row.Token,
				row.Cookie,
				row.Mail,
				row.PassMail,
				row.MailKhoiPhuc,
				"",
				"",
				"",
				"",
				"",
				row.Proxy,
				row.GhiChu,
				"",
				row.TrangThai,
				row.TinhTrang,
				row.Platform,
				row.PhoneName,
				row.ScriptName
			});
		}
		return list;
	}

	public static async Task DeleteFolderSheetAsync(SheetsService service, string spreadsheetId, string folderName, CancellationToken cancellationToken)
	{
		string text = m_5505(folderName);
		int? sheetId = await m_5502(service, spreadsheetId, text, cancellationToken);
		if (sheetId.HasValue)
		{
			BatchUpdateSpreadsheetRequest body = new BatchUpdateSpreadsheetRequest
			{
				Requests = new List<Request>
				{
					new Request
					{
						DeleteSheet = new DeleteSheetRequest
						{
							SheetId = sheetId
						}
					}
				}
			};
			await service.Spreadsheets.BatchUpdate(body, spreadsheetId).ExecuteAsync(cancellationToken);
		}
	}

	public static async Task RenameFolderSheetAsync(SheetsService service, string spreadsheetId, string oldFolderName, string newFolderName, CancellationToken cancellationToken)
	{
		string text = m_5505(oldFolderName);
		string title = m_5505(newFolderName);
		int? sheetId = await m_5502(service, spreadsheetId, text, cancellationToken);
		if (sheetId.HasValue)
		{
			BatchUpdateSpreadsheetRequest body = new BatchUpdateSpreadsheetRequest
			{
				Requests = new List<Request>
				{
					new Request
					{
						UpdateSheetProperties = new UpdateSheetPropertiesRequest
						{
							Properties = new SheetProperties
							{
								SheetId = sheetId,
								Title = title
							},
							Fields = "title"
						}
					}
				}
			};
			await service.Spreadsheets.BatchUpdate(body, spreadsheetId).ExecuteAsync(cancellationToken);
		}
	}

	private static async Task<int?> m_5502(SheetsService P_0, string P_1, string P_2, CancellationToken P_3)
	{
		return (await P_0.Spreadsheets.Get(P_1).ExecuteAsync(P_3)).Sheets.FirstOrDefault((Sheet sheet) => sheet.Properties.Title == P_2)?.Properties.SheetId;
	}

	private static async Task m_5503(SheetsService P_0, string P_1, string P_2, CancellationToken P_3)
	{
		if (!(await m_5502(P_0, P_1, P_2, P_3)).HasValue)
		{
			BatchUpdateSpreadsheetRequest body = new BatchUpdateSpreadsheetRequest
			{
				Requests = new List<Request>
				{
					new Request
					{
						AddSheet = new AddSheetRequest
						{
							Properties = new SheetProperties
							{
								Title = P_2
							}
						}
					}
				}
			};
			await P_0.Spreadsheets.BatchUpdate(body, P_1).ExecuteAsync(P_3);
		}
	}

	private static async Task m_5504(SheetsService P_0, string P_1, string P_2, IReadOnlyList<IList<object>> P_3, CancellationToken P_4)
	{
		await P_0.Spreadsheets.Values.Clear(new ClearValuesRequest(), P_1, "'" + P_2 + "'!A1:Z100000").ExecuteAsync(P_4);
		List<IList<object>> list = new List<IList<object>> { a.Cast<object>().ToList() };
		list.AddRange(P_3);
		ValueRange body = new ValueRange
		{
			Values = list
		};
		SpreadsheetsResource.ValuesResource.UpdateRequest updateRequest = P_0.Spreadsheets.Values.Update(body, P_1, "'" + P_2 + "'!A1");
		updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.RAW;
		await updateRequest.ExecuteAsync(P_4);
	}

	public static async Task<Dictionary<string, List<FacebookAccountRow>>> ImportAllSheetsAsync(SheetsService service, string spreadsheetId, CancellationToken cancellationToken)
	{
		Spreadsheet spreadsheet = await service.Spreadsheets.Get(spreadsheetId).ExecuteAsync(cancellationToken);
		Dictionary<string, List<FacebookAccountRow>> dictionary = new Dictionary<string, List<FacebookAccountRow>>();
		m_5509 obj = default;
		foreach (Sheet sheet in spreadsheet.Sheets)
		{
			string title = sheet.Properties.Title;
			List<FacebookAccountRow> list = new List<FacebookAccountRow>();
			ValueRange valueRange = await service.Spreadsheets.Values.Get(spreadsheetId, "'" + title + "'!A2:V100000").ExecuteAsync(cancellationToken);
			if (valueRange.Values != null)
			{
				foreach (IList<object> value in valueRange.Values)
				{
					obj.A = value;
					string text = m_5506(1, ref obj);
					if (!string.IsNullOrWhiteSpace(text))
					{
						list.Add(new FacebookAccountRow
						{
							Uid = text,
							Pass = m_5506(2, ref obj),
							TwoFA = m_5506(3, ref obj),
							Token = m_5506(4, ref obj),
							Cookie = m_5506(5, ref obj),
							Mail = m_5506(6, ref obj),
							PassMail = m_5506(7, ref obj),
							MailKhoiPhuc = m_5506(8, ref obj),
							BanBe = m_5506(9, ref obj),
							Nhom = m_5506(10, ref obj),
							HoTen = m_5506(11, ref obj),
							GioiTinh = m_5506(12, ref obj),
							Avatar = m_5506(13, ref obj),
							Proxy = m_5506(14, ref obj),
							GhiChu = m_5506(15, ref obj),
							TuongTacCuoi = m_5506(16, ref obj),
							TrangThai = m_5506(17, ref obj),
							TinhTrang = m_5506(18, ref obj),
							PhoneName = m_5506(20, ref obj),
							ScriptName = m_5506(21, ref obj)
						});
					}
				}
			}
			dictionary[title] = list;
		}
		return dictionary;
	}

	public static async Task<Dictionary<string, List<PlatformAccountRow>>> ImportAllSheetsAsPlatformRowsAsync(SheetsService service, string spreadsheetId, CancellationToken cancellationToken)
	{
		Spreadsheet spreadsheet = await service.Spreadsheets.Get(spreadsheetId).ExecuteAsync(cancellationToken);
		Dictionary<string, List<PlatformAccountRow>> dictionary = new Dictionary<string, List<PlatformAccountRow>>();
		B b2 = default;
		foreach (Sheet sheet in spreadsheet.Sheets)
		{
			string title = sheet.Properties.Title;
			List<PlatformAccountRow> list = new List<PlatformAccountRow>();
			ValueRange valueRange = await service.Spreadsheets.Values.Get(spreadsheetId, "'" + title + "'!A2:V100000").ExecuteAsync(cancellationToken);
			if (valueRange.Values != null)
			{
				foreach (IList<object> value in valueRange.Values)
				{
					b2.A = value;
					string text = m_5507(1, ref b2);
					if (!string.IsNullOrWhiteSpace(text))
					{
						list.Add(new PlatformAccountRow
						{
							Uid = text,
							Pass = m_5507(2, ref b2),
							TwoFA = m_5507(3, ref b2),
							Token = m_5507(4, ref b2),
							Cookie = m_5507(5, ref b2),
							Mail = m_5507(6, ref b2),
							PassMail = m_5507(7, ref b2),
							MailKhoiPhuc = m_5507(8, ref b2),
							Proxy = m_5507(14, ref b2),
							GhiChu = m_5507(15, ref b2),
							TrangThai = m_5507(17, ref b2),
							TinhTrang = m_5507(18, ref b2),
							PhoneName = m_5507(20, ref b2),
							ScriptName = m_5507(21, ref b2)
						});
					}
				}
			}
			dictionary[title] = list;
		}
		return dictionary;
	}

	private static string m_5505(string P_0)
	{
		string text = Regex.Replace(P_0, "[:\\\\/?*\\[\\]]", "-").Trim();
		if (string.IsNullOrWhiteSpace(text))
		{
			text = "Thư mục";
		}
		if (text.Length <= 100)
		{
			return text;
		}
		return text.Substring(0, 100);
	}

	[CompilerGenerated]
	internal static string m_5506(int P_0, ref m_5509 P_1)
	{
		if (P_0 >= P_1.A.Count)
		{
			return "";
		}
		return P_1.A[P_0]?.ToString() ?? "";
	}

	[CompilerGenerated]
	internal static string m_5507(int P_0, ref B P_1)
	{
		if (P_0 >= P_1.A.Count)
		{
			return "";
		}
		return P_1.A[P_0]?.ToString() ?? "";
	}
}
