using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class ActiveBrowserEngine
{
	[CompilerGenerated]
	private IAntidetectBrowserClient A;

	[CompilerGenerated]
	private IChromeEngineSettings m_3400;

	[CompilerGenerated]
	private string m_3401 = "";

	[CompilerGenerated]
	private string a = "";

	public IAntidetectBrowserClient Client
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public IChromeEngineSettings Settings
	{
		[CompilerGenerated]
		get
		{
			return m_3400;
		}
		[CompilerGenerated]
		set
		{
			m_3400 = value;
		}
	}

	public string ApiUrl
	{
		[CompilerGenerated]
		get
		{
			return m_3401;
		}
		[CompilerGenerated]
		set
		{
			m_3401 = value;
		}
	}

	public string DisplayName
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
