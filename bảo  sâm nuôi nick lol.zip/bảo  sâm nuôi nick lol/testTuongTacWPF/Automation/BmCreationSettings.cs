using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class BmCreationSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3390
	{
		public static readonly m_3390 A = new m_3390();

		public static Func<string, bool> m_3391;

		public static Func<string, string> m_3392;

		public static Func<string, bool> a;

		public static Func<string, string> m_3393;

		internal bool m_3394(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_3395(string P_0)
		{
			return P_0.Trim();
		}

		internal bool B(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string b(string P_0)
		{
			return P_0.Trim();
		}
	}

	[CompilerGenerated]
	private BmBusinessNameMode A;

	[CompilerGenerated]
	private List<string> m_3380 = new List<string>();

	[CompilerGenerated]
	private bool m_3381 = true;

	[CompilerGenerated]
	private BmAdminNameMode m_3382;

	[CompilerGenerated]
	private List<string> a = new List<string>();

	[CompilerGenerated]
	private bool m_3383 = true;

	[CompilerGenerated]
	private string m_3384 = "gmail.com";

	[CompilerGenerated]
	private int m_3385 = 1;

	[CompilerGenerated]
	private int m_3386 = 10;

	[CompilerGenerated]
	private int B = 30;

	private static readonly string[] m_3387 = new string[20]
	{
		"Apex", "Nova", "Summit", "Nexus", "Pioneer", "Vertex", "Pulse", "Zenith", "Prime", "Quantum",
		"Vanguard", "Catalyst", "Alpha", "Titan", "Horizon", "Starlight", "Core", "Global", "Atlas", "Echo"
	};

	private static readonly string[] m_3388 = new string[16]
	{
		"Digital", "Media", "Commerce", "Marketing", "Ventures", "Studio", "Creative", "Solutions", "Technologies", "Brand",
		"Interactive", "Network", "Capital", "Holdings", "Consulting", "Enterprise"
	};

	private static readonly string[] m_3389 = new string[10] { "Group", "Global", "Agency", "Labs", "Partners", "Co", "Corp", "International", "Hub", "Works" };

	private static readonly string[] b = new string[11]
	{
		"Công Ty TNHH", "Tập Đoàn", "Thương Mại & Dịch Vụ", "Truyền Thông Số", "Giải Pháp Số", "Dịch Vụ Quảng Cáo", "Thời Trang", "Nội Thất", "Gia Dụng Thông Minh", "Bất Động Sản",
		"Đầu Tư Phát Triển"
	};

	private static readonly string[] C = new string[14]
	{
		"Minh Phát", "Hoàng Gia", "An Khang", "Thịnh Vượng", "Đại Nam", "Việt Nhật", "Bảo Long", "Thiên Ân", "Vạn Lộc", "Khánh An",
		"Phương Nam", "Toàn Cầu", "Đông Á", "Tân Tiến"
	};

	[JsonConverter(typeof(JsonStringEnumConverter))]
	public BmBusinessNameMode BusinessNameMode
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public List<string> CustomBusinessNames
	{
		[CompilerGenerated]
		get
		{
			return m_3380;
		}
		[CompilerGenerated]
		set
		{
			m_3380 = value;
		}
	}

	public bool PickCustomBusinessNameRandomly
	{
		[CompilerGenerated]
		get
		{
			return m_3381;
		}
		[CompilerGenerated]
		set
		{
			m_3381 = value;
		}
	}

	[JsonConverter(typeof(JsonStringEnumConverter))]
	public BmAdminNameMode AdminNameMode
	{
		[CompilerGenerated]
		get
		{
			return m_3382;
		}
		[CompilerGenerated]
		set
		{
			m_3382 = value;
		}
	}

	public List<string> CustomAdminNames
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool PickCustomAdminNameRandomly
	{
		[CompilerGenerated]
		get
		{
			return m_3383;
		}
		[CompilerGenerated]
		set
		{
			m_3383 = value;
		}
	}

	public string EmailDomain
	{
		[CompilerGenerated]
		get
		{
			return m_3384;
		}
		[CompilerGenerated]
		set
		{
			m_3384 = value;
		}
	}

	public int BmCount
	{
		[CompilerGenerated]
		get
		{
			return m_3385;
		}
		[CompilerGenerated]
		set
		{
			m_3385 = value;
		}
	}

	public int MinDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return m_3386;
		}
		[CompilerGenerated]
		set
		{
			m_3386 = value;
		}
	}

	public int MaxDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static BmCreationSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new BmCreationSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<BmCreationSettings>(json) ?? new BmCreationSettings();
		}
		catch (JsonException)
		{
			return new BmCreationSettings();
		}
	}

	public string BuildBusinessName(int sequenceIndex)
	{
		if (BusinessNameMode == BmBusinessNameMode.CustomList)
		{
			List<string> list = (from P_0 in CustomBusinessNames
				where !string.IsNullOrWhiteSpace(P_0)
				select P_0.Trim()).ToList();
			if (list.Count > 0)
			{
				if (!PickCustomBusinessNameRandomly)
				{
					return list[Math.Abs(sequenceIndex) % list.Count];
				}
				return list[Random.Shared.Next(list.Count)];
			}
		}
		if (BusinessNameMode == BmBusinessNameMode.RandomVietnamese)
		{
			string obj = b[Random.Shared.Next(b.Length)];
			string text = C[Random.Shared.Next(C.Length)];
			return obj + " " + text;
		}
		string value = m_3387[Random.Shared.Next(m_3387.Length)];
		string value2 = m_3388[Random.Shared.Next(m_3388.Length)];
		string value3 = m_3389[Random.Shared.Next(m_3389.Length)];
		return $"{value} {value2} {value3}";
	}

	public string BuildAdminName(int sequenceIndex, string? fallbackName)
	{
		if (AdminNameMode == BmAdminNameMode.KeepAccountName && !string.IsNullOrWhiteSpace(fallbackName))
		{
			return fallbackName.Trim();
		}
		if (AdminNameMode == BmAdminNameMode.CustomList)
		{
			List<string> list = (from P_0 in CustomAdminNames
				where !string.IsNullOrWhiteSpace(P_0)
				select P_0.Trim()).ToList();
			if (list.Count > 0)
			{
				if (!PickCustomAdminNameRandomly)
				{
					return list[Math.Abs(sequenceIndex) % list.Count];
				}
				return list[Random.Shared.Next(list.Count)];
			}
		}
		string gender = RandomFacebookIdentityGenerator.RandomGender();
		if (AdminNameMode == BmAdminNameMode.RandomEnglish)
		{
			return RandomFacebookIdentityGenerator.RandomEnglishFullName(gender);
		}
		if (AdminNameMode == BmAdminNameMode.RandomVietnamese)
		{
			return RandomFacebookIdentityGenerator.RandomFullName(gender, includeMiddleName: true);
		}
		if (string.IsNullOrWhiteSpace(fallbackName))
		{
			return RandomFacebookIdentityGenerator.RandomEnglishFullName(gender);
		}
		return fallbackName.Trim();
	}

	public string BuildBusinessEmail(string businessName, string adminName)
	{
		string domain = (string.IsNullOrWhiteSpace(EmailDomain) ? "gmail.com" : EmailDomain.Trim().TrimStart('@'));
		return RandomFacebookIdentityGenerator.RandomEmailFromName((!string.IsNullOrWhiteSpace(businessName)) ? businessName : adminName, dotSeparator: false, addRandomSuffix: true, null, domain);
	}
}
