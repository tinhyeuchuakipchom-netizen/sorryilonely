using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class OpenAiTextContentBlock
{
	[CompilerGenerated]
	private string A = "text";

	[CompilerGenerated]
	private string a = "";

	[JsonPropertyName("type")]
	public string Type
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("text")]
	public string Text
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
