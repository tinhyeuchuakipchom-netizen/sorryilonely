using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class PageCreationSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5806
	{
		public static readonly m_5806 A = new m_5806();

		public static Func<string, bool> m_5807;

		public static Func<string, string> m_5808;

		internal bool m_5809(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string a(string P_0)
		{
			return P_0.Trim();
		}
	}

	[CompilerGenerated]
	private PageNameMode A;

	[CompilerGenerated]
	private bool m_5802 = true;

	[CompilerGenerated]
	private List<string> m_5803 = new List<string>();

	[CompilerGenerated]
	private bool a = true;

	[CompilerGenerated]
	private int m_5804 = 1;

	[CompilerGenerated]
	private int m_5805 = 10;

	[CompilerGenerated]
	private int B = 30;

	[JsonConverter(typeof(JsonStringEnumConverter))]
	public PageNameMode NameMode
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool IncludeMiddleName
	{
		[CompilerGenerated]
		get
		{
			return m_5802;
		}
		[CompilerGenerated]
		set
		{
			m_5802 = value;
		}
	}

	public List<string> CustomNames
	{
		[CompilerGenerated]
		get
		{
			return m_5803;
		}
		[CompilerGenerated]
		set
		{
			m_5803 = value;
		}
	}

	public bool PickCustomNameRandomly
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int PageCount
	{
		[CompilerGenerated]
		get
		{
			return m_5804;
		}
		[CompilerGenerated]
		set
		{
			m_5804 = value;
		}
	}

	public int MinDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return m_5805;
		}
		[CompilerGenerated]
		set
		{
			m_5805 = value;
		}
	}

	public int MaxDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static PageCreationSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new PageCreationSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<PageCreationSettings>(json) ?? new PageCreationSettings();
		}
		catch (JsonException)
		{
			return new PageCreationSettings();
		}
	}

	public string BuildPageName(int sequenceIndex)
	{
		string gender = RandomFacebookIdentityGenerator.RandomGender();
		if (NameMode == PageNameMode.RandomEnglish)
		{
			return RandomFacebookIdentityGenerator.RandomEnglishFullName(gender);
		}
		if (NameMode == PageNameMode.CustomList)
		{
			List<string> list = (from P_0 in CustomNames
				where !string.IsNullOrWhiteSpace(P_0)
				select P_0.Trim()).ToList();
			if (list.Count > 0)
			{
				if (!PickCustomNameRandomly)
				{
					return list[Math.Abs(sequenceIndex) % list.Count];
				}
				return list[Random.Shared.Next(list.Count)];
			}
		}
		return RandomFacebookIdentityGenerator.RandomFullName(gender, IncludeMiddleName);
	}
}
