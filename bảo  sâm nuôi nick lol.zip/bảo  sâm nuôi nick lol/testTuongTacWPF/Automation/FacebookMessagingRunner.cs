using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookMessagingRunner
{
	private enum m_4886
	{
		A,
		a,
		B,
		b
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class m_4887
	{
		public static readonly m_4887 A = new m_4887();

		public static Func<FacebookAccountRow, string> m_4888;

		public static Func<FacebookAccountRow, string> a;

		public static Func<string, bool> m_4889;

		public static Func<string, string> m_4890;

		internal string m_4891(FacebookAccountRow P_0)
		{
			return (P_0.ProfileChrome ?? "").Trim();
		}

		internal string m_4892(FacebookAccountRow P_0)
		{
			return (P_0.ProfileChrome ?? "").Trim();
		}

		internal bool m_4893(string P_0)
		{
			return P_0.Length > 0;
		}

		internal string m_4894(string P_0)
		{
			return P_0.Trim();
		}
	}

	[CompilerGenerated]
	private sealed class B
	{
		public string A;

		internal bool m_4895(string P_0)
		{
			if (P_0.Length > 0)
			{
				return !P_0.Equals(A, StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class b
	{
		public Action<AiVisionStepLog> A;

		public int m_4896;

		internal void m_4897(string P_0, string P_1)
		{
			int num = m_4896++;
			A(new AiVisionStepLog
			{
				FlowStepIndex = num,
				SubStep = 1,
				ActionSummary = $"[{num}] {P_0}",
				Reason = P_1
			});
		}
	}

	[CompilerGenerated]
	private sealed class C
	{
		public HashSet<string> A;

		public string m_4898;

		public Func<string, bool> m_4899;

		internal bool m_4900(string P_0)
		{
			if (P_0.Length > 0 && A.Contains(P_0))
			{
				return !P_0.Equals(m_4898, StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}
	}

	private const string A = "[role='button'][aria-label='Message']";

	private const string a = "[role='textbox'][aria-placeholder='Aa'], [role='textbox'][aria-label^='Write to ']";

	public static async Task<int> RunOnPageAsync(IPage page, FacebookAccountRow nick, MessagingSettings settings, IReadOnlyCollection<FacebookAccountRow>? sessionNicks, Action<string, string> log, CancellationToken cancellationToken)
	{
		List<string> list;
		if (settings.Target == MessagingTarget.OpenChromeNicks)
		{
			string A = (nick.ProfileChrome ?? "").Trim();
			list = (from P_0 in sessionNicks ?? new FacebookAccountRow[1] { nick }
				select (P_0.ProfileChrome ?? "").Trim() into P_0
				where P_0.Length > 0 && !P_0.Equals(A, StringComparison.OrdinalIgnoreCase)
				select P_0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
			if (list.Count == 0)
			{
				return 0;
			}
		}
		else
		{
			if (string.IsNullOrWhiteSpace(settings.PostLink))
			{
				return 0;
			}
			list = await m_4882(page, settings, log, cancellationToken);
		}
		HashSet<string> hashSet = m_4884(nick);
		int num = 0;
		foreach (string item2 in list)
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (num >= settings.MaxMessagesPerRun)
			{
				break;
			}
			string item = m_4883(item2);
			if (!hashSet.Contains(item))
			{
				string text = settings.PickMessage();
				if (text == null)
				{
					break;
				}
				m_4886 obj = await m_4880(page, item2, text, cancellationToken);
				if (obj != m_4886.b)
				{
					hashSet.Add(item);
					m_4885(nick, hashSet);
				}
				if (obj == m_4886.A)
				{
					num++;
					log($"Đã nhắn tin cho {item2} ({num}/{settings.MaxMessagesPerRun}).", "Nuôi nick - Nhắn tin");
				}
				await Task.Delay(TimeSpan.FromSeconds(settings.PickDelaySeconds()), cancellationToken);
			}
		}
		return num;
	}

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, MessagingSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, IReadOnlyCollection<FacebookAccountRow>? sessionNicks = null)
	{
		b CS_0024_003C_003E8__locals15 = new b();
		CS_0024_003C_003E8__locals15.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		if (settings.PickMessage() == null)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Chưa nhập nội dung tin nhắn nào.",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		CS_0024_003C_003E8__locals15.m_4896 = 0;
		List<string> list = new List<string>();
		if (settings.Target != MessagingTarget.OpenChromeNicks && string.IsNullOrWhiteSpace(settings.PostLink))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Chưa nhập link bài viết để lấy danh sách người bình luận.",
				TinhTrang = "ERROR"
			};
		}
		HashSet<string> hashSet = m_4884(nick);
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		int num5 = 0;
		int num6 = 0;
		string browserProfileId = nick.BrowserProfileId;
		AiVisionRunResult result;
		try
		{
			_ = 10;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				if (settings.Target != MessagingTarget.OpenChromeNicks)
				{
					goto IL_0685;
				}
				string m_4898 = (nick.ProfileChrome ?? "").Trim();
				HashSet<string> A = new HashSet<string>(from P_0 in sessionNicks ?? new FacebookAccountRow[1] { nick }
					select (P_0.ProfileChrome ?? "").Trim() into P_0
					where P_0.Length > 0
					select P_0, StringComparer.OrdinalIgnoreCase);
				for (int num8 = 0; num8 < 30; num8++)
				{
					cancellationToken.ThrowIfCancellationRequested();
					list = (from P_0 in await client.GetRunningProfileNamesAsync()
						select P_0.Trim() into P_0
						where P_0.Length > 0 && A.Contains(P_0) && !P_0.Equals(m_4898, StringComparison.OrdinalIgnoreCase)
						select P_0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
					if (list.Count > 0 || A.Count <= 1)
					{
						break;
					}
					await Task.Delay(1000, cancellationToken);
				}
				if (list.Count != 0)
				{
					goto IL_0685;
				}
				result = new AiVisionRunResult
				{
					Success = false,
					TinhTrang = "ERROR",
					Message = "Không có nick nào khác trong cùng lượt chạy đang mở trên Chrome."
				};
				goto end_IL_030a;
				IL_0685:
				using (IPlaywright playwright = await Playwright.CreateAsync())
				{
					(OmoBrowserStartResult, IBrowser) tuple = await F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
					omoBrowserStartResult = tuple.Item1;
					IBrowser item = tuple.Item2;
					browserProfileId = nick.BrowserProfileId;
					IBrowserContext browserContext = item.Contexts.FirstOrDefault();
					if (browserContext == null)
					{
						browserContext = await item.NewContextAsync();
					}
					IBrowserContext browserContext2 = browserContext;
					IPage page = browserContext2.Pages.FirstOrDefault();
					if (page == null)
					{
						page = await browserContext2.NewPageAsync();
					}
					IPage page2 = page;
					CS_0024_003C_003E8__locals15.m_4897("Đang đăng nhập...", "Nhắn tin");
					LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
					{
						int num10 = CS_0024_003C_003E8__locals15.m_4896++;
						CS_0024_003C_003E8__locals15.A(new AiVisionStepLog
						{
							FlowStepIndex = num10,
							SubStep = 1,
							ActionSummary = $"[{num10}] {P_0}",
							Reason = P_1
						});
					});
					if (!loginResult.Success)
					{
						result = new AiVisionRunResult
						{
							Success = false,
							Message = "Chưa đăng nhập được để nhắn tin: " + loginResult.TrangThai,
							TinhTrang = loginResult.TinhTrang
						};
					}
					else
					{
						if (settings.Target != MessagingTarget.PostCommenters)
						{
							goto IL_0a41;
						}
						CS_0024_003C_003E8__locals15.m_4897("Đang mở bài viết để lấy danh sách người bình luận...", "Nhắn tin");
						list = await m_4882(page2, settings, (string P_0, string P_1) =>
						{
							int num10 = CS_0024_003C_003E8__locals15.m_4896++;
							CS_0024_003C_003E8__locals15.A(new AiVisionStepLog
							{
								FlowStepIndex = num10,
								SubStep = 1,
								ActionSummary = $"[{num10}] {P_0}",
								Reason = P_1
							});
						}, cancellationToken);
						if (list.Count != 0)
						{
							goto IL_0a41;
						}
						result = new AiVisionRunResult
						{
							Success = true,
							Message = "Không tìm thấy người bình luận nào trong bài viết.",
							TinhTrang = ""
						};
					}
					goto end_IL_06bb;
					IL_0a41:
					CS_0024_003C_003E8__locals15.m_4897($"Có {list.Count} người trong danh sách, bắt đầu nhắn tin...", "Nhắn tin");
					foreach (string item3 in list)
					{
						cancellationToken.ThrowIfCancellationRequested();
						if (num >= settings.MaxMessagesPerRun)
						{
							CS_0024_003C_003E8__locals15.m_4897($"Đã đủ {settings.MaxMessagesPerRun} tin nhắn cho lượt này, dừng lại.", "Nhắn tin");
							break;
						}
						string item2 = m_4883(item3);
						if (hashSet.Contains(item2))
						{
							num2++;
							num3++;
							continue;
						}
						string text = settings.PickMessage();
						if (text != null)
						{
							m_4886 obj = await m_4880(page2, item3, text, cancellationToken);
							if (obj != m_4886.b)
							{
								hashSet.Add(item2);
								m_4885(nick, hashSet);
							}
							switch (obj)
							{
							case m_4886.A:
								num++;
								CS_0024_003C_003E8__locals15.m_4897($"Đã nhắn tin cho {item3} ({num}/{settings.MaxMessagesPerRun}).", "Nhắn tin");
								break;
							case m_4886.a:
								num2++;
								num5++;
								CS_0024_003C_003E8__locals15.m_4897("[Bỏ qua] " + item3 + " không nhắn tin được (Messenger không khả dụng với người này).", "Nhắn tin");
								break;
							case m_4886.B:
								num2++;
								num4++;
								CS_0024_003C_003E8__locals15.m_4897("[Bỏ qua] Trang của " + item3 + " không có nút Nhắn tin.", "Nhắn tin");
								break;
							default:
								num2++;
								num6++;
								CS_0024_003C_003E8__locals15.m_4897("[Bỏ qua] Không mở được trang cá nhân của " + item3 + ".", "Nhắn tin");
								break;
							}
							if (obj == m_4886.A && num < settings.MaxMessagesPerRun)
							{
								int num9 = settings.PickDelaySeconds();
								CS_0024_003C_003E8__locals15.m_4897($"Chờ {num9}s trước tin nhắn tiếp theo...", "Nhắn tin");
								await Task.Delay(TimeSpan.FromSeconds(num9), cancellationToken);
							}
							continue;
						}
						break;
					}
					result = new AiVisionRunResult
					{
						Success = true,
						Message = $"Nhắn tin xong: đã gửi {num} tin, bỏ qua {num2}{m_4879(num3, num4, num5, num6)}.",
						TinhTrang = ""
					};
					end_IL_06bb:;
				}
				end_IL_030a:;
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = $"Đã dừng kịch bản nhắn tin (đã gửi {num} tin).",
					TinhTrang = ""
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi nhắn tin: " + ex2.Message,
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			m_4885(nick, hashSet);
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static string m_4879(int P_0, int P_1, int P_2, int P_3)
	{
		List<string> list = new List<string>();
		if (P_0 > 0)
		{
			list.Add($"{P_0} đã nhắn từ trước");
		}
		if (P_1 > 0)
		{
			list.Add($"{P_1} không tìm thấy nút Nhắn tin trên trang");
		}
		if (P_2 > 0)
		{
			list.Add($"{P_2} Messenger không khả dụng với người đó");
		}
		if (P_3 > 0)
		{
			list.Add($"{P_3} không mở được trang");
		}
		if (list.Count != 0)
		{
			return " (" + string.Join(", ", list) + ")";
		}
		return "";
	}

	private static async Task<m_4886> m_4880(IPage P_0, string P_1, string P_2, CancellationToken P_3)
	{
		string url = (P_1.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? P_1 : ("https://www.facebook.com/" + P_1));
		try
		{
			await P_0.GotoAsync(FacebookUrls.WithEnglishLocale(url), new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			return m_4886.b;
		}
		await Task.Delay(Random.Shared.Next(2500, 4500), P_3);
		ILocator first = P_0.Locator("[role='button'][aria-label='Message']").First;
		if (await first.CountAsync() == 0)
		{
			return m_4886.B;
		}
		await FacebookFriendRequestActions.ClickRobustAsync(first, P_3);
		await Task.Delay(Random.Shared.Next(3000, 5000), P_3);
		ILocator first2 = P_0.Locator("[role='textbox'][aria-placeholder='Aa'], [role='textbox'][aria-label^='Write to ']").First;
		if (await first2.CountAsync() == 0)
		{
			await m_4881(P_0, P_3);
			return m_4886.a;
		}
		await first2.ClickAsync(new LocatorClickOptions
		{
			Timeout = 8000f
		});
		await Task.Delay(Random.Shared.Next(400, 900), P_3);
		await P_0.Keyboard.TypeAsync(P_2, new KeyboardTypeOptions
		{
			Delay = Random.Shared.Next(60, 140)
		});
		await Task.Delay(Random.Shared.Next(500, 1000), P_3);
		await P_0.Keyboard.PressAsync("Enter");
		await Task.Delay(Random.Shared.Next(1500, 2500), P_3);
		await m_4881(P_0, P_3);
		return m_4886.A;
	}

	private static async Task m_4881(IPage P_0, CancellationToken P_1)
	{
		ILocator first = P_0.Locator("[role='button'][aria-label='Close chat']").First;
		if (await first.CountAsync() == 0)
		{
			return;
		}
		try
		{
			await FacebookFriendRequestActions.ClickRobustAsync(first, P_1);
			await Task.Delay(600, P_1);
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
		}
	}

	private static async Task<List<string>> m_4882(IPage P_0, MessagingSettings P_1, Action<string, string> P_2, CancellationToken P_3)
	{
		List<string> list = new List<string>();
		HashSet<string> hashSet = new HashSet<string>();
		try
		{
			await P_0.GotoAsync(FacebookUrls.WithEnglishLocale(P_1.PostLink), new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			P_2("[Bỏ qua] Không mở được bài viết: " + ex.Message, "Nhắn tin");
			return list;
		}
		await Task.Delay(Random.Shared.Next(2500, 4000), P_3);
		Regex hasTextRegex = new Regex("View more comments|View [0-9]+ repl|Previous comments", RegexOptions.IgnoreCase);
		for (int i = 0; i < P_1.LoadMoreCommentsClicks; i++)
		{
			P_3.ThrowIfCancellationRequested();
			ILocator first = P_0.Locator("[role='button']").Filter(new LocatorFilterOptions
			{
				HasTextRegex = hasTextRegex
			}).First;
			if (await first.CountAsync() == 0)
			{
				break;
			}
			try
			{
				await FacebookFriendRequestActions.ClickRobustAsync(first, P_3);
			}
			catch (Exception ex2) when (!(ex2 is OperationCanceledException))
			{
				break;
			}
			await Task.Delay(Random.Shared.Next(1500, 2500), P_3);
		}
		foreach (IElementHandle item in await P_0.QuerySelectorAllAsync("[aria-label^='Comment by ']"))
		{
			P_3.ThrowIfCancellationRequested();
			foreach (IElementHandle item2 in await item.QuerySelectorAllAsync("a[href]"))
			{
				string text = await item2.GetAttributeAsync("href");
				if (!string.IsNullOrEmpty(text) && !text.Contains("/posts/") && !text.Contains("/photo") && !text.Contains("/video") && !text.Contains("/reel") && (text.StartsWith("/") || text.Contains("facebook.com/")))
				{
					string text2 = (text.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? text : ("https://www.facebook.com" + text));
					string text3 = m_4883(text2);
					if (text3.Length != 0 && hashSet.Add(text3))
					{
						list.Add(text2);
						break;
					}
				}
			}
			if (list.Count >= P_1.MaxMessagesPerRun)
			{
				break;
			}
		}
		P_2($"Đã tìm được {list.Count} người bình luận.", "Nhắn tin");
		return list;
	}

	private static string m_4883(string P_0)
	{
		if (!P_0.StartsWith("http", StringComparison.OrdinalIgnoreCase))
		{
			return P_0.Trim();
		}
		try
		{
			Uri uri = new Uri(P_0);
			string text = uri.AbsolutePath.TrimEnd('/');
			if (text.EndsWith("/profile.php", StringComparison.OrdinalIgnoreCase))
			{
				Match match = Regex.Match(uri.Query, "[?&]id=(\\d+)");
				if (match.Success)
				{
					return match.Groups[1].Value;
				}
			}
			return text.TrimStart('/');
		}
		catch (UriFormatException)
		{
			return P_0.Trim();
		}
	}

	private static HashSet<string> m_4884(FacebookAccountRow P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0.MessagingSentJson))
		{
			return new HashSet<string>();
		}
		try
		{
			List<string> list = JsonSerializer.Deserialize<List<string>>(P_0.MessagingSentJson);
			return (list == null) ? new HashSet<string>() : new HashSet<string>(list);
		}
		catch (JsonException)
		{
			return new HashSet<string>();
		}
	}

	private static void m_4885(FacebookAccountRow P_0, HashSet<string> P_1)
	{
		P_0.MessagingSentJson = JsonSerializer.Serialize(P_1.ToList());
	}
}
