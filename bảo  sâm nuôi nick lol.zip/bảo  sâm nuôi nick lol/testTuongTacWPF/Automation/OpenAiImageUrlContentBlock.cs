using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class OpenAiImageUrlContentBlock
{
	[CompilerGenerated]
	private string A = "image_url";

	[CompilerGenerated]
	private OpenAiImageUrl m_2901 = new OpenAiImageUrl();

	[JsonPropertyName("type")]
	public string Type
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("image_url")]
	public OpenAiImageUrl ImageUrl
	{
		[CompilerGenerated]
		get
		{
			return m_2901;
		}
		[CompilerGenerated]
		set
		{
			m_2901 = value;
		}
	}
}
