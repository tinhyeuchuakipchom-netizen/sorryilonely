using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class BaoSamBrowserSettings : IChromeEngineSettings
{
	public const string DownloadUrl = "https://drive.google.com/file/d/1TEg_PjXtIsVrj1ORNUA2MNZclMnDw3vC/view?usp=drive_link";

	[CompilerGenerated]
	private string A = "http://127.0.0.1:50326";

	[CompilerGenerated]
	private int m_3353 = 1;

	[CompilerGenerated]
	private bool m_3354 = true;

	[CompilerGenerated]
	private string a = "Cookie";

	[CompilerGenerated]
	private bool m_3355;

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private int m_3356 = 1;

	[CompilerGenerated]
	private int m_3357 = 1;

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private int m_3358 = 2;

	[CompilerGenerated]
	private int C = 1;

	[CompilerGenerated]
	private int c = 1;

	[CompilerGenerated]
	private int D = 1;

	[CompilerGenerated]
	private int d = 1;

	[CompilerGenerated]
	private int E = 1;

	[CompilerGenerated]
	private int e = 1;

	[CompilerGenerated]
	private bool m_3359 = true;

	[CompilerGenerated]
	private bool m_3360 = true;

	[CompilerGenerated]
	private string m_3361 = "";

	[CompilerGenerated]
	private bool m_3362;

	[CompilerGenerated]
	private string m_3363 = "en-US";

	[CompilerGenerated]
	private string m_3364 = "";

	[CompilerGenerated]
	private bool m_3365;

	[CompilerGenerated]
	private int F = 30;

	[CompilerGenerated]
	private string m_3366 = "";

	[CompilerGenerated]
	private bool m_3367;

	[CompilerGenerated]
	private bool m_3368 = true;

	private static readonly string m_3369 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "baosam_engine_settings.json");

	public string ApiUrl
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int ThreadCount
	{
		[CompilerGenerated]
		get
		{
			return m_3353;
		}
		[CompilerGenerated]
		set
		{
			m_3353 = value;
		}
	}

	public bool UseProxy
	{
		[CompilerGenerated]
		get
		{
			return m_3354;
		}
		[CompilerGenerated]
		set
		{
			m_3354 = value;
		}
	}

	public string LoginType
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool UseCustomUserAgent
	{
		[CompilerGenerated]
		get
		{
			return m_3355;
		}
		[CompilerGenerated]
		set
		{
			m_3355 = value;
		}
	}

	public string CustomUserAgent
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int OsType
	{
		[CompilerGenerated]
		get
		{
			return m_3356;
		}
		[CompilerGenerated]
		set
		{
			m_3356 = value;
		}
	}

	public int WebrtcMode
	{
		[CompilerGenerated]
		get
		{
			return m_3357;
		}
		[CompilerGenerated]
		set
		{
			m_3357 = value;
		}
	}

	public string FixedWebrtcPublicIp
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int GeolocationMode
	{
		[CompilerGenerated]
		get
		{
			return m_3358;
		}
		[CompilerGenerated]
		set
		{
			m_3358 = value;
		}
	}

	public int CanvasMode
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int ClientRectMode
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public int WebglImageMode
	{
		[CompilerGenerated]
		get
		{
			return D;
		}
		[CompilerGenerated]
		set
		{
			D = value;
		}
	}

	public int WebglMetadataMode
	{
		[CompilerGenerated]
		get
		{
			return d;
		}
		[CompilerGenerated]
		set
		{
			d = value;
		}
	}

	public int AudioMode
	{
		[CompilerGenerated]
		get
		{
			return E;
		}
		[CompilerGenerated]
		set
		{
			E = value;
		}
	}

	public int FontMode
	{
		[CompilerGenerated]
		get
		{
			return e;
		}
		[CompilerGenerated]
		set
		{
			e = value;
		}
	}

	public bool IsMaskedMedia
	{
		[CompilerGenerated]
		get
		{
			return m_3359;
		}
		[CompilerGenerated]
		set
		{
			m_3359 = value;
		}
	}

	public bool TimezoneBaseOnIp
	{
		[CompilerGenerated]
		get
		{
			return m_3360;
		}
		[CompilerGenerated]
		set
		{
			m_3360 = value;
		}
	}

	public string Timezone
	{
		[CompilerGenerated]
		get
		{
			return m_3361;
		}
		[CompilerGenerated]
		set
		{
			m_3361 = value;
		}
	}

	public bool IsLanguageBaseOnIp
	{
		[CompilerGenerated]
		get
		{
			return m_3362;
		}
		[CompilerGenerated]
		set
		{
			m_3362 = value;
		}
	}

	public string FixedLanguage
	{
		[CompilerGenerated]
		get
		{
			return m_3363;
		}
		[CompilerGenerated]
		set
		{
			m_3363 = value;
		}
	}

	public string StartupUrls
	{
		[CompilerGenerated]
		get
		{
			return m_3364;
		}
		[CompilerGenerated]
		set
		{
			m_3364 = value;
		}
	}

	public bool RepeatForever
	{
		[CompilerGenerated]
		get
		{
			return m_3365;
		}
		[CompilerGenerated]
		set
		{
			m_3365 = value;
		}
	}

	public int RepeatDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return F;
		}
		[CompilerGenerated]
		set
		{
			F = value;
		}
	}

	public string AdditionArgs
	{
		[CompilerGenerated]
		get
		{
			return m_3366;
		}
		[CompilerGenerated]
		set
		{
			m_3366 = value;
		}
	}

	public bool AutoCloseChromeAfterLogin
	{
		[CompilerGenerated]
		get
		{
			return m_3367;
		}
		[CompilerGenerated]
		set
		{
			m_3367 = value;
		}
	}

	public bool SaveNewCookieAfterLogin
	{
		[CompilerGenerated]
		get
		{
			return m_3368;
		}
		[CompilerGenerated]
		set
		{
			m_3368 = value;
		}
	}

	public static BaoSamBrowserSettings Load()
	{
		try
		{
			if (!File.Exists(m_3369))
			{
				return new BaoSamBrowserSettings();
			}
			return JsonSerializer.Deserialize<BaoSamBrowserSettings>(File.ReadAllText(m_3369)) ?? new BaoSamBrowserSettings();
		}
		catch
		{
			return new BaoSamBrowserSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(m_3369));
		File.WriteAllText(m_3369, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
