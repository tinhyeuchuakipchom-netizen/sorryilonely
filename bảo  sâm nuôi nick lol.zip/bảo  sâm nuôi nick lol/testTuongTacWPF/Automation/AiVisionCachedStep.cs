using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class AiVisionCachedStep
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string? a;

	[CompilerGenerated]
	private string? B;

	[CompilerGenerated]
	private string? b;

	[CompilerGenerated]
	private List<string>? m_2843;

	[CompilerGenerated]
	private string? C;

	[CompilerGenerated]
	private int m_2844;

	[CompilerGenerated]
	private int m_2845;

	[CompilerGenerated]
	private string c = "";

	[CompilerGenerated]
	private int m_2846;

	[CompilerGenerated]
	private int m_2847;

	[CompilerGenerated]
	private int m_2848;

	[CompilerGenerated]
	private int m_2849;

	public string Action
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string? ResourceId
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string? ContentDesc
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string? ElementText
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public List<string>? ScreenTexts
	{
		[CompilerGenerated]
		get
		{
			return m_2843;
		}
		[CompilerGenerated]
		set
		{
			m_2843 = value;
		}
	}

	public string? DisambiguatorText
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int DisambiguatorX
	{
		[CompilerGenerated]
		get
		{
			return m_2844;
		}
		[CompilerGenerated]
		set
		{
			m_2844 = value;
		}
	}

	public int DisambiguatorY
	{
		[CompilerGenerated]
		get
		{
			return m_2845;
		}
		[CompilerGenerated]
		set
		{
			m_2845 = value;
		}
	}

	public string Text
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public int X
	{
		[CompilerGenerated]
		get
		{
			return m_2846;
		}
		[CompilerGenerated]
		set
		{
			m_2846 = value;
		}
	}

	public int Y
	{
		[CompilerGenerated]
		get
		{
			return m_2847;
		}
		[CompilerGenerated]
		set
		{
			m_2847 = value;
		}
	}

	public int X2
	{
		[CompilerGenerated]
		get
		{
			return m_2848;
		}
		[CompilerGenerated]
		set
		{
			m_2848 = value;
		}
	}

	public int Y2
	{
		[CompilerGenerated]
		get
		{
			return m_2849;
		}
		[CompilerGenerated]
		set
		{
			m_2849 = value;
		}
	}
}
