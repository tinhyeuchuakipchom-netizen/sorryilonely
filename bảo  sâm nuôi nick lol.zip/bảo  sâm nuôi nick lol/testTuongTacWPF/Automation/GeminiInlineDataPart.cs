using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class GeminiInlineDataPart
{
	[CompilerGenerated]
	private GeminiInlineData A = new GeminiInlineData();

	[JsonPropertyName("inline_data")]
	public GeminiInlineData InlineData
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
