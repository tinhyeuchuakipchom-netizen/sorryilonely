namespace testTuongTacWPF.Automation;

public enum LiveRecordedActionKind
{
	Tap,
	Text,
	Navigate,
	Scroll,
	KeyPress
}
