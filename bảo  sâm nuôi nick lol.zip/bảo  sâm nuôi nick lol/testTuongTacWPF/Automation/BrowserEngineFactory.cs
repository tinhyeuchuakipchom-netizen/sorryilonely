namespace testTuongTacWPF.Automation;

public static class BrowserEngineFactory
{
	public static ActiveBrowserEngine CreateActiveClient()
	{
		BaoSamBrowserSettings baoSamBrowserSettings = BaoSamBrowserSettings.Load();
		return new ActiveBrowserEngine
		{
			Client = new BaoSamApiClient(baoSamBrowserSettings),
			Settings = baoSamBrowserSettings,
			ApiUrl = baoSamBrowserSettings.ApiUrl,
			DisplayName = "BaoSam Browser"
		};
	}
}
