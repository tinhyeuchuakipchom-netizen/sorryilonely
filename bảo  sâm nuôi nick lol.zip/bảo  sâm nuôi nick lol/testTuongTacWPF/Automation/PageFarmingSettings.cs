using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class PageFarmingSettings
{
	[CompilerGenerated]
	private List<string> A = new List<string>();

	[CompilerGenerated]
	private int m_5821;

	[CompilerGenerated]
	private int a = 1;

	[CompilerGenerated]
	private int B = 3;

	[CompilerGenerated]
	private bool m_5822 = true;

	[CompilerGenerated]
	private int b = 30;

	[CompilerGenerated]
	private bool m_5823 = true;

	[CompilerGenerated]
	private bool m_5824;

	[CompilerGenerated]
	private int C = 1;

	[CompilerGenerated]
	private PostCreationSettings m_5825 = new PostCreationSettings();

	[CompilerGenerated]
	private int c = 5;

	public List<string> TargetPageNames
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxPages
	{
		[CompilerGenerated]
		get
		{
			return m_5821;
		}
		[CompilerGenerated]
		set
		{
			m_5821 = value;
		}
	}

	public int MinMinutesPerPage
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MaxMinutesPerPage
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public bool AutoLike
	{
		[CompilerGenerated]
		get
		{
			return m_5822;
		}
		[CompilerGenerated]
		set
		{
			m_5822 = value;
		}
	}

	public int LikeChancePercent
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public bool WatchReels
	{
		[CompilerGenerated]
		get
		{
			return m_5823;
		}
		[CompilerGenerated]
		set
		{
			m_5823 = value;
		}
	}

	public bool AutoPost
	{
		[CompilerGenerated]
		get
		{
			return m_5824;
		}
		[CompilerGenerated]
		set
		{
			m_5824 = value;
		}
	}

	public int PostsPerPage
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public PostCreationSettings Post
	{
		[CompilerGenerated]
		get
		{
			return m_5825;
		}
		[CompilerGenerated]
		set
		{
			m_5825 = value;
		}
	}

	public int PageSwitchDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public int PickDurationMinutes()
	{
		if (MinMinutesPerPage < MaxMinutesPerPage)
		{
			return Random.Shared.Next(MinMinutesPerPage, MaxMinutesPerPage + 1);
		}
		return MinMinutesPerPage;
	}

	public bool RollChance(int percent)
	{
		return Random.Shared.Next(0, 100) < percent;
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static PageFarmingSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new PageFarmingSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<PageFarmingSettings>(json) ?? new PageFarmingSettings();
		}
		catch (JsonException)
		{
			return new PageFarmingSettings();
		}
	}
}
