namespace testTuongTacWPF.Automation;

public enum AiVisionTargetKind
{
	Phone,
	Chrome
}
