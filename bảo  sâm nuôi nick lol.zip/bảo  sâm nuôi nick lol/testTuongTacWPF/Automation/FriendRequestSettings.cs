using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class FriendRequestSettings
{
	[CompilerGenerated]
	private FriendRequestAction A;

	[CompilerGenerated]
	private FriendRequestSource m_5486;

	[CompilerGenerated]
	private int m_5487;

	[CompilerGenerated]
	private string m_5488 = "";

	[CompilerGenerated]
	private List<string> m_5489 = new List<string>();

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private int m_5490 = 40;

	[CompilerGenerated]
	private int B = 20;

	[CompilerGenerated]
	private int b = 25;

	[CompilerGenerated]
	private int C = 60;

	[CompilerGenerated]
	private int c = 20;

	[JsonConverter(typeof(JsonStringEnumConverter))]
	public FriendRequestAction Action
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonConverter(typeof(JsonStringEnumConverter))]
	public FriendRequestSource Source
	{
		[CompilerGenerated]
		get
		{
			return m_5486;
		}
		[CompilerGenerated]
		set
		{
			m_5486 = value;
		}
	}

	public int NickFolderId
	{
		[CompilerGenerated]
		get
		{
			return m_5487;
		}
		[CompilerGenerated]
		set
		{
			m_5487 = value;
		}
	}

	public string NickFolderName
	{
		[CompilerGenerated]
		get
		{
			return m_5488;
		}
		[CompilerGenerated]
		set
		{
			m_5488 = value;
		}
	}

	public List<string> Uids
	{
		[CompilerGenerated]
		get
		{
			return m_5489;
		}
		[CompilerGenerated]
		set
		{
			m_5489 = value;
		}
	}

	public string GroupLink
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MaxScrolls
	{
		[CompilerGenerated]
		get
		{
			return m_5490;
		}
		[CompilerGenerated]
		set
		{
			m_5490 = value;
		}
	}

	public int MaxRequestsPerRun
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MinDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int MaxDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int MaxConfirmsPerRun
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static FriendRequestSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new FriendRequestSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<FriendRequestSettings>(json) ?? new FriendRequestSettings();
		}
		catch (JsonException)
		{
			return new FriendRequestSettings();
		}
	}

	public int PickDelaySeconds()
	{
		if (MinDelaySeconds < MaxDelaySeconds)
		{
			return Random.Shared.Next(MinDelaySeconds, MaxDelaySeconds + 1);
		}
		return MinDelaySeconds;
	}
}
