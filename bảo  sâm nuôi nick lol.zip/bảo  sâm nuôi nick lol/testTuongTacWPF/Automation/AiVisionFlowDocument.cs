using System.Collections.Generic;
using System.Runtime.CompilerServices;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public class AiVisionFlowDocument
{
	[CompilerGenerated]
	private List<AiVisionFlowStep> A = new List<AiVisionFlowStep>();

	public List<AiVisionFlowStep> Steps
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
