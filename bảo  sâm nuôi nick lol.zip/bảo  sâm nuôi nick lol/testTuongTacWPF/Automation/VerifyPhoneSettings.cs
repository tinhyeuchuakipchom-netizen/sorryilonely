using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class VerifyPhoneSettings
{
	[CompilerGenerated]
	private static class m_6813
	{
		public static Func<char, bool> A;
	}

	[CompilerGenerated]
	private string A = "FunOtp";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private bool m_6807;

	[CompilerGenerated]
	private bool m_6808 = true;

	[CompilerGenerated]
	private bool m_6809 = true;

	[CompilerGenerated]
	private bool m_6810 = true;

	[CompilerGenerated]
	private bool C = true;

	[CompilerGenerated]
	private bool c = true;

	[CompilerGenerated]
	private string m_6811 = "";

	private static readonly string m_6812 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "verify_phone_settings.json");

	public string Provider
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string FunOtpApiKey
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string FunOtpService
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string Country
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public bool RandomInternationalFormat
	{
		[CompilerGenerated]
		get
		{
			return m_6807;
		}
		[CompilerGenerated]
		set
		{
			m_6807 = value;
		}
	}

	public bool RandomViettel
	{
		[CompilerGenerated]
		get
		{
			return m_6808;
		}
		[CompilerGenerated]
		set
		{
			m_6808 = value;
		}
	}

	public bool RandomMobifone
	{
		[CompilerGenerated]
		get
		{
			return m_6809;
		}
		[CompilerGenerated]
		set
		{
			m_6809 = value;
		}
	}

	public bool RandomVinaphone
	{
		[CompilerGenerated]
		get
		{
			return m_6810;
		}
		[CompilerGenerated]
		set
		{
			m_6810 = value;
		}
	}

	public bool RandomVietnamobile
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public bool RandomGmobile
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string RandomCustomPrefixes
	{
		[CompilerGenerated]
		get
		{
			return m_6811;
		}
		[CompilerGenerated]
		set
		{
			m_6811 = value;
		}
	}

	public List<string> BuildRandomPrefixPool()
	{
		List<string> list = new List<string>();
		if (RandomViettel)
		{
			list.AddRange(RandomFacebookIdentityGenerator.ViettelPrefixes);
		}
		if (RandomMobifone)
		{
			list.AddRange(RandomFacebookIdentityGenerator.MobifonePrefixes);
		}
		if (RandomVinaphone)
		{
			list.AddRange(RandomFacebookIdentityGenerator.VinaphonePrefixes);
		}
		if (RandomVietnamobile)
		{
			list.AddRange(RandomFacebookIdentityGenerator.VietnamobilePrefixes);
		}
		if (RandomGmobile)
		{
			list.AddRange(RandomFacebookIdentityGenerator.GmobilePrefixes);
		}
		string[] array = RandomCustomPrefixes.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
		foreach (string text in array)
		{
			if (text.Length > 0 && text.All(char.IsDigit))
			{
				list.Add(text);
			}
		}
		return list;
	}

	public string BuildRandomPhonePreview()
	{
		return RandomFacebookIdentityGenerator.RandomVietnamesePhoneNumber(BuildRandomPrefixPool(), RandomInternationalFormat);
	}

	public IVerifyPhoneTestClient CreateClient()
	{
		if (Provider == "Random")
		{
			throw new InvalidOperationException("Cổng \"Số điện thoại ảo random\" không có client thật - dùng BuildRandomPhonePreview() thay vì CreateClient().");
		}
		return new FunOtpClient(FunOtpApiKey, FunOtpService, Country);
	}

	public static VerifyPhoneSettings Load()
	{
		try
		{
			if (!File.Exists(m_6812))
			{
				return new VerifyPhoneSettings();
			}
			return JsonSerializer.Deserialize<VerifyPhoneSettings>(File.ReadAllText(m_6812)) ?? new VerifyPhoneSettings();
		}
		catch
		{
			return new VerifyPhoneSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(m_6812));
		File.WriteAllText(m_6812, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
