using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookGroupSpamRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_4395
	{
		public static readonly m_4395 A = new m_4395();

		public static Func<string, bool> m_4397;

		public static Func<string, string> m_4398;

		public static Func<string, bool> a;

		internal bool m_4399(string P_0)
		{
			return P_0.Contains("facebook.com/groups", StringComparison.OrdinalIgnoreCase);
		}

		internal string m_4400(string P_0)
		{
			return P_0.Trim();
		}

		internal bool B(string P_0)
		{
			if (P_0.Length >= 8)
			{
				return !string.Equals(P_0, "Facebook", StringComparison.Ordinal);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_4396
	{
		public Action<AiVisionStepLog> A;

		public int m_4401;

		internal void m_4402(string P_0, string P_1)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_4401++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = P_1
			});
		}
	}

	private const string A = "https://www.facebook.com/search/groups/?q=";

	private const string a = "https://www.facebook.com/groups/joins/?locale=en_US";

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, GroupSpamSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		m_4396 CS_0024_003C_003E8__locals14 = new m_4396();
		CS_0024_003C_003E8__locals14.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		CS_0024_003C_003E8__locals14.m_4401 = 0;
		HashSet<string> hashSet = m_4385(nick);
		AiVisionRunResult result;
		try
		{
			_ = 13;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await global::A.F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await global::A.F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals14.m_4402("Đang đăng nhập...", "Spam nhóm");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals14.A(new AiVisionStepLog
					{
						FlowStepIndex = CS_0024_003C_003E8__locals14.m_4401++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = P_1
					});
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để spam nhóm: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					CS_0024_003C_003E8__locals14.m_4402("Đang xác định danh sách nhóm...", "Spam nhóm");
					List<string> list = await m_4387(page2, settings, (string P_0, string P_1) =>
					{
						CS_0024_003C_003E8__locals14.A(new AiVisionStepLog
						{
							FlowStepIndex = CS_0024_003C_003E8__locals14.m_4401++,
							SubStep = 1,
							ActionSummary = P_0,
							Reason = P_1
						});
					}, cancellationToken);
					if (list.Count == 0)
					{
						result = new AiVisionRunResult
						{
							Success = false,
							Message = "Không xác định được nhóm nào để chạy (kiểm tra lại link nhóm/từ khoá tìm nhóm đã cấu hình).",
							TinhTrang = "ERROR"
						};
					}
					else
					{
						int num2 = settings.PickDurationMinutes();
						DateTime dateTime = DateTime.UtcNow.AddMinutes(num2);
						CS_0024_003C_003E8__locals14.m_4402($"Đang spam nhóm trong {num2} phút, {list.Count} nhóm...", "Spam nhóm");
						int num3 = 0;
						int num4 = 0;
						while (DateTime.UtcNow < dateTime)
						{
							cancellationToken.ThrowIfCancellationRequested();
							string url = list[num4 % list.Count];
							num4++;
							await page2.GotoAsync(FacebookUrls.WithEnglishLocale(url), new PageGotoOptions
							{
								Timeout = 30000f,
								WaitUntil = WaitUntilState.DOMContentLoaded
							});
							await Task.Delay(2000, cancellationToken);
							if ((!(settings.FindMode == "RefreshWait")) ? (await m_4388(page2, settings, hashSet, dateTime, (string P_0, string P_1) =>
							{
								CS_0024_003C_003E8__locals14.A(new AiVisionStepLog
								{
									FlowStepIndex = CS_0024_003C_003E8__locals14.m_4401++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken)) : (await m_4389(page2, settings, hashSet, dateTime, (string P_0, string P_1) =>
							{
								CS_0024_003C_003E8__locals14.A(new AiVisionStepLog
								{
									FlowStepIndex = CS_0024_003C_003E8__locals14.m_4401++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken)))
							{
								num3++;
								int num5 = settings.PickCommentSpacingSeconds();
								CS_0024_003C_003E8__locals14.m_4402($"Chờ {num5}s trước khi tìm bài kế tiếp...", "Spam nhóm");
								await Task.Delay(TimeSpan.FromSeconds(num5), cancellationToken);
							}
							else
							{
								await Task.Delay(Random.Shared.Next(2000, 5000), cancellationToken);
							}
						}
						if (settings2.SaveNewCookieAfterLogin)
						{
							await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
						}
						result = new AiVisionRunResult
						{
							Success = true,
							Message = $"Đã spam nhóm xong ({num2} phút, bình luận {num3} bài).",
							TinhTrang = "LIVE"
						};
					}
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex2),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			m_4386(nick, hashSet);
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static HashSet<string> m_4385(FacebookAccountRow P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0.GroupSpamCommentedPostsJson))
		{
			return new HashSet<string>();
		}
		try
		{
			List<string> list = JsonSerializer.Deserialize<List<string>>(P_0.GroupSpamCommentedPostsJson);
			return (list == null) ? new HashSet<string>() : new HashSet<string>(list);
		}
		catch (JsonException)
		{
			return new HashSet<string>();
		}
	}

	private static void m_4386(FacebookAccountRow P_0, HashSet<string> P_1)
	{
		List<string> value = ((P_1.Count <= 500) ? P_1.ToList() : P_1.Skip(P_1.Count - 500).ToList());
		P_0.GroupSpamCommentedPostsJson = JsonSerializer.Serialize(value);
	}

	private static async Task<List<string>> m_4387(IPage P_0, GroupSpamSettings P_1, Action<string, string> P_2, CancellationToken P_3)
	{
		if (P_1.GroupSource == "InputLinks")
		{
			return P_1.GroupLinks.Where((string text3) => text3.Contains("facebook.com/groups", StringComparison.OrdinalIgnoreCase)).Distinct().ToList();
		}
		if (P_1.GroupSource == "ExistingInAccount")
		{
			await P_0.GotoAsync("https://www.facebook.com/groups/joins/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(2000, P_3);
			ILocator locator = P_0.Locator("a[aria-label='View group']");
			int num = await locator.CountAsync();
			List<string> list = new List<string>();
			for (int num2 = 0; num2 < num; num2++)
			{
				string text = await locator.Nth(num2).GetAttributeAsync("href");
				if (!string.IsNullOrEmpty(text))
				{
					list.Add(text);
				}
			}
			return list.Distinct().ToList();
		}
		string url = "https://www.facebook.com/search/groups/?q=" + Uri.EscapeDataString(P_1.SearchKeyword);
		await P_0.GotoAsync(FacebookUrls.WithEnglishLocale(url), new PageGotoOptions
		{
			Timeout = 30000f,
			WaitUntil = WaitUntilState.DOMContentLoaded
		});
		await Task.Delay(2000, P_3);
		ILocator locator2 = P_0.Locator("[aria-label^='Join group ']");
		int num3 = await locator2.CountAsync();
		List<string> list2 = new List<string>();
		for (int num = 0; num < num3; num++)
		{
			if (list2.Count >= P_1.MaxGroupsToJoin)
			{
				break;
			}
			ILocator locator = locator2.Nth(num).Locator("xpath=preceding::a[contains(@href, '/groups/')][1]");
			if (await locator.CountAsync() == 0)
			{
				continue;
			}
			string text2 = await locator.First.GetAttributeAsync("href");
			if (!string.IsNullOrEmpty(text2))
			{
				int num4 = text2.IndexOf('?');
				string item = ((num4 >= 0) ? text2.Substring(0, num4) : text2);
				if (!list2.Contains(item))
				{
					list2.Add(item);
				}
			}
		}
		List<string> list3 = new List<string>();
		foreach (string item2 in list2)
		{
			P_3.ThrowIfCancellationRequested();
			await P_0.GotoAsync(FacebookUrls.WithEnglishLocale(item2), new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(1500, P_3);
			await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(400, 800));
			await Task.Delay(Random.Shared.Next(1500, 3000), P_3);
			await P_0.Mouse.WheelAsync(0f, -Random.Shared.Next(400, 800));
			await Task.Delay(Random.Shared.Next(800, 1800), P_3);
			ILocator locator = P_0.GetByRole(AriaRole.Button, new PageGetByRoleOptions
			{
				Name = "Join group",
				Exact = true
			});
			bool flag = await locator.CountAsync() > 0;
			if (flag)
			{
				flag = await locator.First.IsVisibleAsync();
			}
			if (flag)
			{
				await locator.First.ClickAsync();
				await Task.Delay(2000, P_3);
				P_2("Đã tham gia nhóm: " + item2, "Spam nhóm - Tham gia nhóm");
			}
			list3.Add(item2);
		}
		return list3;
	}

	private static async Task<bool> m_4388(IPage P_0, GroupSpamSettings P_1, HashSet<string> P_2, DateTime P_3, Action<string, string> P_4, CancellationToken P_5)
	{
		int num = 15;
		for (int i = 0; i < num; i++)
		{
			if (!(DateTime.UtcNow < P_3))
			{
				break;
			}
			P_5.ThrowIfCancellationRequested();
			if (await m_4390(P_0, P_1, P_2, P_4, P_5))
			{
				return true;
			}
			await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(500, 1000));
			await Task.Delay(Random.Shared.Next(1500, 3000), P_5);
		}
		P_4("[Bỏ qua] Không tìm thấy bài viết mới phù hợp để bình luận sau khi lướt hết nhóm.", "Spam nhóm - Tìm bài");
		return false;
	}

	private static async Task<bool> m_4389(IPage P_0, GroupSpamSettings P_1, HashSet<string> P_2, DateTime P_3, Action<string, string> P_4, CancellationToken P_5)
	{
		string url = P_0.Url;
		int num = 8;
		for (int i = 0; i < num; i++)
		{
			if (!(DateTime.UtcNow < P_3))
			{
				break;
			}
			P_5.ThrowIfCancellationRequested();
			if (await m_4390(P_0, P_1, P_2, P_4, P_5))
			{
				return true;
			}
			P_4("Chưa có bài mới, chờ rồi tải lại trang...", "Spam nhóm - Tìm bài");
			await Task.Delay(Random.Shared.Next(15000, 30000), P_5);
			await P_0.GotoAsync(FacebookUrls.WithEnglishLocale(url), new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(2000, P_5);
		}
		P_4("[Bỏ qua] Chờ hết số lần tải lại vẫn không thấy bài mới phù hợp.", "Spam nhóm - Tìm bài");
		return false;
	}

	private static async Task<bool> m_4390(IPage P_0, GroupSpamSettings P_1, HashSet<string> P_2, Action<string, string> P_3, CancellationToken P_4)
	{
		ILocator locator = P_0.Locator("[aria-label^='Actions for this post by ']");
		int num = await locator.CountAsync();
		int num2 = P_0.ViewportSize?.Height ?? 800;
		for (int i = 0; i < num; i++)
		{
			ILocator locator2 = locator.Nth(i);
			if (!(await locator2.IsVisibleAsync()))
			{
				continue;
			}
			LocatorBoundingBoxResult locatorBoundingBoxResult = await locator2.BoundingBoxAsync();
			if (locatorBoundingBoxResult == null || locatorBoundingBoxResult.Y + locatorBoundingBoxResult.Height <= 0f || locatorBoundingBoxResult.Y >= (float)num2)
			{
				continue;
			}
			string text = await m_4392(locator2);
			if (text == null || P_2.Contains(text))
			{
				continue;
			}
			ILocator locator3 = await m_4393(P_0, locator2);
			if (locator3 != null)
			{
				string text2 = P_1.PickCommentText();
				if (text2 == null)
				{
					return false;
				}
				await locator3.ClickAsync();
				await Task.Delay(Random.Shared.Next(1200, 2200), P_4);
				if (!(await m_4391(P_0, P_4)))
				{
					await P_0.Keyboard.TypeAsync(text2, new KeyboardTypeOptions
					{
						Delay = Random.Shared.Next(60, 140)
					});
					await Task.Delay(500, P_4);
					await P_0.Keyboard.PressAsync("Enter");
					await Task.Delay(1000, P_4);
					P_2.Add(text);
					P_3("Đã bình luận 1 bài viết mới trong nhóm: \"" + text2 + "\"", "Spam nhóm - Bình luận");
					await m_4394(P_0, P_4);
					return true;
				}
				P_2.Add(text);
				P_3("[Bỏ qua] Đã từng bình luận bài này rồi (thấy tên mình trong danh sách bình luận).", "Spam nhóm - Bình luận");
				await m_4394(P_0, P_4);
			}
		}
		return false;
	}

	private static async Task<bool> m_4391(IPage P_0, CancellationToken P_1)
	{
		ILocator locator = P_0.Locator("[contenteditable='true'][aria-label]");
		if (await locator.CountAsync() == 0)
		{
			return false;
		}
		string text = await locator.First.GetAttributeAsync("aria-label");
		if (string.IsNullOrWhiteSpace(text))
		{
			return false;
		}
		int num = text.LastIndexOf(" as ", StringComparison.Ordinal);
		if (num < 0)
		{
			return false;
		}
		string text2 = text.Substring(num + 4).Trim();
		if (text2.Length == 0)
		{
			return false;
		}
		ILocator locator2 = P_0.Locator("[role='dialog']");
		ILocator locator3 = ((await locator2.CountAsync() > 0) ? locator2.Locator("article[aria-label^='Comment by ']") : P_0.Locator("article[aria-label^='Comment by ']"));
		int num2 = await locator3.CountAsync();
		for (int i = 0; i < num2; i++)
		{
			P_1.ThrowIfCancellationRequested();
			string text3 = await locator3.Nth(i).GetAttributeAsync("aria-label");
			if (!string.IsNullOrEmpty(text3) && (text3.StartsWith("Comment by ", StringComparison.Ordinal) ? text3.Substring("Comment by ".Length) : text3).Contains(text2, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private static async Task<string?> m_4392(ILocator P_0)
	{
		ILocator locator = P_0.Locator("xpath=ancestor::*[@aria-posinset][1]");
		if (await locator.CountAsync() == 0)
		{
			return null;
		}
		string text = (await P_0.GetAttributeAsync("aria-label")) ?? "";
		string text2;
		try
		{
			text2 = await locator.First.InnerTextAsync();
		}
		catch
		{
			return null;
		}
		string text3 = (from text4 in text2.Split('\n')
			select text4.Trim()).FirstOrDefault((string text4) => text4.Length >= 8 && !string.Equals(text4, "Facebook", StringComparison.Ordinal));
		return (text3 == null) ? null : (text + "|" + text3);
	}

	private static async Task<ILocator?> m_4393(IPage P_0, ILocator P_1)
	{
		ILocator locator = P_1.Locator("xpath=following::*[contains(@aria-label, 'comment')][1]");
		return (await locator.CountAsync() > 0) ? locator.First : null;
	}

	private static async Task m_4394(IPage P_0, CancellationToken P_1)
	{
		ILocator locator = P_0.Locator("[role='dialog'] [aria-label='Close'][role='button']");
		if (await locator.CountAsync() != 0 && await locator.First.IsVisibleAsync())
		{
			await locator.First.ClickAsync();
			await Task.Delay(800, P_1);
		}
	}
}
