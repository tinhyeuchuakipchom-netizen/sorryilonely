using System;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;

namespace testTuongTacWPF.Automation;

public class TmailorClient : IVerifyMailTestClient, IAsyncDisposable
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6700
	{
		public static readonly m_6700 A = new m_6700();

		public static Func<int> m_6705;

		internal int m_6706()
		{
			return Program.Main(new string[2] { "install", "chromium" });
		}
	}

	[CompilerGenerated]
	private sealed class m_6701
	{
		public TaskCompletionSource<string> A;

		internal async void m_6707(object? _, IResponse P_1)
		{
			if (!P_1.Url.Contains("/api/webapp-newemail"))
			{
				return;
			}
			try
			{
				TaskCompletionSource<string> taskCompletionSource = A;
				taskCompletionSource.TrySetResult(await P_1.TextAsync());
			}
			catch (Exception exception)
			{
				A.TrySetException(exception);
			}
		}
	}

	private const string A = "https://tmailor.com/";

	private const string a = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

	private readonly string? B;

	private IPlaywright? m_6694;

	private IBrowser? m_6695;

	private IPage? m_6696;

	private string? b;

	private string? C;

	private static bool m_6697;

	private static Task m_6698()
	{
		if (m_6697)
		{
			return Task.CompletedTask;
		}
		m_6697 = true;
		return Task.Run(() => Program.Main(new string[2] { "install", "chromium" }));
	}

	public TmailorClient(string? proxy = null)
	{
		B = proxy;
	}

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		await m_6698();
		ct.ThrowIfCancellationRequested();
		m_6694 = await Playwright.CreateAsync();
		m_6695 = await m_6694.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
		{
			Headless = true,
			Args = new string[1] { "--disable-blink-features=AutomationControlled" },
			Proxy = g.A(B)
		});
		using (g.A(ct, m_6695))
		{
			int num = 0;
			_ = 5;
			try
			{
				IBrowserContext browserContext = await m_6695.NewContextAsync(new BrowserNewContextOptions
				{
					UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
					ViewportSize = new ViewportSize
					{
						Width = 1280,
						Height = 800
					}
				});
				await browserContext.AddInitScriptAsync("Object.defineProperty(navigator, 'webdriver', { get: () => undefined });");
				TaskCompletionSource<string> A = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
				m_6696 = await browserContext.NewPageAsync();
				m_6696.Response += async (object? _, IResponse P_1) =>
				{
					if (!P_1.Url.Contains("/api/webapp-newemail"))
					{
						return;
					}
					try
					{
						TaskCompletionSource<string> taskCompletionSource = A;
						taskCompletionSource.TrySetResult(await P_1.TextAsync());
					}
					catch (Exception exception)
					{
						A.TrySetException(exception);
					}
				};
				await m_6696.GotoAsync("https://tmailor.com/", new PageGotoOptions
				{
					WaitUntil = WaitUntilState.DOMContentLoaded
				});
				Task task = Task.Delay(TimeSpan.FromSeconds(25L), ct);
				if (await Task.WhenAny(A.Task, task) == task)
				{
					ct.ThrowIfCancellationRequested();
					throw new InvalidOperationException("Không nhận được phản hồi tạo mail từ tmailor.com sau 25s (có thể site đổi giao diện hoặc mạng chậm).");
				}
				using JsonDocument jsonDocument = JsonDocument.Parse(await A.Task);
				string text = (jsonDocument.RootElement.TryGetProperty("msg", out var value) ? (value.GetString() ?? "") : "");
				if (text != "ok")
				{
					throw new InvalidOperationException("tmailor.com từ chối tạo mail (phản hồi: \"" + text + "\") - site có cơ chế chống bot ẩn, đôi khi chặn cả request hợp lệ khi nghi ngờ tự động hoá (kể cả sau khi đã vượt Cloudflare). Thử lại sau ít phút hoặc đổi sang cổng mail khác.");
				}
				b = (jsonDocument.RootElement.TryGetProperty("email", out var value2) ? value2.GetString() : null);
				C = (jsonDocument.RootElement.TryGetProperty("accesstoken", out var value3) ? value3.GetString() : null);
				if (string.IsNullOrWhiteSpace(b) || string.IsNullOrWhiteSpace(C))
				{
					throw new InvalidOperationException("Không đọc được địa chỉ mail từ tmailor.com (có thể site đã đổi cấu trúc response).");
				}
				return b;
			}
			catch (Exception) when (ct.IsCancellationRequested)
			{
				throw new OperationCanceledException(ct);
			}
		}
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (m_6696 == null || b == null || C == null)
		{
			throw new InvalidOperationException("Chưa lấy địa chỉ mail - bấm \"Thử lấy mail\" trước.");
		}
		(string, string)? tuple = await m_6699();
		if (!tuple.HasValue)
		{
			return null;
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(await m_6696.EvaluateAsync<string>("\n                async ([email, token, emailCode, emailToken]) => {\n                    const r = await fetch('/api/webapp-read', {\n                        method: 'POST',\n                        headers: { 'Content-Type': 'application/json' },\n                        body: JSON.stringify({\n                            action: 'read',\n                            accesstoken: token,\n                            email_code: emailCode,\n                            email_token: emailToken,\n                            body_url: 1\n                        })\n                    });\n                    return await r.text();\n                }\n            ", new string[4]
		{
			b,
			C,
			tuple.Value.Item1,
			tuple.Value.Item2
		}));
		if (!jsonDocument.RootElement.TryGetProperty("msg", out var value) || value.GetString() != "ok")
		{
			return null;
		}
		if (!jsonDocument.RootElement.TryGetProperty("data", out var value2))
		{
			return null;
		}
		string text = f.A(value2.TryGetProperty("subject", out var value3) ? (value3.GetString() ?? "") : "");
		if (text != null)
		{
			return text;
		}
		string text2 = (value2.TryGetProperty("body", out var value4) ? (value4.GetString() ?? "") : "");
		string text3;
		if (value2.TryGetProperty("url_body", out var value5))
		{
			text3 = value5.GetString() ?? "";
		}
		else
		{
			text3 = (value2.TryGetProperty("readurl", out var value6) ? (value6.GetString() ?? "") : "");
		}
		if (string.IsNullOrWhiteSpace(text2) && !string.IsNullOrWhiteSpace(text3))
		{
			text2 = await m_6696.EvaluateAsync<string>("async (url) => { const r = await fetch(url); return await r.text(); }", text3);
		}
		return f.A(WebUtility.HtmlDecode(Regex.Replace(text2, "<[^>]+>", " ")));
	}

	private async Task<(string Id, string EmailToken)?> m_6699()
	{
		using JsonDocument jsonDocument = JsonDocument.Parse(await m_6696.EvaluateAsync<string>("\n                async ([email, token]) => {\n                    const r = await fetch('/api/webapp-listinbox', {\n                        method: 'POST',\n                        headers: { 'Content-Type': 'application/json' },\n                        body: JSON.stringify({\n                            action: 'listinbox',\n                            listToken: { [email]: token },\n                            fbToken: null,\n                            sk: ''\n                        })\n                    });\n                    return await r.text();\n                }\n            ", new string[2] { b, C }));
		if (!jsonDocument.RootElement.TryGetProperty("data", out var value) || value.ValueKind != JsonValueKind.Object)
		{
			return null;
		}
		string text = null;
		string text2 = null;
		long num = -1L;
		foreach (JsonProperty item in value.EnumerateObject())
		{
			if (!item.Value.TryGetProperty("data", out var value2) || value2.ValueKind != JsonValueKind.Object)
			{
				continue;
			}
			foreach (JsonProperty item2 in value2.EnumerateObject())
			{
				long num2 = ((item2.Value.TryGetProperty("receive_time", out var value3) && value3.TryGetInt64(out var value4)) ? value4 : 0);
				string text3 = (item2.Value.TryGetProperty("email_id", out var value5) ? value5.GetString() : null);
				if (text3 != null && num2 >= num)
				{
					num = num2;
					text = item2.Name;
					text2 = text3;
				}
			}
		}
		return (text != null && text2 != null) ? new (string, string)?((text, text2)) : (((string, string)?)null);
	}

	public async ValueTask DisposeAsync()
	{
		if (m_6695 != null)
		{
			await m_6695.CloseAsync();
		}
		m_6694?.Dispose();
	}
}
