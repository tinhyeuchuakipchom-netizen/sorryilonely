using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class GoogleSheetsSyncSettings
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private string m_5574 = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	public bool Enabled
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string ClientId
	{
		[CompilerGenerated]
		get
		{
			return m_5574;
		}
		[CompilerGenerated]
		set
		{
			m_5574 = value;
		}
	}

	public string ClientSecret
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string SpreadsheetId
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	private static string m_5575(string P_0)
	{
		return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", string.IsNullOrEmpty(P_0) ? "google_sheets_sync_settings.json" : (P_0.ToLowerInvariant() + "_google_sheets_sync_settings.json"));
	}

	public static GoogleSheetsSyncSettings Load(string platformKey = "")
	{
		try
		{
			string path = m_5575(platformKey);
			if (!File.Exists(path))
			{
				return new GoogleSheetsSyncSettings();
			}
			return JsonSerializer.Deserialize<GoogleSheetsSyncSettings>(File.ReadAllText(path)) ?? new GoogleSheetsSyncSettings();
		}
		catch
		{
			return new GoogleSheetsSyncSettings();
		}
	}

	public void Save(string platformKey = "")
	{
		string path = m_5575(platformKey);
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		File.WriteAllText(path, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
