using System;
using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class AiVisionStepLog
{
	[CompilerGenerated]
	private int A;

	[CompilerGenerated]
	private int a;

	[CompilerGenerated]
	private string m_5839 = "";

	[CompilerGenerated]
	private string m_5840 = "";

	[CompilerGenerated]
	private DateTime m_5841 = DateTime.Now;

	[CompilerGenerated]
	private string B = "";

	public int FlowStepIndex
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int SubStep
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string ActionSummary
	{
		[CompilerGenerated]
		get
		{
			return m_5839;
		}
		[CompilerGenerated]
		set
		{
			m_5839 = value;
		}
	}

	public string Reason
	{
		[CompilerGenerated]
		get
		{
			return m_5840;
		}
		[CompilerGenerated]
		set
		{
			m_5840 = value;
		}
	}

	public DateTime Timestamp
	{
		[CompilerGenerated]
		get
		{
			return m_5841;
		}
		[CompilerGenerated]
		set
		{
			m_5841 = value;
		}
	}

	public string TimeLabel
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string FlowStepLabel => $"Bước {FlowStepIndex + 1}.{SubStep}: ";
}
