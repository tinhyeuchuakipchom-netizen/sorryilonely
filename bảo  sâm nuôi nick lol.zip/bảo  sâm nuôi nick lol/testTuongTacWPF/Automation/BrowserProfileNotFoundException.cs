using System;

namespace testTuongTacWPF.Automation;

public class BrowserProfileNotFoundException : Exception
{
	public BrowserProfileNotFoundException(string message)
		: base(message)
	{
	}
}
