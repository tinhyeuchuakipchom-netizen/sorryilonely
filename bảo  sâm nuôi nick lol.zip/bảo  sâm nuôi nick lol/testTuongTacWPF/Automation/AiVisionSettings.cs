using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public class AiVisionSettings
{
	[CompilerGenerated]
	private string A = "Claude";

	[CompilerGenerated]
	private List<string> m_3052 = new List<string>();

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "claude-sonnet-4-5";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string C = "gemini-flash-latest";

	[CompilerGenerated]
	private string c = "";

	[CompilerGenerated]
	private string D = "claude-sonnet-5";

	[CompilerGenerated]
	private string d = "";

	[CompilerGenerated]
	private string E = "kimi-k2.6";

	[CompilerGenerated]
	private string e = "";

	[CompilerGenerated]
	private string F = "";

	[CompilerGenerated]
	private string f = "";

	[CompilerGenerated]
	private string G = "OpenAI";

	[CompilerGenerated]
	private List<CustomAiProvider> m_3053 = new List<CustomAiProvider>();

	[CompilerGenerated]
	private int m_3054 = 2000;

	[CompilerGenerated]
	private int m_3055 = 5;

	[CompilerGenerated]
	private int m_3056 = 4;

	[CompilerGenerated]
	private int m_3057 = 900;

	[CompilerGenerated]
	private bool m_3058 = true;

	private static readonly string g = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "ai_vision_settings.json");

	public string Provider
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public List<string> PriorityTargets
	{
		[CompilerGenerated]
		get
		{
			return m_3052;
		}
		[CompilerGenerated]
		set
		{
			m_3052 = value;
		}
	}

	public string ApiKey
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Model
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string GoogleApiKey
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string GoogleModel
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public string HHTechApiKey
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string HHTechModel
	{
		[CompilerGenerated]
		get
		{
			return D;
		}
		[CompilerGenerated]
		set
		{
			D = value;
		}
	}

	public string VietApiKey
	{
		[CompilerGenerated]
		get
		{
			return d;
		}
		[CompilerGenerated]
		set
		{
			d = value;
		}
	}

	public string VietApiModel
	{
		[CompilerGenerated]
		get
		{
			return E;
		}
		[CompilerGenerated]
		set
		{
			E = value;
		}
	}

	public string CustomApiUrl
	{
		[CompilerGenerated]
		get
		{
			return e;
		}
		[CompilerGenerated]
		set
		{
			e = value;
		}
	}

	public string CustomApiKey
	{
		[CompilerGenerated]
		get
		{
			return F;
		}
		[CompilerGenerated]
		set
		{
			F = value;
		}
	}

	public string CustomModel
	{
		[CompilerGenerated]
		get
		{
			return f;
		}
		[CompilerGenerated]
		set
		{
			f = value;
		}
	}

	public string CustomFormat
	{
		[CompilerGenerated]
		get
		{
			return G;
		}
		[CompilerGenerated]
		set
		{
			G = value;
		}
	}

	public List<CustomAiProvider> SavedCustomProviders
	{
		[CompilerGenerated]
		get
		{
			return m_3053;
		}
		[CompilerGenerated]
		set
		{
			m_3053 = value;
		}
	}

	public int StepDelayMs
	{
		[CompilerGenerated]
		get
		{
			return m_3054;
		}
		[CompilerGenerated]
		set
		{
			m_3054 = value;
		}
	}

	public int MaxConcurrentDevices
	{
		[CompilerGenerated]
		get
		{
			return m_3055;
		}
		[CompilerGenerated]
		set
		{
			m_3055 = value;
		}
	}

	public int PoolMatchRetryAttempts
	{
		[CompilerGenerated]
		get
		{
			return m_3056;
		}
		[CompilerGenerated]
		set
		{
			m_3056 = value;
		}
	}

	public int PoolMatchRetryDelayMs
	{
		[CompilerGenerated]
		get
		{
			return m_3057;
		}
		[CompilerGenerated]
		set
		{
			m_3057 = value;
		}
	}

	public bool SendScreenshot
	{
		[CompilerGenerated]
		get
		{
			return m_3058;
		}
		[CompilerGenerated]
		set
		{
			m_3058 = value;
		}
	}

	public static AiVisionSettings Load()
	{
		try
		{
			if (!File.Exists(g))
			{
				return new AiVisionSettings();
			}
			AiVisionSettings aiVisionSettings = JsonSerializer.Deserialize<AiVisionSettings>(File.ReadAllText(g)) ?? new AiVisionSettings();
			if (aiVisionSettings.PriorityTargets.Count == 0 && aiVisionSettings.Provider != "GeminiAntigravity")
			{
				aiVisionSettings.PriorityTargets.Add(aiVisionSettings.Provider);
			}
			return aiVisionSettings;
		}
		catch
		{
			return new AiVisionSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(g));
		File.WriteAllText(g, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
