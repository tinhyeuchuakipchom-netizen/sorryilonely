namespace testTuongTacWPF.Automation;

public static class VerifyMailProviders
{
	public const string TenMinuteMail = "TenMinuteMail";

	public const string TempMailOrg = "TempMailOrg";

	public const string Tmailor = "Tmailor";

	public const string TempMail100 = "TempMail100";

	public const string TempMailIo = "TempMailIo";

	public const string TemporaryMail = "TemporaryMail";

	public const string DongVanFb = "DongVanFb";

	public const string Random = "Random";
}
