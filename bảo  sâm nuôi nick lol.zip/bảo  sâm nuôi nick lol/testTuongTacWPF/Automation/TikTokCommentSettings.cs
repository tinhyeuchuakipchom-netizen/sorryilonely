using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class TikTokCommentSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6284
	{
		public static readonly m_6284 A = new m_6284();

		public static Func<string, bool> m_6286;

		internal bool m_6287(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_6285
	{
		public string[] A;

		internal bool m_6288(string P_0)
		{
			return A.Contains(Path.GetExtension(P_0).ToLowerInvariant());
		}
	}

	[CompilerGenerated]
	private int A = 3;

	[CompilerGenerated]
	private int a = 5;

	[CompilerGenerated]
	private int B = 4;

	[CompilerGenerated]
	private int b = 8;

	[CompilerGenerated]
	private int C = 100;

	[CompilerGenerated]
	private List<string> m_6279 = new List<string> { "Video cuốn quá bạn ơi \ud83d\ude0d", "Đỉnh thật sự luôn \ud83d\udd25", "Xem đi xem lại vẫn thấy hay", "Tuyệt vời quá ạ ❤\ufe0f", "Nội dung chất lượng ghê \ud83d\udc4f" };

	[CompilerGenerated]
	private bool m_6280;

	[CompilerGenerated]
	private List<string> m_6281 = new List<string> { "❤\ufe0f", "\ud83d\ude0d", "\ud83d\udd25", "\ud83d\udc4f", "\ud83d\ude02", "\ud83d\udcaf", "\ud83e\udd70", "\ud83d\udc4d" };

	[CompilerGenerated]
	private bool m_6282;

	[CompilerGenerated]
	private string m_6283 = "";

	public int MinCount
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxCount
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MinDelaySec
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MaxDelaySec
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int CommentRatePercent
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public List<string> CommentTexts
	{
		[CompilerGenerated]
		get
		{
			return m_6279;
		}
		[CompilerGenerated]
		set
		{
			m_6279 = value;
		}
	}

	public bool AppendEmoji
	{
		[CompilerGenerated]
		get
		{
			return m_6280;
		}
		[CompilerGenerated]
		set
		{
			m_6280 = value;
		}
	}

	public List<string> CommentEmojis
	{
		[CompilerGenerated]
		get
		{
			return m_6281;
		}
		[CompilerGenerated]
		set
		{
			m_6281 = value;
		}
	}

	public bool CommentWithImage
	{
		[CompilerGenerated]
		get
		{
			return m_6282;
		}
		[CompilerGenerated]
		set
		{
			m_6282 = value;
		}
	}

	public string CommentImageFolder
	{
		[CompilerGenerated]
		get
		{
			return m_6283;
		}
		[CompilerGenerated]
		set
		{
			m_6283 = value;
		}
	}

	public int PickCount()
	{
		if (MinCount < MaxCount)
		{
			return Random.Shared.Next(MinCount, MaxCount + 1);
		}
		return MinCount;
	}

	public int PickDelaySec()
	{
		if (MinDelaySec < MaxDelaySec)
		{
			return Random.Shared.Next(MinDelaySec, MaxDelaySec + 1);
		}
		return MinDelaySec;
	}

	public bool RollChance()
	{
		return Random.Shared.Next(0, 100) < CommentRatePercent;
	}

	public string? PickCommentText()
	{
		List<string> list = CommentTexts.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count == 0)
		{
			return null;
		}
		string text = list[Random.Shared.Next(list.Count)].Trim();
		if (AppendEmoji && CommentEmojis.Count > 0)
		{
			string text2 = CommentEmojis[Random.Shared.Next(CommentEmojis.Count)];
			text = text + " " + text2;
		}
		return text;
	}

	public string? PickImagePath()
	{
		if (!CommentWithImage || string.IsNullOrWhiteSpace(CommentImageFolder) || !Directory.Exists(CommentImageFolder))
		{
			return null;
		}
		string[] A = new string[3] { ".jpg", ".jpeg", ".png" };
		List<string> list = (from P_0 in Directory.EnumerateFiles(CommentImageFolder)
			where A.Contains(Path.GetExtension(P_0).ToLowerInvariant())
			select P_0).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static TikTokCommentSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new TikTokCommentSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<TikTokCommentSettings>(json) ?? new TikTokCommentSettings();
		}
		catch
		{
			return new TikTokCommentSettings();
		}
	}
}
