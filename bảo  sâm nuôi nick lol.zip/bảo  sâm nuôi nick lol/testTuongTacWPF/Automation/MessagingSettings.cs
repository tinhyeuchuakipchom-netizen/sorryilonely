using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class MessagingSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5788
	{
		public static readonly m_5788 A = new m_5788();

		public static Func<string, bool> m_5789;

		public static Func<string, string> m_5790;

		internal bool m_5791(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string a(string P_0)
		{
			return P_0.Trim();
		}
	}

	[CompilerGenerated]
	private MessagingTarget A;

	[CompilerGenerated]
	private string m_5785 = "";

	[CompilerGenerated]
	private int m_5786 = 5;

	[CompilerGenerated]
	private List<string> m_5787 = new List<string> { "Chào bạn nhé", "Hi bạn, kết bạn giao lưu nha", "Chào bạn, rất vui được làm quen" };

	[CompilerGenerated]
	private int a = 15;

	[CompilerGenerated]
	private int B = 30;

	[CompilerGenerated]
	private int b = 90;

	[JsonConverter(typeof(JsonStringEnumConverter))]
	public MessagingTarget Target
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string PostLink
	{
		[CompilerGenerated]
		get
		{
			return m_5785;
		}
		[CompilerGenerated]
		set
		{
			m_5785 = value;
		}
	}

	public int LoadMoreCommentsClicks
	{
		[CompilerGenerated]
		get
		{
			return m_5786;
		}
		[CompilerGenerated]
		set
		{
			m_5786 = value;
		}
	}

	public List<string> Messages
	{
		[CompilerGenerated]
		get
		{
			return m_5787;
		}
		[CompilerGenerated]
		set
		{
			m_5787 = value;
		}
	}

	public int MaxMessagesPerRun
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MinDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MaxDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static MessagingSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new MessagingSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<MessagingSettings>(json) ?? new MessagingSettings();
		}
		catch (JsonException)
		{
			return new MessagingSettings();
		}
	}

	public int PickDelaySeconds()
	{
		if (MinDelaySeconds < MaxDelaySeconds)
		{
			return Random.Shared.Next(MinDelaySeconds, MaxDelaySeconds + 1);
		}
		return MinDelaySeconds;
	}

	public string? PickMessage()
	{
		List<string> list = (from P_0 in Messages
			where !string.IsNullOrWhiteSpace(P_0)
			select P_0.Trim()).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}
}
