using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class ChromeAiVisionRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3472
	{
		public static readonly m_3472 A = new m_3472();

		public static Func<BrowserContextCookiesResult, bool> m_3477;

		public static Func<UiElement, string> m_3478;

		public static Func<string, bool> m_3479;

		public static Func<UiElement, string> a;

		public static Func<string, bool> m_3480;

		internal bool m_3481(BrowserContextCookiesResult P_0)
		{
			return P_0.Name == "c_user";
		}

		internal string m_3482(UiElement P_0)
		{
			return P_0.Text;
		}

		internal bool m_3483(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_3484(UiElement P_0)
		{
			return P_0.Text;
		}

		internal bool m_3485(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_3473
	{
		public AiVisionFlowStep A;

		internal bool m_3486(UiElement P_0)
		{
			if (string.Equals(P_0.Text, A.DisambiguatorText, StringComparison.OrdinalIgnoreCase) && Math.Abs(P_0.CenterX - A.DisambiguatorX) <= 60)
			{
				return Math.Abs(P_0.CenterY - A.DisambiguatorY) <= 60;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_3474
	{
		public AiVisionCachedStep A;

		internal bool m_3487(UiElement P_0)
		{
			return P_0.ResourceId == A.ResourceId;
		}

		internal bool a(UiElement P_0)
		{
			return P_0.ContentDesc == A.ContentDesc;
		}

		internal bool B(UiElement P_0)
		{
			return P_0.Text == A.ElementText;
		}
	}

	[CompilerGenerated]
	private sealed class m_3475
	{
		public HashSet<string> A;

		internal bool m_3488(string P_0)
		{
			return !A.Contains(P_0);
		}
	}

	private static IPlaywright? A;

	private static readonly SemaphoreSlim m_3442 = new SemaphoreSlim(1, 1);

	private const string m_3443 = "([x, y]) => {\n            const el = document.elementFromPoint(x, y);\n            if (!el) return null;\n            if (el.tagName === 'HTML' || el.tagName === 'BODY') return null;\n            let r = el.getBoundingClientRect();\n            if (r.width >= window.innerWidth * 0.9 && r.height >= window.innerHeight * 0.9) return null;\n            el.scrollIntoView({ block: 'center', inline: 'nearest' });\n            r = el.getBoundingClientRect();\n            if (r.width === 0 || r.height === 0) return null;\n            return [Math.round(r.left + r.width / 2), Math.round(r.top + r.height / 2)];\n        }";

	private const int m_3444 = 250;

	private const int a = 60;

	private const int B = 3;

	private const int b = 4;

	private const int C = 350;

	private static readonly Regex[] m_3445 = new Regex[5]
	{
		new Regex("^_r_[0-9a-z]+_$", RegexOptions.Compiled),
		new Regex("^:r[0-9a-z]+:$", RegexOptions.Compiled),
		new Regex("^radix-.*[:«][0-9a-z]+[:»]$", RegexOptions.Compiled),
		new Regex("^mui-[0-9]+$", RegexOptions.Compiled),
		new Regex("^(ember|ext-gen)\\d+$", RegexOptions.Compiled)
	};

	public static async Task<AiVisionRunResult> RunFlowForProfileAsync(string profileId, IReadOnlyList<AiVisionFlowStep> flow, IReadOnlyDictionary<string, string> variables, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, Action<int, AiVisionFlowStep?>? onActionRecorded = null)
	{
		if (string.IsNullOrWhiteSpace(profileId))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Chưa có Profile Chrome để chạy thử."
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}."
			};
		}
		bool flag = false;
		AiVisionRunResult result;
		try
		{
			_ = 1;
			try
			{
				result = await m_3451(await ConnectToTestProfileAsync(client, profileId, cancellationToken), AiVisionSettings.Load(), flow, variables, onStep, cancellationToken, onActionRecorded);
			}
			catch (OperationCanceledException)
			{
				flag = true;
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu."
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + m_3471(ex2)
				};
			}
		}
		finally
		{
			if (flag)
			{
				try
				{
					await client.StopProfileAsync(profileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	public static async Task<IPage> ConnectToTestProfileAsync(IAntidetectBrowserClient client, string profileId, CancellationToken cancellationToken)
	{
		cancellationToken.ThrowIfCancellationRequested();
		return (await m_3448(client, profileId, cancellationToken)).Item3;
	}

	public static async Task<AiVisionRunResult> RunFlowForNickAsync(IChromeAutomationAccount nick, IReadOnlyList<AiVisionFlowStep> flow, IReadOnlyDictionary<string, string> variables, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome)."
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}."
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		IBrowser browser = null;
		IBrowserContext browserContext = null;
		IPage page = null;
		AiVisionRunResult result;
		try
		{
			_ = 4;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				(IBrowser, IBrowserContext, IPage) tuple = await m_3449(client, settings, nick, cancellationToken);
				browser = tuple.Item1;
				browserContext = tuple.Item2;
				page = tuple.Item3;
				browserProfileId = nick.BrowserProfileId;
				AiVisionRunResult aiVisionRunResult = await m_3451(page, AiVisionSettings.Load(), flow, variables, onStep, cancellationToken);
				if (aiVisionRunResult.Success && activeBrowserEngine.Settings.SaveNewCookieAfterLogin)
				{
					if (nick is FacebookAccountRow nick2)
					{
						await ChromeLoginRunner.RefreshCookieAsync(nick2, browserContext);
					}
					else
					{
						await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext);
					}
				}
				if (nick is FacebookAccountRow)
				{
					AiVisionRunResult aiVisionRunResult2 = aiVisionRunResult;
					aiVisionRunResult2.TinhTrang = await m_3446(browserContext, page, cancellationToken);
				}
				else if (!aiVisionRunResult.Success)
				{
					aiVisionRunResult.TinhTrang = "ERROR";
				}
				result = aiVisionRunResult;
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + m_3471(ex2),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			try
			{
				if (page != null)
				{
					await page.CloseAsync();
				}
			}
			catch
			{
			}
			try
			{
				if (browserContext != null)
				{
					await browserContext.CloseAsync();
				}
			}
			catch
			{
			}
			try
			{
				if (browser != null)
				{
					await browser.CloseAsync();
					await browser.DisposeAsync();
				}
			}
			catch
			{
			}
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static async Task<string> m_3446(IBrowserContext P_0, IPage P_1, CancellationToken P_2)
	{
		_ = 3;
		try
		{
			await P_1.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(1500, P_2);
			string text = await P_1.ContentAsync();
			bool num = text.Contains("Email address or phone number") || text.Contains("Email hoặc số điện thoại");
			bool flag = P_1.Url.Contains("/checkpoint/") || P_1.Url.Contains("/login");
			if (num | flag)
			{
				return "DIE";
			}
			if ((await P_0.CookiesAsync()).Any((BrowserContextCookiesResult browserContextCookiesResult) => browserContextCookiesResult.Name == "c_user"))
			{
				return "LIVE";
			}
			return "ERROR";
		}
		catch (OperationCanceledException)
		{
			return "ERROR";
		}
		catch
		{
			return "ERROR";
		}
	}

	private static async Task<IPlaywright> m_3447()
	{
		if (A != null)
		{
			return A;
		}
		await m_3442.WaitAsync();
		try
		{
			if (A == null)
			{
				A = await Playwright.CreateAsync();
			}
			return A;
		}
		finally
		{
			m_3442.Release();
		}
	}

	private static async Task<(IBrowser Browser, IBrowserContext Context, IPage Page)> m_3448(IAntidetectBrowserClient P_0, string P_1, CancellationToken P_2)
	{
		P_2.ThrowIfCancellationRequested();
		return await m_3450(await P_0.StartProfileAsync(P_1), P_2);
	}

	private static async Task<(IBrowser Browser, IBrowserContext Context, IPage Page)> m_3449(IAntidetectBrowserClient P_0, IChromeEngineSettings P_1, IChromeAutomationAccount P_2, CancellationToken P_3)
	{
		P_3.ThrowIfCancellationRequested();
		IBrowser item = (await global::A.F.A(P_0, P_1, P_2, await m_3447(), P_3)).Item2;
		IBrowserContext browserContext = item.Contexts.FirstOrDefault();
		if (browserContext == null)
		{
			browserContext = await item.NewContextAsync();
		}
		IBrowserContext browserContext2 = browserContext;
		IPage page = browserContext2.Pages.FirstOrDefault();
		if (page == null)
		{
			page = await browserContext2.NewPageAsync();
		}
		IPage item2 = page;
		return (Browser: item, Context: browserContext2, Page: item2);
	}

	private static async Task<(IBrowser Browser, IBrowserContext Context, IPage Page)> m_3450(OmoBrowserStartResult P_0, CancellationToken P_1)
	{
		IPlaywright playwright = await m_3447();
		string endpointURL = ((!string.IsNullOrWhiteSpace(P_0.WebSocketDebuggingUrl)) ? P_0.WebSocketDebuggingUrl : P_0.RemoteDebuggingAddress);
		Exception ex = null;
		IBrowser browser = null;
		for (int k = 1; k <= 6; k++)
		{
			if (browser != null)
			{
				break;
			}
			P_1.ThrowIfCancellationRequested();
			try
			{
				browser = await playwright.Chromium.ConnectOverCDPAsync(endpointURL);
			}
			catch (Exception ex2)
			{
				ex = ex2;
				if (k < 6)
				{
					await Task.Delay(1000, P_1);
				}
			}
		}
		if (browser == null)
		{
			throw ex;
		}
		IBrowserContext browserContext = browser.Contexts.FirstOrDefault();
		if (browserContext == null)
		{
			browserContext = await browser.NewContextAsync();
		}
		IBrowserContext browserContext2 = browserContext;
		IPage page = browserContext2.Pages.FirstOrDefault();
		if (page == null)
		{
			page = await browserContext2.NewPageAsync();
		}
		IPage item = page;
		return (Browser: browser, Context: browserContext2, Page: item);
	}

	private static async Task<AiVisionRunResult> m_3451(IPage P_0, AiVisionSettings P_1, IReadOnlyList<AiVisionFlowStep> P_2, IReadOnlyDictionary<string, string> P_3, Action<AiVisionStepLog> P_4, CancellationToken P_5, Action<int, AiVisionFlowStep?>? onActionRecorded = null)
	{
		for (int k = 0; k < P_2.Count; k++)
		{
			P_5.ThrowIfCancellationRequested();
			AiVisionFlowStep aiVisionFlowStep = P_2[k];
			switch (aiVisionFlowStep.Type)
			{
			case AiVisionStepType.Wait:
				await Task.Delay(aiVisionFlowStep.WaitMs, P_5);
				break;
			case AiVisionStepType.RandomWait:
			{
				int minValue = Math.Min(aiVisionFlowStep.RandomMinMs, aiVisionFlowStep.RandomMaxMs);
				int num2 = Math.Max(aiVisionFlowStep.RandomMinMs, aiVisionFlowStep.RandomMaxMs);
				await Task.Delay(Random.Shared.Next(minValue, num2 + 1), P_5);
				break;
			}
			case AiVisionStepType.AiGoal:
			{
				if (string.IsNullOrWhiteSpace(aiVisionFlowStep.Goal))
				{
					return new AiVisionRunResult
					{
						Success = false,
						Message = $"Bước {k + 1}: chưa nhập mục tiêu."
					};
				}
				AiVisionRunResult aiVisionRunResult2 = await m_3452(P_0, P_1, aiVisionFlowStep.Goal, aiVisionFlowStep.MaxSteps, k, P_3, P_4, P_5, onActionRecorded);
				if (!aiVisionRunResult2.Success)
				{
					if (aiVisionRunResult2.Message.StartsWith("Chưa bật mục tiêu AI nào", StringComparison.Ordinal))
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = $"Dừng ở bước {k + 1}: {aiVisionRunResult2.Message}"
						};
					}
					P_4(new AiVisionStepLog
					{
						FlowStepIndex = k,
						SubStep = 0,
						ActionSummary = $"[Bỏ qua] Khối Mục tiêu AI ở bước {k + 1} chưa xong: {aiVisionRunResult2.Message}",
						Reason = "Hết số bước tối đa của riêng khối này - tự động chạy tiếp bước kế tiếp trong danh sách."
					});
				}
				break;
			}
			case AiVisionStepType.Scroll:
				await P_0.Mouse.MoveAsync(aiVisionFlowStep.X, aiVisionFlowStep.Y);
				await P_0.Mouse.WheelAsync(aiVisionFlowStep.X2, aiVisionFlowStep.Y2);
				P_4(new AiVisionStepLog
				{
					FlowStepIndex = k,
					SubStep = 1,
					ActionSummary = $"Lăn chuột tại ({aiVisionFlowStep.X},{aiVisionFlowStep.Y}) delta=({aiVisionFlowStep.X2},{aiVisionFlowStep.Y2})",
					Reason = "Bước lăn chuột ghi từ Ghi trực tiếp."
				});
				break;
			case AiVisionStepType.KeyPress:
				await P_0.Keyboard.PressAsync(aiVisionFlowStep.Text);
				P_4(new AiVisionStepLog
				{
					FlowStepIndex = k,
					SubStep = 1,
					ActionSummary = "Phím: " + aiVisionFlowStep.Text,
					Reason = "Bước phím ghi từ Ghi trực tiếp."
				});
				break;
			case AiVisionStepType.Goto:
			{
				if (string.IsNullOrWhiteSpace(aiVisionFlowStep.Url))
				{
					return new AiVisionRunResult
					{
						Success = false,
						Message = $"Bước {k + 1}: chưa có URL để mở."
					};
				}
				string text2 = AiVisionVariables.Substitute(aiVisionFlowStep.Url, P_3);
				await P_0.GotoAsync(text2);
				P_4(new AiVisionStepLog
				{
					FlowStepIndex = k,
					SubStep = 1,
					ActionSummary = "Mở trang: " + text2,
					Reason = "Bước \"Mở trang\" ghi từ Ghi trực tiếp."
				});
				break;
			}
			case AiVisionStepType.Tap:
			case AiVisionStepType.Swipe:
			case AiVisionStepType.Text:
			{
				if (!aiVisionFlowStep.IsMarkedComplete)
				{
					P_4(new AiVisionStepLog
					{
						FlowStepIndex = k,
						SubStep = 1,
						ActionSummary = "[Bỏ qua] Bước chưa đánh dấu.",
						Reason = "Không có toạ độ/phần tử để chạy - bỏ qua, sang bước kế tiếp."
					});
					break;
				}
				string text = await m_3454(P_0, m_3463(aiVisionFlowStep), P_3, P_5);
				if (text != null)
				{
					P_4(new AiVisionStepLog
					{
						FlowStepIndex = k,
						SubStep = 1,
						ActionSummary = text,
						Reason = "Bước đã đánh dấu sẵn."
					});
					break;
				}
				P_4(new AiVisionStepLog
				{
					FlowStepIndex = k,
					SubStep = 1,
					ActionSummary = "[Đánh dấu] Không thực thi được bước này.",
					Reason = "Rơi về AI (nếu có khối AI phía sau)."
				});
				int num = m_3464(P_2, k);
				if (num < 0)
				{
					return new AiVisionRunResult
					{
						Success = false,
						Message = $"Bước {k + 1}: không tìm thấy phần tử đã đánh dấu và không có khối Mục tiêu AI nào phía sau để xử lý tiếp."
					};
				}
				AiVisionFlowStep aiVisionFlowStep2 = P_2[num];
				if (string.IsNullOrWhiteSpace(aiVisionFlowStep2.Goal))
				{
					return new AiVisionRunResult
					{
						Success = false,
						Message = $"Bước {k + 1}: không tìm thấy phần tử đã đánh dấu; khối Mục tiêu AI ở bước {num + 1} chưa nhập mục tiêu."
					};
				}
				AiVisionRunResult aiVisionRunResult = await m_3452(P_0, P_1, aiVisionFlowStep2.Goal, aiVisionFlowStep2.MaxSteps, num, P_3, P_4, P_5, onActionRecorded);
				if (!aiVisionRunResult.Success)
				{
					return new AiVisionRunResult
					{
						Success = false,
						Message = $"Dừng ở bước {num + 1}: {aiVisionRunResult.Message}"
					};
				}
				k = num;
				break;
			}
			}
		}
		return new AiVisionRunResult
		{
			Success = true,
			Message = $"Hoàn thành cả {P_2.Count} bước."
		};
	}

	internal static async Task<AiVisionRunResult> m_3452(IPage P_0, AiVisionSettings P_1, string P_2, int P_3, int P_4, IReadOnlyDictionary<string, string> P_5, Action<AiVisionStepLog> P_6, CancellationToken P_7, Action<int, AiVisionFlowStep?>? onActionRecorded = null)
	{
		if (P_1.PriorityTargets.Count == 0)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Chưa bật mục tiêu AI nào - vào Cài đặt AI Vision bật ít nhất 1 provider/model."
			};
		}
		string goal = AiVisionVariables.Substitute(P_2, P_5);
		List<string> list = new List<string>();
		for (int k = 1; k <= P_3; k++)
		{
			P_7.ThrowIfCancellationRequested();
			byte[] screenshotPng = await m_3468(P_0, P_7);
			List<UiElement> list2 = await m_3470(P_0);
			AiVisionAction aiVisionAction = await AiVisionClient.DecideNextActionAsync(P_1, screenshotPng, goal, list, list2, AiVisionTargetKind.Chrome, P_7);
			UiElement uiElement = m_3465(aiVisionAction, list2, P_0.ViewportSize);
			string text = m_3467(aiVisionAction, uiElement?.Label ?? "");
			P_6(new AiVisionStepLog
			{
				FlowStepIndex = P_4,
				SubStep = k,
				ActionSummary = text,
				Reason = aiVisionAction.Reason
			});
			list.Add(text);
			if (string.Equals(aiVisionAction.Action, "done", StringComparison.OrdinalIgnoreCase))
			{
				return new AiVisionRunResult
				{
					Success = true,
					Message = $"Xong sau {k} thao tác."
				};
			}
			await m_3466(P_0, aiVisionAction, uiElement, P_7);
			if (onActionRecorded != null && !string.Equals(aiVisionAction.Action, "wait", StringComparison.OrdinalIgnoreCase))
			{
				string text2 = (string.Equals(aiVisionAction.Action, "text", StringComparison.OrdinalIgnoreCase) ? AiVisionVariables.FindPlaceholderForValue(aiVisionAction.Text, P_5) : null);
				List<string> screenTexts = m_3461(list2);
				onActionRecorded(P_4, m_3462(aiVisionAction, uiElement, screenTexts, text2));
			}
			await Task.Delay(P_1.StepDelayMs, P_7);
		}
		return new AiVisionRunResult
		{
			Success = false,
			Message = $"AI chưa báo xong sau {P_3} thao tác."
		};
	}

	internal static async Task<(int X, int Y)> m_3453(IPage P_0, int P_1, int P_2, CancellationToken P_3)
	{
		_ = 1;
		try
		{
			int[] array = await P_0.EvaluateAsync<int[]>("([x, y]) => {\n            const el = document.elementFromPoint(x, y);\n            if (!el) return null;\n            if (el.tagName === 'HTML' || el.tagName === 'BODY') return null;\n            let r = el.getBoundingClientRect();\n            if (r.width >= window.innerWidth * 0.9 && r.height >= window.innerHeight * 0.9) return null;\n            el.scrollIntoView({ block: 'center', inline: 'nearest' });\n            r = el.getBoundingClientRect();\n            if (r.width === 0 || r.height === 0) return null;\n            return [Math.round(r.left + r.width / 2), Math.round(r.top + r.height / 2)];\n        }", new int[2] { P_1, P_2 });
			if (array != null && array.Length == 2)
			{
				await Task.Delay(250, P_3);
				return (X: array[0], Y: array[1]);
			}
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
		}
		return (X: P_1, Y: P_2);
	}

	private static async Task<string?> m_3454(IPage P_0, AiVisionCachedStep P_1, IReadOnlyDictionary<string, string> P_2, CancellationToken P_3, Action<string>? onDiagnostic = null, bool P_5 = true)
	{
		_ = 22;
		try
		{
			List<UiElement> list = null;
			List<string> screenTexts = P_1.ScreenTexts;
			if (screenTexts != null && screenTexts.Count > 0)
			{
				list = await m_3470(P_0);
				if (!m_3460(P_1.ScreenTexts, list, P_5, out string diagnostic))
				{
					if (diagnostic != null)
					{
						onDiagnostic?.Invoke(diagnostic);
					}
					return null;
				}
			}
			switch (P_1.Action)
			{
			case "tap":
				var (num5, num6) = await m_3453(P_0, P_1.X, P_1.Y, P_3);
				await P_0.Mouse.ClickAsync(num5, num6);
				return $"[Cache] Click ({num5}, {num6})";
			case "swipe":
				await P_0.Mouse.MoveAsync(P_1.X, P_1.Y);
				await P_0.Mouse.DownAsync();
				await P_0.Mouse.MoveAsync(P_1.X2, P_1.Y2, new MouseMoveOptions
				{
					Steps = 12
				});
				await P_0.Mouse.UpAsync();
				return $"[Cache] Kéo vuốt ({P_1.X},{P_1.Y}) → ({P_1.X2},{P_1.Y2})";
			case "text":
			{
				if (!string.IsNullOrWhiteSpace(P_1.ResourceId) || !string.IsNullOrWhiteSpace(P_1.ContentDesc) || !string.IsNullOrWhiteSpace(P_1.ElementText) || P_1.X != 0 || P_1.Y != 0)
				{
					if (string.IsNullOrWhiteSpace(P_1.ResourceId) && string.IsNullOrWhiteSpace(P_1.ContentDesc) && string.IsNullOrWhiteSpace(P_1.ElementText))
					{
						var (num, num2) = await m_3453(P_0, P_1.X, P_1.Y, P_3);
						await P_0.Mouse.ClickAsync(num, num2);
					}
					else
					{
						if (list == null)
						{
							list = await m_3470(P_0);
						}
						UiElement uiElement = m_3458(list, P_1);
						if (uiElement == null)
						{
							onDiagnostic?.Invoke($"Không tìm thấy ô nhập khớp (ResourceId=\"{P_1.ResourceId}\", ContentDesc=\"{P_1.ContentDesc}\", ElementText=\"{P_1.ElementText}\") trong trang hiện tại - dấu vết màn hình khớp nhưng danh tính ô nhập đã đánh dấu không còn khớp.");
							return null;
						}
						var (num3, num4) = await m_3453(P_0, uiElement.CenterX, uiElement.CenterY, P_3);
						await P_0.Mouse.ClickAsync(num3, num4);
					}
				}
				string text = ((P_1.Text.StartsWith("{{") && P_1.Text.EndsWith("}}")) ? AiVisionVariables.Substitute(P_1.Text, P_2) : P_1.Text);
				try
				{
					await P_0.Keyboard.PressAsync("Control+A");
					await P_0.Keyboard.PressAsync("Backspace");
					await P_0.Keyboard.PressAsync("Control+A");
					await P_0.Keyboard.PressAsync("Delete");
					await P_0.Keyboard.PressAsync("End");
					for (int k = 0; k < 60; k++)
					{
						await P_0.Keyboard.PressAsync("Backspace");
					}
					await P_0.Keyboard.PressAsync("Home");
					for (int k = 0; k < 60; k++)
					{
						await P_0.Keyboard.PressAsync("Delete");
					}
				}
				catch
				{
				}
				await P_0.Keyboard.TypeAsync(text);
				return "[Cache] Gõ chữ: \"" + text + "\"";
			}
			case "keyevent":
				await P_0.Keyboard.PressAsync(P_1.Text);
				return "[Cache] Phím: " + P_1.Text;
			case "navigate":
				await P_0.GotoAsync(P_1.Text);
				return "[Cache] Mở URL: " + P_1.Text;
			default:
				return "[Cache] Chờ";
			}
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
			return null;
		}
	}

	private static async Task<(int Index, AiVisionFlowStep Step)?> m_3455(IPage P_0, IReadOnlyList<AiVisionFlowStep> P_1, int P_2, CancellationToken P_3)
	{
		List<UiElement> list = await m_3470(P_0);
		int? num = null;
		int num2 = int.MaxValue;
		for (int k = 0; k < P_1.Count; k++)
		{
			AiVisionFlowStep aiVisionFlowStep = P_1[k];
			if (aiVisionFlowStep.IsMarked && aiVisionFlowStep.IsMarkedComplete && m_3457(aiVisionFlowStep, list))
			{
				int num3 = Math.Abs(k - P_2);
				if (num3 < num2)
				{
					num2 = num3;
					num = k;
				}
			}
		}
		if (num.HasValue)
		{
			return (num.Value, P_1[num.Value]);
		}
		return null;
	}

	private static bool m_3456(AiVisionFlowStep P_0)
	{
		List<string> screenTexts = P_0.ScreenTexts;
		if ((screenTexts == null || screenTexts.Count <= 0) && string.IsNullOrWhiteSpace(P_0.ResourceId) && string.IsNullOrWhiteSpace(P_0.ContentDesc) && string.IsNullOrWhiteSpace(P_0.ElementText))
		{
			return !string.IsNullOrWhiteSpace(P_0.DisambiguatorText);
		}
		return true;
	}

	private static bool m_3457(AiVisionFlowStep P_0, List<UiElement> P_1)
	{
		if (!m_3456(P_0))
		{
			return false;
		}
		List<string> screenTexts = P_0.ScreenTexts;
		if (screenTexts != null && screenTexts.Count > 0 && !m_3460(P_0.ScreenTexts, P_1, true, out string _))
		{
			return false;
		}
		if ((!string.IsNullOrWhiteSpace(P_0.ResourceId) || !string.IsNullOrWhiteSpace(P_0.ContentDesc) || !string.IsNullOrWhiteSpace(P_0.ElementText)) && m_3458(P_1, m_3463(P_0)) == null)
		{
			return false;
		}
		if (!string.IsNullOrWhiteSpace(P_0.DisambiguatorText) && !P_1.Any((UiElement uiElement) => string.Equals(uiElement.Text, P_0.DisambiguatorText, StringComparison.OrdinalIgnoreCase) && Math.Abs(uiElement.CenterX - P_0.DisambiguatorX) <= 60 && Math.Abs(uiElement.CenterY - P_0.DisambiguatorY) <= 60))
		{
			return false;
		}
		return true;
	}

	private static UiElement? m_3458(List<UiElement> P_0, AiVisionCachedStep P_1)
	{
		if (!string.IsNullOrWhiteSpace(P_1.ResourceId))
		{
			UiElement uiElement = m_3459(P_0.Where((UiElement uiElement4) => uiElement4.ResourceId == P_1.ResourceId), P_1.X, P_1.Y);
			if (uiElement != null)
			{
				return uiElement;
			}
		}
		if (!string.IsNullOrWhiteSpace(P_1.ContentDesc))
		{
			UiElement uiElement2 = m_3459(P_0.Where((UiElement uiElement4) => uiElement4.ContentDesc == P_1.ContentDesc), P_1.X, P_1.Y);
			if (uiElement2 != null)
			{
				return uiElement2;
			}
		}
		if (!string.IsNullOrWhiteSpace(P_1.ElementText))
		{
			UiElement uiElement3 = m_3459(P_0.Where((UiElement uiElement4) => uiElement4.Text == P_1.ElementText), P_1.X, P_1.Y);
			if (uiElement3 != null)
			{
				return uiElement3;
			}
		}
		return null;
	}

	private static UiElement? m_3459(IEnumerable<UiElement> P_0, int P_1, int P_2)
	{
		UiElement result = null;
		double num = double.MaxValue;
		foreach (UiElement item in P_0)
		{
			double num2 = Math.Sqrt(Math.Pow(item.CenterX - P_1, 2.0) + Math.Pow(item.CenterY - P_2, 2.0));
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	private static bool m_3460(List<string>? fingerprint, IReadOnlyList<UiElement> P_1, bool P_2, out string? diagnostic)
	{
		diagnostic = null;
		if (fingerprint == null || fingerprint.Count == 0)
		{
			return true;
		}
		HashSet<string> A = new HashSet<string>(from uiElement in P_1
			select uiElement.Text into value
			where !string.IsNullOrWhiteSpace(value)
			select value, StringComparer.OrdinalIgnoreCase);
		List<string> list = fingerprint.Where((string item) => !A.Contains(item)).ToList();
		if (list.Count == 0)
		{
			return true;
		}
		if (!P_2 && list.Count < fingerprint.Count - list.Count)
		{
			diagnostic = $"Thiếu {list.Count}/{fingerprint.Count} chữ dấu vết màn hình ({string.Join(", ", list)}) nhưng vẫn coi là khớp vì đa số đã khớp.";
			return true;
		}
		diagnostic = $"Chưa khớp dấu vết màn hình - thiếu {list.Count}/{fingerprint.Count} chữ: {string.Join(", ", list)}";
		return false;
	}

	private static List<string> m_3461(IReadOnlyList<UiElement> P_0)
	{
		return (from uiElement in P_0
			select uiElement.Text into value
			where !string.IsNullOrWhiteSpace(value)
			select value).Distinct().Take(3).ToList();
	}

	private static AiVisionFlowStep? m_3462(AiVisionAction action, UiElement? P_1, List<string> screenTexts, string? P_3)
	{
		string text = action.Action.ToLowerInvariant();
		AiVisionStepType? aiVisionStepType;
		if (text == "tap")
		{
			aiVisionStepType = AiVisionStepType.Tap;
		}
		else
		{
			aiVisionStepType = ((!(text == "text")) ? ((AiVisionStepType?)null) : new AiVisionStepType?(AiVisionStepType.Text));
		}
		AiVisionStepType? aiVisionStepType2 = aiVisionStepType;
		if (!aiVisionStepType2.HasValue)
		{
			return null;
		}
		return new AiVisionFlowStep
		{
			Type = aiVisionStepType2.Value,
			ResourceId = P_1?.ResourceId,
			ContentDesc = P_1?.ContentDesc,
			ElementText = P_1?.Text,
			ScreenTexts = screenTexts,
			X = action.X,
			Y = action.Y,
			Text = (P_3 ?? action.Text),
			IsMarkedComplete = true
		};
	}

	private static AiVisionCachedStep m_3463(AiVisionFlowStep P_0)
	{
		AiVisionCachedStep aiVisionCachedStep = new AiVisionCachedStep();
		AiVisionCachedStep aiVisionCachedStep2 = aiVisionCachedStep;
		aiVisionCachedStep2.Action = P_0.Type switch
		{
			AiVisionStepType.Tap => "tap", 
			AiVisionStepType.Swipe => "swipe", 
			AiVisionStepType.Text => "text", 
			AiVisionStepType.Scroll => "scroll", 
			AiVisionStepType.KeyPress => "keypress", 
			_ => "", 
		};
		aiVisionCachedStep.ResourceId = P_0.ResourceId;
		aiVisionCachedStep.ContentDesc = P_0.ContentDesc;
		aiVisionCachedStep.ElementText = P_0.ElementText;
		aiVisionCachedStep.ScreenTexts = P_0.ScreenTexts;
		aiVisionCachedStep.DisambiguatorText = P_0.DisambiguatorText;
		aiVisionCachedStep.DisambiguatorX = P_0.DisambiguatorX;
		aiVisionCachedStep.DisambiguatorY = P_0.DisambiguatorY;
		aiVisionCachedStep.Text = P_0.Text;
		aiVisionCachedStep.X = P_0.X;
		aiVisionCachedStep.Y = P_0.Y;
		aiVisionCachedStep.X2 = P_0.X2;
		aiVisionCachedStep.Y2 = P_0.Y2;
		return aiVisionCachedStep;
	}

	private static int m_3464(IReadOnlyList<AiVisionFlowStep> P_0, int P_1)
	{
		for (int k = P_1 + 1; k < P_0.Count; k++)
		{
			if (P_0[k].Type == AiVisionStepType.AiGoal)
			{
				return k;
			}
		}
		return -1;
	}

	private static UiElement? m_3465(AiVisionAction P_0, IReadOnlyList<UiElement> P_1, PageViewportSizeResult? viewport)
	{
		if (!P_0.Action.Equals("tap", StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		if (P_0.ElementIndex.HasValue && P_0.ElementIndex.Value >= 0 && P_0.ElementIndex.Value < P_1.Count)
		{
			UiElement uiElement = P_1[P_0.ElementIndex.Value];
			P_0.X = uiElement.CenterX;
			P_0.Y = uiElement.CenterY;
			return uiElement;
		}
		int num = viewport?.Width ?? 1280;
		int num2 = viewport?.Height ?? 800;
		P_0.X = P_0.X * num / 1000;
		P_0.Y = P_0.Y * num2 / 1000;
		return null;
	}

	private static async Task m_3466(IPage P_0, AiVisionAction P_1, UiElement? matchedElement, CancellationToken P_3)
	{
		switch (P_1.Action.ToLowerInvariant())
		{
		case "tap":
			(P_1.X, P_1.Y) = await m_3453(P_0, P_1.X, P_1.Y, P_3);
			await P_0.Mouse.ClickAsync(P_1.X, P_1.Y);
			break;
		case "text":
			await P_0.Keyboard.TypeAsync(P_1.Text);
			break;
		case "keyevent":
			await P_0.Keyboard.PressAsync(P_1.Text);
			break;
		case "navigate":
			await P_0.GotoAsync(P_1.Text);
			break;
		}
	}

	private static string m_3467(AiVisionAction P_0, string P_1)
	{
		return P_0.Action.ToLowerInvariant() switch
		{
			"tap" => string.IsNullOrEmpty(P_1) ? $"Click ({P_0.X}, {P_0.Y})" : $"Click \"{P_1}\" ({P_0.X}, {P_0.Y})", 
			"text" => "Gõ chữ: \"" + P_0.Text + "\"", 
			"keyevent" => "Phím: " + P_0.Text, 
			"navigate" => "Mở URL: " + P_0.Text, 
			"done" => "Hoàn thành", 
			_ => "Chờ", 
		};
	}

	private static async Task<byte[]> m_3468(IPage P_0, CancellationToken P_1)
	{
		byte[] array = await P_0.ScreenshotAsync(new PageScreenshotOptions
		{
			Type = ScreenshotType.Png
		});
		for (int k = 2; k <= 4; k++)
		{
			P_1.ThrowIfCancellationRequested();
			await Task.Delay(350, P_1);
			byte[] array2 = await P_0.ScreenshotAsync(new PageScreenshotOptions
			{
				Type = ScreenshotType.Png
			});
			if (((ReadOnlySpan<byte>)array2.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)array))
			{
				return array2;
			}
			array = array2;
		}
		return array;
	}

	private static string m_3469(string P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return "";
		}
		Regex[] array = m_3445;
		for (int k = 0; k < array.Length; k++)
		{
			if (array[k].IsMatch(P_0))
			{
				return "";
			}
		}
		return P_0;
	}

	internal static async Task<List<UiElement>> m_3470(IPage P_0)
	{
		try
		{
			JsonElement jsonElement = await P_0.EvaluateAsync<JsonElement>("() => {\n                const sel = 'a, button, input, textarea, select, [role], [onclick], [contenteditable=\"true\"]';\n                const nodes = Array.from(document.querySelectorAll(sel));\n                const out = [];\n                for (const el of nodes) {\n                    const rect = el.getBoundingClientRect();\n                    if (rect.width <= 0 || rect.height <= 0) continue;\n                    if (rect.bottom < 0 || rect.right < 0 || rect.top > window.innerHeight || rect.left > window.innerWidth) continue;\n                    const style = window.getComputedStyle(el);\n                    if (style.visibility === 'hidden' || style.display === 'none') continue;\n                    let text = (el.innerText || el.value || el.placeholder || '').toString().trim().slice(0, 80);\n                    let ariaLabel = (el.getAttribute('aria-label') || '').trim();\n                    let id = el.id || '';\n                    out.push({\n                        tag: el.tagName.toLowerCase(),\n                        text: text,\n                        ariaLabel: ariaLabel,\n                        id: id,\n                        left: Math.round(rect.left), top: Math.round(rect.top),\n                        right: Math.round(rect.right), bottom: Math.round(rect.bottom)\n                    });\n                    if (out.length >= 60) break;\n                }\n                return out;\n            }");
			List<UiElement> list = new List<UiElement>();
			foreach (JsonElement item in jsonElement.EnumerateArray())
			{
				list.Add(new UiElement
				{
					ClassName = (item.GetProperty("tag").GetString() ?? ""),
					Text = (item.GetProperty("text").GetString() ?? ""),
					ContentDesc = (item.GetProperty("ariaLabel").GetString() ?? ""),
					ResourceId = m_3469(item.GetProperty("id").GetString() ?? ""),
					Left = item.GetProperty("left").GetInt32(),
					Top = item.GetProperty("top").GetInt32(),
					Right = item.GetProperty("right").GetInt32(),
					Bottom = item.GetProperty("bottom").GetInt32()
				});
			}
			return list;
		}
		catch
		{
			return new List<UiElement>();
		}
	}

	private static string m_3471(Exception P_0)
	{
		List<string> list = new List<string> { P_0.Message };
		for (Exception innerException = P_0.InnerException; innerException != null; innerException = innerException.InnerException)
		{
			list.Add(innerException.Message);
		}
		return string.Join(" → ", list);
	}
}
