using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class GroupSpamSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5591
	{
		public static readonly m_5591 A = new m_5591();

		public static Func<string, bool> m_5592;

		internal bool m_5593(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private string A = "InputLinks";

	[CompilerGenerated]
	private List<string> m_5586 = new List<string>();

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private int m_5587 = 3;

	[CompilerGenerated]
	private string B = "Scroll";

	[CompilerGenerated]
	private int m_5588 = 5;

	[CompilerGenerated]
	private int m_5589 = 15;

	[CompilerGenerated]
	private int b = 20;

	[CompilerGenerated]
	private int C = 60;

	[CompilerGenerated]
	private List<string> m_5590 = new List<string> { "Hay quá ạ", "Cảm ơn admin đã chia sẻ", "Đúng cái mình cần", "Hữu ích quá", "\ud83d\udc4d\ud83d\udc4d\ud83d\udc4d" };

	public string GroupSource
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public List<string> GroupLinks
	{
		[CompilerGenerated]
		get
		{
			return m_5586;
		}
		[CompilerGenerated]
		set
		{
			m_5586 = value;
		}
	}

	public string SearchKeyword
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MaxGroupsToJoin
	{
		[CompilerGenerated]
		get
		{
			return m_5587;
		}
		[CompilerGenerated]
		set
		{
			m_5587 = value;
		}
	}

	public string FindMode
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MinMinutes
	{
		[CompilerGenerated]
		get
		{
			return m_5588;
		}
		[CompilerGenerated]
		set
		{
			m_5588 = value;
		}
	}

	public int MaxMinutes
	{
		[CompilerGenerated]
		get
		{
			return m_5589;
		}
		[CompilerGenerated]
		set
		{
			m_5589 = value;
		}
	}

	public int MinCommentSpacingSeconds
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int MaxCommentSpacingSeconds
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public List<string> CommentTexts
	{
		[CompilerGenerated]
		get
		{
			return m_5590;
		}
		[CompilerGenerated]
		set
		{
			m_5590 = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static GroupSpamSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new GroupSpamSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<GroupSpamSettings>(json) ?? new GroupSpamSettings();
		}
		catch (JsonException)
		{
			return new GroupSpamSettings();
		}
	}

	public int PickDurationMinutes()
	{
		if (MinMinutes < MaxMinutes)
		{
			return Random.Shared.Next(MinMinutes, MaxMinutes + 1);
		}
		return MinMinutes;
	}

	public int PickCommentSpacingSeconds()
	{
		if (MinCommentSpacingSeconds < MaxCommentSpacingSeconds)
		{
			return Random.Shared.Next(MinCommentSpacingSeconds, MaxCommentSpacingSeconds + 1);
		}
		return MinCommentSpacingSeconds;
	}

	public string? PickCommentText()
	{
		List<string> list = CommentTexts.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}
}
