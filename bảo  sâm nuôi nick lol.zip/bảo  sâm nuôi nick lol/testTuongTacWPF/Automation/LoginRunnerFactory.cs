using System;

namespace testTuongTacWPF.Automation;

public static class LoginRunnerFactory
{
	public static ILoginRunner GetRunner(string platform, string packageType = "Katana", Action<string>? onStatusUpdate = null)
	{
		if (!(platform == "Chrome"))
		{
			if (platform == "Phone")
			{
				return new PhoneLoginRunner(packageType, onStatusUpdate);
			}
			return new PhoneLoginRunner(packageType, onStatusUpdate);
		}
		return new ChromeLoginRunner();
	}
}
