using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public static class CliProxyApiController
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3867
	{
		public static readonly m_3867 A = new m_3867();

		public static Func<string, string> m_3872;

		public static DataReceivedEventHandler m_3873;

		public static DataReceivedEventHandler a;

		internal string m_3874(string P_0)
		{
			return Path.GetFileNameWithoutExtension(P_0);
		}

		internal void m_3875(object P_0, DataReceivedEventArgs P_1)
		{
		}

		internal void m_3876(object P_0, DataReceivedEventArgs P_1)
		{
		}
	}

	[CompilerGenerated]
	private sealed class m_3868
	{
		public StringBuilder A;

		internal void m_3877(object P_0, DataReceivedEventArgs P_1)
		{
			if (P_1.Data != null)
			{
				A.AppendLine(P_1.Data);
			}
		}

		internal void a(object P_0, DataReceivedEventArgs P_1)
		{
			if (P_1.Data != null)
			{
				A.AppendLine(P_1.Data);
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_3869
	{
		public string A;

		internal string m_3878(string P_0)
		{
			if (!P_0.StartsWith(A + "-", StringComparison.OrdinalIgnoreCase))
			{
				return P_0;
			}
			return P_0.Substring(A.Length + 1);
		}
	}

	private static readonly string A = Path.Combine(AppContext.BaseDirectory, "setup", "platform-tools");

	private static readonly string a = Path.Combine(AppContext.BaseDirectory, "dulieu", "cliproxyapi");

	public const int Port = 8391;

	private static Process? m_3859;

	private static bool m_3860;

	private static string? B;

	public static string ExePath => Path.Combine(A, "cli-proxy-api.exe");

	public static string LocalChatEndpointUrl => $"http://127.0.0.1:{8391}/v1/chat/completions";

	public static bool IsExeAvailable => File.Exists(ExePath);

	public static bool IsServerRunning
	{
		get
		{
			Process process = m_3859;
			if (process != null)
			{
				return !process.HasExited;
			}
			return false;
		}
	}

	[SpecialName]
	private static string m_3861()
	{
		return Path.Combine(a, "config.yaml");
	}

	[SpecialName]
	private static string m_3862()
	{
		return Path.Combine(a, "auth");
	}

	[SpecialName]
	private static string m_3863()
	{
		return Path.Combine(a, "local_api_key.txt");
	}

	public static string GetLocalApiKey()
	{
		if (B != null)
		{
			return B;
		}
		Directory.CreateDirectory(a);
		if (File.Exists(m_3863()))
		{
			string value = File.ReadAllText(m_3863()).Trim();
			if (!string.IsNullOrWhiteSpace(value))
			{
				B = value;
				return B;
			}
		}
		B = "fbp-" + Convert.ToHexString(RandomNumberGenerator.GetBytes(24)).ToLowerInvariant();
		File.WriteAllText(m_3863(), B);
		return B;
	}

	private static void b()
	{
		Directory.CreateDirectory(a);
		Directory.CreateDirectory(m_3862());
		string localApiKey = GetLocalApiKey();
		string contents = "host: \"127.0.0.1\"\n" + $"port: {8391}\n" + "auth-dir: \"" + m_3862().Replace("\\", "\\\\") + "\"\napi-keys:\n  - " + localApiKey + "\n";
		File.WriteAllText(m_3861(), contents);
	}

	private static async Task<(bool Success, string Message)> m_3864(string P_0, CancellationToken P_1)
	{
		if (!IsExeAvailable)
		{
			return (Success: false, Message: "Thiếu file cần thiết cho mục \"AI Đăng Nhập Trực Tiếp\" - liên hệ hỗ trợ.");
		}
		b();
		C();
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = ExePath,
			Arguments = $"-{P_0}-login -config \"{m_3861()}\"",
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true,
			WorkingDirectory = CliProxyApiController.A
		};
		using Process process = new Process
		{
			StartInfo = startInfo
		};
		StringBuilder A = new StringBuilder();
		process.OutputDataReceived += (object obj2, DataReceivedEventArgs e) =>
		{
			if (e.Data != null)
			{
				A.AppendLine(e.Data);
			}
		};
		process.ErrorDataReceived += (object obj2, DataReceivedEventArgs e) =>
		{
			if (e.Data != null)
			{
				A.AppendLine(e.Data);
			}
		};
		process.Start();
		process.BeginOutputReadLine();
		process.BeginErrorReadLine();
		try
		{
			await process.WaitForExitAsync(P_1);
		}
		catch (OperationCanceledException)
		{
			try
			{
				process.Kill(entireProcessTree: true);
			}
			catch
			{
			}
			return (Success: false, Message: "Đã huỷ đăng nhập.");
		}
		if (process.ExitCode != 0)
		{
			return (Success: false, Message: $"Đăng nhập thất bại (mã {process.ExitCode}):\n{A}");
		}
		return (Success: true, Message: string.IsNullOrWhiteSpace(A.ToString()) ? "Đăng nhập thành công." : A.ToString().Trim());
	}

	private static void C()
	{
		try
		{
			Process process = m_3859;
			int? num = ((process != null && !process.HasExited) ? new int?(m_3859.Id) : ((int?)null));
			Process[] processesByName = Process.GetProcessesByName("cli-proxy-api");
			foreach (Process process2 in processesByName)
			{
				try
				{
					if (!num.HasValue || process2.Id != num.Value)
					{
						process2.Kill(entireProcessTree: true);
					}
				}
				catch
				{
				}
				finally
				{
					process2.Dispose();
				}
			}
		}
		catch
		{
		}
	}

	public static Task<(bool Success, string Message)> LoginAntigravityAsync(CancellationToken cancellationToken)
	{
		return m_3864("antigravity", cancellationToken);
	}

	public static Task<(bool Success, string Message)> LoginClaudeAsync(CancellationToken cancellationToken)
	{
		return m_3864("claude", cancellationToken);
	}

	private static List<string> m_3865(string P_0)
	{
		try
		{
			if (!Directory.Exists(m_3862()))
			{
				return new List<string>();
			}
			return (from path in Directory.GetFiles(m_3862(), P_0 + "-*.json")
				select Path.GetFileNameWithoutExtension(path) into text
				select (!text.StartsWith(P_0 + "-", StringComparison.OrdinalIgnoreCase)) ? text : text.Substring(P_0.Length + 1)).ToList();
		}
		catch
		{
			return new List<string>();
		}
	}

	public static List<string> ListLoggedInAccounts()
	{
		return m_3865("antigravity");
	}

	public static List<string> ListClaudeAccounts()
	{
		return m_3865("claude");
	}

	private static bool m_3866(string P_0, string P_1)
	{
		try
		{
			string path = Path.Combine(m_3862(), P_0 + "-" + P_1 + ".json");
			if (!File.Exists(path))
			{
				return false;
			}
			File.Delete(path);
			return true;
		}
		catch
		{
			return false;
		}
	}

	public static bool LogoutGoogleAccount(string account)
	{
		return m_3866("antigravity", account);
	}

	public static bool LogoutClaudeAccount(string account)
	{
		return m_3866("claude", account);
	}

	public static async Task<List<string>> FetchAvailableModelsAsync(CancellationToken cancellationToken)
	{
		List<string> list = new List<string>();
		try
		{
			await EnsureServerReadyAsync(cancellationToken);
			using HttpClient httpClient = new HttpClient
			{
				Timeout = TimeSpan.FromSeconds(10L)
			};
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, $"http://127.0.0.1:{8391}/v1/models");
			httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", GetLocalApiKey());
			using HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(httpRequestMessage, cancellationToken);
			string json = await httpResponseMessage.Content.ReadAsStringAsync(cancellationToken);
			if (!httpResponseMessage.IsSuccessStatusCode)
			{
				return list;
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(json);
			if (jsonDocument.RootElement.TryGetProperty("data", out var value) && value.ValueKind == JsonValueKind.Array)
			{
				foreach (JsonElement item in value.EnumerateArray())
				{
					if (item.TryGetProperty("id", out var value2) && value2.ValueKind == JsonValueKind.String)
					{
						string text = value2.GetString();
						if (!string.IsNullOrWhiteSpace(text))
						{
							list.Add(text);
						}
					}
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public static async Task EnsureServerReadyAsync(CancellationToken cancellationToken)
	{
		if (!IsExeAvailable)
		{
			return;
		}
		if (!IsServerRunning)
		{
			b();
			m_3860 = false;
			m_3859 = Process.Start(new ProcessStartInfo
			{
				FileName = ExePath,
				Arguments = "-config \"" + m_3861() + "\"",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				CreateNoWindow = true,
				WorkingDirectory = A
			});
			if (m_3859 == null)
			{
				return;
			}
			m_3859.OutputDataReceived += delegate
			{
			};
			m_3859.ErrorDataReceived += delegate
			{
			};
			m_3859.BeginOutputReadLine();
			m_3859.BeginErrorReadLine();
		}
		if (m_3860)
		{
			return;
		}
		for (int num = 0; num < 30; num++)
		{
			cancellationToken.ThrowIfCancellationRequested();
			try
			{
				using TcpClient tcpClient = new TcpClient();
				await tcpClient.ConnectAsync("127.0.0.1", 8391, cancellationToken);
				m_3860 = true;
				break;
			}
			catch
			{
				await Task.Delay(300, cancellationToken);
			}
		}
	}

	public static void StopServer()
	{
		try
		{
			Process process = m_3859;
			if (process != null && !process.HasExited)
			{
				m_3859.Kill(entireProcessTree: true);
			}
		}
		catch
		{
		}
		m_3859 = null;
		m_3860 = false;
	}
}
