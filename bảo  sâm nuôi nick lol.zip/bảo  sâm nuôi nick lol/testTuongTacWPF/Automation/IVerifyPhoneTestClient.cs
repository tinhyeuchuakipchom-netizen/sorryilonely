using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public interface IVerifyPhoneTestClient
{
	Task<string> GetNewPhoneNumberAsync(CancellationToken ct = default(CancellationToken));

	Task<string?> TryGetOtpAsync();
}
