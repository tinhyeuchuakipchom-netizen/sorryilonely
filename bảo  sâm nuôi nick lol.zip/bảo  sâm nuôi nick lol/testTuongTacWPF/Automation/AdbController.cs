using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;
using A;

namespace testTuongTacWPF.Automation;

public static class AdbController
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_2687
	{
		public static readonly m_2687 A = new m_2687();

		public static Func<char, bool> m_2690;

		public static Func<string, bool> m_2691;

		public static Func<string, bool> a;

		public static Func<string, bool> B;

		public static Func<string, bool> b;

		internal bool m_2692(char P_0)
		{
			return P_0 > '\u007f';
		}

		internal bool m_2693(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_2694(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_2695(string P_0)
		{
			return P_0.Length > 0;
		}

		internal bool m_2696(string P_0)
		{
			return P_0.Length > 0;
		}
	}

	[CompilerGenerated]
	private sealed class m_2688
	{
		public string A;

		internal bool m_2697(string P_0)
		{
			return string.Equals(P_0.TrimEnd(new char[2] { '\\', '/' }), A.TrimEnd(new char[2] { '\\', '/' }), StringComparison.OrdinalIgnoreCase);
		}

		internal bool a(string P_0)
		{
			return string.Equals(P_0.TrimEnd(new char[2] { '\\', '/' }), A.TrimEnd(new char[2] { '\\', '/' }), StringComparison.OrdinalIgnoreCase);
		}
	}

	public static readonly string AdbExePath;

	private const string A = "/sdcard/fastbox_ui_dump.xml";

	private const string a = "com.android.adbkeyboard";

	private const string B = "com.android.adbkeyboard/.AdbIME";

	private static readonly HashSet<string> m_2678;

	private static readonly SemaphoreSlim m_2679;

	private static readonly string[] m_2680;

	private static string m_2681()
	{
		string[] array = new string[5]
		{
			Path.Combine(AppContext.BaseDirectory, "setup", "platform-tools", "adb.exe"),
			Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "setup", "platform-tools", "adb.exe"),
			Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "setup", "platform-tools", "adb.exe")),
			null,
			null
		};
		InlineArray7<string> buffer = default;
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 0) = AppContext.BaseDirectory;
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 1) = "..";
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 2) = "..";
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 3) = "..";
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 4) = "setup";
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 5) = "platform-tools";
		global::A.H.a<InlineArray7<string>, string>(ref buffer, 6) = "adb.exe";
		array[3] = Path.Combine(global::A.H.m_6821<InlineArray7<string>, string>(in buffer, 7));
		array[4] = "c:\\Users\\Admin\\Documents\\GitHub\\test-tuong-tac\\testTuongTacWPF\\setup\\platform-tools\\adb.exe";
		string[] array2 = array;
		string[] array3 = array2;
		foreach (string path in array3)
		{
			if (File.Exists(path))
			{
				return Path.GetFullPath(path);
			}
		}
		return array2[0];
	}

	public static void EnsureAdbInEnvironmentPath()
	{
		try
		{
			string A = Path.Combine(AppContext.BaseDirectory, "setup", "platform-tools");
			if (Directory.Exists(A))
			{
				string text = Environment.GetEnvironmentVariable("PATH", EnvironmentVariableTarget.Process) ?? "";
				if (!text.Split(';', StringSplitOptions.RemoveEmptyEntries).Any((string P_0) => string.Equals(P_0.TrimEnd(new char[2] { '\\', '/' }), A.TrimEnd(new char[2] { '\\', '/' }), StringComparison.OrdinalIgnoreCase)))
				{
					Environment.SetEnvironmentVariable("PATH", A + ";" + text, EnvironmentVariableTarget.Process);
				}
				string text2 = Environment.GetEnvironmentVariable("PATH", EnvironmentVariableTarget.User) ?? "";
				if (!text2.Split(';', StringSplitOptions.RemoveEmptyEntries).Any((string P_0) => string.Equals(P_0.TrimEnd(new char[2] { '\\', '/' }), A.TrimEnd(new char[2] { '\\', '/' }), StringComparison.OrdinalIgnoreCase)))
				{
					string value = (string.IsNullOrEmpty(text2) ? A : (text2.TrimEnd(';') + ";" + A));
					Environment.SetEnvironmentVariable("PATH", value, EnvironmentVariableTarget.User);
				}
			}
		}
		catch (Exception)
		{
		}
	}

	static AdbController()
	{
		AdbExePath = m_2681();
		m_2678 = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		m_2679 = new SemaphoreSlim(1, 1);
		m_2680 = new string[19]
		{
			"android.permission.READ_CONTACTS", "android.permission.WRITE_CONTACTS", "android.permission.GET_ACCOUNTS", "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_AUDIO",
			"android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.POST_NOTIFICATIONS", "android.permission.READ_PHONE_STATE", "android.permission.READ_PHONE_NUMBERS", "android.permission.CALL_PHONE", "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS"
		};
		EnsureAdbInEnvironmentPath();
	}

	public static async Task<byte[]> ScreenshotAsync(string deviceSerial, CancellationToken cancellationToken)
	{
		using Process process = m_2686("-s " + deviceSerial + " exec-out screencap -p");
		using MemoryStream memoryStream = new MemoryStream();
		Task task = process.StandardOutput.BaseStream.CopyToAsync(memoryStream, cancellationToken);
		Task task2 = process.StandardError.ReadToEndAsync(cancellationToken);
		InlineArray2<Task> buffer = default;
		global::A.H.a<InlineArray2<Task>, Task>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task>, Task>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task>, Task>(in buffer, 2));
		await process.WaitForExitAsync(cancellationToken);
		byte[] array = memoryStream.ToArray();
		if (array.Length == 0)
		{
			throw new InvalidOperationException("Không chụp được màn hình máy " + deviceSerial + " (adb trả về rỗng - kiểm tra máy còn kết nối không).");
		}
		return array;
	}

	public static async Task<(int Width, int Height)> GetScreenSizeAsync(string deviceSerial, CancellationToken cancellationToken)
	{
		using Process process = m_2686("-s " + deviceSerial + " shell wm size");
		Task<string> task = process.StandardOutput.ReadToEndAsync(cancellationToken);
		Task<string> task2 = process.StandardError.ReadToEndAsync(cancellationToken);
		InlineArray2<Task<string>> buffer = default;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
		await process.WaitForExitAsync(cancellationToken);
		string result = task.Result;
		Match match = Regex.Match(result, "Override size:\\s*(\\d+)x(\\d+)");
		Match match2 = (match.Success ? match : Regex.Match(result, "Physical size:\\s*(\\d+)x(\\d+)"));
		if (!match2.Success)
		{
			throw new InvalidOperationException($"Không đọc được độ phân giải màn hình máy {deviceSerial} (adb trả về: {result.Trim()}).");
		}
		return (Width: int.Parse(match2.Groups[1].Value), Height: int.Parse(match2.Groups[2].Value));
	}

	public static async Task<List<UiElement>> DumpUiElementsAsync(string deviceSerial, CancellationToken cancellationToken)
	{
		_ = 9;
		try
		{
			using CancellationTokenSource cancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
			cancellationTokenSource.CancelAfter(TimeSpan.FromSeconds(4.0));
			bool flag = false;
			using (Process process = m_2686($"-s {deviceSerial} shell \"rm -f {"/sdcard/fastbox_ui_dump.xml"} && uiautomator dump {"/sdcard/fastbox_ui_dump.xml"}\""))
			{
				Task<string> task = process.StandardOutput.ReadToEndAsync(cancellationTokenSource.Token);
				Task<string> task2 = process.StandardError.ReadToEndAsync(cancellationTokenSource.Token);
				try
				{
					InlineArray2<Task<string>> buffer = default;
					global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
					global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
					await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
					await process.WaitForExitAsync(cancellationTokenSource.Token);
					flag = process.ExitCode == 0 && task.Result.Contains("UI hierchary dumped to");
				}
				catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
				{
					try
					{
						process.Kill();
					}
					catch
					{
					}
					return new List<UiElement>();
				}
				if (!flag)
				{
					string text = (task2.IsCompletedSuccessfully ? task2.Result : "");
					if (text.Contains("already registered") || text.Contains("IllegalStateException"))
					{
						try
						{
							await RunShellAsync(deviceSerial, "pkill -f uiautomator || killall -9 uiautomator", cancellationToken);
						}
						catch
						{
						}
						await Task.Delay(500, cancellationToken);
						flag = (await RunShellCaptureAsync(deviceSerial, "uiautomator dump /sdcard/fastbox_ui_dump.xml", cancellationToken)).Contains("UI hierchary dumped to");
					}
					else if (text.Contains("could not get idle state") || !flag)
					{
						await RunShellAsync(deviceSerial, "input tap 450 800", cancellationToken);
						await Task.Delay(500, cancellationToken);
						flag = (await RunShellCaptureAsync(deviceSerial, "uiautomator dump /sdcard/fastbox_ui_dump.xml", cancellationToken)).Contains("UI hierchary dumped to");
					}
				}
			}
			if (!flag)
			{
				return new List<UiElement>();
			}
			using Process process2 = m_2686("-s " + deviceSerial + " exec-out cat /sdcard/fastbox_ui_dump.xml");
			using MemoryStream memoryStream = new MemoryStream();
			Task task3 = process2.StandardOutput.BaseStream.CopyToAsync(memoryStream, cancellationToken);
			Task task4 = process2.StandardError.ReadToEndAsync(cancellationToken);
			InlineArray2<Task> buffer2 = default;
			global::A.H.a<InlineArray2<Task>, Task>(ref buffer2, 0) = task3;
			global::A.H.a<InlineArray2<Task>, Task>(ref buffer2, 1) = task4;
			await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task>, Task>(in buffer2, 2));
			await process2.WaitForExitAsync(cancellationToken);
			return m_2682(Encoding.UTF8.GetString(memoryStream.ToArray()));
		}
		catch
		{
			return new List<UiElement>();
		}
	}

	private static List<UiElement> m_2682(string P_0)
	{
		List<UiElement> list = new List<UiElement>();
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return list;
		}
		try
		{
			foreach (XElement item in XDocument.Parse(P_0).Descendants("node"))
			{
				string obj = item.Attribute("clickable")?.Value ?? "false";
				string text = item.Attribute("class")?.Value ?? "";
				string text2 = item.Attribute("text")?.Value ?? "";
				string text3 = item.Attribute("content-desc")?.Value ?? "";
				string resourceId = item.Attribute("resource-id")?.Value ?? "";
				bool flag = !string.IsNullOrWhiteSpace(text2) || !string.IsNullOrWhiteSpace(text3);
				if (!((obj == "true" || text.Contains("EditText")) | flag))
				{
					continue;
				}
				Match match = Regex.Match(item.Attribute("bounds")?.Value ?? "", "\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]");
				if (!match.Success)
				{
					continue;
				}
				int num = int.Parse(match.Groups[1].Value);
				int num2 = int.Parse(match.Groups[2].Value);
				int num3 = int.Parse(match.Groups[3].Value);
				int num4 = int.Parse(match.Groups[4].Value);
				if (num3 > num && num4 > num2)
				{
					list.Add(new UiElement
					{
						Text = text2,
						ContentDesc = text3,
						ResourceId = resourceId,
						ClassName = text,
						Focused = (item.Attribute("focused")?.Value == "true"),
						Enabled = (item.Attribute("enabled")?.Value != "false"),
						Left = num,
						Top = num2,
						Right = num3,
						Bottom = num4
					});
					if (list.Count >= 300)
					{
						break;
					}
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public static Task TapAsync(string deviceSerial, int x, int y, CancellationToken cancellationToken)
	{
		return RunShellAsync(deviceSerial, $"input tap {x} {y}", cancellationToken);
	}

	public static Task SwipeAsync(string deviceSerial, int x1, int y1, int x2, int y2, int durationMs, CancellationToken cancellationToken)
	{
		return RunShellAsync(deviceSerial, $"input swipe {x1} {y1} {x2} {y2} {durationMs}", cancellationToken);
	}

	public static Task KeyEventAsync(string deviceSerial, string keycode, CancellationToken cancellationToken)
	{
		return RunShellAsync(deviceSerial, "input keyevent " + keycode, cancellationToken);
	}

	private static string m_2683()
	{
		string path = Path.GetDirectoryName(AdbExePath) ?? "";
		string[] array = new string[7]
		{
			Path.Combine(path, "ADBKeyboard.apk"),
			Path.Combine(AppContext.BaseDirectory, "setup", "platform-tools", "ADBKeyboard.apk"),
			Path.Combine(AppContext.BaseDirectory, "dulieu", "apk", "ADBKeyboard.apk"),
			Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "setup", "platform-tools", "ADBKeyboard.apk"),
			Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dulieu", "apk", "ADBKeyboard.apk"),
			Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "setup", "platform-tools", "ADBKeyboard.apk")),
			Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "dulieu", "apk", "ADBKeyboard.apk"))
		};
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (File.Exists(text))
			{
				return text;
			}
		}
		return array[0];
	}

	private static async Task m_2684(string P_0, CancellationToken P_1)
	{
		if (m_2678.Contains(P_0))
		{
			return;
		}
		await m_2679.WaitAsync(P_1);
		try
		{
			if (m_2678.Contains(P_0))
			{
				return;
			}
			bool flag = (await RunShellCaptureAsync(P_0, "pm list packages | grep \"com.android.adbkeyboard\"", P_1)).Contains("com.android.adbkeyboard", StringComparison.OrdinalIgnoreCase);
			if (!flag)
			{
				string text = m_2683();
				if (!File.Exists(text))
				{
					throw new InvalidOperationException("Máy " + P_0 + " chưa cài ADB Keyboard. Vui lòng vào Danh sách Phone → chọn máy → bấm \"Cài lại các app\" để cài.");
				}
				try
				{
					await InstallApkAsync(P_0, text, P_1);
				}
				catch
				{
				}
				for (int l = 1; l <= 20; l++)
				{
					await Task.Delay(500, P_1);
					flag = (await RunShellCaptureAsync(P_0, "pm list packages | grep \"com.android.adbkeyboard\"", P_1)).Contains("com.android.adbkeyboard", StringComparison.OrdinalIgnoreCase);
					if (flag)
					{
						break;
					}
				}
				if (!flag)
				{
					throw new InvalidOperationException("Máy " + P_0 + " cài ADB Keyboard không thành công. Vui lòng vào Danh sách Phone → chọn máy → bấm \"Cài lại các app\" để cài thủ công.");
				}
			}
			string shellCommand = "settings put secure enabled_input_methods \"com.android.adbkeyboard/.AdbIME:com.android.inputmethod.pinyin/.InputService\" && settings put secure default_input_method com.android.adbkeyboard/.AdbIME";
			await RunShellCaptureAsync(P_0, shellCommand, P_1);
			await RunShellCaptureAsync(P_0, "ime enable com.android.adbkeyboard/.AdbIME", P_1);
			await RunShellCaptureAsync(P_0, "ime set com.android.adbkeyboard/.AdbIME", P_1);
			await Task.Delay(3000, P_1);
			string text2 = await RunShellCaptureAsync(P_0, "settings get secure default_input_method", P_1);
			if (text2.Trim() != "com.android.adbkeyboard/.AdbIME")
			{
				throw new InvalidOperationException($"Không thể đặt {"com.android.adbkeyboard/.AdbIME"} làm bàn phím mặc định trên máy {P_0} (hiện là: {text2.Trim()}).");
			}
			m_2678.Add(P_0);
		}
		finally
		{
			m_2679.Release();
		}
	}

	public static async Task ClearTextAsync(string deviceSerial, int deleteCount = 60, CancellationToken cancellationToken = default(CancellationToken))
	{
		try
		{
			await RunShellAsync(deviceSerial, "am broadcast -a ADB_CLEAR_TEXT", cancellationToken);
		}
		catch
		{
		}
		List<string> list = new List<string> { "288", "67", "123" };
		list.AddRange(Enumerable.Repeat("67", deleteCount));
		list.Add("122");
		list.AddRange(Enumerable.Repeat("112", deleteCount));
		string text = string.Join(" ", list);
		await RunShellAsync(deviceSerial, "input keyevent " + text, cancellationToken);
	}

	public static async Task HideKeyboardIfShownAsync(string deviceSerial, CancellationToken cancellationToken = default(CancellationToken))
	{
		_ = 2;
		try
		{
			if ((await RunShellCaptureAsync(deviceSerial, "dumpsys input_method | grep mInputShown", cancellationToken)).Contains("mInputShown=true", StringComparison.OrdinalIgnoreCase))
			{
				await RunShellAsync(deviceSerial, "input keyevent 4", cancellationToken);
				await Task.Delay(300, cancellationToken);
			}
		}
		catch
		{
		}
	}

	public static async Task<string> GetCurrentFocusedActivityAsync(string deviceSerial, CancellationToken cancellationToken = default(CancellationToken))
	{
		try
		{
			return await RunShellCaptureAsync(deviceSerial, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", cancellationToken);
		}
		catch
		{
			return string.Empty;
		}
	}

	public static async Task InputTextAsync(string deviceSerial, string text, CancellationToken cancellationToken)
	{
		await ClearTextAsync(deviceSerial, 50, cancellationToken);
		await Task.Delay(100, cancellationToken);
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		await m_2684(deviceSerial, cancellationToken);
		try
		{
			await m_2685(deviceSerial, text, cancellationToken);
		}
		catch
		{
			if (text.Any((char P_0) => P_0 > '\u007f'))
			{
				await RunShellAsync(deviceSerial, "am broadcast -a ADB_INPUT_TEXT --es msg \"" + text.Replace("\"", "\\\"") + "\"", cancellationToken);
				return;
			}
			string text2 = text.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("'", "\\'")
				.Replace("(", "\\(")
				.Replace(")", "\\)")
				.Replace("&", "\\&")
				.Replace(";", "\\;")
				.Replace(" ", "%s");
			await RunShellAsync(deviceSerial, "input text \"" + text2 + "\"", cancellationToken);
		}
	}

	private static async Task m_2685(string P_0, string P_1, CancellationToken P_2)
	{
		if (string.IsNullOrEmpty(P_1))
		{
			return;
		}
		string value = Convert.ToBase64String(Encoding.UTF8.GetBytes(P_1));
		using Process process = new Process();
		process.StartInfo = new ProcessStartInfo
		{
			FileName = AdbExePath,
			Arguments = $"-s {P_0} shell am broadcast -a ADB_INPUT_B64 --es msg \"{value}\"",
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			UseShellExecute = false,
			CreateNoWindow = true
		};
		process.Start();
		Task<string> task = process.StandardOutput.ReadToEndAsync(P_2);
		Task<string> task2 = process.StandardError.ReadToEndAsync(P_2);
		InlineArray2<Task<string>> buffer = default;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
		await process.WaitForExitAsync(P_2);
		string text = task.Result.Trim();
		string text2 = task2.Result.Trim();
		string text3 = string.Join(" | ", new string[2] { text, text2 }.Where((string text4) => text4.Length > 0));
		if (text3.Contains("not found", StringComparison.OrdinalIgnoreCase) || text3.Contains("result=-1", StringComparison.OrdinalIgnoreCase) || (!text.Contains("Broadcasting:", StringComparison.OrdinalIgnoreCase) && !text.Contains("result=0", StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(text)))
		{
			throw new InvalidOperationException("ADB Keyboard không khả dụng trên máy " + P_0 + ". Cài app ADB Keyboard hoặc dùng text ASCII thuần.");
		}
	}

	public static async Task InstallApkAsync(string deviceSerial, string apkPath, CancellationToken cancellationToken)
	{
		using Process process = m_2686($"-s {deviceSerial} install -r \"{apkPath}\"");
		Task<string> task = process.StandardOutput.ReadToEndAsync(cancellationToken);
		Task<string> task2 = process.StandardError.ReadToEndAsync(cancellationToken);
		InlineArray2<Task<string>> buffer = default;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
		await process.WaitForExitAsync(cancellationToken);
		string text = task.Result.Trim();
		string text2 = task2.Result.Trim();
		string text3 = string.Join(" | ", new string[2] { text, text2 }.Where((string P_0) => P_0.Length > 0));
		if (text3.Contains("Success", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		throw new InvalidOperationException("Cài app thất bại trên máy " + deviceSerial + ": " + ((text3.Length > 0) ? text3 : "(không có thông báo lỗi)"));
	}

	public static async Task PushFileAsync(string deviceSerial, string localPath, string remotePath, CancellationToken cancellationToken)
	{
		using Process process = m_2686($"-s {deviceSerial} push \"{localPath}\" \"{remotePath}\"");
		await process.WaitForExitAsync(cancellationToken);
	}

	public static async Task<string> RunShellCaptureAsync(string deviceSerial, string shellCommand, CancellationToken cancellationToken)
	{
		using Process process = m_2686("-s " + deviceSerial + " shell " + shellCommand);
		Task<string> task = process.StandardOutput.ReadToEndAsync(cancellationToken);
		Task<string> task2 = process.StandardError.ReadToEndAsync(cancellationToken);
		InlineArray2<Task<string>> buffer = default;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
		await process.WaitForExitAsync(cancellationToken);
		return task.Result;
	}

	public static async Task RunShellAsync(string deviceSerial, string shellCommand, CancellationToken cancellationToken)
	{
		using Process process = m_2686("-s " + deviceSerial + " shell " + shellCommand);
		Task<string> task = process.StandardOutput.ReadToEndAsync(cancellationToken);
		Task<string> task2 = process.StandardError.ReadToEndAsync(cancellationToken);
		InlineArray2<Task<string>> buffer = default;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
		await process.WaitForExitAsync(cancellationToken);
		string text = task.Result.Trim();
		string text2 = task2.Result.Trim();
		string text3 = string.Join(" | ", new string[2] { text, text2 }.Where((string P_0) => P_0.Length > 0));
		if (process.ExitCode != 0)
		{
			throw new InvalidOperationException($"adb shell thất bại (exit {process.ExitCode}) trên máy {deviceSerial}: {((text3.Length > 0) ? text3 : "(không có thông báo lỗi)")}");
		}
		if (text3.Contains("error", StringComparison.OrdinalIgnoreCase) || text3.Contains("no devices", StringComparison.OrdinalIgnoreCase) || text3.Contains("device offline", StringComparison.OrdinalIgnoreCase) || text3.Contains("unauthorized", StringComparison.OrdinalIgnoreCase) || text3.Contains("not found", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("adb shell báo lỗi trên máy " + deviceSerial + ": " + text3);
		}
	}

	public static async Task<List<string>> ListDevicesAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		List<string> list = new List<string>();
		try
		{
			using Process process = m_2686("devices");
			string text = await process.StandardOutput.ReadToEndAsync(cancellationToken);
			await process.WaitForExitAsync(cancellationToken);
			string[] array = text.Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
			for (int l = 0; l < array.Length; l++)
			{
				Match match = Regex.Match(array[l].Trim(), "^(?<device>\\S+)\\s+device$");
				if (match.Success)
				{
					list.Add(match.Groups["device"].Value);
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public static async Task EnsureEnglishLanguageAsync(string deviceSerial, CancellationToken cancellationToken = default(CancellationToken))
	{
		_ = 4;
		try
		{
			await RunShellCaptureAsync(deviceSerial, "pm grant net.sanapeli.adbchangelanguage android.permission.CHANGE_CONFIGURATION 2>/dev/null", cancellationToken);
			await RunShellCaptureAsync(deviceSerial, "appops set net.sanapeli.adbchangelanguage android:change_configuration allow 2>/dev/null", cancellationToken);
			await RunShellCaptureAsync(deviceSerial, "am start -n net.sanapeli.adbchangelanguage/.AdbChangeLanguage -e language en -e country US 2>/dev/null", cancellationToken);
			await Task.Delay(500, cancellationToken);
			await RunShellCaptureAsync(deviceSerial, "setprop persist.sys.locale en-US && setprop persist.sys.language en && setprop persist.sys.country US", cancellationToken);
		}
		catch
		{
		}
	}

	public static async Task<bool> CheckInternetAsync(string deviceSerial, CancellationToken cancellationToken = default(CancellationToken))
	{
		try
		{
			return (await RunShellCaptureAsync(deviceSerial, "ping -c 2 -W 3 8.8.8.8", cancellationToken)).Contains("bytes from", StringComparison.OrdinalIgnoreCase);
		}
		catch
		{
			return false;
		}
	}

	public static async Task RestartServerAsync(CancellationToken cancellationToken)
	{
		using (Process process = m_2686("kill-server"))
		{
			await process.StandardOutput.ReadToEndAsync(cancellationToken);
			await process.StandardError.ReadToEndAsync(cancellationToken);
			await process.WaitForExitAsync(cancellationToken);
		}
		using Process process2 = m_2686("start-server");
		Task<string> task = process2.StandardOutput.ReadToEndAsync(cancellationToken);
		Task<string> task2 = process2.StandardError.ReadToEndAsync(cancellationToken);
		InlineArray2<Task<string>> buffer = default;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 0) = task;
		global::A.H.a<InlineArray2<Task<string>>, Task<string>>(ref buffer, 1) = task2;
		await Task.WhenAll(global::A.H.m_6821<InlineArray2<Task<string>>, Task<string>>(in buffer, 2));
		await process2.WaitForExitAsync(cancellationToken);
		if (process2.ExitCode != 0)
		{
			string text = string.Join(" | ", new string[2]
			{
				task.Result.Trim(),
				task2.Result.Trim()
			}.Where((string P_0) => P_0.Length > 0));
			throw new InvalidOperationException("Không khởi động lại được adb server: " + ((text.Length > 0) ? text : "(không có thông báo lỗi)"));
		}
	}

	public static async Task GrantAllAppPermissionsAsync(string deviceSerial, string package, CancellationToken cancellationToken = default(CancellationToken))
	{
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			string[] array = m_2680;
			foreach (string value in array)
			{
				StringBuilder stringBuilder2 = stringBuilder;
				StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(24, 2, stringBuilder2);
				handler.AppendLiteral("pm grant ");
				handler.AppendFormatted(package);
				handler.AppendLiteral(" ");
				handler.AppendFormatted(value);
				handler.AppendLiteral(" 2>/dev/null; ");
				stringBuilder2.Append(ref handler);
			}
			await RunShellCaptureAsync(deviceSerial, stringBuilder.ToString(), cancellationToken);
		}
		catch
		{
		}
	}

	public static async Task<KatanaSessionResult> GetKatanaTokenAndCookieAsync(string deviceSerial, CancellationToken cancellationToken = default(CancellationToken))
	{
		string text = Path.Combine(AppContext.BaseDirectory, "dulieu");
		try
		{
			Directory.CreateDirectory(text);
		}
		catch
		{
		}
		string text2 = Path.Combine(text, "TL" + deviceSerial + "Cookies.txt");
		string text3 = "";
		try
		{
			try
			{
				await RunShellCaptureAsync(deviceSerial, "su 0 cp /data/data/com.facebook.katana/app_light_prefs/com.facebook.katana/authentication /sdcard/Download/authentication", cancellationToken);
				using (Process process = m_2686($"-s {deviceSerial} pull /sdcard/Download/authentication \"{text2}\""))
				{
					await process.StandardOutput.ReadToEndAsync(cancellationToken);
					await process.StandardError.ReadToEndAsync(cancellationToken);
					await process.WaitForExitAsync(cancellationToken);
				}
				if (File.Exists(text2))
				{
					text3 = await File.ReadAllTextAsync(text2, cancellationToken);
					try
					{
						File.Delete(text2);
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			if (string.IsNullOrWhiteSpace(text3) || !text3.Contains("EAA", StringComparison.Ordinal))
			{
				try
				{
					text3 = await RunShellCaptureAsync(deviceSerial, "su 0 cat /data/data/com.facebook.katana/app_light_prefs/com.facebook.katana/authentication", cancellationToken);
				}
				catch
				{
				}
			}
			if (string.IsNullOrWhiteSpace(text3) || !text3.Contains("EAA", StringComparison.Ordinal))
			{
				try
				{
					text3 = await RunShellCaptureAsync(deviceSerial, "su -c 'cat /data/data/com.facebook.katana/app_light_prefs/com.facebook.katana/authentication'", cancellationToken);
				}
				catch
				{
				}
			}
			try
			{
				await RunShellCaptureAsync(deviceSerial, "rm -f /sdcard/Download/authentication", cancellationToken);
			}
			catch
			{
			}
			if (string.IsNullOrWhiteSpace(text3) || text3.Contains("not found", StringComparison.OrdinalIgnoreCase) || text3.Contains("No such file", StringComparison.OrdinalIgnoreCase) || text3.Contains("Permission denied", StringComparison.OrdinalIgnoreCase) || text3.Contains("inaccessible", StringComparison.OrdinalIgnoreCase))
			{
				return new KatanaSessionResult
				{
					Success = false,
					ErrorMessage = "Không đọc được file authentication Katana (máy chưa root hoặc Katana chưa đăng nhập)."
				};
			}
			string text4 = Regex.Match(text3, "EAA[a-z,A-Z,0-9]{0,}").ToString();
			string text5 = "datr=" + Regex.Match(text3, "\"name\":\"datr\",\"value\":\"(.*?)\"").Groups[1].Value;
			string text6 = "fr=" + Regex.Match(text3, "\"name\":\"fr\",\"value\":\"(.*?)\"").Groups[1].Value;
			string text7 = "xs=" + Regex.Match(text3, "\"name\":\"xs\",\"value\":\"(.*?)\"").Groups[1].Value;
			string text8 = "c_user=" + Regex.Match(text3, "\"name\":\"c_user\",\"value\":\"(.*?)\"").Groups[1].Value;
			int num = 1920;
			int num2 = 1080;
			try
			{
				num = (int)SystemParameters.PrimaryScreenWidth;
				num2 = (int)SystemParameters.PrimaryScreenHeight;
			}
			catch
			{
			}
			string text9 = "wd=" + num + "x" + num2;
			string text10 = text5 + ";" + text8 + ";" + text7 + ";" + text6 + ";" + text9;
			string value = Regex.Match(text10, "c_user=(.*?);").Groups[1].Value;
			string text11 = text4;
			string cookie = text10;
			if (string.IsNullOrEmpty(text11) && string.IsNullOrEmpty(value))
			{
				return new KatanaSessionResult
				{
					Success = false,
					ErrorMessage = "Không tìm thấy token/cookie trong file authentication Katana."
				};
			}
			return new KatanaSessionResult
			{
				Success = true,
				Uid = value,
				Token = text11,
				Cookie = cookie,
				RawText = text3
			};
		}
		catch (Exception ex)
		{
			try
			{
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
			}
			catch
			{
			}
			return new KatanaSessionResult
			{
				Success = false,
				ErrorMessage = "Lỗi: " + ex.Message
			};
		}
	}

	public static async Task<KatanaSessionResult> GetFbLiteTokenAndCookieAsync(string deviceSerial, CancellationToken cancellationToken = default(CancellationToken))
	{
		string text = Path.Combine(AppContext.BaseDirectory, "dulieu");
		try
		{
			Directory.CreateDirectory(text);
		}
		catch
		{
		}
		string text2 = Path.Combine(text, "TL" + deviceSerial + "Cookies.txt");
		string text3 = "";
		try
		{
			try
			{
				await RunShellCaptureAsync(deviceSerial, "su 0 cp /data/data/com.facebook.lite/files/PropertiesStore_v02 /sdcard/Download/PropertiesStore_v02", cancellationToken);
				using (Process process = m_2686($"-s {deviceSerial} pull /sdcard/Download/PropertiesStore_v02 \"{text2}\""))
				{
					await process.StandardOutput.ReadToEndAsync(cancellationToken);
					await process.StandardError.ReadToEndAsync(cancellationToken);
					await process.WaitForExitAsync(cancellationToken);
				}
				if (File.Exists(text2))
				{
					byte[] bytes = await File.ReadAllBytesAsync(text2, cancellationToken);
					text3 = Encoding.Latin1.GetString(bytes);
					try
					{
						File.Delete(text2);
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			if (string.IsNullOrWhiteSpace(text3) || (!text3.Contains("EAA", StringComparison.Ordinal) && !text3.Contains("c_user", StringComparison.Ordinal)))
			{
				try
				{
					text3 = await RunShellCaptureAsync(deviceSerial, "su 0 cat /data/data/com.facebook.lite/files/PropertiesStore_v02", cancellationToken);
				}
				catch
				{
				}
			}
			if (string.IsNullOrWhiteSpace(text3) || (!text3.Contains("EAA", StringComparison.Ordinal) && !text3.Contains("c_user", StringComparison.Ordinal)))
			{
				try
				{
					text3 = await RunShellCaptureAsync(deviceSerial, "su -c 'cat /data/data/com.facebook.lite/files/PropertiesStore_v02'", cancellationToken);
				}
				catch
				{
				}
			}
			try
			{
				await RunShellCaptureAsync(deviceSerial, "rm -f /sdcard/Download/PropertiesStore_v02", cancellationToken);
			}
			catch
			{
			}
			if (string.IsNullOrWhiteSpace(text3) || text3.Contains("not found", StringComparison.OrdinalIgnoreCase) || text3.Contains("No such file", StringComparison.OrdinalIgnoreCase) || text3.Contains("Permission denied", StringComparison.OrdinalIgnoreCase) || text3.Contains("inaccessible", StringComparison.OrdinalIgnoreCase))
			{
				return new KatanaSessionResult
				{
					Success = false,
					ErrorMessage = "Không đọc được file PropertiesStore_v02 FB Lite (máy chưa root hoặc FB Lite chưa đăng nhập)."
				};
			}
			string text4 = Regex.Match(text3, "EAA[a-zA-Z0-9]+").ToString();
			MatchCollection matchCollection = Regex.Matches(text3, "\"expires\"(.*?)}");
			string text5 = "";
			foreach (Match item in matchCollection)
			{
				string text6 = Regex.Match(item.Value, "\"name\":\"(.*?)\"").Groups[1].Value.ToString();
				string text7 = Regex.Match(item.Value, "\"value\":\"(.*?)\"").Groups[1].Value.ToString();
				if (!string.IsNullOrEmpty(text6) && !string.IsNullOrEmpty(text7))
				{
					text5 = text5 + text6 + "=" + text7 + ";";
				}
			}
			if (string.IsNullOrEmpty(text5))
			{
				string value = Regex.Match(text3, "\"name\":\"datr\",\"value\":\"(.*?)\"").Groups[1].Value;
				string value2 = Regex.Match(text3, "\"name\":\"fr\",\"value\":\"(.*?)\"").Groups[1].Value;
				string value3 = Regex.Match(text3, "\"name\":\"xs\",\"value\":\"(.*?)\"").Groups[1].Value;
				string value4 = Regex.Match(text3, "\"name\":\"c_user\",\"value\":\"(.*?)\"").Groups[1].Value;
				if (!string.IsNullOrEmpty(value4))
				{
					text5 = $"c_user={value4};xs={value3};datr={value};fr={value2};";
				}
			}
			string text8 = Regex.Match(text5, "c_user=(.*?);").Groups[1].Value.ToString();
			if (string.IsNullOrEmpty(text8))
			{
				text8 = Regex.Match(text3, "\"name\":\"c_user\",\"value\":\"(.*?)\"").Groups[1].Value.ToString();
			}
			string text9 = text4;
			string text10 = text5;
			if (string.IsNullOrEmpty(text9) && string.IsNullOrEmpty(text8) && string.IsNullOrEmpty(text10))
			{
				return new KatanaSessionResult
				{
					Success = false,
					ErrorMessage = "Không tìm thấy token/cookie trong file PropertiesStore_v02 của FB Lite."
				};
			}
			return new KatanaSessionResult
			{
				Success = true,
				Uid = text8,
				Token = text9,
				Cookie = text10,
				RawText = text3
			};
		}
		catch (Exception ex)
		{
			try
			{
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
			}
			catch
			{
			}
			return new KatanaSessionResult
			{
				Success = false,
				ErrorMessage = "Lỗi: " + ex.Message
			};
		}
	}

	private static Process m_2686(string P_0)
	{
		return Process.Start(new ProcessStartInfo
		{
			FileName = AdbExePath,
			Arguments = P_0,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			UseShellExecute = false,
			CreateNoWindow = true
		}) ?? throw new InvalidOperationException("Không khởi động được adb.exe.");
	}
}
