using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class LiveRecordedAction
{
	[CompilerGenerated]
	private LiveRecordedActionKind A;

	[CompilerGenerated]
	private int m_5615;

	[CompilerGenerated]
	private int a;

	[CompilerGenerated]
	private string? m_5616;

	[CompilerGenerated]
	private string? m_5617;

	[CompilerGenerated]
	private string? B;

	[CompilerGenerated]
	private string? b;

	[CompilerGenerated]
	private string? C;

	[CompilerGenerated]
	private int m_5618;

	[CompilerGenerated]
	private int m_5619;

	public LiveRecordedActionKind Kind
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int X
	{
		[CompilerGenerated]
		get
		{
			return m_5615;
		}
		[CompilerGenerated]
		set
		{
			m_5615 = value;
		}
	}

	public int Y
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string? Value
	{
		[CompilerGenerated]
		get
		{
			return m_5616;
		}
		[CompilerGenerated]
		set
		{
			m_5616 = value;
		}
	}

	public string? Url
	{
		[CompilerGenerated]
		get
		{
			return m_5617;
		}
		[CompilerGenerated]
		set
		{
			m_5617 = value;
		}
	}

	public string? ResourceId
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string? ContentDesc
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string? ElementText
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int DeltaX
	{
		[CompilerGenerated]
		get
		{
			return m_5618;
		}
		[CompilerGenerated]
		set
		{
			m_5618 = value;
		}
	}

	public int DeltaY
	{
		[CompilerGenerated]
		get
		{
			return m_5619;
		}
		[CompilerGenerated]
		set
		{
			m_5619 = value;
		}
	}
}
