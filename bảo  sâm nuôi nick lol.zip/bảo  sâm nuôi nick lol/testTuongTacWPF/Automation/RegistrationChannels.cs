namespace testTuongTacWPF.Automation;

public static class RegistrationChannels
{
	public const string Mail = "Mail";

	public const string Phone = "Phone";
}
