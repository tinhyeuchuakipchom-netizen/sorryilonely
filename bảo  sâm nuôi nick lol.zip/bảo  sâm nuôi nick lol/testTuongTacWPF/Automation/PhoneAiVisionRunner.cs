using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Licensing;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class PhoneAiVisionRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5865
	{
		public static readonly m_5865 A = new m_5865();

		public static Func<UiElement, bool> m_5869;

		public static Func<UiElement, string> m_5870;

		public static Func<string, bool> m_5871;

		public static Func<UiElement, string> a;

		public static Func<string, bool> m_5872;

		internal bool m_5873(UiElement P_0)
		{
			return P_0.Focused;
		}

		internal string m_5874(UiElement P_0)
		{
			return P_0.Text;
		}

		internal bool m_5875(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string B(UiElement P_0)
		{
			return P_0.Text;
		}

		internal bool m_5876(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_5866
	{
		public HashSet<string> A;

		internal bool m_5877(string P_0)
		{
			return !A.Contains(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_5867
	{
		public AiVisionFlowStep A;

		internal bool m_5878(UiElement P_0)
		{
			if (string.Equals(P_0.Text, A.DisambiguatorText, StringComparison.OrdinalIgnoreCase) && Math.Abs(P_0.CenterX - A.DisambiguatorX) <= 60)
			{
				return Math.Abs(P_0.CenterY - A.DisambiguatorY) <= 60;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_5868
	{
		public AiVisionCachedStep A;

		internal bool m_5879(UiElement P_0)
		{
			return P_0.ResourceId == A.ResourceId;
		}

		internal bool a(UiElement P_0)
		{
			return P_0.ContentDesc == A.ContentDesc;
		}

		internal bool B(UiElement P_0)
		{
			return P_0.Text == A.ElementText;
		}
	}

	private const int A = 60;

	private const int a = 3;

	private const int B = 4;

	private const int b = 350;

	private static readonly string m_5846 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "ai_vision_debug");

	public static Task<AiVisionRunResult> RunFlowAsync(IDeviceController device, IReadOnlyList<AiVisionFlowStep> flow, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, Action<int, AiVisionFlowStep?>? onActionRecorded = null)
	{
		return RunFlowAsync(device, flow, new Dictionary<string, string>(), onStep, cancellationToken, onActionRecorded);
	}

	public static async Task<AiVisionRunResult> RunFlowAsync(IDeviceController device, IReadOnlyList<AiVisionFlowStep> flow, IReadOnlyDictionary<string, string> variables, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, Action<int, AiVisionFlowStep?>? onActionRecorded = null)
	{
		if (!LicenseClient.IsPhoneAiUnlocked)
		{
			UnlockWindow.ShowExpiredNotice();
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Tính năng AI Vision cho Phone cần nâng cấp Pro (hoặc đã hết 7 ngày dùng thử) - liên hệ để nâng cấp."
			};
		}
		AiVisionSettings aiVisionSettings = AiVisionSettings.Load();
		var (num, num2) = await device.GetScreenSizeAsync(cancellationToken);
		try
		{
			for (int i = 0; i < flow.Count; i++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				AiVisionFlowStep aiVisionFlowStep = flow[i];
				switch (aiVisionFlowStep.Type)
				{
				case AiVisionStepType.Wait:
					await Task.Delay(aiVisionFlowStep.WaitMs, cancellationToken);
					break;
				case AiVisionStepType.RandomWait:
				{
					int minValue = Math.Min(aiVisionFlowStep.RandomMinMs, aiVisionFlowStep.RandomMaxMs);
					int num7 = Math.Max(aiVisionFlowStep.RandomMinMs, aiVisionFlowStep.RandomMaxMs);
					await Task.Delay(Random.Shared.Next(minValue, num7 + 1), cancellationToken);
					break;
				}
				case AiVisionStepType.AiGoal:
				{
					if (string.IsNullOrWhiteSpace(aiVisionFlowStep.Goal))
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = $"Bước {i + 1}: chưa nhập mục tiêu."
						};
					}
					AiVisionRunResult aiVisionRunResult2 = await m_5847(device, aiVisionSettings, aiVisionFlowStep.Goal, aiVisionFlowStep.MaxSteps, i, num, num2, variables, onStep, cancellationToken, onActionRecorded);
					if (!aiVisionRunResult2.Success)
					{
						if (aiVisionRunResult2.Message.StartsWith("Chưa bật mục tiêu AI nào", StringComparison.Ordinal))
						{
							return new AiVisionRunResult
							{
								Success = false,
								Message = $"Dừng ở bước {i + 1}: {aiVisionRunResult2.Message}"
							};
						}
						onStep(new AiVisionStepLog
						{
							FlowStepIndex = i,
							SubStep = 0,
							ActionSummary = $"[Bỏ qua] Khối Mục tiêu AI ở bước {i + 1} chưa xong: {aiVisionRunResult2.Message}",
							Reason = "Hết số bước tối đa của riêng khối này - tự động chạy tiếp bước kế tiếp trong danh sách."
						});
					}
					break;
				}
				case AiVisionStepType.Tap:
				case AiVisionStepType.Swipe:
				case AiVisionStepType.Text:
				{
					string text = null;
					int num3 = i;
					int num4 = Math.Max(1, aiVisionSettings.PoolMatchRetryAttempts);
					int num5 = ((aiVisionSettings.PoolMatchRetryDelayMs <= 100) ? (aiVisionSettings.PoolMatchRetryDelayMs * 1000) : aiVisionSettings.PoolMatchRetryDelayMs);
					int val = 1200;
					for (int j = 1; j <= num4; j++)
					{
						DateTime dateTime = DateTime.UtcNow.AddMilliseconds(num5);
						while (DateTime.UtcNow <= dateTime)
						{
							cancellationToken.ThrowIfCancellationRequested();
							if (aiVisionFlowStep.IsMarkedComplete && !m_5850(aiVisionFlowStep))
							{
								text = await m_5848(device, m_5857(aiVisionFlowStep), variables, cancellationToken);
							}
							else
							{
								(int Index, AiVisionFlowStep Step)? tuple2 = await m_5849(device, flow, i, cancellationToken);
								if (tuple2.HasValue)
								{
									text = await m_5848(device, m_5857(tuple2.Value.Step), variables, cancellationToken);
									if (text != null)
									{
										num3 = tuple2.Value.Index;
									}
								}
							}
							if (text != null)
							{
								break;
							}
							double totalSeconds = (dateTime - DateTime.UtcNow).TotalSeconds;
							if (totalSeconds <= 0.5)
							{
								break;
							}
							onStep(new AiVisionStepLog
							{
								FlowStepIndex = i,
								SubStep = 1,
								ActionSummary = $"[Dò màn hình liên tục] Chưa khớp bước nào (Lượt {j}/{num4}), tự động quét lại (còn {totalSeconds:0}s)...",
								Reason = "Tự động chạy ngay khi phần tử/màn hình vừa xuất hiện, không chờ vô ích."
							});
							await Task.Delay(Math.Min(val, (int)(totalSeconds * 1000.0)), cancellationToken);
						}
						if (text != null)
						{
							break;
						}
					}
					if (text != null)
					{
						onStep(new AiVisionStepLog
						{
							FlowStepIndex = num3,
							SubStep = 1,
							ActionSummary = text,
							Reason = ((num3 == i) ? "Bước đã đánh dấu sẵn." : "Màn hình khớp bước khác trong kịch bản (dò lại toàn bộ).")
						});
						i = num3;
						break;
					}
					onStep(new AiVisionStepLog
					{
						FlowStepIndex = i,
						SubStep = 1,
						ActionSummary = "[Đánh dấu] Không có bước nào trong kịch bản khớp màn hình hiện tại.",
						Reason = "Rơi về AI (nếu có khối AI phía sau)."
					});
					int num6 = m_5858(flow, i);
					if (num6 < 0)
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = $"Bước {i + 1}: không tìm thấy phần tử đã đánh dấu và không có khối Mục tiêu AI nào phía sau để xử lý tiếp."
						};
					}
					AiVisionFlowStep aiVisionFlowStep2 = flow[num6];
					if (string.IsNullOrWhiteSpace(aiVisionFlowStep2.Goal))
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = $"Bước {i + 1}: không tìm thấy phần tử đã đánh dấu; khối Mục tiêu AI ở bước {num6 + 1} chưa nhập mục tiêu."
						};
					}
					AiVisionRunResult aiVisionRunResult = await m_5847(device, aiVisionSettings, aiVisionFlowStep2.Goal, aiVisionFlowStep2.MaxSteps, num6, num, num2, variables, onStep, cancellationToken, onActionRecorded);
					if (!aiVisionRunResult.Success)
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = $"Dừng ở bước {num6 + 1}: {aiVisionRunResult.Message}"
						};
					}
					i = num6;
					break;
				}
				}
			}
			return new AiVisionRunResult
			{
				Success = true,
				Message = $"Hoàn thành cả {flow.Count} bước."
			};
		}
		finally
		{
			m_5861();
		}
	}

	private static async Task<AiVisionRunResult> m_5847(IDeviceController P_0, AiVisionSettings P_1, string P_2, int P_3, int P_4, int P_5, int P_6, IReadOnlyDictionary<string, string> P_7, Action<AiVisionStepLog> P_8, CancellationToken P_9, Action<int, AiVisionFlowStep?>? onActionRecorded = null)
	{
		if (P_1.PriorityTargets.Count == 0)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Chưa bật mục tiêu AI nào - vào Cài đặt AI Vision bật ít nhất 1 provider/model."
			};
		}
		string goal = AiVisionVariables.Substitute(P_2, P_7);
		List<string> list = new List<string>();
		for (int i = 1; i <= P_3; i++)
		{
			P_9.ThrowIfCancellationRequested();
			byte[] array = await m_5860(P_0, P_9);
			m_5862(array, P_4, i);
			List<UiElement> list2 = await P_0.DumpUiElementsAsync(P_9);
			AiVisionAction aiVisionAction = await AiVisionClient.DecideNextActionAsync(P_1, array, goal, list, list2, P_9);
			(string, UiElement) tuple = m_5859(aiVisionAction, list2, P_5, P_6);
			string item = tuple.Item1;
			UiElement item2 = tuple.Item2;
			string text = m_5864(aiVisionAction, item);
			P_8(new AiVisionStepLog
			{
				FlowStepIndex = P_4,
				SubStep = i,
				ActionSummary = text,
				Reason = aiVisionAction.Reason
			});
			list.Add(text);
			if (string.Equals(aiVisionAction.Action, "done", StringComparison.OrdinalIgnoreCase))
			{
				return new AiVisionRunResult
				{
					Success = true,
					Message = $"Xong sau {i} thao tác."
				};
			}
			await m_5863(P_0, aiVisionAction, P_9);
			if (onActionRecorded != null && !string.Equals(aiVisionAction.Action, "wait", StringComparison.OrdinalIgnoreCase))
			{
				string text2 = (string.Equals(aiVisionAction.Action, "text", StringComparison.OrdinalIgnoreCase) ? AiVisionVariables.FindPlaceholderForValue(aiVisionAction.Text, P_7) : null);
				List<string> screenTexts = m_5855(list2);
				onActionRecorded(P_4, m_5856(aiVisionAction, item2, screenTexts, text2));
			}
			await Task.Delay(P_1.StepDelayMs, P_9);
		}
		return new AiVisionRunResult
		{
			Success = false,
			Message = $"AI chưa báo xong sau {P_3} thao tác."
		};
	}

	private static async Task<string?> m_5848(IDeviceController P_0, AiVisionCachedStep P_1, IReadOnlyDictionary<string, string> P_2, CancellationToken P_3, Action<string>? onDiagnostic = null, bool P_5 = true)
	{
		_ = 11;
		try
		{
			List<UiElement> list = null;
			List<string> screenTexts = P_1.ScreenTexts;
			if (screenTexts != null && screenTexts.Count > 0)
			{
				list = await P_0.DumpUiElementsAsync(P_3);
				if (!m_5854(P_1.ScreenTexts, list, P_5, out string diagnostic))
				{
					if (diagnostic != null)
					{
						onDiagnostic?.Invoke(diagnostic);
					}
					return null;
				}
			}
			switch (P_1.Action)
			{
			case "tap":
				if (!string.IsNullOrWhiteSpace(P_1.ResourceId) || !string.IsNullOrWhiteSpace(P_1.ContentDesc) || !string.IsNullOrWhiteSpace(P_1.ElementText))
				{
					if (list == null)
					{
						list = await P_0.DumpUiElementsAsync(P_3);
					}
					UiElement uiElement2 = m_5852(list, P_1);
					if (uiElement2 == null)
					{
						onDiagnostic?.Invoke($"Không tìm thấy phần tử khớp (ResourceId=\"{P_1.ResourceId}\", ContentDesc=\"{P_1.ContentDesc}\", ElementText=\"{P_1.ElementText}\") trong màn hình hiện tại - dấu vết màn hình khớp nhưng danh tính phần tử đã đánh dấu không còn khớp.");
						return null;
					}
					await P_0.TapAsync(uiElement2.CenterX, uiElement2.CenterY, P_3);
					return $"[Cache] Tap \"{uiElement2.Label}\" ({uiElement2.CenterX}, {uiElement2.CenterY})";
				}
				await P_0.TapAsync(P_1.X, P_1.Y, P_3);
				return $"[Cache] Tap ({P_1.X}, {P_1.Y})";
			case "swipe":
				await P_0.SwipeAsync(P_1.X, P_1.Y, P_1.X2, P_1.Y2, 400, P_3);
				return $"[Cache] Swipe ({P_1.X},{P_1.Y}) → ({P_1.X2},{P_1.Y2})";
			case "text":
			{
				if (!string.IsNullOrWhiteSpace(P_1.ResourceId) || !string.IsNullOrWhiteSpace(P_1.ContentDesc) || !string.IsNullOrWhiteSpace(P_1.ElementText) || P_1.X != 0 || P_1.Y != 0)
				{
					if (string.IsNullOrWhiteSpace(P_1.ResourceId) && string.IsNullOrWhiteSpace(P_1.ContentDesc) && string.IsNullOrWhiteSpace(P_1.ElementText))
					{
						await P_0.TapAsync(P_1.X, P_1.Y, P_3);
					}
					else
					{
						if (list == null)
						{
							list = await P_0.DumpUiElementsAsync(P_3);
						}
						UiElement uiElement = m_5852(list, P_1);
						if (uiElement == null)
						{
							onDiagnostic?.Invoke($"Không tìm thấy ô nhập khớp (ResourceId=\"{P_1.ResourceId}\", ContentDesc=\"{P_1.ContentDesc}\", ElementText=\"{P_1.ElementText}\") trong màn hình hiện tại - dấu vết màn hình khớp nhưng danh tính ô nhập đã đánh dấu không còn khớp.");
							return null;
						}
						await P_0.TapAsync(uiElement.CenterX, uiElement.CenterY, P_3);
					}
					await Task.Delay(400, P_3);
					if (!(await P_0.DumpUiElementsAsync(P_3)).Any((UiElement uiElement3) => uiElement3.Focused))
					{
						onDiagnostic?.Invoke($"Đã tap ({P_1.X},{P_1.Y}) nhưng không có ô nào đang nhận focus trên máy - chữ sẽ không vào đâu cả dù lệnh gõ không báo lỗi. Có thể tap bị lệch chỗ hoặc ô này không nhận input qua adb, thử \"Đánh dấu lại\" bước này.");
						return null;
					}
				}
				string text = ((P_1.Text.StartsWith("{{") && P_1.Text.EndsWith("}}")) ? AiVisionVariables.Substitute(P_1.Text, P_2) : P_1.Text);
				await P_0.InputTextAsync(text, P_3);
				return "[Cache] Gõ chữ: \"" + text + "\"";
			}
			case "keyevent":
				await P_0.KeyEventAsync(P_1.Text, P_3);
				return "[Cache] Phím: " + P_1.Text;
			default:
				return "[Cache] Chờ";
			}
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			onDiagnostic?.Invoke(ex2.Message);
			return null;
		}
	}

	private static async Task<(int Index, AiVisionFlowStep Step)?> m_5849(IDeviceController P_0, IReadOnlyList<AiVisionFlowStep> P_1, int P_2, CancellationToken P_3)
	{
		List<UiElement> list = await P_0.DumpUiElementsAsync(P_3);
		int? num = null;
		int num2 = int.MaxValue;
		for (int i = 0; i < P_1.Count; i++)
		{
			AiVisionFlowStep aiVisionFlowStep = P_1[i];
			if (aiVisionFlowStep.IsMarked && aiVisionFlowStep.IsMarkedComplete && m_5851(aiVisionFlowStep, list))
			{
				int num3 = Math.Abs(i - P_2);
				if (num3 < num2)
				{
					num2 = num3;
					num = i;
				}
			}
		}
		if (num.HasValue)
		{
			return (num.Value, P_1[num.Value]);
		}
		return null;
	}

	private static bool m_5850(AiVisionFlowStep P_0)
	{
		List<string> screenTexts = P_0.ScreenTexts;
		if ((screenTexts == null || screenTexts.Count <= 0) && string.IsNullOrWhiteSpace(P_0.ResourceId) && string.IsNullOrWhiteSpace(P_0.ContentDesc) && string.IsNullOrWhiteSpace(P_0.ElementText))
		{
			return !string.IsNullOrWhiteSpace(P_0.DisambiguatorText);
		}
		return true;
	}

	private static bool m_5851(AiVisionFlowStep P_0, List<UiElement> P_1)
	{
		if (!m_5850(P_0))
		{
			return false;
		}
		List<string> screenTexts = P_0.ScreenTexts;
		if (screenTexts != null && screenTexts.Count > 0 && !m_5854(P_0.ScreenTexts, P_1, true, out string _))
		{
			return false;
		}
		if ((!string.IsNullOrWhiteSpace(P_0.ResourceId) || !string.IsNullOrWhiteSpace(P_0.ContentDesc) || !string.IsNullOrWhiteSpace(P_0.ElementText)) && m_5852(P_1, m_5857(P_0)) == null)
		{
			return false;
		}
		if (!string.IsNullOrWhiteSpace(P_0.DisambiguatorText) && !P_1.Any((UiElement uiElement) => string.Equals(uiElement.Text, P_0.DisambiguatorText, StringComparison.OrdinalIgnoreCase) && Math.Abs(uiElement.CenterX - P_0.DisambiguatorX) <= 60 && Math.Abs(uiElement.CenterY - P_0.DisambiguatorY) <= 60))
		{
			return false;
		}
		return true;
	}

	private static UiElement? m_5852(List<UiElement> P_0, AiVisionCachedStep P_1)
	{
		if (!string.IsNullOrWhiteSpace(P_1.ResourceId))
		{
			UiElement uiElement = m_5853(P_0.Where((UiElement uiElement4) => uiElement4.ResourceId == P_1.ResourceId), P_1.X, P_1.Y);
			if (uiElement != null)
			{
				return uiElement;
			}
		}
		if (!string.IsNullOrWhiteSpace(P_1.ContentDesc))
		{
			UiElement uiElement2 = m_5853(P_0.Where((UiElement uiElement4) => uiElement4.ContentDesc == P_1.ContentDesc), P_1.X, P_1.Y);
			if (uiElement2 != null)
			{
				return uiElement2;
			}
		}
		if (!string.IsNullOrWhiteSpace(P_1.ElementText))
		{
			UiElement uiElement3 = m_5853(P_0.Where((UiElement uiElement4) => uiElement4.Text == P_1.ElementText), P_1.X, P_1.Y);
			if (uiElement3 != null)
			{
				return uiElement3;
			}
		}
		return null;
	}

	private static UiElement? m_5853(IEnumerable<UiElement> P_0, int P_1, int P_2)
	{
		UiElement result = null;
		double num = double.MaxValue;
		foreach (UiElement item in P_0)
		{
			double num2 = Math.Sqrt(Math.Pow(item.CenterX - P_1, 2.0) + Math.Pow(item.CenterY - P_2, 2.0));
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	private static bool m_5854(List<string>? fingerprint, IReadOnlyList<UiElement> P_1, bool P_2, out string? diagnostic)
	{
		diagnostic = null;
		if (fingerprint == null || fingerprint.Count == 0)
		{
			return true;
		}
		HashSet<string> A = new HashSet<string>(from uiElement in P_1
			select uiElement.Text into value
			where !string.IsNullOrWhiteSpace(value)
			select value, StringComparer.OrdinalIgnoreCase);
		List<string> list = fingerprint.Where((string item) => !A.Contains(item)).ToList();
		if (list.Count == 0)
		{
			return true;
		}
		if (!P_2 && list.Count < fingerprint.Count - list.Count)
		{
			diagnostic = $"Thiếu {list.Count}/{fingerprint.Count} chữ dấu vết màn hình ({string.Join(", ", list)}) nhưng vẫn coi là khớp vì đa số đã khớp.";
			return true;
		}
		diagnostic = $"Chưa khớp dấu vết màn hình - thiếu {list.Count}/{fingerprint.Count} chữ: {string.Join(", ", list)}";
		return false;
	}

	private static List<string> m_5855(IReadOnlyList<UiElement> P_0)
	{
		return (from uiElement in P_0
			select uiElement.Text into value
			where !string.IsNullOrWhiteSpace(value)
			select value).Distinct().Take(3).ToList();
	}

	private static AiVisionFlowStep? m_5856(AiVisionAction action, UiElement? P_1, List<string> screenTexts, string? P_3)
	{
		AiVisionStepType? aiVisionStepType = action.Action.ToLowerInvariant() switch
		{
			"tap" => (AiVisionStepType?)AiVisionStepType.Tap, 
			"swipe" => AiVisionStepType.Swipe, 
			"text" => AiVisionStepType.Text, 
			_ => null, 
		};
		if (!aiVisionStepType.HasValue)
		{
			return null;
		}
		return new AiVisionFlowStep
		{
			Type = aiVisionStepType.Value,
			ResourceId = P_1?.ResourceId,
			ContentDesc = P_1?.ContentDesc,
			ElementText = P_1?.Text,
			ScreenTexts = screenTexts,
			X = action.X,
			Y = action.Y,
			X2 = action.X2,
			Y2 = action.Y2,
			Text = (P_3 ?? action.Text),
			IsMarkedComplete = true
		};
	}

	private static AiVisionCachedStep m_5857(AiVisionFlowStep P_0)
	{
		AiVisionCachedStep aiVisionCachedStep = new AiVisionCachedStep();
		AiVisionCachedStep aiVisionCachedStep2 = aiVisionCachedStep;
		aiVisionCachedStep2.Action = P_0.Type switch
		{
			AiVisionStepType.Tap => "tap", 
			AiVisionStepType.Swipe => "swipe", 
			AiVisionStepType.Text => "text", 
			_ => "", 
		};
		aiVisionCachedStep.ResourceId = P_0.ResourceId;
		aiVisionCachedStep.ContentDesc = P_0.ContentDesc;
		aiVisionCachedStep.ElementText = P_0.ElementText;
		aiVisionCachedStep.ScreenTexts = P_0.ScreenTexts;
		aiVisionCachedStep.DisambiguatorText = P_0.DisambiguatorText;
		aiVisionCachedStep.DisambiguatorX = P_0.DisambiguatorX;
		aiVisionCachedStep.DisambiguatorY = P_0.DisambiguatorY;
		aiVisionCachedStep.Text = P_0.Text;
		aiVisionCachedStep.X = P_0.X;
		aiVisionCachedStep.Y = P_0.Y;
		aiVisionCachedStep.X2 = P_0.X2;
		aiVisionCachedStep.Y2 = P_0.Y2;
		return aiVisionCachedStep;
	}

	private static int m_5858(IReadOnlyList<AiVisionFlowStep> P_0, int P_1)
	{
		for (int i = P_1 + 1; i < P_0.Count; i++)
		{
			if (P_0[i].Type == AiVisionStepType.AiGoal)
			{
				return i;
			}
		}
		return -1;
	}

	private static (string Label, UiElement? Element) m_5859(AiVisionAction P_0, IReadOnlyList<UiElement> P_1, int P_2, int P_3)
	{
		if (!P_0.Action.Equals("tap", StringComparison.OrdinalIgnoreCase) && !P_0.Action.Equals("swipe", StringComparison.OrdinalIgnoreCase))
		{
			return (Label: "", Element: null);
		}
		if (P_0.Action.Equals("tap", StringComparison.OrdinalIgnoreCase) && P_0.ElementIndex.HasValue && P_0.ElementIndex.Value >= 0 && P_0.ElementIndex.Value < P_1.Count)
		{
			UiElement uiElement = P_1[P_0.ElementIndex.Value];
			P_0.X = uiElement.CenterX;
			P_0.Y = uiElement.CenterY;
			return (Label: uiElement.Label, Element: uiElement);
		}
		P_0.X = P_0.X * P_2 / 1000;
		P_0.Y = P_0.Y * P_3 / 1000;
		P_0.X2 = P_0.X2 * P_2 / 1000;
		P_0.Y2 = P_0.Y2 * P_3 / 1000;
		return (Label: "", Element: null);
	}

	private static async Task<byte[]> m_5860(IDeviceController P_0, CancellationToken P_1)
	{
		byte[] array = await P_0.ScreenshotAsync(P_1);
		for (int i = 2; i <= 4; i++)
		{
			await Task.Delay(350, P_1);
			byte[] array2 = await P_0.ScreenshotAsync(P_1);
			if (((ReadOnlySpan<byte>)array2.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)array))
			{
				return array2;
			}
			array = array2;
		}
		return array;
	}

	private static void m_5861()
	{
		try
		{
			if (Directory.Exists(m_5846))
			{
				Directory.Delete(m_5846, recursive: true);
			}
		}
		catch
		{
		}
	}

	private static void m_5862(byte[] P_0, int P_1, int P_2)
	{
		try
		{
			Directory.CreateDirectory(m_5846);
			string path = $"{DateTime.Now:HHmmss}_buoc{P_1 + 1}_{P_2}.png";
			File.WriteAllBytes(Path.Combine(m_5846, path), P_0);
		}
		catch
		{
		}
	}

	private static Task m_5863(IDeviceController P_0, AiVisionAction P_1, CancellationToken P_2)
	{
		return P_1.Action.ToLowerInvariant() switch
		{
			"tap" => P_0.TapAsync(P_1.X, P_1.Y, P_2), 
			"swipe" => P_0.SwipeAsync(P_1.X, P_1.Y, P_1.X2, P_1.Y2, 400, P_2), 
			"text" => P_0.InputTextAsync(P_1.Text, P_2), 
			"keyevent" => P_0.KeyEventAsync(P_1.Text, P_2), 
			_ => Task.CompletedTask, 
		};
	}

	private static string m_5864(AiVisionAction P_0, string P_1)
	{
		return P_0.Action.ToLowerInvariant() switch
		{
			"tap" => string.IsNullOrEmpty(P_1) ? $"Tap ({P_0.X}, {P_0.Y})" : $"Tap \"{P_1}\" ({P_0.X}, {P_0.Y})", 
			"swipe" => $"Swipe ({P_0.X},{P_0.Y}) → ({P_0.X2},{P_0.Y2})", 
			"text" => "Gõ chữ: \"" + P_0.Text + "\"", 
			"keyevent" => "Phím: " + P_0.Text, 
			"done" => "Hoàn thành", 
			_ => "Chờ", 
		};
	}
}
