using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class ClaudeRequest
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private int m_2866;

	[CompilerGenerated]
	private object[] m_2867 = Array.Empty<object>();

	[JsonPropertyName("model")]
	public string Model
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("max_tokens")]
	public int MaxTokens
	{
		[CompilerGenerated]
		get
		{
			return m_2866;
		}
		[CompilerGenerated]
		set
		{
			m_2866 = value;
		}
	}

	[JsonPropertyName("messages")]
	public object[] Messages
	{
		[CompilerGenerated]
		get
		{
			return m_2867;
		}
		[CompilerGenerated]
		set
		{
			m_2867 = value;
		}
	}
}
