using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookPostCreationRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5267
	{
		public static readonly m_5267 A = new m_5267();

		public static Func<string, bool> m_5269;

		public static Func<string, bool> a;

		internal bool m_5270(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal bool m_5271(string P_0)
		{
			if (!P_0.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase) && !P_0.EndsWith(".mov", StringComparison.OrdinalIgnoreCase) && !P_0.EndsWith(".avi", StringComparison.OrdinalIgnoreCase) && !P_0.EndsWith(".mkv", StringComparison.OrdinalIgnoreCase) && !P_0.EndsWith(".webm", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.EndsWith(".m4v", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_5268
	{
		public ILocator[] A;

		public CancellationToken m_5272;

		internal async Task<ILocator?> m_5273(int P_0)
		{
			ILocator[] array = A;
			foreach (ILocator locator in array)
			{
				if (await m_5264(locator, P_0, m_5272))
				{
					return locator.First;
				}
			}
			return null;
		}
	}

	[CompilerGenerated]
	private sealed class B
	{
		public Action<AiVisionStepLog> A;

		public List<string> m_5280;

		public int m_5281;

		internal void m_5282(string P_0, string P_1)
		{
			m_5280.Add($"{m_5280.Count + 1}. {P_0}");
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_5281++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = P_1
			});
		}

		internal string m_5283(string P_0)
		{
			if (m_5280.Count != 0)
			{
				return P_0 + "\n\n— Nhật ký các bước —\n" + string.Join("\n", m_5280);
			}
			return P_0;
		}
	}

	private const string A = "https://www.facebook.com/?locale=en_US";

	private static readonly Regex m_5253 = new Regex("what's on your mind|bạn đang nghĩ gì|what are you thinking|create a post|create post|tạo bài viết|write something|viết gì đó", RegexOptions.IgnoreCase);

	private static readonly HashSet<string> m_5254 = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "post", "đăng", "next", "tiếp", "share", "chia sẻ" };

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, PostCreationSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		B CS_0024_003C_003E8__locals21 = new B();
		CS_0024_003C_003E8__locals21.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		int num = Math.Max(1, settings.PostCount);
		bool flag = settings.Contents.Any((string P_0) => !string.IsNullOrWhiteSpace(P_0));
		if (!settings.AttachImage || settings.PickMediaFiles().Count <= 0)
		{
			_ = settings.AttachVideo;
		}
		if (!flag && !settings.AttachImage && !settings.AttachVideo)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Bài viết trống: chưa nhập nội dung và cũng không đính kèm ảnh/video.",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		CS_0024_003C_003E8__locals21.m_5281 = 0;
		CS_0024_003C_003E8__locals21.m_5280 = new List<string>();
		int num2 = 0;
		AiVisionRunResult result;
		try
		{
			_ = 9;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await global::A.F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await global::A.F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals21.m_5282("Đang đăng nhập...", "Đăng bài viết");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals21.m_5280.Add($"{CS_0024_003C_003E8__locals21.m_5280.Count + 1}. {P_0}");
					CS_0024_003C_003E8__locals21.A(new AiVisionStepLog
					{
						FlowStepIndex = CS_0024_003C_003E8__locals21.m_5281++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = P_1
					});
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = CS_0024_003C_003E8__locals21.m_5283("Chưa đăng nhập được để đăng bài: " + loginResult.TrangThai),
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					CS_0024_003C_003E8__locals21.m_5282($"Đang đăng {num} bài viết...", "Đăng bài viết");
					for (int num4 = 0; num4 < num; num4++)
					{
						cancellationToken.ThrowIfCancellationRequested();
						string text = settings.PickContent();
						List<string> list = settings.PickMediaFiles();
						if (string.IsNullOrWhiteSpace(text) && list.Count == 0)
						{
							CS_0024_003C_003E8__locals21.m_5282($"[Bỏ qua] Bài {num4 + 1}: không có nội dung lẫn ảnh/video hợp lệ để đăng.", "Đăng bài viết");
							continue;
						}
						try
						{
							await PostSingleAsync(page2, $"Bài {num4 + 1}", text, list, settings.Audience, (string P_0, string P_1) =>
							{
								CS_0024_003C_003E8__locals21.m_5280.Add($"{CS_0024_003C_003E8__locals21.m_5280.Count + 1}. {P_0}");
								CS_0024_003C_003E8__locals21.A(new AiVisionStepLog
								{
									FlowStepIndex = CS_0024_003C_003E8__locals21.m_5281++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = P_1
								});
							}, cancellationToken);
							num2++;
							CS_0024_003C_003E8__locals21.m_5282($"Đã đăng bài {num4 + 1}/{num}" + ((list.Count > 0) ? $" (đính kèm {list.Count} file)." : "."), "Đăng bài viết");
						}
						catch (OperationCanceledException)
						{
							throw;
						}
						catch (Exception ex2)
						{
							CS_0024_003C_003E8__locals21.m_5282($"[Bỏ qua] Bài {num4 + 1} lỗi: {ex2.Message.Split('\n')[0].Trim()}", "Đăng bài viết");
							await a(page2, cancellationToken);
						}
						if (num4 < num - 1)
						{
							int num5 = settings.PickSpacingSeconds();
							CS_0024_003C_003E8__locals21.m_5282($"Nghỉ {num5}s trước bài kế tiếp...", "Đăng bài viết");
							await Task.Delay(TimeSpan.FromSeconds(num5), cancellationToken);
						}
					}
					if (settings2.SaveNewCookieAfterLogin)
					{
						await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
					}
					result = new AiVisionRunResult
					{
						Success = (num2 > 0),
						Message = CS_0024_003C_003E8__locals21.m_5283((num2 > 0) ? $"Đã đăng {num2}/{num} bài viết." : "Không đăng được bài nào - xem nhật ký các bước bên dưới."),
						TinhTrang = ((num2 > 0) ? "LIVE" : "ERROR")
					};
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = (num2 > 0),
					Message = CS_0024_003C_003E8__locals21.m_5283($"Đã dừng theo yêu cầu (đã đăng {num2}/{num} bài)."),
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex4)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = CS_0024_003C_003E8__locals21.m_5283("Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex4)),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	public static async Task PostSingleAsync(IPage page, string prefix, string? content, List<string> mediaFiles, string audience, Action<string, string> log, CancellationToken cancellationToken, bool skipNavigateToFeed = false)
	{
		bool flag = !skipNavigateToFeed;
		if (flag)
		{
			flag = !(await m_5262(page));
		}
		if (flag)
		{
			log("[" + prefix + "] Mở lại trang chủ facebook.com...", prefix);
			await page.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(Random.Shared.Next(2000, 3500), cancellationToken);
		}
		log("[" + prefix + "] Tìm & bấm ô soạn bài (\"Bạn đang nghĩ gì?\")...", prefix);
		ILocator locator = await m_5263(page, cancellationToken);
		ILocator locator2 = locator.Locator("xpath=ancestor::*[@role='dialog'][1]");
		if (await locator2.CountAsync() == 0)
		{
			locator2 = page.Locator("body");
		}
		if (!string.IsNullOrWhiteSpace(content))
		{
			log($"[{prefix}] Gõ nội dung ({content.Length} ký tự)...", prefix);
			await locator.ClickAsync(new LocatorClickOptions
			{
				Timeout = 8000f,
				Force = true
			});
			await Task.Delay(400, cancellationToken);
			await page.Keyboard.TypeAsync(content, new KeyboardTypeOptions
			{
				Delay = Random.Shared.Next(20, 60)
			});
			await Task.Delay(600, cancellationToken);
		}
		else
		{
			log("[" + prefix + "] Không có nội dung chữ - chỉ đăng media.", prefix);
		}
		if (mediaFiles.Count > 0)
		{
			log($"[{prefix}] Đính kèm {mediaFiles.Count} file, đang nạp vào ô chọn tệp...", prefix);
			ILocator first = locator2.Locator("input[type='file']").First;
			if (await first.CountAsync() == 0)
			{
				first = page.Locator("input[type='file']").First;
			}
			if (await first.CountAsync() == 0)
			{
				throw new Exception("Không tìm thấy ô chọn tệp (input[type=file]) để đính kèm ảnh/video.");
			}
			await first.SetInputFilesAsync(mediaFiles.ToArray());
			log("[" + prefix + "] Đã nạp file, chờ Facebook xử lý xong...", prefix);
			await m_5265(page, locator2, mediaFiles, cancellationToken);
		}
		await m_5261(page, locator2, audience, prefix, log, cancellationToken);
		await Task.Delay(1200, cancellationToken);
		await m_5255(page, locator2, prefix, log, cancellationToken);
	}

	private static async Task m_5255(IPage P_0, ILocator P_1, string P_2, Action<string, string> P_3, CancellationToken P_4)
	{
		for (int j = 0; j < 5; j++)
		{
			P_4.ThrowIfCancellationRequested();
			if (!(await m_5262(P_0)))
			{
				return;
			}
			(ILocator, string) tuple = await m_5256(P_0, P_1);
			var (locator, _) = tuple;
			_ = tuple.Item2;
			if (locator == null)
			{
				await Task.Delay(2000, P_4);
				if (!(await m_5262(P_0)))
				{
					return;
				}
				string text;
				(locator, text) = await m_5256(P_0, P_1);
				if (locator == null)
				{
					throw new Exception("Không tìm thấy nút Tiếp/Đăng (Next/Post) để hoàn tất đăng bài. " + text);
				}
			}
			await m_5266(locator, P_4);
			string text2 = await locator.First.GetAttributeAsync("aria-label");
			if (text2 == null)
			{
				text2 = await m_5257(locator.First);
			}
			string text3 = text2;
			P_3($"[{P_2}] Bấm \"{text3}\"...", P_2);
			await locator.First.ClickAsync(new LocatorClickOptions
			{
				Timeout = 10000f
			});
			await m_5260(P_0, P_1, text3, P_4);
		}
		if (await m_5262(P_0))
		{
			throw new Exception("Đã bấm nhiều lần Tiếp/Đăng nhưng khung soạn chưa đóng - có thể mạng chậm khi tải ảnh/video, tài khoản bị hạn chế, hoặc Facebook hỏi thêm bước lạ.");
		}
	}

	private static async Task<(ILocator? button, string diag)> m_5256(IPage P_0, ILocator P_1)
	{
		ILocator locator = P_1.Locator("[role='button']");
		int num = await locator.CountAsync();
		List<string> list = new List<string>();
		for (int num2 = num - 1; num2 >= 0; num2--)
		{
			ILocator locator2 = locator.Nth(num2);
			string text = ((await locator2.GetAttributeAsync("aria-label")) ?? "").Trim();
			string text2 = (await m_5257(locator2)).Trim();
			if (list.Count < 20 && (text.Length > 0 || text2.Length > 0))
			{
				list.Add($"[{text}|{text2}]");
			}
			if (m_5254.Contains(text) || m_5254.Contains(text2))
			{
				return (button: locator2, diag: "");
			}
		}
		string[] array = new string[6] { "Next", "Post", "Đăng", "Tiếp", "Share", "Chia sẻ" };
		foreach (string text3 in array)
		{
			ILocator locator2 = P_0.GetByText(text3, new PageGetByTextOptions
			{
				Exact = true
			});
			int num3 = await locator2.CountAsync();
			for (int j = 0; j < num3; j++)
			{
				bool flag;
				try
				{
					flag = await locator2.Nth(j).IsVisibleAsync();
				}
				catch
				{
					flag = false;
				}
				if (flag)
				{
					return (button: locator2.Nth(j), diag: "");
				}
			}
		}
		string item = ((list.Count > 0) ? ("Nút trong khung soạn (label|text): " + string.Join(" ", list)) : "không đọc được nút nào trong khung soạn.");
		return (button: null, diag: item);
	}

	private static async Task<string> m_5257(ILocator P_0)
	{
		try
		{
			return (await P_0.InnerTextAsync(new LocatorInnerTextOptions
			{
				Timeout = 1500f
			}))?.Trim() ?? "?";
		}
		catch
		{
			return "?";
		}
	}

	private static async Task<bool> m_5258(IPage P_0, string[] P_1, CancellationToken P_2, int P_3 = 8000)
	{
		foreach (string text in P_1)
		{
			P_2.ThrowIfCancellationRequested();
			ILocator byText = P_0.GetByText(text, new PageGetByTextOptions
			{
				Exact = true
			});
			int num = await byText.CountAsync();
			for (int k = 0; k < num; k++)
			{
				ILocator locator = byText.Nth(k);
				bool flag;
				try
				{
					flag = await locator.IsVisibleAsync();
				}
				catch
				{
					flag = false;
				}
				if (flag)
				{
					try
					{
						await locator.ClickAsync(new LocatorClickOptions
						{
							Timeout = P_3
						});
						return true;
					}
					catch (OperationCanceledException)
					{
						throw;
					}
					catch
					{
					}
				}
			}
		}
		return false;
	}

	private static Task<bool> a(IPage P_0, string[] P_1, CancellationToken P_2, int P_3 = 8000)
	{
		return m_5258(P_0, P_1, P_2, P_3);
	}

	private static async Task<bool> m_5259(IPage P_0, string[] P_1, CancellationToken P_2)
	{
		if (await m_5258(P_0, P_1, P_2))
		{
			return true;
		}
		HashSet<string> hashSet = new HashSet<string>(P_1, StringComparer.OrdinalIgnoreCase);
		ILocator locator = P_0.Locator("[role='radio'], [role='menuitemradio']");
		int num = await locator.CountAsync();
		for (int j = 0; j < num; j++)
		{
			P_2.ThrowIfCancellationRequested();
			ILocator locator2 = locator.Nth(j);
			string item = ((await locator2.GetAttributeAsync("aria-label")) ?? "").Trim();
			string item2 = (await m_5257(locator2)).Trim().Split('\n')[0].Trim();
			if (hashSet.Contains(item) || hashSet.Contains(item2))
			{
				try
				{
					await locator2.ClickAsync(new LocatorClickOptions
					{
						Timeout = 8000f
					});
					return true;
				}
				catch (OperationCanceledException)
				{
					throw;
				}
				catch
				{
					return false;
				}
			}
		}
		return false;
	}

	private static async Task m_5260(IPage P_0, ILocator P_1, string P_2, CancellationToken P_3)
	{
		for (int j = 0; j < 30000; j += 1200)
		{
			P_3.ThrowIfCancellationRequested();
			if (!(await m_5262(P_0)))
			{
				break;
			}
			ILocator item = (await m_5256(P_0, P_1)).Item1;
			if (item != null)
			{
				string text = await item.First.GetAttributeAsync("aria-label");
				if (text == null)
				{
					text = await m_5257(item.First);
				}
				bool flag = !string.Equals(text, P_2, StringComparison.OrdinalIgnoreCase);
				if (flag)
				{
					flag = await item.First.GetAttributeAsync("aria-disabled") != "true";
				}
				if (flag)
				{
					break;
				}
			}
			await Task.Delay(1200, P_3);
		}
	}

	private static async Task m_5261(IPage P_0, ILocator P_1, string P_2, string P_3, Action<string, string> P_4, CancellationToken P_5)
	{
		if (P_2 == "Keep")
		{
			return;
		}
		(string viLabel, string[] match)? tuple = new PostCreationSettings
		{
			Audience = P_2
		}.AudienceInfo();
		if (!tuple.HasValue)
		{
			return;
		}
		try
		{
			P_4($"[{P_3}] Đổi đối tượng sang \"{tuple.Value.viLabel}\"...", P_3);
			Regex nameRegex = new Regex("friends|public|only me|bạn bè|công khai|chỉ mình|audience|đối tượng", RegexOptions.IgnoreCase);
			ILocator first = P_1.GetByRole(AriaRole.Button, new LocatorGetByRoleOptions
			{
				NameRegex = nameRegex
			}).First;
			if (await first.CountAsync() == 0)
			{
				P_4("[" + P_3 + "] [Cảnh báo] Không thấy nút chọn đối tượng - đăng với đối tượng mặc định.", P_3);
				return;
			}
			await first.ClickAsync(new LocatorClickOptions
			{
				Timeout = 8000f
			});
			await Task.Delay(1200, P_5);
			if (!(await m_5259(P_0, tuple.Value.match, P_5)))
			{
				P_4($"[{P_3}] [Cảnh báo] Không thấy dòng \"{tuple.Value.viLabel}\" - đăng với đối tượng mặc định.", P_3);
				return;
			}
			await Task.Delay(600, P_5);
			bool flag = false;
			for (int j = 0; j < 6; j++)
			{
				if (flag)
				{
					break;
				}
				flag = await a(P_0, new string[2] { "Done", "Xong" }, P_5);
				if (!flag)
				{
					await Task.Delay(700, P_5);
				}
			}
			if (!flag)
			{
				P_4("[" + P_3 + "] [Cảnh báo] Không bấm được nút Done - đăng với đối tượng mặc định.", P_3);
				return;
			}
			await Task.Delay(1000, P_5);
			P_4($"[{P_3}] Đã đặt đối tượng \"{tuple.Value.viLabel}\" (đã bấm Done).", P_3);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			P_4($"[{P_3}] [Cảnh báo] Đổi đối tượng lỗi ({ex2.Message.Split('\n')[0].Trim()}) - đăng với đối tượng mặc định.", P_3);
		}
	}

	private static async Task<bool> m_5262(IPage P_0)
	{
		return await P_0.Locator("[role='dialog'] [contenteditable='true'][role='textbox']").CountAsync() > 0;
	}

	private static async Task<ILocator> m_5263(IPage P_0, CancellationToken P_1)
	{
		m_5268 obj = new m_5268();
		obj.m_5272 = P_1;
		obj.A = new ILocator[4]
		{
			P_0.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions
			{
				NameRegex = m_5253
			}),
			P_0.Locator("[role='dialog'] [contenteditable='true'][role='textbox']"),
			P_0.Locator("[role='dialog'] [contenteditable='true']"),
			P_0.Locator("div[contenteditable='true'][role='textbox']")
		};
		ILocator locator = await obj.m_5273(1500);
		if (locator != null)
		{
			return locator;
		}
		ILocator[] array = new ILocator[4]
		{
			P_0.GetByText(m_5253).First,
			P_0.GetByRole(AriaRole.Button, new PageGetByRoleOptions
			{
				NameRegex = m_5253
			}).First,
			P_0.Locator("div[role='button']").Filter(new LocatorFilterOptions
			{
				HasTextRegex = m_5253
			}).First,
			P_0.Locator("[aria-label*='Create post'], [aria-label*='Tạo bài viết'], [aria-label*='What\\'s on your mind'], [aria-label*='bạn đang nghĩ gì']").First
		};
		ILocator[] array2 = array;
		foreach (ILocator locator2 in array2)
		{
			if (await locator2.CountAsync() != 0)
			{
				try
				{
					await locator2.ClickAsync(new LocatorClickOptions
					{
						Timeout = 5000f,
						Force = true
					});
				}
				catch (Exception)
				{
					continue;
				}
				ILocator locator3 = await obj.m_5273(4000);
				if (locator3 != null)
				{
					return locator3;
				}
			}
		}
		ILocator locator4 = await obj.m_5273(4000);
		if (locator4 != null)
		{
			return locator4;
		}
		int value = await P_0.Locator("[role='dialog']").CountAsync();
		int value2 = await P_0.Locator("[contenteditable='true']").CountAsync();
		string url = P_0.Url;
		throw new Exception($"Bấm ô soạn bài nhưng không mở được khung soạn (hộp thoại đang mở: {value}, vùng nhập contenteditable: {value2}, url: {url}). " + "Có thể chưa đăng nhập xong, tài khoản bị hạn chế đăng bài, hoặc Facebook đổi giao diện.");
	}

	private static async Task<bool> m_5264(ILocator P_0, int P_1, CancellationToken P_2)
	{
		try
		{
			await P_0.First.WaitForAsync(new LocatorWaitForOptions
			{
				State = WaitForSelectorState.Visible,
				Timeout = P_1
			});
			return true;
		}
		catch (TimeoutException)
		{
			return false;
		}
		catch (PlaywrightException)
		{
			return false;
		}
	}

	private static async Task m_5265(IPage P_0, ILocator P_1, List<string> P_2, CancellationToken P_3)
	{
		int num = (P_2.Any((string text) => text.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".mov", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".avi", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".mkv", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".webm", StringComparison.OrdinalIgnoreCase) || text.EndsWith(".m4v", StringComparison.OrdinalIgnoreCase)) ? 180000 : 45000);
		for (int num2 = 0; num2 < num; num2 += 1000)
		{
			P_3.ThrowIfCancellationRequested();
			if (await P_1.Locator("img[src^='blob:'], img[src^='data:'], video").CountAsync() >= P_2.Count)
			{
				await Task.Delay(1500, P_3);
				break;
			}
			await Task.Delay(1000, P_3);
		}
	}

	private static async Task m_5266(ILocator P_0, CancellationToken P_1)
	{
		int num = 0;
		while (num < 180000)
		{
			P_1.ThrowIfCancellationRequested();
			if (await P_0.CountAsync() == 0)
			{
				await Task.Delay(1000, P_1);
				num += 1000;
				continue;
			}
			if (await P_0.First.GetAttributeAsync("aria-disabled") != "true")
			{
				break;
			}
			await Task.Delay(1000, P_1);
			num += 1000;
		}
	}

	private static async Task a(IPage P_0, CancellationToken P_1)
	{
		_ = 5;
		try
		{
			if (await P_0.Locator("[role='dialog']").CountAsync() != 0)
			{
				await P_0.Keyboard.PressAsync("Escape");
				await Task.Delay(800, P_1);
				ILocator first = P_0.Locator("[role='dialog'] [aria-label='Discard post'], [role='dialog'] [aria-label='Discard'], div[role='button']:has-text('Discard'), div[role='button']:has-text('Bỏ')").First;
				if (await first.CountAsync() > 0)
				{
					await first.ClickAsync(new LocatorClickOptions
					{
						Force = true,
						Timeout = 5000f
					});
					await Task.Delay(600, P_1);
				}
			}
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
		}
	}
}
