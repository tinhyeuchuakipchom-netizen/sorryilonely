using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class OpenAiChatMessage
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private object m_2896 = "";

	[JsonPropertyName("role")]
	public string Role
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("content")]
	public object Content
	{
		[CompilerGenerated]
		get
		{
			return m_2896;
		}
		[CompilerGenerated]
		set
		{
			m_2896 = value;
		}
	}
}
