using System;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class TikTokLikeSettings
{
	[CompilerGenerated]
	private int A = 5;

	[CompilerGenerated]
	private int a = 10;

	[CompilerGenerated]
	private int B = 3;

	[CompilerGenerated]
	private int b = 8;

	[CompilerGenerated]
	private int C = 90;

	public int MinCount
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxCount
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MinDelaySec
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MaxDelaySec
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int LikeRatePercent
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int PickCount()
	{
		if (MinCount < MaxCount)
		{
			return Random.Shared.Next(MinCount, MaxCount + 1);
		}
		return MinCount;
	}

	public int PickDelaySec()
	{
		if (MinDelaySec < MaxDelaySec)
		{
			return Random.Shared.Next(MinDelaySec, MaxDelaySec + 1);
		}
		return MinDelaySec;
	}

	public bool RollChance()
	{
		return Random.Shared.Next(0, 100) < LikeRatePercent;
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static TikTokLikeSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new TikTokLikeSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<TikTokLikeSettings>(json) ?? new TikTokLikeSettings();
		}
		catch
		{
			return new TikTokLikeSettings();
		}
	}
}
