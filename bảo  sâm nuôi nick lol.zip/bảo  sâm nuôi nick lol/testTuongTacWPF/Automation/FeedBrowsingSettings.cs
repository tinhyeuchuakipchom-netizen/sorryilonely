using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class FeedBrowsingSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5472
	{
		public static readonly m_5472 A = new m_5472();

		public static Func<string, bool> m_5473;

		internal bool m_5474(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private int A = 3;

	[CompilerGenerated]
	private int a = 8;

	[CompilerGenerated]
	private bool m_5456 = true;

	[CompilerGenerated]
	private int B = 30;

	[CompilerGenerated]
	private bool m_5457;

	[CompilerGenerated]
	private int b = 10;

	[CompilerGenerated]
	private List<string> m_5458 = new List<string> { "Hay quá \ud83d\ude0d", "Đẹp quá", "Thích cái này ghê", "Xem hoài không chán", "\ud83d\udd25\ud83d\udd25\ud83d\udd25" };

	[CompilerGenerated]
	private bool m_5459 = true;

	[CompilerGenerated]
	private bool m_5460 = true;

	[CompilerGenerated]
	private int C = 15;

	[CompilerGenerated]
	private bool m_5461 = true;

	[CompilerGenerated]
	private int c = 15;

	[CompilerGenerated]
	private bool m_5462;

	[CompilerGenerated]
	private int D = 20;

	[CompilerGenerated]
	private FriendRequestSettings m_5463 = new FriendRequestSettings();

	[CompilerGenerated]
	private bool m_5464;

	[CompilerGenerated]
	private int d = 5;

	[CompilerGenerated]
	private PostCreationSettings m_5465 = new PostCreationSettings();

	[CompilerGenerated]
	private bool m_5466;

	[CompilerGenerated]
	private int E = 5;

	[CompilerGenerated]
	private MessagingSettings m_5467 = new MessagingSettings();

	[CompilerGenerated]
	private bool m_5468;

	[CompilerGenerated]
	private int e = 5;

	[CompilerGenerated]
	private PageCreationSettings m_5469 = new PageCreationSettings();

	[CompilerGenerated]
	private bool m_5470;

	[CompilerGenerated]
	private PageFarmingSettings m_5471 = new PageFarmingSettings();

	public int MinMinutes
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxMinutes
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool AutoLike
	{
		[CompilerGenerated]
		get
		{
			return m_5456;
		}
		[CompilerGenerated]
		set
		{
			m_5456 = value;
		}
	}

	public int LikeChancePercent
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public bool AutoComment
	{
		[CompilerGenerated]
		get
		{
			return m_5457;
		}
		[CompilerGenerated]
		set
		{
			m_5457 = value;
		}
	}

	public int CommentChancePercent
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public List<string> CommentTexts
	{
		[CompilerGenerated]
		get
		{
			return m_5458;
		}
		[CompilerGenerated]
		set
		{
			m_5458 = value;
		}
	}

	public bool WatchReels
	{
		[CompilerGenerated]
		get
		{
			return m_5459;
		}
		[CompilerGenerated]
		set
		{
			m_5459 = value;
		}
	}

	public bool ViewOtherProfiles
	{
		[CompilerGenerated]
		get
		{
			return m_5460;
		}
		[CompilerGenerated]
		set
		{
			m_5460 = value;
		}
	}

	public int ViewOtherProfilesChancePercent
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public bool ViewComments
	{
		[CompilerGenerated]
		get
		{
			return m_5461;
		}
		[CompilerGenerated]
		set
		{
			m_5461 = value;
		}
	}

	public int ViewCommentsChancePercent
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public bool AutoAddFriend
	{
		[CompilerGenerated]
		get
		{
			return m_5462;
		}
		[CompilerGenerated]
		set
		{
			m_5462 = value;
		}
	}

	public int AddFriendChancePercent
	{
		[CompilerGenerated]
		get
		{
			return D;
		}
		[CompilerGenerated]
		set
		{
			D = value;
		}
	}

	public FriendRequestSettings FriendRequest
	{
		[CompilerGenerated]
		get
		{
			return m_5463;
		}
		[CompilerGenerated]
		set
		{
			m_5463 = value;
		}
	}

	public bool AutoPost
	{
		[CompilerGenerated]
		get
		{
			return m_5464;
		}
		[CompilerGenerated]
		set
		{
			m_5464 = value;
		}
	}

	public int PostChancePercent
	{
		[CompilerGenerated]
		get
		{
			return d;
		}
		[CompilerGenerated]
		set
		{
			d = value;
		}
	}

	public PostCreationSettings Post
	{
		[CompilerGenerated]
		get
		{
			return m_5465;
		}
		[CompilerGenerated]
		set
		{
			m_5465 = value;
		}
	}

	public bool AutoMessage
	{
		[CompilerGenerated]
		get
		{
			return m_5466;
		}
		[CompilerGenerated]
		set
		{
			m_5466 = value;
		}
	}

	public int MessageChancePercent
	{
		[CompilerGenerated]
		get
		{
			return E;
		}
		[CompilerGenerated]
		set
		{
			E = value;
		}
	}

	public MessagingSettings Messaging
	{
		[CompilerGenerated]
		get
		{
			return m_5467;
		}
		[CompilerGenerated]
		set
		{
			m_5467 = value;
		}
	}

	public bool AutoCreatePage
	{
		[CompilerGenerated]
		get
		{
			return m_5468;
		}
		[CompilerGenerated]
		set
		{
			m_5468 = value;
		}
	}

	public int CreatePageChancePercent
	{
		[CompilerGenerated]
		get
		{
			return e;
		}
		[CompilerGenerated]
		set
		{
			e = value;
		}
	}

	public PageCreationSettings PageCreation
	{
		[CompilerGenerated]
		get
		{
			return m_5469;
		}
		[CompilerGenerated]
		set
		{
			m_5469 = value;
		}
	}

	public bool AutoFarmPage
	{
		[CompilerGenerated]
		get
		{
			return m_5470;
		}
		[CompilerGenerated]
		set
		{
			m_5470 = value;
		}
	}

	public PageFarmingSettings PageFarming
	{
		[CompilerGenerated]
		get
		{
			return m_5471;
		}
		[CompilerGenerated]
		set
		{
			m_5471 = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static FeedBrowsingSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new FeedBrowsingSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<FeedBrowsingSettings>(json) ?? new FeedBrowsingSettings();
		}
		catch (JsonException)
		{
			return new FeedBrowsingSettings();
		}
	}

	public int PickDurationMinutes()
	{
		if (MinMinutes < MaxMinutes)
		{
			return Random.Shared.Next(MinMinutes, MaxMinutes + 1);
		}
		return MinMinutes;
	}

	public bool RollChance(int percent)
	{
		return Random.Shared.Next(0, 100) < percent;
	}

	public string? PickCommentText()
	{
		List<string> list = CommentTexts.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}
}
