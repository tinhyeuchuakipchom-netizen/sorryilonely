using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookFriendRequestRunner
{
	[CompilerGenerated]
	private sealed class m_4334
	{
		public Action<AiVisionStepLog> A;

		public int m_4335;

		internal void m_4336(string P_0, string P_1)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_4335++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = P_1
			});
		}
	}

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, FriendRequestSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		m_4334 CS_0024_003C_003E8__locals19 = new m_4334();
		CS_0024_003C_003E8__locals19.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		CS_0024_003C_003E8__locals19.m_4335 = 0;
		List<string> list = new List<string>();
		bool flag = settings.Action == FriendRequestAction.ConfirmIncoming;
		if (!flag && settings.Source != FriendRequestSource.GroupPosters)
		{
			list = FacebookFriendRequestActions.LoadTargetsFromList(nick, settings);
			if (list.Count == 0)
			{
				return new AiVisionRunResult
				{
					Success = false,
					TinhTrang = "ERROR",
					Message = ((settings.Source == FriendRequestSource.NickFolder) ? ("Thư mục \"" + settings.NickFolderName + "\" không có nick nào có UID để kết bạn.") : "Chưa nạp UID nào để kết bạn.")
				};
			}
		}
		HashSet<string> hashSet = FacebookFriendRequestActions.LoadSentUids(nick);
		int num = 0;
		int num2 = 0;
		string browserProfileId = nick.BrowserProfileId;
		AiVisionRunResult result;
		try
		{
			_ = 9;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals19.m_4336("Đang đăng nhập...", "Kết bạn");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals19.A(new AiVisionStepLog
					{
						FlowStepIndex = CS_0024_003C_003E8__locals19.m_4335++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = P_1
					});
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để kết bạn: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else if (flag)
				{
					CS_0024_003C_003E8__locals19.m_4336("Đang xác nhận lời mời kết bạn người khác gửi đến...", "Kết bạn");
					int value = await FacebookFriendRequestActions.ConfirmIncomingRequestsAsync(page2, settings.MaxConfirmsPerRun, (string P_0, string P_1) =>
					{
						CS_0024_003C_003E8__locals19.A(new AiVisionStepLog
						{
							FlowStepIndex = CS_0024_003C_003E8__locals19.m_4335++,
							SubStep = 1,
							ActionSummary = P_0,
							Reason = P_1
						});
					}, cancellationToken);
					result = new AiVisionRunResult
					{
						Success = true,
						Message = $"Đã xác nhận {value} lời mời kết bạn.",
						TinhTrang = ""
					};
				}
				else
				{
					if (settings.Source != FriendRequestSource.GroupPosters)
					{
						goto IL_08be;
					}
					CS_0024_003C_003E8__locals19.m_4336("Đang lướt nhóm để tìm người đăng bài...", "Kết bạn");
					list = await A(page2, settings, hashSet, (string P_0, string P_1) =>
					{
						CS_0024_003C_003E8__locals19.A(new AiVisionStepLog
						{
							FlowStepIndex = CS_0024_003C_003E8__locals19.m_4335++,
							SubStep = 1,
							ActionSummary = P_0,
							Reason = P_1
						});
					}, cancellationToken);
					if (list.Count != 0)
					{
						goto IL_08be;
					}
					result = new AiVisionRunResult
					{
						Success = true,
						Message = "Đã lướt hết nhóm nhưng không tìm thấy người đăng bài mới nào để kết bạn.",
						TinhTrang = ""
					};
				}
				goto end_IL_0434;
				IL_08be:
				CS_0024_003C_003E8__locals19.m_4336($"Có {list.Count} người trong danh sách, bắt đầu gửi lời mời...", "Kết bạn");
				foreach (string item2 in list)
				{
					cancellationToken.ThrowIfCancellationRequested();
					if (num >= settings.MaxRequestsPerRun)
					{
						CS_0024_003C_003E8__locals19.m_4336($"Đã đủ {settings.MaxRequestsPerRun} lời mời cho lượt này, dừng lại.", "Kết bạn");
						break;
					}
					if (hashSet.Contains(item2))
					{
						num2++;
						continue;
					}
					FriendRequestOutcome friendRequestOutcome = await FacebookFriendRequestActions.TrySendToUidAsync(page2, item2, cancellationToken);
					if (friendRequestOutcome != FriendRequestOutcome.Error)
					{
						hashSet.Add(item2);
						FacebookFriendRequestActions.SaveSentUids(nick, hashSet);
					}
					switch (friendRequestOutcome)
					{
					case FriendRequestOutcome.Sent:
						num++;
						CS_0024_003C_003E8__locals19.m_4336($"Đã gửi lời mời kết bạn tới {item2} ({num}/{settings.MaxRequestsPerRun}).", "Kết bạn");
						break;
					case FriendRequestOutcome.AlreadyFriend:
						num2++;
						CS_0024_003C_003E8__locals19.m_4336("[Bỏ qua] " + item2 + " đã là bạn bè.", "Kết bạn");
						break;
					case FriendRequestOutcome.AlreadyRequested:
						num2++;
						CS_0024_003C_003E8__locals19.m_4336("[Bỏ qua] " + item2 + " đã được gửi lời mời từ trước.", "Kết bạn");
						break;
					case FriendRequestOutcome.NoButton:
						num2++;
						CS_0024_003C_003E8__locals19.m_4336("[Bỏ qua] " + item2 + " không có nút Kết bạn (trang bị khoá/không tồn tại/chặn kết bạn).", "Kết bạn");
						break;
					default:
						num2++;
						CS_0024_003C_003E8__locals19.m_4336("[Bỏ qua] Không mở được trang cá nhân của " + item2 + ".", "Kết bạn");
						break;
					}
					if (friendRequestOutcome == FriendRequestOutcome.Sent && num < settings.MaxRequestsPerRun)
					{
						int num4 = settings.PickDelaySeconds();
						CS_0024_003C_003E8__locals19.m_4336($"Chờ {num4}s trước lời mời tiếp theo...", "Kết bạn");
						await Task.Delay(TimeSpan.FromSeconds(num4), cancellationToken);
					}
				}
				result = new AiVisionRunResult
				{
					Success = true,
					Message = $"Kết bạn xong: đã gửi {num} lời mời, bỏ qua {num2}.",
					TinhTrang = ""
				};
				end_IL_0434:;
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = $"Đã dừng kịch bản kết bạn (đã gửi {num} lời mời).",
					TinhTrang = ""
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi kết bạn: " + ex2.Message,
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			FacebookFriendRequestActions.SaveSentUids(nick, hashSet);
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static async Task<List<string>> A(IPage P_0, FriendRequestSettings P_1, HashSet<string> P_2, Action<string, string> P_3, CancellationToken P_4)
	{
		string url = (string.IsNullOrWhiteSpace(P_1.GroupLink) ? "https://www.facebook.com/groups/feed/?locale=en_US" : P_1.GroupLink.Trim());
		try
		{
			await P_0.GotoAsync(FacebookUrls.WithEnglishLocale(url), new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			P_3("[Bỏ qua] Không mở được nhóm: " + ex.Message, "Kết bạn");
			return new List<string>();
		}
		await Task.Delay(Random.Shared.Next(2500, 4000), P_4);
		List<string> list = new List<string>();
		HashSet<string> hashSet = new HashSet<string>();
		Regex regex = new Regex("/groups/[^/]+/user/(\\d+)", RegexOptions.IgnoreCase);
		for (int i = 0; i < P_1.MaxScrolls; i++)
		{
			if (list.Count >= P_1.MaxRequestsPerRun)
			{
				break;
			}
			P_4.ThrowIfCancellationRequested();
			foreach (IElementHandle item in await P_0.QuerySelectorAllAsync("a[href*='/user/']"))
			{
				string text = await item.GetAttributeAsync("href");
				if (string.IsNullOrEmpty(text))
				{
					continue;
				}
				Match match = regex.Match(text);
				if (!match.Success)
				{
					continue;
				}
				string value = match.Groups[1].Value;
				if (hashSet.Add(value) && !P_2.Contains(value))
				{
					list.Add(value);
					if (list.Count >= P_1.MaxRequestsPerRun)
					{
						break;
					}
				}
			}
			await P_0.Mouse.WheelAsync(0f, Random.Shared.Next(600, 1100));
			await Task.Delay(Random.Shared.Next(1500, 3000), P_4);
		}
		P_3($"Đã tìm được {list.Count} người đăng bài trong nhóm.", "Kết bạn");
		return list;
	}
}
