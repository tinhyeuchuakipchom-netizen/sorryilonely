using System.Collections.Generic;
using System.Runtime.CompilerServices;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public class ScriptExportDocument
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private List<AiVisionFlowStep> m_3031 = new List<AiVisionFlowStep>();

	public string Name
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Platform
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public List<AiVisionFlowStep> Steps
	{
		[CompilerGenerated]
		get
		{
			return m_3031;
		}
		[CompilerGenerated]
		set
		{
			m_3031 = value;
		}
	}
}
