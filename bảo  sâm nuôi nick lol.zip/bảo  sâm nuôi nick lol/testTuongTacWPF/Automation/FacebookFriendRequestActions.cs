using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using testTuongTacWPF.Data;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookFriendRequestActions
{
	[Serializable]
	[CompilerGenerated]
	private sealed class A
	{
		public static readonly A m_4294 = new A();

		public static Func<FacebookAccountRow, string> m_4295;

		public static Func<string, string> m_4296;

		internal string m_4297(FacebookAccountRow P_0)
		{
			return P_0.Uid;
		}

		internal string m_4298(string P_0)
		{
			return P_0?.Trim() ?? "";
		}
	}

	[CompilerGenerated]
	private sealed class a
	{
		public FriendRequestSettings A;

		public FacebookAccountRow m_4299;

		internal bool m_4300(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A.NickFolderId;
		}

		internal bool m_4301(string P_0)
		{
			if (P_0.Length > 0)
			{
				return !P_0.Equals(m_4299.Uid?.Trim(), StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}
	}

	public const string AddFriendSelector = "[role='button'][aria-label^='Add Friend'], [role='button'][aria-label^='Add friend']";

	public const string CancelRequestSelector = "[role='button'][aria-label^='Cancel Request'], [role='button'][aria-label^='Cancel request']";

	public const string AlreadyFriendSelector = "[role='button'][aria-label^='Friends']";

	public static async Task<FriendRequestOutcome> TrySendOnCurrentProfileAsync(IPage page, CancellationToken cancellationToken)
	{
		ILocator first = page.Locator("[role='button'][aria-label^='Add Friend'], [role='button'][aria-label^='Add friend']").First;
		if (await first.CountAsync() == 0)
		{
			if (await page.Locator("[role='button'][aria-label^='Friends']").CountAsync() > 0)
			{
				return FriendRequestOutcome.AlreadyFriend;
			}
			if (await page.Locator("[role='button'][aria-label^='Cancel Request'], [role='button'][aria-label^='Cancel request']").CountAsync() > 0)
			{
				return FriendRequestOutcome.AlreadyRequested;
			}
			return FriendRequestOutcome.NoButton;
		}
		await ClickRobustAsync(first, cancellationToken);
		await Task.Delay(Random.Shared.Next(1500, 2500), cancellationToken);
		if (await page.Locator("[role='button'][aria-label^='Add Friend'], [role='button'][aria-label^='Add friend']").CountAsync() == 0)
		{
			return FriendRequestOutcome.Sent;
		}
		await CloseAnyOpenDialogAsync(page, cancellationToken);
		return FriendRequestOutcome.NoButton;
	}

	public static async Task ClickRobustAsync(ILocator locator, CancellationToken cancellationToken)
	{
		await locator.ScrollIntoViewIfNeededAsync();
		await Task.Delay(400, cancellationToken);
		try
		{
			await locator.ClickAsync(new LocatorClickOptions
			{
				Timeout = 8000f
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			await locator.ClickAsync(new LocatorClickOptions
			{
				Force = true,
				Timeout = 5000f
			});
		}
	}

	public static async Task CloseAnyOpenDialogAsync(IPage page, CancellationToken cancellationToken)
	{
		ILocator locator = page.Locator("[role='dialog'] [aria-label='Close'][role='button']");
		if (await locator.CountAsync() != 0 && await locator.First.IsVisibleAsync())
		{
			await ClickRobustAsync(locator.First, cancellationToken);
			await Task.Delay(800, cancellationToken);
		}
	}

	public static async Task<int> ConfirmIncomingRequestsAsync(IPage page, int maxConfirms, Action<string, string> log, CancellationToken cancellationToken)
	{
		try
		{
			await page.GotoAsync("https://www.facebook.com/friends/requests?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			log("[Bỏ qua] Không mở được trang lời mời kết bạn: " + ex.Message, "Kết bạn - Xác nhận");
			return 0;
		}
		await Task.Delay(Random.Shared.Next(2500, 4000), cancellationToken);
		int num = 0;
		while (num < maxConfirms)
		{
			cancellationToken.ThrowIfCancellationRequested();
			ILocator first = page.GetByRole(AriaRole.Button, new PageGetByRoleOptions
			{
				Name = "Confirm",
				Exact = true
			}).First;
			if (await first.CountAsync() == 0)
			{
				break;
			}
			try
			{
				await ClickRobustAsync(first, cancellationToken);
			}
			catch (Exception ex2) when (!(ex2 is OperationCanceledException))
			{
				log("[Bỏ qua] Không bấm được nút xác nhận: " + ex2.Message, "Kết bạn - Xác nhận");
				break;
			}
			num++;
			log($"Đã xác nhận {num} lời mời kết bạn.", "Kết bạn - Xác nhận");
			await Task.Delay(Random.Shared.Next(1500, 3000), cancellationToken);
		}
		if (num == 0)
		{
			log("Không có lời mời kết bạn nào đang chờ xác nhận.", "Kết bạn - Xác nhận");
		}
		return num;
	}

	public static async Task<FriendRequestOutcome> TrySendToUidAsync(IPage page, string uid, CancellationToken cancellationToken)
	{
		try
		{
			await page.GotoAsync("https://www.facebook.com/" + uid + "?locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
			return FriendRequestOutcome.Error;
		}
		await Task.Delay(Random.Shared.Next(2500, 4500), cancellationToken);
		return await TrySendOnCurrentProfileAsync(page, cancellationToken);
	}

	public static List<string> LoadTargetsFromList(FacebookAccountRow nick, FriendRequestSettings settings)
	{
		IEnumerable<string> source;
		if (settings.Source != FriendRequestSource.NickFolder)
		{
			IEnumerable<string> uids = settings.Uids;
			source = uids;
		}
		else
		{
			source = from P_0 in FacebookAccountDatabase.LoadAll()
				where P_0.FolderId == settings.NickFolderId
				select P_0.Uid;
		}
		return (from P_0 in source
			select P_0?.Trim() ?? "" into P_0
			where P_0.Length > 0 && !P_0.Equals(nick.Uid?.Trim(), StringComparison.OrdinalIgnoreCase)
			select P_0).Distinct().ToList();
	}

	public static HashSet<string> LoadSentUids(FacebookAccountRow nick)
	{
		if (string.IsNullOrWhiteSpace(nick.FriendRequestSentJson))
		{
			return new HashSet<string>();
		}
		try
		{
			List<string> list = JsonSerializer.Deserialize<List<string>>(nick.FriendRequestSentJson);
			return (list == null) ? new HashSet<string>() : new HashSet<string>(list);
		}
		catch (JsonException)
		{
			return new HashSet<string>();
		}
	}

	public static void SaveSentUids(FacebookAccountRow nick, HashSet<string> sentUids)
	{
		nick.FriendRequestSentJson = JsonSerializer.Serialize(sentUids.ToList());
	}
}
