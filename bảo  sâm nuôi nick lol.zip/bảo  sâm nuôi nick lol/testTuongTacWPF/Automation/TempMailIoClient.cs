using System;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;

namespace testTuongTacWPF.Automation;

public class TempMailIoClient : IVerifyMailTestClient, IAsyncDisposable
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6181
	{
		public static readonly m_6181 A = new m_6181();

		public static Func<int> m_6184;

		public static Func<BrowserContextCookiesResult, string> m_6185;

		internal int m_6186()
		{
			return Program.Main(new string[2] { "install", "chromium" });
		}

		internal string m_6187(BrowserContextCookiesResult P_0)
		{
			return P_0.Name + "=" + P_0.Value;
		}
	}

	private const string A = "https://tempmail.io/";

	private const string a = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

	private readonly string? B;

	private readonly HttpClient m_6178 = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private string? b;

	private static bool m_6179;

	private static Task m_6180()
	{
		if (m_6179)
		{
			return Task.CompletedTask;
		}
		m_6179 = true;
		return Task.Run(() => Program.Main(new string[2] { "install", "chromium" }));
	}

	public TempMailIoClient(string? proxy = null)
	{
		B = proxy;
	}

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		await m_6180();
		ct.ThrowIfCancellationRequested();
		using IPlaywright playwright = await Playwright.CreateAsync();
		string result;
		await using (IBrowser browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
		{
			Headless = true,
			Args = new string[1] { "--disable-blink-features=AutomationControlled" },
			Proxy = g.A(B)
		}))
		{
			using (g.A(ct, browser))
			{
				int num = 0;
				_ = 6;
				try
				{
					IBrowserContext browserContext = await browser.NewContextAsync(new BrowserNewContextOptions
					{
						UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
						ViewportSize = new ViewportSize
						{
							Width = 1280,
							Height = 800
						}
					});
					await browserContext.AddInitScriptAsync("Object.defineProperty(navigator, 'webdriver', { get: () => undefined });");
					IPage page = await browserContext.NewPageAsync();
					string text = "";
					for (int i = 0; i < 5; i++)
					{
						await page.GotoAsync("https://tempmail.io/", new PageGotoOptions
						{
							WaitUntil = WaitUntilState.DOMContentLoaded
						});
						await page.WaitForFunctionAsync("() => { const el = document.querySelector('#email'); return !!(el && el.value && el.value.includes('@')); }", new PageWaitForFunctionOptions
						{
							Timeout = 20000f
						});
						text = await page.Locator("#email").InputValueAsync();
						if (!text.Contains(".club", StringComparison.OrdinalIgnoreCase))
						{
							break;
						}
					}
					if (string.IsNullOrWhiteSpace(text) || !text.Contains('@'))
					{
						throw new InvalidOperationException("Không đọc được địa chỉ mail từ tempmail.io (có thể site đã đổi giao diện).");
					}
					b = string.Join("; ", (await browserContext.CookiesAsync()).Select((BrowserContextCookiesResult P_0) => P_0.Name + "=" + P_0.Value));
					result = text;
				}
				catch (Exception) when (ct.IsCancellationRequested)
				{
					throw new OperationCanceledException(ct);
				}
			}
		}
		return result;
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (b == null)
		{
			throw new InvalidOperationException("Chưa lấy địa chỉ mail - bấm \"Thử lấy mail\" trước.");
		}
		using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, "https://tempmail.io/scripts.php");
		httpRequestMessage.Headers.Add("Accept", "application/json, text/plain, */*");
		httpRequestMessage.Headers.Add("Accept-Language", "vi");
		httpRequestMessage.Headers.TryAddWithoutValidation("Cookie", b);
		httpRequestMessage.Headers.Add("Origin", "https://tempmail.io");
		httpRequestMessage.Headers.Add("Referer", "https://tempmail.io/");
		httpRequestMessage.Headers.Add("Sec-Fetch-Dest", "empty");
		httpRequestMessage.Headers.Add("Sec-Fetch-Mode", "cors");
		httpRequestMessage.Headers.Add("Sec-Fetch-Site", "same-origin");
		httpRequestMessage.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
		httpRequestMessage.Headers.Add("sec-ch-ua", "\"Chromium\";v=\"131\", \"Google Chrome\";v=\"131\", \"Not?A_Brand\";v=\"99\"");
		httpRequestMessage.Headers.Add("sec-ch-ua-mobile", "?0");
		httpRequestMessage.Headers.Add("sec-ch-ua-platform", "\"Windows\"");
		httpRequestMessage.Content = new MultipartFormDataContent { 
		{
			new StringContent("messages"),
			"action"
		} };
		using HttpResponseMessage httpResponseMessage = await m_6178.SendAsync(httpRequestMessage);
		string text = await httpResponseMessage.Content.ReadAsStringAsync();
		if (!text.Contains("href=\"/view/"))
		{
			return null;
		}
		string text2 = f.A(text, "href=\"/view/", "\"");
		if (string.IsNullOrEmpty(text2))
		{
			return null;
		}
		using HttpRequestMessage httpRequestMessage2 = new HttpRequestMessage(HttpMethod.Get, "https://tempmail.io/view/" + text2);
		httpRequestMessage2.Headers.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
		httpRequestMessage2.Headers.Add("Accept-Language", "vi");
		httpRequestMessage2.Headers.TryAddWithoutValidation("Cookie", b);
		httpRequestMessage2.Headers.Add("Referer", "https://tempmail.io/");
		httpRequestMessage2.Headers.Add("Sec-Fetch-Dest", "document");
		httpRequestMessage2.Headers.Add("Sec-Fetch-Mode", "navigate");
		httpRequestMessage2.Headers.Add("Sec-Fetch-Site", "same-origin");
		httpRequestMessage2.Headers.Add("Sec-Fetch-User", "?1");
		httpRequestMessage2.Headers.Add("Upgrade-Insecure-Requests", "1");
		httpRequestMessage2.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
		httpRequestMessage2.Headers.Add("sec-ch-ua", "\"Chromium\";v=\"131\", \"Google Chrome\";v=\"131\", \"Not?A_Brand\";v=\"99\"");
		httpRequestMessage2.Headers.Add("sec-ch-ua-mobile", "?0");
		httpRequestMessage2.Headers.Add("sec-ch-ua-platform", "\"Windows\"");
		using HttpResponseMessage httpResponseMessage2 = await m_6178.SendAsync(httpRequestMessage2);
		Match match = Regex.Match(await httpResponseMessage2.Content.ReadAsStringAsync(), "\\b(\\d{5})\\b");
		return match.Success ? match.Groups[1].Value : null;
	}

	public ValueTask DisposeAsync()
	{
		m_6178.Dispose();
		return ValueTask.CompletedTask;
	}
}
