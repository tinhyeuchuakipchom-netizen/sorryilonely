using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookBmCreationRunner
{
	public class BmCreateSingleResult
	{
		[CompilerGenerated]
		private bool A;

		[CompilerGenerated]
		private bool a;

		[CompilerGenerated]
		private string m_3975 = "";

		[CompilerGenerated]
		private string m_3976 = "";

		public bool Success
		{
			[CompilerGenerated]
			get
			{
				return A;
			}
			[CompilerGenerated]
			set
			{
				A = value;
			}
		}

		public bool IsLimitBlocked
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public string CreatedBmId
		{
			[CompilerGenerated]
			get
			{
				return m_3975;
			}
			[CompilerGenerated]
			set
			{
				m_3975 = value;
			}
		}

		public string CreatedBmName
		{
			[CompilerGenerated]
			get
			{
				return m_3976;
			}
			[CompilerGenerated]
			set
			{
				m_3976 = value;
			}
		}

		public static implicit operator bool(BmCreateSingleResult res)
		{
			return res?.Success ?? false;
		}
	}

	[CompilerGenerated]
	private sealed class m_3970
	{
		public Action<AiVisionStepLog> A;

		public int m_3977;

		internal void m_3978(string P_0)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_3977++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = "Tạo BM"
			});
		}

		internal void m_3979(string P_0, string P_1)
		{
			m_3978(P_0);
		}
	}

	private const string A = "https://business.facebook.com/latest/settings/business_overview";

	private const string a = "https://business.facebook.com/overview";

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, BmCreationSettings bmSettings, int sequenceIndex)
	{
		m_3970 CS_0024_003C_003E8__locals9 = new m_3970();
		CS_0024_003C_003E8__locals9.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		CS_0024_003C_003E8__locals9.m_3977 = 0;
		AiVisionRunResult result;
		try
		{
			_ = 8;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await F.A(client, settings, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await F.A(client, settings, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals9.m_3978("Đang đăng nhập và kiểm tra ngôn ngữ...");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals9.m_3978(P_0);
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để tạo BM: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					int num2 = Math.Max(1, bmSettings.BmCount);
					int num3 = 0;
					int num4 = 0;
					while (true)
					{
						if (num4 < num2)
						{
							cancellationToken.ThrowIfCancellationRequested();
							CS_0024_003C_003E8__locals9.m_3978($"[{num4 + 1}/{num2}] Đang tiến hành tạo Business Manager (BM)...");
							BmCreateSingleResult bmCreateSingleResult = await CreateSingleBmOnPageAsync(page2, bmSettings, sequenceIndex + num4, (string P_0) =>
							{
								CS_0024_003C_003E8__locals9.A(new AiVisionStepLog
								{
									FlowStepIndex = CS_0024_003C_003E8__locals9.m_3977++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = "Tạo BM"
								});
							}, cancellationToken);
							if (bmCreateSingleResult.IsLimitBlocked)
							{
								CS_0024_003C_003E8__locals9.m_3978("Cảnh báo: Tài khoản bị giới hạn tạo BM từ Facebook (Limit Reached For The Number Of Businesses).");
								result = new AiVisionRunResult
								{
									Success = false,
									Message = "Bị giới hạn tạo BM: Facebook thông báo nick đã đạt giới hạn số lượng Doanh nghiệp có thể tạo lúc này.",
									TinhTrang = "LIMIT_BM"
								};
								break;
							}
							if (bmCreateSingleResult.Success)
							{
								num3++;
							}
							if (num4 < num2 - 1)
							{
								int num5 = Math.Max(1, bmSettings.MinDelaySeconds);
								int num6 = Math.Max(num5, bmSettings.MaxDelaySeconds);
								int num7 = Random.Shared.Next(num5, num6 + 1);
								CS_0024_003C_003E8__locals9.m_3978($"Đã tạo xong {num4 + 1}/{num2} BM. Nghỉ {num7}s trước khi tạo BM tiếp theo...");
								await Task.Delay(num7 * 1000, cancellationToken);
							}
							num4++;
							continue;
						}
						if (settings.SaveNewCookieAfterLogin)
						{
							await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
						}
						result = ((num3 > 0) ? new AiVisionRunResult
						{
							Success = true,
							Message = $"Đã tạo thành công {num3}/{num2} BM trên Chrome.",
							TinhTrang = "LIVE"
						} : new AiVisionRunResult
						{
							Success = false,
							Message = $"Không tạo được BM nào (0/{num2}) - kiểm tra lại thủ công.",
							TinhTrang = "ERROR"
						});
						break;
					}
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex2),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	public static async Task<BmCreateSingleResult> CreateSingleBmOnPageAsync(IPage page, BmCreationSettings bmSettings, int sequenceIndex, Action<string> log, CancellationToken cancellationToken)
	{
		if (!page.Url.Contains("business.facebook.com"))
		{
			log("Đang mở trang Business Manager...");
			try
			{
				await page.GotoAsync("https://business.facebook.com/overview", new PageGotoOptions
				{
					Timeout = 35000f,
					WaitUntil = WaitUntilState.DOMContentLoaded
				});
			}
			catch (Exception ex) when (ex.Message.Contains("ERR_TOO_MANY_REDIRECTS", StringComparison.OrdinalIgnoreCase))
			{
				log("Phát hiện chuyển hướng lặp, thử truy cập qua /select_business...");
				try
				{
					await page.GotoAsync("https://business.facebook.com/select_business", new PageGotoOptions
					{
						Timeout = 35000f,
						WaitUntil = WaitUntilState.DOMContentLoaded
					});
				}
				catch
				{
					await page.GotoAsync("https://business.facebook.com/", new PageGotoOptions
					{
						Timeout = 35000f,
						WaitUntil = WaitUntilState.DOMContentLoaded
					});
				}
			}
			await Task.Delay(3000, cancellationToken);
		}
		string text = bmSettings.BuildBusinessName(sequenceIndex);
		string text2 = bmSettings.BuildAdminName(sequenceIndex, "");
		string text3 = bmSettings.BuildBusinessEmail(text, text2);
		string[] array = text2.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
		string text4;
		if (array.Length > 1)
		{
			text4 = array[0];
		}
		else
		{
			text4 = ((array.Length != 0) ? array[0] : "Admin");
		}
		string text5 = ((array.Length > 1) ? string.Join(" ", array.Skip(1)) : "Facebook");
		log($"Tạo BM: \"{text}\" (Quản trị: {text2} | Mail: {text3})...");
		log("Đang gửi gói tin GraphQL tạo BM trực tiếp...");
		try
		{
			string arg = JsonSerializer.Serialize(new A<string, string, string, string>(text, text4, text5, text3));
			using JsonDocument jsonDocument = JsonDocument.Parse(await page.EvaluateAsync<string>("async (payloadStr) => {\n                    let reqData = JSON.parse(payloadStr);\n\n                    // 1. Dò tìm token fb_dtsg từ window hoặc script DOM\n                    let dtsg = window.DTSGInitialData?.token;\n                    if (!dtsg) {\n                        let el = document.querySelector('[name=\"fb_dtsg\"]');\n                        if (el) dtsg = el.value;\n                    }\n                    if (!dtsg) {\n                        for (let s of document.querySelectorAll('script')) {\n                            let m = s.textContent.match(/[\"']token[\"']\\s*:\\s*[\"'](NA[^\"']+)[\"']/);\n                            if (m) { dtsg = m[1]; break; }\n                        }\n                    }\n\n                    // 2. Dò tìm actor_id / user_id\n                    let userId = window.Env?.USER_ID;\n                    if (!userId) {\n                        let m = document.cookie.match(/c_user=(\\d+)/);\n                        if (m) userId = m[1];\n                    }\n\n                    if (!dtsg || !userId) {\n                        return JSON.stringify({ ok: false, error: 'MISSING_TOKENS', dtsg: !!dtsg, userId: !!userId });\n                    }\n\n                    let variables = {\n                        input: {\n                            actor_id: userId,\n                            client_mutation_id: String(Math.floor(Math.random() * 1000)),\n                            business_name: reqData.bizName,\n                            user_first_name: reqData.firstName,\n                            user_last_name: reqData.lastName,\n                            user_email: reqData.email,\n                            creation_source: 'MBS_BUSINESS_CREATION_IN_SCOPE_SELECTOR_FOOTER',\n                            entry_point: 'BIZWEB_SCOPE_SELECTOR_FOOTER_CREATION_BUTTON'\n                        }\n                    };\n\n                    let params = new URLSearchParams();\n                    params.append('av', userId);\n                    params.append('__user', userId);\n                    params.append('__a', '1');\n                    params.append('fb_dtsg', dtsg);\n                    params.append('fb_api_caller_class', 'RelayModern');\n                    params.append('fb_api_req_friendly_name', 'useBusinessCreationMutationMutation');\n                    params.append('server_timestamps', 'true');\n                    params.append('doc_id', '28057338880523368');\n                    params.append('variables', JSON.stringify(variables));\n\n                    let resp = await fetch('/api/graphql/', {\n                        method: 'POST',\n                        headers: {\n                            'Content-Type': 'application/x-www-form-urlencoded'\n                        },\n                        body: params.toString()\n                    });\n\n                    let text = await resp.text();\n                    return JSON.stringify({ ok: true, status: resp.status, text: text });\n                }", arg));
			JsonElement rootElement = jsonDocument.RootElement;
			if (rootElement.TryGetProperty("ok", out var value) && value.GetBoolean())
			{
				using JsonDocument jsonDocument2 = JsonDocument.Parse(rootElement.GetProperty("text").GetString() ?? "");
				JsonElement rootElement2 = jsonDocument2.RootElement;
				if (rootElement2.TryGetProperty("data", out var value2) && value2.TryGetProperty("bizkit_create_business", out var value3) && value3.ValueKind == JsonValueKind.Object && value3.TryGetProperty("id", out var value4))
				{
					string text6 = value4.GetString() ?? "";
					log($"Tạo BM \"{text}\" thành công siêu tốc qua GraphQL! (BM ID: {text6})");
					return new BmCreateSingleResult
					{
						Success = true,
						CreatedBmId = text6,
						CreatedBmName = text
					};
				}
				if (rootElement2.TryGetProperty("errors", out var value5) && value5.ValueKind == JsonValueKind.Array)
				{
					foreach (JsonElement item in value5.EnumerateArray())
					{
						int num = (item.TryGetProperty("code", out var value6) ? value6.GetInt32() : 0);
						string text7 = (item.TryGetProperty("description", out var value7) ? (value7.GetString() ?? "") : "");
						string text8 = (item.TryGetProperty("summary", out var value8) ? (value8.GetString() ?? "") : "");
						if (num == 1690114 || text7.Contains("limit", StringComparison.OrdinalIgnoreCase) || text8.Contains("Limit Reached", StringComparison.OrdinalIgnoreCase))
						{
							log("Tài khoản đã đạt giới hạn tạo BM của Facebook (Limit Reached For The Number Of Businesses).");
							return new BmCreateSingleResult
							{
								Success = false,
								IsLimitBlocked = true
							};
						}
						log("Facebook báo lỗi: " + text8 + " - " + text7);
					}
				}
			}
		}
		catch (Exception ex2)
		{
			log("Gói tin GraphQL không áp dụng được: " + ex2.Message + " -> Chuyển sang quét UI...");
		}
		cancellationToken.ThrowIfCancellationRequested();
		if (page.Url.Contains("/overview"))
		{
			return await m_3965(page, text, text2, text3, log, cancellationToken);
		}
		return await m_3964(page, text, text2, text3, log, cancellationToken);
	}

	private static async Task<BmCreateSingleResult> m_3964(IPage P_0, string P_1, string P_2, string P_3, Action<string> P_4, CancellationToken P_5)
	{
		ILocator locator = P_0.Locator("text='Create a business portfolio'").Or(P_0.Locator("text='Tạo danh mục kinh doanh'")).Or(P_0.Locator("text='Tạo tài khoản kinh doanh'"));
		if (await locator.CountAsync() == 0)
		{
			ILocator locator2 = P_0.Locator("[aria-label*='Business portfolio']").Or(P_0.Locator("[aria-haspopup='menu']")).Or(P_0.Locator("[role='combobox']"));
			if (await locator2.CountAsync() > 0)
			{
				P_4("Đang mở menu danh mục doanh nghiệp...");
				await locator2.First.ClickAsync();
				await Task.Delay(1500, P_5);
			}
		}
		if (await locator.CountAsync() > 0)
		{
			P_4("Đang bấm \"Create a business portfolio\"...");
			await locator.First.ClickAsync();
			await Task.Delay(3000, P_5);
		}
		IReadOnlyList<ILocator> readOnlyList = await P_0.Locator("[role='dialog'] input, input").AllAsync();
		List<ILocator> list = new List<ILocator>();
		foreach (ILocator item in readOnlyList)
		{
			if (await item.IsVisibleAsync())
			{
				list.Add(item);
			}
		}
		if (list.Count < 3)
		{
			P_4($"Không tìm thấy đủ ô nhập tạo BM trên giao diện (thấy {list.Count} ô).");
			return new BmCreateSingleResult
			{
				Success = false
			};
		}
		P_4("Điền thông tin BM vào form UI: \"" + P_1 + "\"...");
		await list[0].ClickAsync();
		await list[0].FillAsync(P_1);
		await Task.Delay(300, P_5);
		string[] array = P_2.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
		string value;
		if (array.Length > 1)
		{
			value = array[0];
		}
		else
		{
			value = ((array.Length != 0) ? array[0] : "Admin");
		}
		string value2 = ((array.Length > 1) ? string.Join(" ", array.Skip(1)) : "Facebook");
		if (list.Count < 4)
		{
			await list[1].ScrollIntoViewIfNeededAsync();
			await list[1].ClickAsync();
			await list[1].FillAsync(P_2);
			await list[2].ScrollIntoViewIfNeededAsync();
			await list[2].ClickAsync();
			await list[2].FillAsync(P_3);
		}
		else
		{
			await list[1].ScrollIntoViewIfNeededAsync();
			await list[1].ClickAsync();
			await list[1].FillAsync(value);
			await list[2].ScrollIntoViewIfNeededAsync();
			await list[2].ClickAsync();
			await list[2].FillAsync(value2);
			await list[3].ScrollIntoViewIfNeededAsync();
			await list[3].ClickAsync();
			await list[3].FillAsync(P_3);
		}
		await Task.Delay(500, P_5);
		ILocator locator3 = P_0.Locator("[role='dialog'] [role='button']:has-text('Create'), [role='dialog'] button:has-text('Create'), [role='dialog'] [role='button']:has-text('Tạo'), [role='dialog'] button:has-text('Tạo')");
		if (await locator3.CountAsync() == 0)
		{
			locator3 = P_0.Locator("[role='button']:has-text('Submit'), button:has-text('Submit'), [role='button']:has-text('Gửi'), button:has-text('Gửi')");
		}
		if (await locator3.CountAsync() > 0)
		{
			P_4("Đang bấm gửi thông tin tạo BM...");
			await locator3.First.ClickAsync();
		}
		return await m_3966(P_0, P_1, P_4, P_5);
	}

	private static async Task<BmCreateSingleResult> m_3965(IPage P_0, string P_1, string P_2, string P_3, Action<string> P_4, CancellationToken P_5)
	{
		List<ILocator> list = await m_3967(P_0);
		if (list.Count < 3)
		{
			ILocator locator = P_0.Locator("[role='button']:has-text('Create an account'), button:has-text('Create an account'), a:has-text('Create an account'), [role='button']:has-text('Create account'), button:has-text('Create account'), [role='button']:has-text('Tạo tài khoản'), button:has-text('Tạo tài khoản')");
			if (await locator.CountAsync() > 0)
			{
				P_4("Đang bấm nút \"Create an account\" để mở form tạo BM...");
				await locator.First.ClickAsync();
				await Task.Delay(3000, P_5);
			}
			list = await m_3967(P_0);
		}
		if (list.Count < 3)
		{
			P_4($"Không tìm thấy form điền thông tin tạo BM (tìm thấy {list.Count} ô nhập).");
			return new BmCreateSingleResult
			{
				Success = false
			};
		}
		P_4($"Điền thông tin BM: Doanh nghiệp=\"{P_1}\", Quản trị=\"{P_2}\", Email=\"{P_3}\"...");
		await list[0].ClickAsync();
		await list[0].FillAsync(P_1);
		await Task.Delay(300, P_5);
		string text = "";
		try
		{
			text = await list[1].InputValueAsync();
		}
		catch
		{
		}
		if (!string.Equals(text, P_2, StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(P_2))
		{
			await list[1].ClickAsync();
			await list[1].FillAsync(P_2);
			await Task.Delay(300, P_5);
		}
		await list[2].ScrollIntoViewIfNeededAsync();
		await list[2].ClickAsync();
		await list[2].FillAsync(P_3);
		await Task.Delay(500, P_5);
		ILocator locator2 = P_0.Locator("[role='button']:has-text('Submit'), button:has-text('Submit'), [role='button']:has-text('Gửi'), button:has-text('Gửi')");
		if (await locator2.CountAsync() > 0)
		{
			P_4("Đang bấm gửi thông tin tạo BM...");
			await locator2.First.ClickAsync();
		}
		return await m_3966(P_0, P_1, P_4, P_5);
	}

	private static async Task<BmCreateSingleResult> m_3966(IPage P_0, string P_1, Action<string> P_2, CancellationToken P_3)
	{
		P_2("Đang chờ Facebook xử lý tạo BM...");
		for (int i = 0; i < 15; i++)
		{
			P_3.ThrowIfCancellationRequested();
			await Task.Delay(1000, P_3);
			string text = await m_3968(P_0);
			if (text.Contains("was created", StringComparison.OrdinalIgnoreCase) || text.Contains("Confirm your email address", StringComparison.OrdinalIgnoreCase) || text.Contains("đã được tạo", StringComparison.OrdinalIgnoreCase) || text.Contains("Xác nhận địa chỉ email", StringComparison.OrdinalIgnoreCase))
			{
				P_2("Đã tạo BM \"" + P_1 + "\" thành công!");
				ILocator locator = P_0.Locator("[role='button']:has-text('Done'), button:has-text('Done'), [role='button']:has-text('Xong'), button:has-text('Xong')");
				if (await locator.CountAsync() > 0)
				{
					try
					{
						await locator.First.ClickAsync();
					}
					catch
					{
					}
				}
				return new BmCreateSingleResult
				{
					Success = true,
					CreatedBmName = P_1
				};
			}
			if (text.Contains("limit for the number of Businesses", StringComparison.OrdinalIgnoreCase) || text.Contains("cannot create business", StringComparison.OrdinalIgnoreCase) || text.Contains("reached the limit", StringComparison.OrdinalIgnoreCase) || text.Contains("giới hạn số lượng Doanh nghiệp", StringComparison.OrdinalIgnoreCase) || text.Contains("đạt giới hạn", StringComparison.OrdinalIgnoreCase))
			{
				P_2("Tài khoản đã đạt giới hạn tạo BM của Facebook.");
				return new BmCreateSingleResult
				{
					Success = false,
					IsLimitBlocked = true
				};
			}
			if (text.Contains("Unable to create business", StringComparison.OrdinalIgnoreCase) || text.Contains("Something went wrong", StringComparison.OrdinalIgnoreCase) || text.Contains("Không thể tạo tài khoản kinh doanh", StringComparison.OrdinalIgnoreCase))
			{
				P_2("Facebook từ chối tạo BM: " + m_3969(text, 120));
				return new BmCreateSingleResult
				{
					Success = false
				};
			}
		}
		P_2("Hết thời gian chờ phản hồi tạo BM \"" + P_1 + "\".");
		return new BmCreateSingleResult
		{
			Success = false
		};
	}

	private static async Task<List<ILocator>> m_3967(IPage P_0)
	{
		List<ILocator> list = new List<ILocator>();
		try
		{
			foreach (ILocator item in await P_0.Locator("input").AllAsync())
			{
				if (await item.IsVisibleAsync())
				{
					list.Add(item);
				}
			}
		}
		catch
		{
		}
		return list;
	}

	private static async Task<string> m_3968(IPage P_0)
	{
		try
		{
			return await P_0.InnerTextAsync("body");
		}
		catch
		{
			return "";
		}
	}

	private static string m_3969(string P_0, int P_1)
	{
		if (P_0.Length > P_1)
		{
			return P_0.Substring(0, P_1) + "...";
		}
		return P_0;
	}
}
