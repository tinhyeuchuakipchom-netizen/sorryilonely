namespace testTuongTacWPF.Automation;

public enum BmAdminNameMode
{
	KeepAccountName,
	RandomEnglish,
	RandomVietnamese,
	CustomList
}
