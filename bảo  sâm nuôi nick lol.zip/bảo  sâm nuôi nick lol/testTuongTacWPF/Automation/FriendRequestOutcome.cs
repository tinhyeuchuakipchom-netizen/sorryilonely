namespace testTuongTacWPF.Automation;

public enum FriendRequestOutcome
{
	Sent,
	AlreadyFriend,
	AlreadyRequested,
	NoButton,
	Error
}
