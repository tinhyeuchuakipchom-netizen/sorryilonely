using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class UiElement
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private bool m_6750;

	[CompilerGenerated]
	private bool m_6751 = true;

	[CompilerGenerated]
	private int m_6752;

	[CompilerGenerated]
	private int m_6753;

	[CompilerGenerated]
	private int m_6754;

	[CompilerGenerated]
	private int m_6755;

	public string Text
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string ContentDesc
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string ResourceId
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string ClassName
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public bool Focused
	{
		[CompilerGenerated]
		get
		{
			return m_6750;
		}
		[CompilerGenerated]
		set
		{
			m_6750 = value;
		}
	}

	public bool Enabled
	{
		[CompilerGenerated]
		get
		{
			return m_6751;
		}
		[CompilerGenerated]
		set
		{
			m_6751 = value;
		}
	}

	public int Left
	{
		[CompilerGenerated]
		get
		{
			return m_6752;
		}
		[CompilerGenerated]
		set
		{
			m_6752 = value;
		}
	}

	public int Top
	{
		[CompilerGenerated]
		get
		{
			return m_6753;
		}
		[CompilerGenerated]
		set
		{
			m_6753 = value;
		}
	}

	public int Right
	{
		[CompilerGenerated]
		get
		{
			return m_6754;
		}
		[CompilerGenerated]
		set
		{
			m_6754 = value;
		}
	}

	public int Bottom
	{
		[CompilerGenerated]
		get
		{
			return m_6755;
		}
		[CompilerGenerated]
		set
		{
			m_6755 = value;
		}
	}

	public int CenterX => (Left + Right) / 2;

	public int CenterY => (Top + Bottom) / 2;

	public string Label
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(Text))
			{
				return Text;
			}
			if (!string.IsNullOrWhiteSpace(ContentDesc))
			{
				return ContentDesc;
			}
			if (!string.IsNullOrWhiteSpace(ResourceId))
			{
				return ResourceId;
			}
			return ClassName;
		}
	}
}
