namespace testTuongTacWPF.Automation;

public static class PostAudiences
{
	public const string Keep = "Keep";

	public const string Public = "Public";

	public const string Friends = "Friends";

	public const string OnlyMe = "OnlyMe";
}
