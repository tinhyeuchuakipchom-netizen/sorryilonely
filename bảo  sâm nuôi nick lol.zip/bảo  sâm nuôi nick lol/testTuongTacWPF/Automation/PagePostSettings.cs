using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class PagePostSettings
{
	[CompilerGenerated]
	private int A = 1;

	[CompilerGenerated]
	private int a;

	[CompilerGenerated]
	private int B = 5;

	[CompilerGenerated]
	private List<string> m_5831 = new List<string>();

	[CompilerGenerated]
	private PostCreationSettings m_5832 = new PostCreationSettings();

	public int PostsPerPage
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxPages
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int PageSwitchDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public List<string> TargetPageNames
	{
		[CompilerGenerated]
		get
		{
			return m_5831;
		}
		[CompilerGenerated]
		set
		{
			m_5831 = value;
		}
	}

	public PostCreationSettings Post
	{
		[CompilerGenerated]
		get
		{
			return m_5832;
		}
		[CompilerGenerated]
		set
		{
			m_5832 = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static PagePostSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new PagePostSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<PagePostSettings>(json) ?? new PagePostSettings();
		}
		catch (JsonException)
		{
			return new PagePostSettings();
		}
	}
}
