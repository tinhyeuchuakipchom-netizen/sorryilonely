using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookKatanaPhoneLoginService
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_4750
	{
		public static readonly m_4750 A = new m_4750();

		public static Func<UiElement, bool> m_4755;

		public static Func<UiElement, bool> a;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		public static Func<UiElement, bool> C;

		public static Func<UiElement, bool> c;

		public static Func<UiElement, bool> D;

		public static Func<UiElement, bool> d;

		public static Func<UiElement, bool> E;

		public static Func<UiElement, bool> e;

		public static Func<UiElement, bool> F;

		public static Func<UiElement, bool> f;

		public static Func<UiElement, bool> G;

		public static Func<UiElement, bool> g;

		public static Func<UiElement, bool> H;

		public static Func<UiElement, bool> h;

		public static Func<UiElement, bool> I;

		public static Func<UiElement, bool> i;

		public static Func<UiElement, bool> J;

		public static Func<UiElement, string> m_4756;

		public static Func<UiElement, bool> j;

		public static Func<UiElement, bool> K;

		public static Func<UiElement, bool> k;

		public static Func<UiElement, bool> L;

		public static Func<UiElement, bool> l;

		public static Func<UiElement, bool> M;

		public static Func<UiElement, bool> m;

		public static Func<UiElement, bool> N;

		public static Func<UiElement, bool> n;

		public static Func<UiElement, bool> O;

		public static Func<UiElement, bool> o;

		public static Func<UiElement, bool> P;

		public static Func<UiElement, bool> p;

		public static Func<UiElement, bool> Q;

		public static Func<UiElement, bool> q;

		internal bool m_4757(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4758(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4759(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4760(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4761(UiElement P_0)
		{
			if (!P_0.Text.Equals("Log in", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Log in", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4762(UiElement P_0)
		{
			if (!P_0.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("6-digit code", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4763(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4764(UiElement P_0)
		{
			if (!P_0.Text.Contains("Try another way", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Try another way", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Need another way", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Need another way", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Having trouble", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Having trouble", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4765(UiElement P_0)
		{
			if (!P_0.Text.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Code generator", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Code generator", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Trình tạo mã", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Trình tạo mã", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4766(UiElement P_0)
		{
			if (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View"))
			{
				if (!P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4767(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4768(UiElement P_0)
		{
			if (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View"))
			{
				if (!P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Submit", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Submit", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Xác nhận", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Xác nhận", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4769(UiElement P_0)
		{
			if (!P_0.Text.Contains("Enter password to log in", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Enter password to log in", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Nhập mật khẩu để đăng nhập", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Nhập mật khẩu để đăng nhập", StringComparison.OrdinalIgnoreCase) && (!P_0.Text.Equals("Password", StringComparison.OrdinalIgnoreCase) || P_0.ClassName.Contains("EditText")))
			{
				if (P_0.ContentDesc.Equals("Password", StringComparison.OrdinalIgnoreCase))
				{
					return !P_0.ClassName.Contains("EditText");
				}
				return false;
			}
			return true;
		}

		internal bool m_4770(UiElement P_0)
		{
			if (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View"))
			{
				if (!P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4771(UiElement P_0)
		{
			if (P_0.ClassName.Contains("EditText"))
			{
				if (!P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Password", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4772(UiElement P_0)
		{
			if (!P_0.Text.Contains("confirm", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("confirm", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("log in", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("log in", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4773(UiElement P_0)
		{
			if (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View"))
			{
				if (!P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4774(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Bạn đang nghĩ gì", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Bạn đang nghĩ gì", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tìm kiếm trên Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Tìm kiếm trên Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.ResourceId.Contains("feed_tab"))
			{
				return P_0.ResourceId.Contains("tab_bar");
			}
			return true;
		}

		internal bool m_4775(UiElement P_0)
		{
			if (!P_0.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Two-factor", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Two-factor", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Xác thực 2 yếu tố", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Xác thực 2 yếu tố", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Xác thực hai yếu tố", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Xác thực hai yếu tố", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("login code", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("login code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Enter code", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Enter code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Mã đăng nhập", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Mã đăng nhập", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Nhập mã", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Nhập mã", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Security code", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Security code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Mã bảo mật", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Mã bảo mật", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Approve from another device", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Approve from another device", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Phê duyệt từ thiết bị khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Phê duyệt từ thiết bị khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Try another way", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Try another way", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.StartsWith("Code,", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Go to your authentication app", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Go to your authentication app", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Trust this device", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Trust this device", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Choose a way to confirm", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Choose a way to confirm", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Chọn cách xác nhận", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Chọn cách xác nhận", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal string m_4776(UiElement P_0)
		{
			return $"{P_0.Text} {P_0.ContentDesc} {P_0.ResourceId}";
		}

		internal bool m_4777(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("permission_allow_button") && !P_0.ResourceId.Contains("permission_allow_foreground_only_button") && !P_0.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("While using the app", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Allow", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4778(UiElement P_0)
		{
			if (!P_0.Text.Equals("Save", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Save", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Lưu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Lưu", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Save browser", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Save browser", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Trust this device", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Trust this device", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tin cậy thiết bị này", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Tin cậy thiết bị này", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4779(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4780(UiElement P_0)
		{
			if (!P_0.Text.Contains("Use another profile", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Use another profile", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Use another account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Use another account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Log into another account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Log into another account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Log in to another account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Log in to another account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("another profile", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("another profile", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("another account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("another account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Usar otra cuenta", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Usar otra cuenta", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("otro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("otro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("otra cuenta", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("otra cuenta", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Utiliser un autre profil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Utiliser un autre profil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("autre profil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("autre profil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Usar outro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Usar outro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("outro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("outro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Dùng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Dùng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Sử dụng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Sử dụng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Đăng nhập bằng tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Đăng nhập bằng tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Đăng nhập vào tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Đăng nhập vào tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Dùng tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Dùng tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Sử dụng tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Sử dụng tài khoản khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Trang cá nhân khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Trang cá nhân khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Tài khoản khác", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Tài khoản khác", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4781(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4782(UiElement P_0)
		{
			if (P_0.CenterY >= 700 && P_0.CenterY <= 860 && P_0.Right - P_0.Left > 500)
			{
				if (!P_0.ClassName.Contains("Button"))
				{
					return P_0.ClassName.Contains("ViewGroup");
				}
				return true;
			}
			return false;
		}

		internal bool m_4783(UiElement P_0)
		{
			if (P_0.CenterY >= 850 && P_0.CenterY <= 960)
			{
				if (!P_0.ClassName.Contains("Button"))
				{
					return P_0.ClassName.Contains("View");
				}
				return true;
			}
			return false;
		}

		internal bool m_4784(UiElement P_0)
		{
			if (!P_0.Text.Contains("Đăng nhập", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Đăng nhập", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Số di động", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Số di động", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Quên mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Quên mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Dùng trang cá nhân", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Dùng trang cá nhân", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Tiếng Việt", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tiếng Việt", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Iniciar sesión", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Iniciar sesión", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Contraseña", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Contraseña", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Crear cuenta", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Crear cuenta", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Español", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Español", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Se connecter", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Se connecter", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Entrar", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Entrar", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4785(UiElement P_0)
		{
			if (!P_0.Text.Contains("English", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("English", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Log in", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Log in", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Password", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Mobile number or email", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Mobile number or email", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Forgot password", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Forgot password", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Create new account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Create new account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Join Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Join Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("I already have a profile", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("I already have a profile", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Get started", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Get started", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("another profile", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("another profile", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("another account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("another account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4786(UiElement P_0)
		{
			if (string.IsNullOrWhiteSpace(P_0.Text) && string.IsNullOrWhiteSpace(P_0.ContentDesc) && !P_0.ClassName.Contains("EditText"))
			{
				return P_0.ClassName.Contains("Button");
			}
			return true;
		}

		internal bool m_4787(UiElement P_0)
		{
			if (!P_0.Text.Equals("Không", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Không", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Not now", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Not now", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Ahora no", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Ahora no", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Lúc khác", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Lúc khác", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Hủy", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Hủy", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Cancelar", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Cancelar", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4788(UiElement P_0)
		{
			if (P_0.Text.Contains("Facebook", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.Text.Contains("Thử dùng", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("idioma", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Contains("language", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4789(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4790(UiElement P_0)
		{
			if (P_0.CenterY >= 60 && P_0.CenterY <= 300 && P_0.CenterX >= 200 && P_0.CenterX <= 700 && !string.Equals(P_0.ClassName, "android.widget.FrameLayout", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ClassName.Contains("Button") && !P_0.ClassName.Contains("View"))
				{
					return P_0.ClassName.Contains("TextView");
				}
				return true;
			}
			return false;
		}

		internal bool R(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("English (US)", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("English (US)", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.StartsWith("English", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.StartsWith("English", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_4751
	{
		public FacebookAccountRow A;

		public Action<string> m_4791;

		internal void m_4792(string P_0)
		{
			A.TrangThai = P_0;
			m_4791?.Invoke(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_4752
	{
		public List<UiElement> A;

		public Func<UiElement, bool> m_4793;

		internal bool m_4794(UiElement P_0)
		{
			if (P_0.ClassName.Contains("EditText"))
			{
				if (!P_0.ContentDesc.StartsWith("Code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Code", StringComparison.OrdinalIgnoreCase))
				{
					return A.Any((UiElement uiElement) => uiElement.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("6-digit code", StringComparison.OrdinalIgnoreCase));
				}
				return true;
			}
			return false;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct m_4753
	{
		public List<UiElement> A;
	}

	[CompilerGenerated]
	private sealed class m_4754
	{
		public string[] A;

		internal bool m_4795(UiElement P_0)
		{
			return A.Any((string value) => P_0.Text.Equals(value, StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals(value, StringComparison.OrdinalIgnoreCase));
		}
	}

	[CompilerGenerated]
	private sealed class c
	{
		public UiElement A;

		internal bool m_4796(string P_0)
		{
			if (!A.Text.Equals(P_0, StringComparison.OrdinalIgnoreCase))
			{
				return A.ContentDesc.Equals(P_0, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class D
	{
		public string[] A;

		internal bool m_4797(UiElement P_0)
		{
			return A.Any((string value) => P_0.Text.Contains(value, StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains(value, StringComparison.OrdinalIgnoreCase));
		}
	}

	[CompilerGenerated]
	private sealed class d
	{
		public UiElement A;

		internal bool m_4798(string P_0)
		{
			if (!A.Text.Contains(P_0, StringComparison.OrdinalIgnoreCase))
			{
				return A.ContentDesc.Contains(P_0, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	public const string KatanaPackage = "com.facebook.katana";

	public const string KatanaMainActivity = "com.facebook.katana/.LoginActivity";

	public static async Task<LoginResult> LoginAccountAsync(FacebookAccountRow account, Action<string>? onStatus, CancellationToken cancellationToken)
	{
		if (string.IsNullOrWhiteSpace(account.PhoneName))
		{
			string text = (await AdbController.ListDevicesAsync(cancellationToken)).FirstOrDefault() ?? "";
			if (string.IsNullOrEmpty(text))
			{
				LoginResult loginResult = new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Nick chưa gắn Phone và không tìm thấy thiết bị Android nào đang kết nối."
				};
				account.TrangThai = loginResult.TrangThai;
				account.TinhTrang = loginResult.TinhTrang;
				return loginResult;
			}
			account.PhoneName = text;
		}
		account.TrangThai = "Bắt đầu đăng nhập FB Katana...";
		account.TinhTrang = "";
		string text2 = ((!string.IsNullOrWhiteSpace(account.Uid)) ? account.Uid.Trim() : (account.Mail?.Trim() ?? ""));
		string text3 = account.Pass?.Trim() ?? "";
		if (string.IsNullOrWhiteSpace(text2) || string.IsNullOrWhiteSpace(text3))
		{
			LoginResult loginResult2 = new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Nick chưa có UID/Mail hoặc Mật khẩu."
			};
			account.TrangThai = loginResult2.TrangThai;
			account.TinhTrang = loginResult2.TinhTrang;
			return loginResult2;
		}
		LoginResult loginResult3 = await LoginAsync(account.PhoneName, text2, text3, account.TwoFA, account.Proxy, (string P_0) =>
		{
			account.TrangThai = P_0;
			onStatus?.Invoke(P_0);
		}, cancellationToken);
		account.TrangThai = loginResult3.TrangThai;
		account.TinhTrang = loginResult3.TinhTrang;
		if (loginResult3.Success)
		{
			try
			{
				KatanaSessionResult katanaSessionResult = await AdbController.GetKatanaTokenAndCookieAsync(account.PhoneName, cancellationToken);
				if (katanaSessionResult.Success)
				{
					if (!string.IsNullOrEmpty(katanaSessionResult.Uid) && string.IsNullOrEmpty(account.Uid))
					{
						account.Uid = katanaSessionResult.Uid;
					}
					if (!string.IsNullOrEmpty(katanaSessionResult.Token))
					{
						account.Token = katanaSessionResult.Token;
					}
					if (!string.IsNullOrEmpty(katanaSessionResult.Cookie))
					{
						account.Cookie = katanaSessionResult.Cookie;
					}
				}
			}
			catch
			{
			}
		}
		return loginResult3;
	}

	public static async Task<LoginResult> LoginAsync(string deviceSerial, string loginId, string pass, string? twoFA, string? proxy, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 88;
		try
		{
			onStatus("Kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi."
				};
			}
			onStatus("Kiểm tra cài đặt ban đầu & cấu hình máy...");
			await PhoneInitialSetupService.EnsureInitialSetupAsync(deviceSerial, "Katana", onStatus, cancellationToken);
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			if (!string.IsNullOrWhiteSpace(proxy))
			{
				onStatus("Đang kết nối Proxy " + proxy + " qua Super Proxy...");
				if (!(await SuperProxyController.SetupAndStartProxyAsync(deviceSerial, proxy, onStatus, cancellationToken)))
				{
					onStatus("Cảnh báo: Kết nối proxy qua Super Proxy không thành công, tiếp tục chạy bằng mạng máy.");
				}
			}
			else
			{
				onStatus("Không sử dụng Proxy -> Đang ngắt kết nối & reset sạch app Super Proxy...");
				await SuperProxyController.StopProxyAsync(deviceSerial, onStatus, cancellationToken);
			}
			onStatus("Xóa dữ liệu app Facebook Katana (pm clear) để làm sạch môi trường...");
			await AdbController.RunShellAsync(deviceSerial, "pm clear com.facebook.katana", cancellationToken);
			await Task.Delay(800, cancellationToken);
			try
			{
				await AdbController.GrantAllAppPermissionsAsync(deviceSerial, "com.facebook.katana", cancellationToken);
			}
			catch
			{
			}
			await Task.Delay(300, cancellationToken);
			onStatus("Khởi chạy Facebook Katana sạch...");
			await AdbController.RunShellAsync(deviceSerial, "am start -n com.facebook.katana/.LoginActivity", cancellationToken);
			await Task.Delay(3500, cancellationToken);
			await EnsureFacebookAppLanguageEnglishAsync(deviceSerial, onStatus, cancellationToken);
			string text = await AdbController.RunShellCaptureAsync(deviceSerial, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", cancellationToken);
			if ((text.Contains("FbMainTabActivity") || text.Contains("MainActivity")) && FacebookKatanaPhoneLoginService.A(await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)))
			{
				return new LoginResult
				{
					Success = true,
					TinhTrang = "LIVE",
					TrangThai = "Tài khoản đang đăng nhập sẵn trên Facebook Katana."
				};
			}
			onStatus("Đang dò tìm ô nhập thông tin đăng nhập...");
			await AdbController.HideKeyboardIfShownAsync(deviceSerial, cancellationToken);
			await Task.Delay(400, cancellationToken);
			List<UiElement> A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			(int, int)? tuple = b(A);
			if (tuple.HasValue)
			{
				onStatus("Chọn: Use another profile (Đăng nhập tài khoản khác)...");
				await AdbController.TapAsync(deviceSerial, tuple.Value.Item1, tuple.Value.Item2, cancellationToken);
				await Task.Delay(2500, cancellationToken);
				A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			}
			List<UiElement> list = A.Where((UiElement P_0) => P_0.ClassName.Contains("EditText")).ToList();
			int num = 0;
			while (list.Count < 2 && num < 8)
			{
				num++;
				onStatus($"Đang chờ hiển thị form đăng nhập ({num}/8)...");
				if (await FacebookKatanaPhoneLoginService.A(deviceSerial, A, onStatus, cancellationToken))
				{
					await Task.Delay(2000, cancellationToken);
					A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
					list = A.Where((UiElement P_0) => P_0.ClassName.Contains("EditText")).ToList();
					if (list.Count >= 2)
					{
						break;
					}
				}
				tuple = b(A);
				if (tuple.HasValue)
				{
					onStatus("Chọn: Use another profile (Đăng nhập tài khoản khác)...");
					await AdbController.TapAsync(deviceSerial, tuple.Value.Item1, tuple.Value.Item2, cancellationToken);
					await Task.Delay(2500, cancellationToken);
				}
				await Task.Delay(2000, cancellationToken);
				await AdbController.HideKeyboardIfShownAsync(deviceSerial, cancellationToken);
				A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				list = A.Where((UiElement P_0) => P_0.ClassName.Contains("EditText")).ToList();
				if (text.Contains("FbMainTabActivity") || FacebookKatanaPhoneLoginService.A(A))
				{
					return new LoginResult
					{
						Success = true,
						TinhTrang = "LIVE",
						TrangThai = "Đăng nhập thành công (đã vào Trang chủ)."
					};
				}
			}
			if (list.Count < 2)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Không tìm thấy form nhập tài khoản và mật khẩu của Facebook Katana."
				};
			}
			UiElement uiElement = list[0];
			_ = list[1];
			onStatus("Nhập tài khoản: " + loginId + "...");
			await AdbController.TapAsync(deviceSerial, uiElement.CenterX, uiElement.CenterY, cancellationToken);
			await Task.Delay(400, cancellationToken);
			await AdbController.ClearTextAsync(deviceSerial, 50, cancellationToken);
			await AdbController.InputTextAsync(deviceSerial, loginId, cancellationToken);
			await Task.Delay(400, cancellationToken);
			await AdbController.HideKeyboardIfShownAsync(deviceSerial, cancellationToken);
			await Task.Delay(400, cancellationToken);
			A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			list = A.Where((UiElement P_0) => P_0.ClassName.Contains("EditText")).ToList();
			UiElement uiElement2 = ((list.Count >= 2) ? list[1] : list.Last());
			onStatus("Nhập mật khẩu...");
			await AdbController.TapAsync(deviceSerial, uiElement2.CenterX, uiElement2.CenterY, cancellationToken);
			await Task.Delay(400, cancellationToken);
			await AdbController.ClearTextAsync(deviceSerial, 50, cancellationToken);
			await AdbController.InputTextAsync(deviceSerial, pass, cancellationToken);
			await Task.Delay(400, cancellationToken);
			await AdbController.HideKeyboardIfShownAsync(deviceSerial, cancellationToken);
			await Task.Delay(500, cancellationToken);
			A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			UiElement? uiElement3 = A.FirstOrDefault((UiElement P_0) => P_0.Text.Equals("Log in", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Log in", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase));
			int x = uiElement3?.CenterX ?? 450;
			int y = uiElement3?.CenterY ?? 991;
			onStatus("Bấm nút Đăng nhập (Log in)...");
			await AdbController.TapAsync(deviceSerial, x, y, cancellationToken);
			onStatus("Đang chờ phản hồi từ Facebook...");
			await Task.Delay(5000, cancellationToken);
			int num2 = 25;
			int num3 = 0;
			for (int num4 = 1; num4 <= num2; num4++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				text = await AdbController.RunShellCaptureAsync(deviceSerial, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", cancellationToken);
				A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				if (text.Contains("FbMainTabActivity") || FacebookKatanaPhoneLoginService.A(A))
				{
					onStatus("Đã vào Trang chủ (News Feed). Đang kiểm tra tình trạng tài khoản qua Graph API...");
					string text2 = ((!string.IsNullOrWhiteSpace(loginId)) ? loginId : "");
					string text3 = "LIVE";
					if (!string.IsNullOrEmpty(text2))
					{
						text3 = await FacebookKatanaPhoneLoginService.A(text2, cancellationToken);
					}
					if (text3 == "LIVE")
					{
						return new LoginResult
						{
							Success = true,
							TinhTrang = "LIVE",
							TrangThai = "Đăng nhập thành công (News Feed LIVE)."
						};
					}
					return new LoginResult
					{
						Success = false,
						TinhTrang = "DIE",
						TrangThai = "Tài khoản bị DIE/Checkpoint sau khi đăng nhập."
					};
				}
				string text4 = B(A);
				if (text4 != null)
				{
					if (!(text4 == "SAI_2FA") || num3 >= 3)
					{
						string tinhTrang = text4 switch
						{
							"SAI_MK" => "SAI_MK", 
							"SAI_2FA" => "SAI_2FA", 
							"DIE" => "DIE", 
							"CHECKPOINT" => "CHECKPOINT", 
							_ => "ERROR", 
						};
						return new LoginResult
						{
							Success = false,
							TinhTrang = tinhTrang,
							TrangThai = "Facebook báo: " + text4
						};
					}
					onStatus("Mã 2FA vừa nhập có thể đã hết hạn, đang thử lấy mã mới...");
				}
				if (a(A))
				{
					if (string.IsNullOrWhiteSpace(twoFA))
					{
						return new LoginResult
						{
							Success = false,
							TinhTrang = "2FA",
							TrangThai = "Tài khoản yêu cầu mã 2FA nhưng nick chưa có 2FA Secret Key."
						};
					}
					UiElement uiElement4 = A.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText") && (P_0.ContentDesc.StartsWith("Code", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Code", StringComparison.OrdinalIgnoreCase) || A.Any((UiElement uiElement13) => uiElement13.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Contains("6-digit code", StringComparison.OrdinalIgnoreCase))));
					if (uiElement4 == null)
					{
						List<UiElement> list2 = A.Where((UiElement P_0) => P_0.ClassName.Contains("EditText")).ToList();
						if (list2.Count == 1)
						{
							uiElement4 = list2[0];
						}
					}
					if (uiElement4 == null)
					{
						UiElement uiElement5 = A.FirstOrDefault((UiElement P_0) => P_0.Text.Contains("Try another way", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Try another way", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Need another way", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Need another way", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Having trouble", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Having trouble", StringComparison.OrdinalIgnoreCase));
						if (uiElement5 != null)
						{
							onStatus("Màn hình yêu cầu phê duyệt từ thiết bị khác -> Bấm 'Thử cách khác' (Try another way)...");
							await AdbController.TapAsync(deviceSerial, uiElement5.CenterX, uiElement5.CenterY, cancellationToken);
							await Task.Delay(2500, cancellationToken);
							A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
						}
						UiElement uiElement6 = A.FirstOrDefault((UiElement P_0) => P_0.Text.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Code generator", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Code generator", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Trình tạo mã", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Trình tạo mã", StringComparison.OrdinalIgnoreCase));
						if (uiElement6 != null)
						{
							onStatus("Chọn phương thức xác thực: Ứng dụng xác thực (Authentication app)...");
							await AdbController.TapAsync(deviceSerial, uiElement6.CenterX, uiElement6.CenterY, cancellationToken);
							await Task.Delay(1500, cancellationToken);
							A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
							UiElement uiElement7 = A.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && (P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase)));
							if (uiElement7 != null)
							{
								await AdbController.TapAsync(deviceSerial, uiElement7.CenterX, uiElement7.CenterY, cancellationToken);
								await Task.Delay(3000, cancellationToken);
								A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
							}
						}
						uiElement4 = A.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText"));
					}
					if (uiElement4 != null && num3 < 3)
					{
						num3++;
						onStatus($"Phát hiện ô nhập mã 2FA! Đang tính mã xác thực TOTP (lần {num3}/3)...");
						string text5 = PlaywrightHumanHelpers.Get2fa(twoFA);
						if (!string.IsNullOrWhiteSpace(text5))
						{
							onStatus("Nhập mã 2FA (" + text5 + ")...");
							await AdbController.TapAsync(deviceSerial, uiElement4.CenterX, uiElement4.CenterY, cancellationToken);
							await Task.Delay(300, cancellationToken);
							await AdbController.ClearTextAsync(deviceSerial, 20, cancellationToken);
							await AdbController.InputTextAsync(deviceSerial, text5, cancellationToken);
							await Task.Delay(500, cancellationToken);
							await AdbController.HideKeyboardIfShownAsync(deviceSerial, cancellationToken);
							await Task.Delay(500, cancellationToken);
							A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
							UiElement uiElement8 = A.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && (P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Submit", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Submit", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Xác nhận", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Xác nhận", StringComparison.OrdinalIgnoreCase)));
							if (uiElement8 != null)
							{
								onStatus("Bấm Tiếp tục gửi mã 2FA...");
								await AdbController.TapAsync(deviceSerial, uiElement8.CenterX, uiElement8.CenterY, cancellationToken);
								await Task.Delay(4000, cancellationToken);
							}
							else
							{
								await AdbController.KeyEventAsync(deviceSerial, "66", cancellationToken);
								await Task.Delay(4000, cancellationToken);
							}
							continue;
						}
					}
				}
				UiElement uiElement9 = A.FirstOrDefault((UiElement P_0) => P_0.Text.Contains("Enter password to log in", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Enter password to log in", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Nhập mật khẩu để đăng nhập", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Nhập mật khẩu để đăng nhập", StringComparison.OrdinalIgnoreCase) || (P_0.Text.Equals("Password", StringComparison.OrdinalIgnoreCase) && !P_0.ClassName.Contains("EditText")) || (P_0.ContentDesc.Equals("Password", StringComparison.OrdinalIgnoreCase) && !P_0.ClassName.Contains("EditText")));
				if (uiElement9 != null && !string.IsNullOrWhiteSpace(pass))
				{
					onStatus("Chọn phương thức xác nhận tài khoản: Nhập mật khẩu (Password)...");
					await AdbController.TapAsync(deviceSerial, uiElement9.CenterX, uiElement9.CenterY, cancellationToken);
					await Task.Delay(1500, cancellationToken);
					A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
					UiElement uiElement10 = A.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && (P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase)));
					if (uiElement10 != null)
					{
						await AdbController.TapAsync(deviceSerial, uiElement10.CenterX, uiElement10.CenterY, cancellationToken);
						await Task.Delay(2500, cancellationToken);
					}
					continue;
				}
				UiElement uiElement11 = A.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText") && (P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Password", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase)));
				if (uiElement11 != null && !string.IsNullOrWhiteSpace(pass) && A.Any((UiElement P_0) => P_0.Text.Contains("confirm", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("confirm", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("log in", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("log in", StringComparison.OrdinalIgnoreCase)))
				{
					onStatus("Điền mật khẩu xác thực bổ sung...");
					await AdbController.TapAsync(deviceSerial, uiElement11.CenterX, uiElement11.CenterY, cancellationToken);
					await Task.Delay(300, cancellationToken);
					await AdbController.ClearTextAsync(deviceSerial, 30, cancellationToken);
					await AdbController.InputTextAsync(deviceSerial, pass, cancellationToken);
					await Task.Delay(500, cancellationToken);
					await AdbController.HideKeyboardIfShownAsync(deviceSerial, cancellationToken);
					await Task.Delay(400, cancellationToken);
					A = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
					UiElement uiElement12 = A.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && (P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp tục", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase)));
					if (uiElement12 != null)
					{
						onStatus("Bấm Đăng nhập / Tiếp tục sau khi điền mật khẩu...");
						await AdbController.TapAsync(deviceSerial, uiElement12.CenterX, uiElement12.CenterY, cancellationToken);
						await Task.Delay(4000, cancellationToken);
						continue;
					}
				}
				if (await FacebookKatanaPhoneLoginService.A(deviceSerial, A, onStatus, cancellationToken))
				{
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				onStatus($"Đang xử lý đăng nhập... ({num4}/{num2})");
				await Task.Delay(2500, cancellationToken);
			}
			if ((await AdbController.RunShellCaptureAsync(deviceSerial, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", cancellationToken)).Contains("FbMainTabActivity"))
			{
				return new LoginResult
				{
					Success = true,
					TinhTrang = "LIVE",
					TrangThai = "Đăng nhập thành công."
				};
			}
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Hết thời gian chờ hoàn tất đăng nhập Facebook Katana."
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Đã hủy đăng nhập theo yêu cầu."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi ngoại lệ khi đăng nhập: " + ex2.Message
			};
		}
	}

	private static bool A(List<UiElement> P_0)
	{
		return P_0.Any((UiElement uiElement) => uiElement.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Bạn đang nghĩ gì", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Bạn đang nghĩ gì", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Tìm kiếm trên Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Tìm kiếm trên Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.ResourceId.Contains("feed_tab") || uiElement.ResourceId.Contains("tab_bar"));
	}

	private static bool a(List<UiElement> P_0)
	{
		return P_0.Any((UiElement uiElement) => uiElement.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Two-factor", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Two-factor", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Xác thực 2 yếu tố", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Xác thực 2 yếu tố", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Xác thực hai yếu tố", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Xác thực hai yếu tố", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("login code", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("login code", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Enter code", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Enter code", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Mã đăng nhập", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Mã đăng nhập", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Nhập mã", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Nhập mã", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Security code", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Security code", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Mã bảo mật", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Mã bảo mật", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Authentication app", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Ứng dụng xác thực", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Approve from another device", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Approve from another device", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Phê duyệt từ thiết bị khác", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Phê duyệt từ thiết bị khác", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Try another way", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Try another way", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Thử cách khác", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.StartsWith("Code,", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Go to your authentication app", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Go to your authentication app", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Trust this device", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Trust this device", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Choose a way to confirm", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Choose a way to confirm", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Chọn cách xác nhận", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Chọn cách xác nhận", StringComparison.OrdinalIgnoreCase));
	}

	private static string? B(List<UiElement> P_0)
	{
		foreach (UiElement item in P_0)
		{
			string text = (item.Text + " " + item.ContentDesc).Trim();
			if (!string.IsNullOrEmpty(text))
			{
				if (text.Contains("Incorrect password", StringComparison.OrdinalIgnoreCase) || text.Contains("Wrong password", StringComparison.OrdinalIgnoreCase) || text.Contains("Mật khẩu không chính xác", StringComparison.OrdinalIgnoreCase) || text.Contains("Sai mật khẩu", StringComparison.OrdinalIgnoreCase))
				{
					return "SAI_MK";
				}
				if (text.Contains("The login code you entered doesn't match", StringComparison.OrdinalIgnoreCase) || text.Contains("Mã đăng nhập bạn nhập không khớp", StringComparison.OrdinalIgnoreCase) || text.Contains("Login code has expired", StringComparison.OrdinalIgnoreCase) || text.Contains("Mã đăng nhập đã hết hạn", StringComparison.OrdinalIgnoreCase) || text.Contains("Invalid code", StringComparison.OrdinalIgnoreCase) || text.Contains("Mã không hợp lệ", StringComparison.OrdinalIgnoreCase))
				{
					return "SAI_2FA";
				}
				if (text.Contains("No account found", StringComparison.OrdinalIgnoreCase) || text.Contains("Không tìm thấy tài khoản", StringComparison.OrdinalIgnoreCase) || text.Contains("Can't find account", StringComparison.OrdinalIgnoreCase))
				{
					return "SAI_MK";
				}
				if (text.Contains("Account disabled", StringComparison.OrdinalIgnoreCase) || text.Contains("Tài khoản đã bị vô hiệu hóa", StringComparison.OrdinalIgnoreCase) || text.Contains("Your account has been disabled", StringComparison.OrdinalIgnoreCase))
				{
					return "DIE";
				}
				if (text.Contains("Your account has been locked", StringComparison.OrdinalIgnoreCase) || text.Contains("Tài khoản của bạn đã bị khóa", StringComparison.OrdinalIgnoreCase) || text.Contains("Confirm your identity", StringComparison.OrdinalIgnoreCase) || text.Contains("Xác nhận danh tính", StringComparison.OrdinalIgnoreCase) || text.Contains("We suspended your account", StringComparison.OrdinalIgnoreCase) || text.Contains("Chúng tôi đã đình chỉ tài khoản của bạn", StringComparison.OrdinalIgnoreCase))
				{
					return "CHECKPOINT";
				}
			}
		}
		return null;
	}

	private static async Task<bool> A(string P_0, List<UiElement> P_1, Action<string> P_2, CancellationToken P_3)
	{
		m_4753 obj = default;
		obj.A = P_1;
		if (obj.A.Count == 0)
		{
			return false;
		}
		string text = string.Join(" ", obj.A.Select((UiElement uiElement11) => $"{uiElement11.Text} {uiElement11.ContentDesc} {uiElement11.ResourceId}")).ToLowerInvariant();
		if (text.Contains("checking info") || text.Contains("com.google.android.gms") || text.Contains("sign in with google") || text.Contains("đăng nhập bằng google") || text.Contains("choose an account") || text.Contains("chọn tài khoản") || text.Contains("use your google account") || text.Contains("google play services") || text.Contains("sign in - google accounts"))
		{
			P_2("Phát hiện màn hình Google / GMS - đang bấm Cancel / Back...");
			UiElement uiElement = A(new string[5] { "Cancel", "Hủy", "Huỷ", "Dismiss", "None of the above" }, ref obj);
			if (uiElement == null)
			{
				await AdbController.KeyEventAsync(P_0, "4", P_3);
			}
			else
			{
				await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_3);
			}
			await Task.Delay(1500, P_3);
			return true;
		}
		if (text.Contains("you'll be logged out") || text.Contains("are you sure you want to leave") || text.Contains("bạn sẽ bị đăng xuất"))
		{
			UiElement uiElement2 = A(new string[3] { "Cancel", "Huỷ", "Hủy" }, ref obj);
			if (uiElement2 != null)
			{
				await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_3);
				P_2("Gặp dialog cảnh báo đăng xuất - bấm Cancel để giữ phiên.");
				return true;
			}
		}
		if ((text.Contains("allow") && text.Contains("don't allow")) || text.Contains("permission_allow_button") || (text.Contains("cho phép") && text.Contains("từ chối")))
		{
			UiElement uiElement3 = obj.A.FirstOrDefault((UiElement uiElement11) => uiElement11.ResourceId.Contains("permission_allow_button") || uiElement11.ResourceId.Contains("permission_allow_foreground_only_button") || uiElement11.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) || uiElement11.Text.Equals("While using the app", StringComparison.OrdinalIgnoreCase) || uiElement11.ContentDesc.Equals("Allow", StringComparison.OrdinalIgnoreCase) || uiElement11.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase));
			if (uiElement3 != null)
			{
				await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_3);
				P_2("Cấp quyền ứng dụng (Allow).");
				return true;
			}
		}
		if (text.Contains("i already have a profile") || (text.Contains("join facebook") && text.Contains("get started")))
		{
			UiElement uiElement4 = a(new string[3] { "I already have a profile", "already have a profile", "already have" }, ref obj);
			if (uiElement4 != null)
			{
				await AdbController.TapAsync(P_0, uiElement4.CenterX, uiElement4.CenterY, P_3);
				P_2("Màn Join Facebook - bấm 'I already have a profile'.");
				return true;
			}
		}
		if (text.Contains("facebook") && (text.Contains("thử dùng tiếng việt") || text.Contains("use facebook in")))
		{
			UiElement uiElement5 = A(new string[7] { "Không", "Not now", "Lúc khác", "English", "Hủy", "Huỷ", "Cancel" }, ref obj);
			if (uiElement5 != null)
			{
				P_2("Từ chối gợi ý đổi ngôn ngữ, giữ Tiếng Anh...");
				await AdbController.TapAsync(P_0, uiElement5.CenterX, uiElement5.CenterY, P_3);
				return true;
			}
		}
		UiElement uiElement6 = obj.A.FirstOrDefault((UiElement uiElement11) => uiElement11.Text.Equals("Save", StringComparison.OrdinalIgnoreCase) || uiElement11.ContentDesc.Equals("Save", StringComparison.OrdinalIgnoreCase) || uiElement11.Text.Equals("Lưu", StringComparison.OrdinalIgnoreCase) || uiElement11.ContentDesc.Equals("Lưu", StringComparison.OrdinalIgnoreCase) || uiElement11.Text.Equals("Save browser", StringComparison.OrdinalIgnoreCase) || uiElement11.ContentDesc.Equals("Save browser", StringComparison.OrdinalIgnoreCase) || uiElement11.Text.Equals("Trust this device", StringComparison.OrdinalIgnoreCase) || uiElement11.ContentDesc.Equals("Trust this device", StringComparison.OrdinalIgnoreCase) || uiElement11.Text.Equals("Tin cậy thiết bị này", StringComparison.OrdinalIgnoreCase) || uiElement11.ContentDesc.Equals("Tin cậy thiết bị này", StringComparison.OrdinalIgnoreCase));
		if (uiElement6 != null && (text.Contains("save your login info") || text.Contains("lưu thông tin") || text.Contains("save browser") || text.Contains("trust this device") || text.Contains("tin cậy thiết bị") || text.Contains("remember")))
		{
			P_2("Bấm Lưu thông tin đăng nhập / Tin cậy thiết bị...");
			await AdbController.TapAsync(P_0, uiElement6.CenterX, uiElement6.CenterY, P_3);
			return true;
		}
		if (text.Contains("enter your password to log in") || text.Contains("nhập mật khẩu để đăng nhập"))
		{
			UiElement uiElement7 = A(new string[1] { "OK" }, ref obj);
			if (uiElement7 != null)
			{
				P_2("Dialog yêu cầu mật khẩu - bấm OK.");
				await AdbController.TapAsync(P_0, uiElement7.CenterX, uiElement7.CenterY, P_3);
				return true;
			}
		}
		UiElement uiElement8 = A(new string[11]
		{
			"Skip", "Skip for now", "Bỏ qua", "Not now", "Not Now", "Maybe later", "Để sau", "No thanks", "Không, cảm ơn", "Later",
			"SKIP"
		}, ref obj);
		if (uiElement8 != null)
		{
			string text2 = ((!string.IsNullOrWhiteSpace(uiElement8.Text)) ? uiElement8.Text.Trim() : uiElement8.ContentDesc.Trim());
			P_2("Bấm bỏ qua (" + text2 + ")...");
			await AdbController.TapAsync(P_0, uiElement8.CenterX, uiElement8.CenterY, P_3);
			return true;
		}
		UiElement uiElement9 = A(new string[4] { "Close", "Đóng", "Dismiss", "X" }, ref obj);
		if (uiElement9 != null)
		{
			P_2("Bấm X / Close...");
			await AdbController.TapAsync(P_0, uiElement9.CenterX, uiElement9.CenterY, P_3);
			return true;
		}
		if (!obj.A.Any((UiElement uiElement11) => uiElement11.ClassName.Contains("EditText")))
		{
			UiElement uiElement10 = A(new string[6] { "Continue", "Tiếp tục", "Tiếp", "OK", "Done", "Xong" }, ref obj);
			if (uiElement10 != null)
			{
				string text3 = ((!string.IsNullOrWhiteSpace(uiElement10.Text)) ? uiElement10.Text.Trim() : uiElement10.ContentDesc.Trim());
				P_2("Bấm tiếp tục (" + text3 + ")...");
				await AdbController.TapAsync(P_0, uiElement10.CenterX, uiElement10.CenterY, P_3);
				return true;
			}
		}
		return false;
	}

	private static (int X, int Y)? b(List<UiElement> elements)
	{
		UiElement uiElement = elements.FirstOrDefault((UiElement P_0) => P_0.Text.Contains("Use another profile", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Use another profile", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Use another account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Use another account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Log into another account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Log into another account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Log in to another account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Log in to another account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("another profile", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("another profile", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("another account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("another account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Usar otra cuenta", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Usar otra cuenta", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("otro perfil", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("otro perfil", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("otra cuenta", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("otra cuenta", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Utiliser un autre profil", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Utiliser un autre profil", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("autre profil", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("autre profil", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Usar outro perfil", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Usar outro perfil", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("outro perfil", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("outro perfil", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Dùng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Dùng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Sử dụng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Sử dụng trang cá nhân khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Đăng nhập bằng tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Đăng nhập bằng tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Đăng nhập vào tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Đăng nhập vào tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Dùng tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Dùng tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Sử dụng tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Sử dụng tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Trang cá nhân khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Trang cá nhân khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Tài khoản khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tài khoản khác", StringComparison.OrdinalIgnoreCase));
		if (uiElement != null)
		{
			return (uiElement.CenterX, uiElement.CenterY);
		}
		if (!elements.Any((UiElement P_0) => P_0.ClassName.Contains("EditText")))
		{
			UiElement uiElement2 = elements.FirstOrDefault((UiElement P_0) => P_0.CenterY >= 700 && P_0.CenterY <= 860 && P_0.Right - P_0.Left > 500 && (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("ViewGroup")));
			if (uiElement2 != null)
			{
				return (uiElement2.CenterX, uiElement2.Bottom + 60);
			}
			UiElement uiElement3 = elements.FirstOrDefault((UiElement P_0) => P_0.CenterY >= 850 && P_0.CenterY <= 960 && (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")));
			if (uiElement3 != null)
			{
				return (uiElement3.CenterX, uiElement3.CenterY);
			}
		}
		return null;
	}

	private static bool C(List<UiElement> P_0)
	{
		if (P_0 == null || P_0.Count == 0)
		{
			return true;
		}
		if (P_0.Any((UiElement uiElement) => uiElement.Text.Contains("Đăng nhập", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Đăng nhập", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Số di động", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Số di động", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Quên mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Quên mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Dùng trang cá nhân", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Dùng trang cá nhân", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Tiếng Việt", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Tiếng Việt", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Iniciar sesión", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Iniciar sesión", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Contraseña", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Contraseña", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Crear cuenta", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Crear cuenta", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Usar otro perfil", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Español", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Español", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Se connecter", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Se connecter", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Entrar", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Entrar", StringComparison.OrdinalIgnoreCase)))
		{
			return false;
		}
		P_0.Any((UiElement uiElement) => uiElement.Text.Contains("English", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("English", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Equals("Log in", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Equals("Log in", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Password", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Mobile number or email", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Mobile number or email", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Forgot password", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Forgot password", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Create new account", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Create new account", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Join Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Join Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("I already have a profile", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("I already have a profile", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Get started", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Get started", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("another profile", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("another profile", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("another account", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("another account", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase));
		return true;
	}

	public static async Task EnsureFacebookAppLanguageEnglishAsync(string deviceSerial, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 14;
		try
		{
			try
			{
				await AdbController.RunShellCaptureAsync(deviceSerial, "cmd locale set-app-locales com.facebook.katana --locales en-US 2>/dev/null", cancellationToken);
			}
			catch
			{
			}
			List<UiElement> list = new List<UiElement>();
			for (int i = 0; i < 6; i++)
			{
				list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				if (list.Any((UiElement P_0) => !string.IsNullOrWhiteSpace(P_0.Text) || !string.IsNullOrWhiteSpace(P_0.ContentDesc) || P_0.ClassName.Contains("EditText") || P_0.ClassName.Contains("Button")))
				{
					break;
				}
				await Task.Delay(1000, cancellationToken);
			}
			UiElement uiElement = list.FirstOrDefault((UiElement P_0) => P_0.Text.Equals("Không", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Không", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Not now", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Not now", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Ahora no", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Ahora no", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Lúc khác", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Lúc khác", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Hủy", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Hủy", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Cancelar", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Cancelar", StringComparison.OrdinalIgnoreCase));
			if (uiElement != null && list.Any((UiElement P_0) => P_0.Text.Contains("Facebook", StringComparison.OrdinalIgnoreCase) && (P_0.Text.Contains("Thử dùng", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("idioma", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("language", StringComparison.OrdinalIgnoreCase))))
			{
				onStatus("Từ chối gợi ý đổi ngôn ngữ, giữ Tiếng Anh...");
				await AdbController.TapAsync(deviceSerial, uiElement.CenterX, uiElement.CenterY, cancellationToken);
				await Task.Delay(1500, cancellationToken);
				list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			}
			if (C(list))
			{
				onStatus("Facebook đang ở Tiếng Anh (English) -> Giữ nguyên, tiếp tục đăng nhập.");
				return;
			}
			onStatus("Phát hiện Facebook đang hiển thị ngôn ngữ khác. Đang chuyển về Tiếng Anh (English)...");
			if (!list.Any((UiElement P_0) => P_0.ClassName.Contains("EditText")))
			{
				(int, int)? tuple = b(list);
				if (tuple.HasValue)
				{
					onStatus("Chuyển sang form đăng nhập để chọn ngôn ngữ English...");
					await AdbController.TapAsync(deviceSerial, tuple.Value.Item1, tuple.Value.Item2, cancellationToken);
					await Task.Delay(2000, cancellationToken);
					list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				}
			}
			UiElement uiElement2 = list.FirstOrDefault((UiElement P_0) => P_0.CenterY >= 60 && P_0.CenterY <= 300 && P_0.CenterX >= 200 && P_0.CenterX <= 700 && !string.Equals(P_0.ClassName, "android.widget.FrameLayout", StringComparison.OrdinalIgnoreCase) && (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View") || P_0.ClassName.Contains("TextView")));
			int x = uiElement2?.CenterX ?? 450;
			int y = uiElement2?.CenterY ?? 100;
			string text = ((!string.IsNullOrWhiteSpace(uiElement2?.Text)) ? uiElement2.Text.Trim() : (uiElement2?.ContentDesc?.Trim() ?? "menu"));
			onStatus("Mở menu ngôn ngữ (" + text + ")...");
			await AdbController.TapAsync(deviceSerial, x, y, cancellationToken);
			await Task.Delay(2000, cancellationToken);
			UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("English (US)", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("English (US)", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.StartsWith("English", StringComparison.OrdinalIgnoreCase) || P_0.Text.StartsWith("English", StringComparison.OrdinalIgnoreCase));
			if (uiElement3 != null)
			{
				onStatus("Chọn: English (US)...");
				await AdbController.TapAsync(deviceSerial, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
				await Task.Delay(3000, cancellationToken);
				onStatus("Đã chuyển ngôn ngữ Facebook sang English thành công.");
			}
			else
			{
				onStatus("Không tìm thấy mục English trong danh sách -> Nhấn Back giữ nguyên màn hình.");
				await AdbController.RunShellAsync(deviceSerial, "input keyevent 4", cancellationToken);
			}
		}
		catch (Exception ex)
		{
			onStatus("Lưu ý khi kiểm tra ngôn ngữ: " + ex.Message);
		}
	}

	private static async Task<string> A(string P_0, CancellationToken P_1 = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return "LIVE";
		}
		try
		{
			using HttpClient httpClient = new HttpClient
			{
				Timeout = TimeSpan.FromSeconds(15L)
			};
			using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, "https://graph.facebook.com/" + P_0.Trim() + "/picture?redirect=false");
			httpRequestMessage.Headers.Add("user-agent", "Mozilla/5.0");
			using HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(httpRequestMessage, P_1);
			return (await httpResponseMessage.Content.ReadAsStringAsync(P_1)).Contains("width") ? "LIVE" : "DIE";
		}
		catch
		{
			return "LIVE";
		}
	}

	[CompilerGenerated]
	internal static UiElement? A(string[] kws, ref m_4753 P_1)
	{
		return P_1.A.FirstOrDefault((UiElement uiElement) => kws.Any((string value) => uiElement.Text.Equals(value, StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Equals(value, StringComparison.OrdinalIgnoreCase)));
	}

	[CompilerGenerated]
	internal static UiElement? a(string[] kws, ref m_4753 P_1)
	{
		return P_1.A.FirstOrDefault((UiElement uiElement) => kws.Any((string value) => uiElement.Text.Contains(value, StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains(value, StringComparison.OrdinalIgnoreCase)));
	}
}
