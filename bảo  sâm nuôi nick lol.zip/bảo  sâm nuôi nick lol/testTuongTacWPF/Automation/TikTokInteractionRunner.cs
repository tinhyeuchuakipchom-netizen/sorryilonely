using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public static class TikTokInteractionRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6325
	{
		public static readonly m_6325 A = new m_6325();

		public static Func<UiElement, bool> m_6341;

		public static Func<UiElement, bool> a;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		public static Func<UiElement, bool> C;

		public static Func<UiElement, bool> c;

		public static Func<UiElement, bool> D;

		public static Func<UiElement, bool> d;

		public static Func<UiElement, bool> E;

		public static Func<UiElement, bool> e;

		public static Func<UiElement, bool> F;

		public static Func<UiElement, bool> f;

		public static Func<UiElement, bool> G;

		public static Func<UiElement, bool> g;

		public static Func<UiElement, bool> H;

		public static Func<UiElement, bool> h;

		public static Func<UiElement, bool> I;

		public static Func<UiElement, bool> i;

		public static Func<UiElement, bool> J;

		public static Func<UiElement, bool> j;

		public static Func<UiElement, bool> K;

		public static Func<UiElement, bool> k;

		public static Func<UiElement, bool> L;

		internal bool m_6342(UiElement P_0)
		{
			if (P_0.Enabled && m_6322(P_0, TikTokInteractionRunner.C))
			{
				return !m_6322(P_0, TikTokInteractionRunner.c);
			}
			return false;
		}

		internal bool m_6343(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, "edit profile", "sửa hồ sơ", "chỉnh sửa") && !P_0.ResourceId.Contains("edit_profile"))
				{
					return P_0.ResourceId.Contains("bq7");
				}
				return true;
			}
			return false;
		}

		internal bool m_6344(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				return m_6322(P_0, "select from gallery", "upload photo", "chọn từ thư viện", "thư viện", "gallery");
			}
			return false;
		}

		internal bool m_6345(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				return m_6322(P_0, "save", "lưu", "confirm", "xác nhận", "post", "done");
			}
			return false;
		}

		internal bool m_6346(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.g))
				{
					return P_0.ResourceId.Contains("share");
				}
				return true;
			}
			return false;
		}

		internal bool m_6347(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.H))
				{
					return P_0.ResourceId.Contains("repost");
				}
				return true;
			}
			return false;
		}

		internal bool m_6348(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.h))
				{
					return P_0.ResourceId.Contains("copy");
				}
				return true;
			}
			return false;
		}

		internal bool m_6349(UiElement P_0)
		{
			if (P_0.Enabled && m_6322(P_0, TikTokInteractionRunner.G))
			{
				return P_0.Top > 1300;
			}
			return false;
		}

		internal bool m_6350(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, "close", "đóng"))
				{
					return P_0.ResourceId.Contains("bs7");
				}
				return true;
			}
			return false;
		}

		internal bool m_6351(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				return m_6322(P_0, TikTokInteractionRunner.f);
			}
			return false;
		}

		internal bool m_6352(UiElement P_0)
		{
			return m_6322(P_0, TikTokInteractionRunner.B);
		}

		internal bool m_6353(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.a) && !P_0.ResourceId.Contains("g65"))
				{
					if (P_0.ResourceId.Contains("g6o"))
					{
						return m_6322(P_0, "like");
					}
					return false;
				}
				return true;
			}
			return false;
		}

		internal bool m_6354(UiElement P_0)
		{
			return m_6322(P_0, TikTokInteractionRunner.d);
		}

		internal bool m_6355(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.D))
				{
					return P_0.ResourceId.Contains("i74");
				}
				return true;
			}
			return false;
		}

		internal bool m_6356(UiElement P_0)
		{
			return m_6322(P_0, TikTokInteractionRunner.c);
		}

		internal bool m_6357(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.C) && !P_0.ResourceId.EndsWith(":id/ivc"))
				{
					return P_0.ResourceId == "ivc";
				}
				return true;
			}
			return false;
		}

		internal bool m_6358(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, TikTokInteractionRunner.b))
				{
					return P_0.ResourceId.Contains("eor");
				}
				return true;
			}
			return false;
		}

		internal bool m_6359(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText") && !m_6322(P_0, TikTokInteractionRunner.E))
			{
				return P_0.ResourceId.Contains("ejc");
			}
			return true;
		}

		internal bool m_6360(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				return m_6322(P_0, TikTokInteractionRunner.e);
			}
			return false;
		}

		internal bool m_6361(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, "close", "đóng"))
				{
					return P_0.ResourceId.Contains("bs7");
				}
				return true;
			}
			return false;
		}

		internal bool m_6362(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				return m_6322(P_0, TikTokInteractionRunner.F);
			}
			return false;
		}

		internal bool m_6363(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!P_0.ClassName.Contains("ImageView"))
				{
					return m_6322(P_0, "photo", "image", "ảnh");
				}
				return true;
			}
			return false;
		}

		internal bool m_6364(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				return m_6322(P_0, TikTokInteractionRunner.e);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_6326
	{
		public int A;

		public int a;

		internal bool m_6365(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, "profile", "hồ sơ", "me"))
				{
					if ((double)P_0.Top > (double)A * 0.88)
					{
						return (double)P_0.Right > (double)a * 0.75;
					}
					return false;
				}
				return true;
			}
			return false;
		}

		internal bool m_6366(UiElement P_0)
		{
			if (P_0.ClassName.Contains("ImageView") && (double)P_0.Top > (double)A * 0.08)
			{
				return (double)P_0.Top < (double)A * 0.35;
			}
			return false;
		}

		internal bool B(UiElement P_0)
		{
			if (P_0.Enabled)
			{
				if (!m_6322(P_0, "change photo", "đổi ảnh", "photo", "camera"))
				{
					if ((double)P_0.Top > (double)A * 0.05 && (double)P_0.Top < (double)A * 0.35 && (double)P_0.CenterX > (double)a * 0.3)
					{
						return (double)P_0.CenterX < (double)a * 0.7;
					}
					return false;
				}
				return true;
			}
			return false;
		}

		internal bool b(UiElement P_0)
		{
			if (P_0.Enabled && (P_0.ClassName.Contains("ImageView") || m_6322(P_0, "photo", "image", "ảnh")))
			{
				return (double)P_0.Top > (double)A * 0.1;
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_6327
	{
		public int A;

		public int a;

		internal bool m_6367(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("user_avatar"))
			{
				if ((double)P_0.Right > (double)A * 0.8 && (double)P_0.Top > (double)a * 0.4)
				{
					return (double)P_0.Top < (double)a * 0.6;
				}
				return false;
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_6328
	{
		public string A;

		internal bool m_6368(string P_0)
		{
			return A.Contains(P_0);
		}
	}

	private static readonly string[] A = new string[2] { "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" };

	private static readonly string[] a = new string[2] { "like video", "thích video" };

	private static readonly string[] B = new string[3] { "unlike video", "bỏ thích", "đã thích" };

	private static readonly string[] b = new string[5] { "read or add comments", "xem hoặc thêm bình luận", "comment", "bình luận", "binh luan" };

	private static readonly string[] C = new string[2] { "follow ", "theo dõi " };

	private static readonly string[] c = new string[6] { "following", "đang theo dõi", "dang theo doi", "friends", "bạn bè", "requested" };

	private static readonly string[] D = new string[5] { "favorites", "favorite", "yêu thích", "lưu video", "bookmark" };

	private static readonly string[] d = new string[3] { "remove this video from favorites", "bỏ khỏi yêu thích", "đã lưu" };

	private static readonly string[] E = new string[6] { "add comment", "thêm bình luận", "them binh luan", "viết bình luận", "viet binh luan", "bình luận" };

	private static readonly string[] e = new string[6] { "post", "send", "đăng", "dang", "gửi", "gui" };

	private static readonly string[] F = new string[8] { "image", "photo", "ảnh", "anh", "gallery", "album", "sticker", "gif" };

	private static readonly string[] f = new string[16]
	{
		"not now", "không phải bây giờ", "để sau", "later", "cancel", "hủy", "close", "đóng", "skip", "bỏ qua",
		"dismiss", "got it", "đã hiểu", "don't allow", "từ chối", "không cho phép"
	};

	private static readonly string[] G = new string[2] { "home", "trang chủ" };

	private static readonly string[] g = new string[5] { "share video", "chia sẻ video", "share", "chia sẻ", "chia se" };

	private static readonly string[] H = new string[3] { "repost", "đăng lại", "dang lai" };

	private static readonly string[] h = new string[4] { "copy link", "sao chép liên kết", "sao chep lien ket", "copy_link" };

	public static async Task<LoginResult> RunAsync(string deviceSerial, TikTokInteractionSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 17;
		try
		{
			onStatus("Đang kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			string text = await m_6323(deviceSerial, cancellationToken);
			if (text == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Máy chưa cài TikTok"
				};
			}
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			onStatus("Kiểm tra trạng thái TikTok (nick đã đăng nhập sẵn)...");
			await m_6314(deviceSerial, text, onStatus, cancellationToken);
			await m_6315(deviceSerial, onStatus, cancellationToken);
			var (num, num2) = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			if (num <= 0 || num2 <= 0)
			{
				num = 900;
				num2 = 1600;
			}
			int num3 = settings.PickDurationMinutes();
			DateTime dateTime = DateTime.UtcNow.AddMinutes(num3);
			onStatus($"Bắt đầu lướt tương tác TikTok ~{num3} phút...");
			int num4 = 0;
			int num5 = 0;
			int num6 = 0;
			int num7 = 0;
			int num8 = 0;
			while (DateTime.UtcNow < dateTime)
			{
				cancellationToken.ThrowIfCancellationRequested();
				num4++;
				await Task.Delay(TimeSpan.FromSeconds(Random.Shared.Next(4, 9)), cancellationToken);
				List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				await m_6316(deviceSerial, list, cancellationToken);
				if (settings.AutoLike && settings.RollChance(settings.LikeChancePercent))
				{
					onStatus($"Video {num4}: thả tim...");
					if (await m_6317(deviceSerial, num, num2, list, cancellationToken))
					{
						num5++;
					}
					await Task.Delay(Random.Shared.Next(600, 1200), cancellationToken);
				}
				if (settings.AutoFavorite && settings.RollChance(settings.FavoriteChancePercent))
				{
					onStatus($"Video {num4}: lưu vào yêu thích...");
					if (await m_6318(deviceSerial, num, num2, list, cancellationToken))
					{
						num8++;
					}
					await Task.Delay(Random.Shared.Next(600, 1200), cancellationToken);
				}
				if (settings.AutoFollow && settings.RollChance(settings.FollowChancePercent))
				{
					onStatus($"Video {num4}: kiểm tra & follow...");
					if (await m_6319(deviceSerial, num, num2, list, cancellationToken))
					{
						num7++;
					}
					await Task.Delay(Random.Shared.Next(600, 1200), cancellationToken);
				}
				if (settings.AutoComment && settings.RollChance(settings.CommentChancePercent))
				{
					onStatus($"Video {num4}: mở bình luận...");
					if (await m_6320(deviceSerial, num, num2, settings, list, cancellationToken))
					{
						num6++;
					}
					await Task.Delay(Random.Shared.Next(800, 1500), cancellationToken);
				}
				int x = num / 2 + Random.Shared.Next(-30, 30);
				int y = (int)((double)num2 * 0.76) + Random.Shared.Next(-25, 25);
				int x2 = num / 2 + Random.Shared.Next(-30, 30);
				int y2 = (int)((double)num2 * 0.24) + Random.Shared.Next(-25, 25);
				int durationMs = Random.Shared.Next(240, 380);
				await AdbController.SwipeAsync(deviceSerial, x, y, x2, y2, durationMs, cancellationToken);
				int value = Math.Max(0, (int)(dateTime - DateTime.UtcNow).TotalMinutes);
				onStatus($"Đang lướt video {num4} (còn ~{value} phút)...");
			}
			string text2 = $"Xong: lướt {num4} video / {num3} phút";
			List<string> list2 = new List<string>();
			if (settings.AutoLike)
			{
				list2.Add($"tim {num5}");
			}
			if (settings.AutoFavorite)
			{
				list2.Add($"lưu {num8}");
			}
			if (settings.AutoFollow)
			{
				list2.Add($"follow {num7}");
			}
			if (settings.AutoComment)
			{
				list2.Add($"cmt {num6}");
			}
			if (list2.Count > 0)
			{
				text2 = text2 + " (" + string.Join(", ", list2) + ")";
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "OK",
				TrangThai = text2
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "STOP",
				TrangThai = "Đã dừng."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi tương tác TikTok: " + ex2.Message
			};
		}
	}

	public static async Task<LoginResult> RunLikeOnlyAsync(string deviceSerial, TikTokLikeSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 11;
		try
		{
			onStatus("Đang kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			string text = await m_6323(deviceSerial, cancellationToken);
			if (text == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Máy chưa cài TikTok"
				};
			}
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			onStatus("Mở TikTok & đưa về màn hình chính...");
			await m_6314(deviceSerial, text, onStatus, cancellationToken);
			await m_6315(deviceSerial, onStatus, cancellationToken);
			var (num, num2) = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			if (num <= 0 || num2 <= 0)
			{
				num = 900;
				num2 = 1600;
			}
			int num3 = settings.PickCount();
			int num4 = 0;
			int num5 = 0;
			onStatus($"Bắt đầu kịch bản Thả tim (mục tiêu: {num3} video)...");
			while (num4 < num3)
			{
				cancellationToken.ThrowIfCancellationRequested();
				num5++;
				int num6 = settings.PickDelaySec();
				onStatus($"Xem video {num5} (~{num6}s)... (đã thả tim {num4}/{num3})");
				await Task.Delay(TimeSpan.FromSeconds(num6), cancellationToken);
				List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				await m_6316(deviceSerial, list, cancellationToken);
				if (settings.RollChance())
				{
					onStatus($"Thả tim video {num5}...");
					if (await m_6317(deviceSerial, num, num2, list, cancellationToken))
					{
						num4++;
					}
					await Task.Delay(Random.Shared.Next(600, 1200), cancellationToken);
				}
				if (num4 >= num3)
				{
					break;
				}
				await m_6312(deviceSerial, num, num2, cancellationToken);
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "OK",
				TrangThai = $"Hoàn thành thả tim {num4}/{num3} video (lướt {num5} video)"
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "STOP",
				TrangThai = "Đã dừng."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi thả tim: " + ex2.Message
			};
		}
	}

	public static async Task<LoginResult> RunCommentOnlyAsync(string deviceSerial, TikTokCommentSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 11;
		try
		{
			onStatus("Đang kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			string text = await m_6323(deviceSerial, cancellationToken);
			if (text == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Máy chưa cài TikTok"
				};
			}
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			onStatus("Mở TikTok & đưa về màn hình chính...");
			await m_6314(deviceSerial, text, onStatus, cancellationToken);
			await m_6315(deviceSerial, onStatus, cancellationToken);
			var (num, num2) = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			if (num <= 0 || num2 <= 0)
			{
				num = 900;
				num2 = 1600;
			}
			TikTokInteractionSettings tikTokInteractionSettings = new TikTokInteractionSettings
			{
				CommentTexts = settings.CommentTexts,
				AppendEmoji = settings.AppendEmoji,
				CommentEmojis = settings.CommentEmojis,
				CommentWithImage = settings.CommentWithImage,
				CommentImageFolder = settings.CommentImageFolder
			};
			int num3 = settings.PickCount();
			int num4 = 0;
			int num5 = 0;
			onStatus($"Bắt đầu kịch bản Bình luận (mục tiêu: {num3} bình luận)...");
			while (num4 < num3)
			{
				cancellationToken.ThrowIfCancellationRequested();
				num5++;
				int num6 = settings.PickDelaySec();
				onStatus($"Xem video {num5} (~{num6}s)... (đã cmt {num4}/{num3})");
				await Task.Delay(TimeSpan.FromSeconds(num6), cancellationToken);
				List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				await m_6316(deviceSerial, list, cancellationToken);
				if (settings.RollChance())
				{
					onStatus($"Mở và gửi bình luận video {num5}...");
					if (await m_6320(deviceSerial, num, num2, tikTokInteractionSettings, list, cancellationToken))
					{
						num4++;
					}
					await Task.Delay(Random.Shared.Next(1000, 2000), cancellationToken);
				}
				if (num4 >= num3)
				{
					break;
				}
				await m_6312(deviceSerial, num, num2, cancellationToken);
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "OK",
				TrangThai = $"Hoàn thành bình luận {num4}/{num3} video"
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "STOP",
				TrangThai = "Đã dừng."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi bình luận: " + ex2.Message
			};
		}
	}

	public static async Task<LoginResult> RunFollowOnlyAsync(string deviceSerial, TikTokFollowSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 16;
		try
		{
			onStatus("Đang kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			string text = await m_6323(deviceSerial, cancellationToken);
			if (text == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Máy chưa cài TikTok"
				};
			}
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			onStatus("Mở TikTok & đưa về màn hình chính...");
			await m_6314(deviceSerial, text, onStatus, cancellationToken);
			var (num, num2) = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			if (num <= 0 || num2 <= 0)
			{
				num = 900;
				num2 = 1600;
			}
			int num3 = settings.PickCount();
			int num4 = 0;
			if (settings.FollowMode == "List" && settings.TargetUsernames.Count > 0)
			{
				onStatus($"Bắt đầu follow theo danh sách ({settings.TargetUsernames.Count} username)...");
				foreach (string targetUsername in settings.TargetUsernames)
				{
					cancellationToken.ThrowIfCancellationRequested();
					if (num4 < num3)
					{
						onStatus("Tìm kiếm & follow @" + targetUsername + "...");
						await AdbController.RunShellAsync(deviceSerial, "am start -a android.intent.action.VIEW -d \"https://www.tiktok.com/@" + targetUsername + "\"", cancellationToken);
						await Task.Delay(3500, cancellationToken);
						List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
						await m_6316(deviceSerial, list, cancellationToken);
						UiElement uiElement = list.FirstOrDefault((UiElement P_0) => P_0.Enabled && m_6322(P_0, C) && !m_6322(P_0, c));
						if (uiElement != null)
						{
							await AdbController.TapAsync(deviceSerial, uiElement.CenterX, uiElement.CenterY, cancellationToken);
							num4++;
							onStatus($"Đã follow @{targetUsername} ({num4}/{num3})");
						}
						await Task.Delay(TimeSpan.FromSeconds(settings.PickDelaySec()), cancellationToken);
						continue;
					}
					break;
				}
			}
			else
			{
				await m_6315(deviceSerial, onStatus, cancellationToken);
				onStatus($"Bắt đầu lướt feed & follow (mục tiêu: {num3} kênh)...");
				int num5 = 0;
				while (num4 < num3)
				{
					cancellationToken.ThrowIfCancellationRequested();
					num5++;
					int num6 = settings.PickDelaySec();
					onStatus($"Xem video {num5} (~{num6}s)... (đã follow {num4}/{num3})");
					await Task.Delay(TimeSpan.FromSeconds(num6), cancellationToken);
					List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
					await m_6316(deviceSerial, list, cancellationToken);
					onStatus($"Kiểm tra nút follow video {num5}...");
					if (await m_6319(deviceSerial, num, num2, list, cancellationToken))
					{
						num4++;
						onStatus($"Đã follow tác giả video {num5} ({num4}/{num3})");
					}
					if (num4 >= num3)
					{
						break;
					}
					await m_6312(deviceSerial, num, num2, cancellationToken);
				}
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "OK",
				TrangThai = $"Hoàn thành follow {num4}/{num3} kênh"
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "STOP",
				TrangThai = "Đã dừng."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi follow: " + ex2.Message
			};
		}
	}

	public static async Task<LoginResult> RunShareOnlyAsync(string deviceSerial, TikTokShareSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 10;
		try
		{
			onStatus("Đang kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			string text = await m_6323(deviceSerial, cancellationToken);
			if (text == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Máy chưa cài TikTok"
				};
			}
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			onStatus("Mở TikTok & đưa về màn hình chính...");
			await m_6314(deviceSerial, text, onStatus, cancellationToken);
			await m_6315(deviceSerial, onStatus, cancellationToken);
			var (num, num2) = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			if (num <= 0 || num2 <= 0)
			{
				num = 900;
				num2 = 1600;
			}
			int num3 = settings.PickCount();
			int num4 = 0;
			int num5 = 0;
			string value = ((settings.ShareType == "CopyLink") ? "Sao chép liên kết" : "Đăng lại (Repost)");
			onStatus($"Bắt đầu chia sẻ ({value}, mục tiêu: {num3} video)...");
			while (num4 < num3)
			{
				cancellationToken.ThrowIfCancellationRequested();
				num5++;
				int num6 = settings.PickDelaySec();
				onStatus($"Xem video {num5} (~{num6}s)... (đã chia sẻ {num4}/{num3})");
				await Task.Delay(TimeSpan.FromSeconds(num6), cancellationToken);
				List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
				await m_6316(deviceSerial, list, cancellationToken);
				onStatus($"Mở chia sẻ video {num5}...");
				if (await m_6313(deviceSerial, num, num2, settings.ShareType, list, cancellationToken))
				{
					num4++;
					onStatus($"Đã chia sẻ ({value}) video {num5} ({num4}/{num3})");
				}
				if (num4 >= num3)
				{
					break;
				}
				await m_6312(deviceSerial, num, num2, cancellationToken);
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "OK",
				TrangThai = $"Hoàn thành chia sẻ {num4}/{num3} video ({value})"
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "STOP",
				TrangThai = "Đã dừng."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi chia sẻ: " + ex2.Message
			};
		}
	}

	public static async Task<LoginResult> RunUpdateAvatarAsync(string deviceSerial, TikTokAvatarSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 33;
		try
		{
			onStatus("Đang kiểm tra file ảnh avatar...");
			string text = settings.PickAvatarPath();
			if (text == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Không tìm thấy file ảnh trong thư mục cấu hình"
				};
			}
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			string text2 = await m_6323(deviceSerial, cancellationToken);
			if (text2 == null)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Máy chưa cài TikTok"
				};
			}
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			string value = Path.GetExtension(text).ToLowerInvariant();
			string text3 = $"/sdcard/Pictures/tiktok_avatar_{DateTime.Now.Ticks}{value}";
			onStatus("Đẩy file ảnh " + Path.GetFileName(text) + " vào thiết bị...");
			if (!(await m_6324(deviceSerial, text, text3, cancellationToken)))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Lỗi đẩy file ảnh qua ADB"
				};
			}
			await AdbController.RunShellAsync(deviceSerial, "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + text3, cancellationToken);
			await Task.Delay(1000, cancellationToken);
			onStatus("Mở TikTok & chuyển sang trang cá nhân (Profile)...");
			await m_6314(deviceSerial, text2, onStatus, cancellationToken);
			var (a, A) = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			if (a <= 0 || A <= 0)
			{
				a = 900;
				A = 1600;
			}
			List<UiElement> list = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			await m_6316(deviceSerial, list, cancellationToken);
			UiElement uiElement = list.FirstOrDefault((UiElement P_0) => P_0.Enabled && (m_6322(P_0, "profile", "hồ sơ", "me") || ((double)P_0.Top > (double)A * 0.88 && (double)P_0.Right > (double)a * 0.75)));
			if (uiElement == null)
			{
				await AdbController.TapAsync(deviceSerial, (int)((double)a * 0.9), (int)((double)A * 0.96), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, uiElement.CenterX, uiElement.CenterY, cancellationToken);
			}
			await Task.Delay(2500, cancellationToken);
			List<UiElement> list2 = await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken);
			await m_6316(deviceSerial, list2, cancellationToken);
			UiElement uiElement2 = list2.FirstOrDefault((UiElement P_0) => P_0.Enabled && (m_6322(P_0, "edit profile", "sửa hồ sơ", "chỉnh sửa") || P_0.ResourceId.Contains("edit_profile") || P_0.ResourceId.Contains("bq7")));
			if (uiElement2 != null)
			{
				await AdbController.TapAsync(deviceSerial, uiElement2.CenterX, uiElement2.CenterY, cancellationToken);
			}
			else
			{
				UiElement uiElement3 = list2.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("ImageView") && (double)P_0.Top > (double)A * 0.08 && (double)P_0.Top < (double)A * 0.35);
				if (uiElement3 == null)
				{
					await AdbController.TapAsync(deviceSerial, a / 2, (int)((double)A * 0.28), cancellationToken);
				}
				else
				{
					await AdbController.TapAsync(deviceSerial, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
				}
			}
			await Task.Delay(2500, cancellationToken);
			UiElement uiElement4 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.Enabled && (m_6322(P_0, "change photo", "đổi ảnh", "photo", "camera") || ((double)P_0.Top > (double)A * 0.05 && (double)P_0.Top < (double)A * 0.35 && (double)P_0.CenterX > (double)a * 0.3 && (double)P_0.CenterX < (double)a * 0.7)));
			if (uiElement4 == null)
			{
				await AdbController.TapAsync(deviceSerial, a / 2, (int)((double)A * 0.2), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, uiElement4.CenterX, uiElement4.CenterY, cancellationToken);
			}
			await Task.Delay(1800, cancellationToken);
			UiElement uiElement5 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.Enabled && m_6322(P_0, "select from gallery", "upload photo", "chọn từ thư viện", "thư viện", "gallery"));
			if (uiElement5 != null)
			{
				await AdbController.TapAsync(deviceSerial, uiElement5.CenterX, uiElement5.CenterY, cancellationToken);
				await Task.Delay(2000, cancellationToken);
			}
			UiElement uiElement6 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.Enabled && (P_0.ClassName.Contains("ImageView") || m_6322(P_0, "photo", "image", "ảnh")) && (double)P_0.Top > (double)A * 0.1);
			if (uiElement6 == null)
			{
				await AdbController.TapAsync(deviceSerial, (int)((double)a * 0.18), (int)((double)A * 0.22), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, uiElement6.CenterX, uiElement6.CenterY, cancellationToken);
			}
			await Task.Delay(2000, cancellationToken);
			UiElement uiElement7 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.Enabled && m_6322(P_0, "save", "lưu", "confirm", "xác nhận", "post", "done"));
			if (uiElement7 == null)
			{
				await AdbController.TapAsync(deviceSerial, (int)((double)a * 0.85), (int)((double)A * 0.95), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, uiElement7.CenterX, uiElement7.CenterY, cancellationToken);
			}
			onStatus("Đang chờ tải ảnh đại diện lên...");
			await Task.Delay(4500, cancellationToken);
			if (settings.DeleteAfterUse && File.Exists(text))
			{
				try
				{
					File.Delete(text);
				}
				catch
				{
				}
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "OK",
				TrangThai = "Cập nhật avatar thành công (" + Path.GetFileName(text) + ")"
			};
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "STOP",
				TrangThai = "Đã dừng."
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi cập nhật avatar: " + ex2.Message
			};
		}
	}

	private static async Task m_6312(string P_0, int P_1, int P_2, CancellationToken P_3)
	{
		int x = P_1 / 2 + Random.Shared.Next(-30, 30);
		int y = (int)((double)P_2 * 0.76) + Random.Shared.Next(-25, 25);
		int x2 = P_1 / 2 + Random.Shared.Next(-30, 30);
		int y2 = (int)((double)P_2 * 0.24) + Random.Shared.Next(-25, 25);
		int durationMs = Random.Shared.Next(240, 380);
		await AdbController.SwipeAsync(P_0, x, y, x2, y2, durationMs, P_3);
	}

	private static async Task<bool> m_6313(string P_0, int P_1, int P_2, string P_3, List<UiElement> P_4, CancellationToken P_5)
	{
		UiElement uiElement = P_4.FirstOrDefault((UiElement uiElement4) => uiElement4.Enabled && (m_6322(uiElement4, g) || uiElement4.ResourceId.Contains("share")));
		if (uiElement == null)
		{
			await AdbController.TapAsync(P_0, (int)((double)P_1 * 0.93), (int)((double)P_2 * 0.81), P_5);
		}
		else
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_5);
		}
		await Task.Delay(1500, P_5);
		List<UiElement> source = await AdbController.DumpUiElementsAsync(P_0, P_5);
		bool result = false;
		if (string.Equals(P_3, "Repost", StringComparison.OrdinalIgnoreCase))
		{
			UiElement uiElement2 = source.FirstOrDefault((UiElement uiElement4) => uiElement4.Enabled && (m_6322(uiElement4, H) || uiElement4.ResourceId.Contains("repost")));
			if (uiElement2 != null)
			{
				await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_5);
				result = true;
			}
		}
		else
		{
			UiElement uiElement3 = source.FirstOrDefault((UiElement uiElement4) => uiElement4.Enabled && (m_6322(uiElement4, h) || uiElement4.ResourceId.Contains("copy")));
			if (uiElement3 != null)
			{
				await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_5);
				result = true;
			}
		}
		await Task.Delay(800, P_5);
		await AdbController.KeyEventAsync(P_0, "4", P_5);
		await Task.Delay(500, P_5);
		return result;
	}

	private static async Task m_6314(string P_0, string P_1, Action<string> P_2, CancellationToken P_3)
	{
		if (!(await AdbController.RunShellCaptureAsync(P_0, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", P_3)).Contains(P_1))
		{
			P_2("Mở TikTok (giữ nguyên nick đã đăng nhập)...");
			await AdbController.RunShellAsync(P_0, "am start -n " + P_1 + "/com.ss.android.ugc.aweme.splash.SplashActivity", P_3);
			await Task.Delay(4000, P_3);
			if (!(await AdbController.RunShellCaptureAsync(P_0, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", P_3)).Contains(P_1))
			{
				await AdbController.RunShellAsync(P_0, "monkey -p " + P_1 + " -c android.intent.category.LAUNCHER 1", P_3);
				await Task.Delay(4000, P_3);
			}
		}
	}

	private static async Task m_6315(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		for (int l = 0; l < 4; l++)
		{
			P_2.ThrowIfCancellationRequested();
			List<UiElement> list = await AdbController.DumpUiElementsAsync(P_0, P_2);
			if (list.Count == 0)
			{
				await Task.Delay(1000, P_2);
				continue;
			}
			if (await m_6316(P_0, list, P_2))
			{
				await Task.Delay(1500, P_2);
				continue;
			}
			if (list.FirstOrDefault((UiElement uiElement) => uiElement.Enabled && m_6322(uiElement, G) && uiElement.Top > 1300) != null || !list.Any((UiElement uiElement) => uiElement.Enabled && (m_6322(uiElement, "close", "đóng") || uiElement.ResourceId.Contains("bs7"))))
			{
				break;
			}
			await AdbController.KeyEventAsync(P_0, "4", P_2);
			await Task.Delay(1000, P_2);
		}
	}

	private static async Task<bool> m_6316(string P_0, List<UiElement> P_1, CancellationToken P_2)
	{
		UiElement uiElement = P_1.FirstOrDefault((UiElement uiElement2) => uiElement2.Enabled && m_6322(uiElement2, f));
		if (uiElement != null)
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
			return true;
		}
		return false;
	}

	private static async Task<bool> m_6317(string P_0, int P_1, int P_2, List<UiElement> P_3, CancellationToken P_4)
	{
		if (P_3.Any((UiElement uiElement2) => m_6322(uiElement2, B)))
		{
			return false;
		}
		UiElement uiElement = P_3.FirstOrDefault((UiElement uiElement2) => uiElement2.Enabled && (m_6322(uiElement2, a) || uiElement2.ResourceId.Contains("g65") || (uiElement2.ResourceId.Contains("g6o") && m_6322(uiElement2, "like"))));
		if (uiElement != null)
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_4);
			return true;
		}
		int x = P_1 / 2;
		int y = P_2 / 2;
		await AdbController.TapAsync(P_0, x, y, P_4);
		await Task.Delay(130, P_4);
		await AdbController.TapAsync(P_0, x, y, P_4);
		return true;
	}

	private static async Task<bool> m_6318(string P_0, int P_1, int P_2, List<UiElement> P_3, CancellationToken P_4)
	{
		if (P_3.Any((UiElement uiElement2) => m_6322(uiElement2, d)))
		{
			return false;
		}
		UiElement uiElement = P_3.FirstOrDefault((UiElement uiElement2) => uiElement2.Enabled && (m_6322(uiElement2, D) || uiElement2.ResourceId.Contains("i74")));
		if (uiElement != null)
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_4);
			return true;
		}
		await AdbController.TapAsync(P_0, (int)((double)P_1 * 0.93), (int)((double)P_2 * 0.74), P_4);
		return true;
	}

	private static async Task<bool> m_6319(string P_0, int P_1, int P_2, List<UiElement> P_3, CancellationToken P_4)
	{
		if (P_3.Any((UiElement uiElement3) => m_6322(uiElement3, c)))
		{
			return false;
		}
		UiElement uiElement = P_3.FirstOrDefault((UiElement uiElement3) => uiElement3.Enabled && (m_6322(uiElement3, C) || uiElement3.ResourceId.EndsWith(":id/ivc") || uiElement3.ResourceId == "ivc"));
		if (uiElement != null)
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_4);
			return true;
		}
		UiElement uiElement2 = P_3.FirstOrDefault((UiElement uiElement3) => uiElement3.ResourceId.Contains("user_avatar") || ((double)uiElement3.Right > (double)P_1 * 0.8 && (double)uiElement3.Top > (double)P_2 * 0.4 && (double)uiElement3.Top < (double)P_2 * 0.6));
		if (uiElement2 != null)
		{
			await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.Bottom + 10, P_4);
			return true;
		}
		return false;
	}

	private static async Task<bool> m_6320(string P_0, int P_1, int P_2, TikTokInteractionSettings P_3, List<UiElement> P_4, CancellationToken P_5)
	{
		UiElement uiElement = P_4.FirstOrDefault((UiElement uiElement5) => uiElement5.Enabled && (m_6322(uiElement5, b) || uiElement5.ResourceId.Contains("eor")));
		if (uiElement == null)
		{
			await AdbController.TapAsync(P_0, (int)((double)P_1 * 0.93), (int)((double)P_2 * 0.67), P_5);
		}
		else
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_5);
		}
		await Task.Delay(1300, P_5);
		UiElement uiElement2 = (await AdbController.DumpUiElementsAsync(P_0, P_5)).FirstOrDefault((UiElement uiElement5) => uiElement5.ClassName.Contains("EditText") || m_6322(uiElement5, E) || uiElement5.ResourceId.Contains("ejc"));
		if (uiElement2 == null)
		{
			await AdbController.TapAsync(P_0, (int)((double)P_1 * 0.4), (int)((double)P_2 * 0.95), P_5);
		}
		else
		{
			await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_5);
		}
		await Task.Delay(800, P_5);
		string text = P_3.PickImagePath();
		string text2 = P_3.BuildCommentText();
		bool flag = false;
		if (text != null && (text2 == null || Random.Shared.Next(0, 100) < 50))
		{
			flag = await m_6321(P_0, text, P_5);
		}
		if (!flag && text2 != null)
		{
			await AdbController.InputTextAsync(P_0, text2, P_5);
			await Task.Delay(700, P_5);
			UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(P_0, P_5)).FirstOrDefault((UiElement uiElement5) => uiElement5.Enabled && m_6322(uiElement5, e));
			if (uiElement3 != null)
			{
				await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_5);
				flag = true;
			}
			else
			{
				await AdbController.TapAsync(P_0, (int)((double)P_1 * 0.92), (int)((double)P_2 * 0.6), P_5);
				flag = true;
			}
			await Task.Delay(1000, P_5);
		}
		UiElement uiElement4 = (await AdbController.DumpUiElementsAsync(P_0, P_5)).FirstOrDefault((UiElement uiElement5) => uiElement5.Enabled && (m_6322(uiElement5, "close", "đóng") || uiElement5.ResourceId.Contains("bs7")));
		if (uiElement4 == null)
		{
			await AdbController.KeyEventAsync(P_0, "4", P_5);
		}
		else
		{
			await AdbController.TapAsync(P_0, uiElement4.CenterX, uiElement4.CenterY, P_5);
		}
		await Task.Delay(600, P_5);
		return flag;
	}

	private static async Task<bool> m_6321(string P_0, string P_1, CancellationToken P_2)
	{
		_ = 10;
		try
		{
			if (!File.Exists(P_1))
			{
				return false;
			}
			string text = "/sdcard/Pictures/fastbox_ttcmt" + Path.GetExtension(P_1).ToLowerInvariant();
			if (!(await m_6324(P_0, P_1, text, P_2)))
			{
				return false;
			}
			await AdbController.RunShellAsync(P_0, "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + text, P_2);
			await Task.Delay(800, P_2);
			UiElement uiElement = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement4) => uiElement4.Enabled && m_6322(uiElement4, F));
			if (uiElement == null)
			{
				return false;
			}
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
			await Task.Delay(1500, P_2);
			UiElement uiElement2 = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement4) => uiElement4.Enabled && (uiElement4.ClassName.Contains("ImageView") || m_6322(uiElement4, "photo", "image", "ảnh")));
			if (uiElement2 == null)
			{
				return false;
			}
			await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_2);
			await Task.Delay(1000, P_2);
			UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement4) => uiElement4.Enabled && m_6322(uiElement4, e));
			if (uiElement3 != null)
			{
				await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_2);
				return true;
			}
			return false;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
			return false;
		}
	}

	private static bool m_6322(UiElement P_0, params string[] needles)
	{
		string A = (P_0.ContentDesc + " " + P_0.Text).ToLowerInvariant();
		return needles.Any((string value) => A.Contains(value));
	}

	private static async Task<string?> m_6323(string P_0, CancellationToken P_1)
	{
		string text = await AdbController.RunShellCaptureAsync(P_0, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", P_1);
		string[] array = A;
		foreach (string text2 in array)
		{
			if (text.Contains(text2))
			{
				return text2;
			}
		}
		string[] array2 = A;
		foreach (string text3 in array2)
		{
			if ((await AdbController.RunShellCaptureAsync(P_0, "pm list packages " + text3, P_1)).Contains(text3))
			{
				return text3;
			}
		}
		return null;
	}

	private static async Task<bool> m_6324(string P_0, string P_1, string P_2, CancellationToken P_3)
	{
		try
		{
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				FileName = AdbController.AdbExePath,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				UseShellExecute = false,
				CreateNoWindow = true
			};
			processStartInfo.ArgumentList.Add("-s");
			processStartInfo.ArgumentList.Add(P_0);
			processStartInfo.ArgumentList.Add("push");
			processStartInfo.ArgumentList.Add(P_1);
			processStartInfo.ArgumentList.Add(P_2);
			using Process process = new Process
			{
				StartInfo = processStartInfo
			};
			process.Start();
			await process.WaitForExitAsync(P_3);
			return process.ExitCode == 0;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
			return false;
		}
	}
}
