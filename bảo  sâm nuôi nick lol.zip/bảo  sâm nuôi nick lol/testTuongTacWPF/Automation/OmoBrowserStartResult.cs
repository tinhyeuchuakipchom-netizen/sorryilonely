using System;
using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class OmoBrowserStartResult
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private nint m_3263 = IntPtr.Zero;

	public string RemoteDebuggingAddress
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string WebSocketDebuggingUrl
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public nint WindowHandle
	{
		[CompilerGenerated]
		get
		{
			return m_3263;
		}
		[CompilerGenerated]
		set
		{
			m_3263 = value;
		}
	}
}
