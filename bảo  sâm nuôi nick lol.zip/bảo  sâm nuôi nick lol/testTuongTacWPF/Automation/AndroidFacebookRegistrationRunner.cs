using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class AndroidFacebookRegistrationRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3088
	{
		public static readonly m_3088 A = new m_3088();

		public static Func<UiElement, string> m_3090;

		public static Func<UiElement, bool> m_3091;

		public static Func<UiElement, bool> a;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		public static Func<UiElement, bool> C;

		public static Func<UiElement, bool> c;

		public static Func<UiElement, bool> D;

		public static Func<UiElement, bool> d;

		public static Func<UiElement, bool> E;

		public static Func<UiElement, bool> e;

		public static Func<UiElement, bool> F;

		public static Func<UiElement, bool> f;

		public static Func<UiElement, bool> G;

		public static Func<UiElement, bool> g;

		public static Func<UiElement, bool> H;

		public static Func<UiElement, bool> h;

		public static Func<UiElement, bool> I;

		public static Func<UiElement, bool> i;

		public static Func<UiElement, bool> J;

		public static Func<UiElement, bool> j;

		public static Func<UiElement, bool> K;

		public static Func<UiElement, bool> k;

		public static Func<UiElement, bool> L;

		public static Func<UiElement, bool> l;

		public static Func<UiElement, bool> M;

		public static Func<UiElement, bool> m;

		public static Func<UiElement, bool> N;

		public static Func<UiElement, string> m_3092;

		public static Func<UiElement, bool> n;

		public static Func<UiElement, bool> O;

		public static Func<UiElement, bool> o;

		public static Func<UiElement, bool> P;

		public static Func<UiElement, string> m_3093;

		public static Func<UiElement, bool> p;

		public static Func<UiElement, bool> Q;

		public static Func<UiElement, bool> q;

		public static Func<UiElement, bool> R;

		public static Func<UiElement, bool> r;

		public static Func<UiElement, bool> S;

		public static Func<UiElement, bool> s;

		public static Func<UiElement, bool> T;

		internal string m_3094(UiElement P_0)
		{
			return $"{P_0.Text} {P_0.ContentDesc} {P_0.ResourceId}";
		}

		internal bool m_3095(UiElement P_0)
		{
			if (!P_0.Text.Equals("Cancel", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Cancel", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Hủy", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Huỷ", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Dismiss", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("None of the above", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3096(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("permission_allow_button") && !P_0.ResourceId.Contains("permission_allow_foreground_only_button") && !P_0.Text.Equals("ALLOW", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("While using the app", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Trong khi dùng ứng dụng", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("ALLOW", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Allow", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3097(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Create new account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Create an account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Create new account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Create an account", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3098(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Get started", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Bắt đầu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Create new account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Create an account", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tạo tài khoản mới", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Get started", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Bắt đầu", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Create new account", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Create an account", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Tạo tài khoản mới", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3099(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("First name", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Họ", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3100(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Last name", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Tên", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3101(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3102(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("datePicker"))
			{
				if (P_0.ResourceId.Contains("button1"))
				{
					if (!P_0.Text.Equals("SET", StringComparison.OrdinalIgnoreCase))
					{
						return P_0.Text.Equals("Set", StringComparison.OrdinalIgnoreCase);
					}
					return true;
				}
				return false;
			}
			return true;
		}

		internal bool m_3103(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("button1") && !P_0.Text.Equals("SET", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Set", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("ĐẶT", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("OK", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3104(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3105(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Age", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ClassName.Contains("EditText");
			}
			return true;
		}

		internal bool m_3106(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3107(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3108(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_3109(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("mobile", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3110(UiElement P_0)
		{
			if (P_0.ClassName.Contains("EditText"))
			{
				if (!P_0.ContentDesc.Contains("mobile", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3111(UiElement P_0)
		{
			if (P_0.ClassName.Contains("EditText"))
			{
				return P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}

		internal bool m_3112(UiElement P_0)
		{
			if (P_0.ClassName.Contains("EditText"))
			{
				return P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}

		internal bool m_3113(UiElement P_0)
		{
			if (P_0.ClassName.Contains("EditText"))
			{
				if (!P_0.ContentDesc.Contains("mobile", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3114(UiElement P_0)
		{
			if ((P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Contains("email", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3115(UiElement P_0)
		{
			if ((P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Contains("mobile number", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("mobile number", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Contains("số di động", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3116(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText"))
			{
				if (P_0.ClassName.Contains("TextView"))
				{
					return P_0.Focused;
				}
				return false;
			}
			return true;
		}

		internal bool m_3117(UiElement P_0)
		{
			if ((P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3118(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText"))
			{
				if (P_0.ClassName.Contains("TextView"))
				{
					return P_0.Focused;
				}
				return false;
			}
			return true;
		}

		internal bool m_3119(UiElement P_0)
		{
			if ((P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3120(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Save", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Save", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Lưu", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3121(UiElement P_0)
		{
			if ((!P_0.ClassName.Contains("Button") || (!P_0.ContentDesc.Equals("I agree", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("I agree", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase))) && !P_0.ContentDesc.Trim().Equals("I agree", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Trim().Equals("I agree", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Trim().Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Trim().Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal string m_3122(UiElement P_0)
		{
			return $"{P_0.Text} {P_0.ContentDesc} {P_0.ResourceId}";
		}

		internal bool m_3123(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("permission_allow_button") && !P_0.ResourceId.Contains("permission_allow_foreground_only_button") && !P_0.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("While using the app", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Allow", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3124(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_3125(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Confirmation code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Confirmation code", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("mã xác nhận", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("mã xác nhận", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_3126(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Confirm", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Confirm", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal string m_3127(UiElement P_0)
		{
			return $"{P_0.Text} {P_0.ContentDesc} {P_0.ResourceId}";
		}

		internal bool m_3128(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_3129(UiElement P_0)
		{
			return P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_3130(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_3131(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Save", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Save", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_3132(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Mobile number or email", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.ClassName.Contains("EditText"))
				{
					if (!P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase))
					{
						return P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase);
					}
					return true;
				}
				return false;
			}
			return true;
		}

		internal bool t(UiElement P_0)
		{
			if (P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ClassName.Contains("EditText");
			}
			return false;
		}

		internal bool U(UiElement P_0)
		{
			return P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase);
		}

		internal bool u(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Log in", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Log in", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_3089
	{
		public List<string> A;

		public Action<AiVisionStepLog> m_3133;

		public int m_3134;

		internal void m_3135(string P_0)
		{
			A.Add($"{A.Count + 1}. {P_0}");
			m_3133(new AiVisionStepLog
			{
				FlowStepIndex = m_3134++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = "Reg Android"
			});
		}

		internal string a(string P_0)
		{
			if (A.Count != 0)
			{
				return P_0 + "\n\n— Nhật ký các bước —\n" + string.Join("\n", A);
			}
			return P_0;
		}

		internal void B(string P_0)
		{
			m_3135(P_0);
		}

		internal void b(string P_0)
		{
			m_3135(P_0);
		}

		internal void C(string P_0)
		{
			m_3135(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class B
	{
		public double A;

		public double a;

		public Func<UiElement, bool> m_3136;

		public Func<UiElement, bool> m_3137;

		public Func<UiElement, bool> m_3138;

		public Func<UiElement, bool> b;

		internal bool m_3139(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("First name", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Họ", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.ClassName.Contains("EditText"))
				{
					return P_0.Left < (int)(450.0 * A);
				}
				return false;
			}
			return true;
		}

		internal bool m_3140(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Last name", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tên", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.ClassName.Contains("EditText"))
				{
					return P_0.Left >= (int)(450.0 * A);
				}
				return false;
			}
			return true;
		}

		internal bool m_3141(UiElement P_0)
		{
			if (P_0.Text.Length != 4 || !int.TryParse(P_0.Text, out var result) || result < 2020 || result > 2035 || P_0.Top >= (int)(800.0 * a))
			{
				if (P_0.Left >= (int)(500.0 * A) && P_0.Top <= (int)(760.0 * a))
				{
					return P_0.ClassName.Contains("Button");
				}
				return false;
			}
			return true;
		}

		internal bool m_3142(UiElement P_0)
		{
			if ((!P_0.ClassName.Contains("EditText") || P_0.Top < (int)(280.0 * a) || P_0.Top > (int)(600.0 * a)) && (!P_0.ClassName.Contains("ViewGroup") || P_0.Top < (int)(300.0 * a) || P_0.Bottom > (int)(550.0 * a)))
			{
				if (P_0.Top >= (int)(300.0 * a) && P_0.Bottom <= (int)(550.0 * a))
				{
					if (!P_0.ContentDesc.Contains("years old") && !P_0.Text.Contains("years old") && !P_0.ContentDesc.Contains("tuổi"))
					{
						return P_0.Text.Contains("tuổi");
					}
					return true;
				}
				return false;
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class b
	{
		public bool A;

		internal bool m_3143(UiElement P_0)
		{
			if (!A || (!P_0.ContentDesc.Equals("Male", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Nam") && !P_0.Text.Contains("Nam")))
			{
				if (!A)
				{
					if (!P_0.ContentDesc.Equals("Female", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Nữ"))
					{
						return P_0.Text.Contains("Nữ");
					}
					return true;
				}
				return false;
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class C
	{
		public List<string> A;

		public Action<AiVisionStepLog> m_3144;

		public int m_3145;

		internal void m_3146(string P_0)
		{
			A.Add($"{A.Count + 1}. {P_0}");
			m_3144(new AiVisionStepLog
			{
				FlowStepIndex = m_3145++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = "Verify Android"
			});
		}

		internal string a(string P_0)
		{
			if (A.Count != 0)
			{
				return P_0 + "\n\n— Nhật ký các bước —\n" + string.Join("\n", A);
			}
			return P_0;
		}

		internal void B(string P_0)
		{
			m_3146(P_0);
		}

		internal void b(string P_0)
		{
			m_3146(P_0);
		}

		internal void m_3147(string P_0)
		{
			m_3146(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class c
	{
		public Func<Task<string?>> A;

		public bool m_3148;

		public bool a;

		public IVerifyPhoneTestClient m_3149;

		public Func<CancellationToken, Task<string>> m_3150;

		public IVerifyMailTestClient m_3151;

		public FacebookAccountRow m_3152;

		public Func<string, string> m_3153;

		public double m_3154;

		public double m_3155;

		public Func<UiElement, bool> m_3156;

		internal async Task<bool> m_3157()
		{
			if (A != null)
			{
				return true;
			}
			if (m_3148)
			{
				return false;
			}
			if (a)
			{
				m_3149 = VerifyPhoneSettings.Load().CreateClient();
				m_3150 = m_3149.GetNewPhoneNumberAsync;
				A = m_3149.TryGetOtpAsync;
			}
			else
			{
				m_3151 = VerifyMailSettings.Load().CreateClient();
				m_3150 = m_3151.GetNewMailAddressAsync;
				A = m_3151.TryGetOtpAsync;
			}
			await Task.CompletedTask;
			return true;
		}

		internal AiVisionRunResult m_3158(string P_0)
		{
			m_3152.TinhTrang = "NOVERY";
			return new AiVisionRunResult
			{
				Success = true,
				TinhTrang = "NOVERY",
				Message = m_3153(P_0)
			};
		}

		internal AiVisionRunResult m_3159(string P_0)
		{
			return new AiVisionRunResult
			{
				Success = false,
				TinhTrang = "ERROR",
				Message = m_3153(P_0)
			};
		}

		internal bool m_3160(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Close", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Close", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("X", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("X", StringComparison.OrdinalIgnoreCase) && (!P_0.ClassName.Contains("Button") || (!P_0.ContentDesc.Contains("Close") && !P_0.ContentDesc.Contains("Dismiss"))))
			{
				if (P_0.ClassName.Contains("ImageView") && P_0.Top < (int)(600.0 * m_3154))
				{
					return P_0.Left < (int)(150.0 * m_3155);
				}
				return false;
			}
			return true;
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	internal struct D
	{
		public List<UiElement> A;
	}

	[CompilerGenerated]
	private sealed class d
	{
		public string[] A;

		internal bool m_3165(UiElement P_0)
		{
			return A.Any((string value) => P_0.Text.Equals(value, StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals(value, StringComparison.OrdinalIgnoreCase));
		}
	}

	[CompilerGenerated]
	private sealed class E
	{
		public UiElement A;

		internal bool m_3166(string P_0)
		{
			if (!A.Text.Equals(P_0, StringComparison.OrdinalIgnoreCase))
			{
				return A.ContentDesc.Equals(P_0, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class e
	{
		public string[] A;

		internal bool m_3167(UiElement P_0)
		{
			return A.Any((string value) => P_0.Text.Contains(value, StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains(value, StringComparison.OrdinalIgnoreCase));
		}
	}

	[CompilerGenerated]
	private sealed class F
	{
		public UiElement A;

		internal bool m_3168(string P_0)
		{
			if (!A.Text.Contains(P_0, StringComparison.OrdinalIgnoreCase))
			{
				return A.ContentDesc.Contains(P_0, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	public const string KatanaPackage = "com.facebook.katana";

	public const string KatanaMainActivity = "com.facebook.katana/.LoginActivity";

	public const string LitePackage = "com.facebook.lite";

	public const string LiteMainActivity = "com.facebook.lite/.MainActivity";

	private const int A = 6;

	private static DateTime m_3081()
	{
		int num = Random.Shared.Next(18, 46);
		DateTime now = DateTime.Now;
		int day = Random.Shared.Next(1, 29);
		int month = Random.Shared.Next(1, 13);
		return new DateTime(now.Year - num, month, day);
	}

	private static bool m_3082(string P_0)
	{
		if (!P_0.Contains("title or symbol") && !P_0.Contains("trying to include a title") && !P_0.Contains("include a title or symbol") && !P_0.Contains("name they use in everyday life") && !P_0.Contains("what their friends call them") && !P_0.Contains("chức danh hoặc ký hiệu") && !P_0.Contains("tên bạn dùng hằng ngày"))
		{
			return P_0.Contains("tên mà bạn bè");
		}
		return true;
	}

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, bool verifyOtp, string packageType, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		m_3089 CS_0024_003C_003E8__locals58 = new m_3089();
		CS_0024_003C_003E8__locals58.m_3133 = onStep;
		string text = nick.PhoneName;
		if (string.IsNullOrWhiteSpace(text))
		{
			text = (await AdbController.ListDevicesAsync(cancellationToken)).FirstOrDefault() ?? "";
			if (string.IsNullOrEmpty(text))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Nick chưa được gắn Phone Android và không tìm thấy thiết bị kết nối nào."
				};
			}
			nick.PhoneName = text;
		}
		RegistrationRunSettings registrationRunSettings = RegistrationRunSettings.Load();
		registrationRunSettings.Clamp();
		bool flag = string.Equals(packageType, "Lite", StringComparison.OrdinalIgnoreCase);
		string text2 = (flag ? "com.facebook.lite" : "com.facebook.katana");
		string text3 = (flag ? "com.facebook.lite/.MainActivity" : "com.facebook.katana/.LoginActivity");
		string text4 = (flag ? "Facebook Lite" : "Facebook Katana");
		CS_0024_003C_003E8__locals58.m_3134 = 0;
		CS_0024_003C_003E8__locals58.A = new List<string>();
		CS_0024_003C_003E8__locals58.m_3135($"Bắt đầu đăng ký Facebook trên {text4} (Máy: {text})...");
		try
		{
			await PhoneInitialSetupService.EnsureInitialSetupAsync(text, packageType, (string P_0) =>
			{
				CS_0024_003C_003E8__locals58.m_3135(P_0);
			}, cancellationToken);
			CS_0024_003C_003E8__locals58.m_3135("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(text, cancellationToken);
			if (!string.IsNullOrWhiteSpace(nick.Proxy))
			{
				CS_0024_003C_003E8__locals58.m_3135("Đang kết nối Proxy " + nick.Proxy + " qua Super Proxy...");
				if (!(await SuperProxyController.SetupAndStartProxyAsync(text, nick.Proxy, (string P_0) =>
				{
					CS_0024_003C_003E8__locals58.m_3135(P_0);
				}, cancellationToken)))
				{
					CS_0024_003C_003E8__locals58.m_3135("Cảnh báo: Kết nối proxy qua Super Proxy không thành công, tiếp tục chạy bằng mạng máy.");
				}
			}
			else
			{
				CS_0024_003C_003E8__locals58.m_3135("Không sử dụng Proxy -> Đang ngắt kết nối & reset sạch app Super Proxy...");
				await SuperProxyController.StopProxyAsync(text, (string P_0) =>
				{
					CS_0024_003C_003E8__locals58.m_3135(P_0);
				}, cancellationToken);
			}
			(string, string, string) tuple = m_3085(nick);
			string text5 = tuple.Item1;
			string item = tuple.Item2;
			string item2 = tuple.Item3;
			string[] array = AndroidFacebookRegistrationRunner.a(text5);
			string text6 = array[0];
			string text7 = array[1];
			DateTime value = m_3081();
			bool baitEnabled = registrationRunSettings.BaitEnabled;
			bool flag2 = (baitEnabled ? registrationRunSettings.BaitUsePhone : (RegistrationChannelSettings.Load().Channel == "Phone"));
			IVerifyPhoneTestClient verifyPhoneTestClient = null;
			IVerifyMailTestClient verifyMailTestClient = null;
			string text8;
			if (baitEnabled)
			{
				text8 = (flag2 ? VerifyPhoneSettings.Load().BuildRandomPhonePreview() : VerifyMailSettings.Load().BuildRandomMailPreview());
				CS_0024_003C_003E8__locals58.m_3135("Mồi " + (flag2 ? "SĐT ảo" : "Email ảo") + ": " + text8);
			}
			else if (flag2)
			{
				VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
				if (!string.IsNullOrWhiteSpace(nick.Uid))
				{
					text8 = nick.Uid;
				}
				else if (verifyOtp && verifyPhoneSettings.Provider != "Random")
				{
					CS_0024_003C_003E8__locals58.m_3135("Đang lấy số điện thoại qua cổng \"" + verifyPhoneSettings.Provider + "\" (Cài đặt Verify Phone)...");
					try
					{
						verifyPhoneTestClient = verifyPhoneSettings.CreateClient();
						text8 = await verifyPhoneTestClient.GetNewPhoneNumberAsync(cancellationToken);
					}
					catch (Exception ex)
					{
						CS_0024_003C_003E8__locals58.m_3135("Lỗi lấy số qua API: " + ex.Message + " -> Dùng số từ cấu hình Tạo luồng.");
						text8 = verifyPhoneSettings.BuildRandomPhonePreview();
						verifyPhoneTestClient = null;
					}
				}
				else
				{
					text8 = verifyPhoneSettings.BuildRandomPhonePreview();
				}
			}
			else
			{
				VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
				if (!string.IsNullOrWhiteSpace(nick.Mail))
				{
					text8 = nick.Mail;
				}
				else if (verifyOtp && verifyMailSettings.Provider != "Random")
				{
					CS_0024_003C_003E8__locals58.m_3135("Đang lấy mail qua cổng \"" + verifyMailSettings.Provider + "\" (Cài đặt Verify Mail)...");
					try
					{
						verifyMailTestClient = verifyMailSettings.CreateClient();
						text8 = await verifyMailTestClient.GetNewMailAddressAsync(cancellationToken);
					}
					catch (Exception ex2)
					{
						CS_0024_003C_003E8__locals58.m_3135("Lỗi lấy mail qua API: " + ex2.Message + " -> Dùng mail từ cấu hình Tạo luồng.");
						text8 = verifyMailSettings.BuildRandomMailPreview();
						verifyMailTestClient = null;
					}
				}
				else
				{
					text8 = verifyMailSettings.BuildRandomMailPreview();
				}
			}
			CS_0024_003C_003E8__locals58.m_3135($"Đang điền form đăng ký ({text5}, {item}, {(flag2 ? "SĐT" : "Mail")}: {text8})...");
			CS_0024_003C_003E8__locals58.m_3135("Đang xóa sạch dữ liệu ứng dụng " + text4 + "...");
			try
			{
				await AdbController.RunShellAsync(text, "am force-stop " + text2, cancellationToken);
			}
			catch
			{
			}
			try
			{
				await AdbController.RunShellAsync(text, "pm clear " + text2, cancellationToken);
			}
			catch
			{
			}
			await Task.Delay(800, cancellationToken);
			CS_0024_003C_003E8__locals58.m_3135("Đang cấp toàn bộ quyền hệ thống cho " + text4 + "...");
			try
			{
				await AdbController.GrantAllAppPermissionsAsync(text, text2, cancellationToken);
			}
			catch
			{
			}
			await Task.Delay(300, cancellationToken);
			CS_0024_003C_003E8__locals58.m_3135("Đang khởi động " + text4 + "...");
			await AdbController.RunShellAsync(text, "am start -n " + text3, cancellationToken);
			await Task.Delay(3500, cancellationToken);
			(int, int) tuple2 = await AdbController.GetScreenSizeAsync(text, cancellationToken);
			int item3 = tuple2.Item1;
			int item4 = tuple2.Item2;
			double A = (double)item3 / 900.0;
			double a = (double)item4 / 1600.0;
			bool flag3 = false;
			bool flag4 = false;
			int num = 35;
			int num2 = 0;
			for (int num3 = 0; num3 < num; num3++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				await Task.Delay(1500, cancellationToken);
				List<UiElement> list = await AdbController.DumpUiElementsAsync(text, cancellationToken);
				if (list.Count == 0)
				{
					await Task.Delay(1000, cancellationToken);
					continue;
				}
				string text9 = string.Join(" ", list.Select((UiElement P_0) => $"{P_0.Text} {P_0.ContentDesc} {P_0.ResourceId}")).ToLowerInvariant();
				if (text9.Contains("checking info") || text9.Contains("com.google.android.gms") || text9.Contains("sign in with google") || text9.Contains("đăng nhập bằng google") || text9.Contains("choose an account") || text9.Contains("chọn tài khoản") || text9.Contains("use your google account") || text9.Contains("google play services") || text9.Contains("sign in - google accounts"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Đăng nhập Google / Gmail - đang quay lại (Back) để về Facebook...");
					UiElement uiElement = list.FirstOrDefault((UiElement P_0) => P_0.Text.Equals("Cancel", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Cancel", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Hủy", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Huỷ", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Dismiss", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("None of the above", StringComparison.OrdinalIgnoreCase));
					if (uiElement == null)
					{
						await AdbController.KeyEventAsync(text, "4", cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement.CenterX, uiElement.CenterY, cancellationToken);
					}
					await Task.Delay(1500, cancellationToken);
					continue;
				}
				if ((text9.Contains("launcher") || text9.Contains("home screen") || text9.Contains("search games")) && !text9.Contains("facebook") && !text9.Contains("meta") && !text9.Contains("lite"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện rơi về màn hình chính (Launcher) - đang mở lại " + text4 + "...");
					await AdbController.RunShellAsync(text, "am start -n " + text3, cancellationToken);
					await Task.Delay(2000, cancellationToken);
					continue;
				}
				if (text9.Contains("allow facebook") || text9.Contains("cho phép facebook") || (text9.Contains("allow") && text9.Contains("don't allow")) || (text9.Contains("cho phép") && text9.Contains("từ chối")) || text9.Contains("permission_allow_button") || text9.Contains("access your contacts") || text9.Contains("access your location") || text9.Contains("access photos") || text9.Contains("make and manage phone calls") || text9.Contains("truy cập danh bạ"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện hộp thoại xin quyền - đang bấm Cho phép (ALLOW)...");
					UiElement uiElement2 = list.FirstOrDefault((UiElement P_0) => P_0.ResourceId.Contains("permission_allow_button") || P_0.ResourceId.Contains("permission_allow_foreground_only_button") || P_0.Text.Equals("ALLOW", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("While using the app", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Trong khi dùng ứng dụng", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("ALLOW", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Allow", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Cho phép", StringComparison.OrdinalIgnoreCase));
					if (uiElement2 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(565.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement2.CenterX, uiElement2.CenterY, cancellationToken);
					}
					await Task.Delay(1000, cancellationToken);
					continue;
				}
				if (text9.Contains("use another profile") || text9.Contains("log into another account") || (text9.Contains("continue") && text9.Contains("profile photo")))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Tài khoản cũ - đang bấm Tạo tài khoản mới (Create new account)...");
					UiElement uiElement3 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("Create new account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Create an account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Create new account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Create an account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Tạo tài khoản", StringComparison.OrdinalIgnoreCase));
					if (uiElement3 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(1427.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if (text9.Contains("tham gia facebook") || text9.Contains("bắt đầu") || text9.Contains("get started") || text9.Contains("tạo tài khoản mới") || text9.Contains("create new account") || text9.Contains("join facebook") || text9.Contains("meta account"))
				{
					UiElement uiElement4 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("Get started", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Bắt đầu", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Create new account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Create an account", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tạo tài khoản mới", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Get started", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Bắt đầu", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Create new account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Create an account", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Tạo tài khoản mới", StringComparison.OrdinalIgnoreCase));
					if (uiElement4 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), flag ? ((int)(1412.0 * a)) : ((int)(1345.0 * a)), cancellationToken);
					}
					else
					{
						CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Chào mừng - đang bấm Bắt đầu / Tạo tài khoản...");
						await AdbController.TapAsync(text, uiElement4.CenterX, uiElement4.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if (text9.Contains("bạn tên gì") || text9.Contains("what's your name") || text9.Contains("họ,") || text9.Contains("tên,") || text9.Contains("first name") || text9.Contains("last name"))
				{
					if (m_3082(text9))
					{
						num2++;
						if (num2 > 6)
						{
							return new AiVisionRunResult
							{
								Success = false,
								TinhTrang = "ERROR",
								Message = CS_0024_003C_003E8__locals58.a($"Facebook liên tục từ chối tên (tước hiệu/ký hiệu) sau {6} lần đổi tên - tên cuối \"{text5}\" vẫn bị từ chối.")
							};
						}
						text5 = RandomFacebookIdentityGenerator.RandomFullName(item, includeMiddleName: true);
						string[] array2 = AndroidFacebookRegistrationRunner.a(text5);
						text6 = array2[0];
						text7 = array2[1];
						nick.HoTen = text5;
						CS_0024_003C_003E8__locals58.m_3135($"Tên bị Facebook từ chối (tước hiệu/ký hiệu) - đổi tên mới: {text5} (lần {num2}/{6})");
					}
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Tên - đang điền: " + text5 + "...");
					if (flag)
					{
						UiElement uiElement5 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("First name", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Họ", StringComparison.OrdinalIgnoreCase) || (P_0.ClassName.Contains("EditText") && P_0.Left < (int)(450.0 * A)));
						if (uiElement5 == null)
						{
							await AdbController.TapAsync(text, (int)(199.0 * A), (int)(399.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement5.CenterX, uiElement5.CenterY, cancellationToken);
						}
						await Task.Delay(300, cancellationToken);
						await AdbController.InputTextAsync(text, text6, cancellationToken);
						await Task.Delay(300, cancellationToken);
						UiElement uiElement6 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Last name", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tên", StringComparison.OrdinalIgnoreCase) || (P_0.ClassName.Contains("EditText") && P_0.Left >= (int)(450.0 * A)));
						if (uiElement6 == null)
						{
							await AdbController.TapAsync(text, (int)(629.0 * A), (int)(399.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement6.CenterX, uiElement6.CenterY, cancellationToken);
						}
						await Task.Delay(300, cancellationToken);
						await AdbController.InputTextAsync(text, text7, cancellationToken);
						await Task.Delay(300, cancellationToken);
					}
					else
					{
						UiElement uiElement7 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("First name", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Họ", StringComparison.OrdinalIgnoreCase));
						if (uiElement7 == null)
						{
							await AdbController.TapAsync(text, (int)(270.0 * A), (int)(398.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement7.CenterX, uiElement7.CenterY, cancellationToken);
						}
						await Task.Delay(300, cancellationToken);
						await AdbController.InputTextAsync(text, text6, cancellationToken);
						await Task.Delay(300, cancellationToken);
						UiElement uiElement8 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Last name", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tên", StringComparison.OrdinalIgnoreCase));
						if (uiElement8 == null)
						{
							await AdbController.TapAsync(text, (int)(629.0 * A), (int)(398.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement8.CenterX, uiElement8.CenterY, cancellationToken);
						}
						await Task.Delay(300, cancellationToken);
						await AdbController.InputTextAsync(text, text7, cancellationToken);
						await Task.Delay(300, cancellationToken);
					}
					await AdbController.KeyEventAsync(text, "4", cancellationToken);
					await Task.Delay(500, cancellationToken);
					UiElement uiElement9 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase)));
					if (uiElement9 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(526.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement9.CenterX, uiElement9.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if (text9.Contains("set date") || text9.Contains("đặt ngày") || text9.Contains("datepicker") || text9.Contains("numberpicker") || (text9.Contains("cancel") && text9.Contains("set")) || (text9.Contains("hủy") && text9.Contains("đặt")) || list.Any((UiElement P_0) => P_0.ResourceId.Contains("datePicker") || (P_0.ResourceId.Contains("button1") && (P_0.Text.Equals("SET", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Set", StringComparison.OrdinalIgnoreCase)))))
				{
					CS_0024_003C_003E8__locals58.m_3135($"Phát hiện hộp chọn Ngày sinh - đang chỉnh năm sinh ({value:yyyy})...");
					UiElement uiElement10 = list.FirstOrDefault((UiElement P_0) => (P_0.Text.Length == 4 && int.TryParse(P_0.Text, out var result) && result >= 2020 && result <= 2035 && P_0.Top < (int)(800.0 * a)) || (P_0.Left >= (int)(500.0 * A) && P_0.Top <= (int)(760.0 * a) && P_0.ClassName.Contains("Button")));
					int x = uiElement10?.CenterX ?? ((int)(602.0 * A));
					int y = uiElement10?.CenterY ?? ((int)(721.0 * a));
					for (int num4 = 0; num4 < 25; num4++)
					{
						await AdbController.TapAsync(text, x, y, cancellationToken);
						await Task.Delay(50, cancellationToken);
					}
					await Task.Delay(400, cancellationToken);
					UiElement uiElement11 = list.FirstOrDefault((UiElement P_0) => P_0.ResourceId.Contains("button1") || P_0.Text.Equals("SET", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Set", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("ĐẶT", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("OK", StringComparison.OrdinalIgnoreCase));
					if (uiElement11 == null)
					{
						await AdbController.TapAsync(text, (int)(594.0 * A), (int)(1102.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement11.CenterX, uiElement11.CenterY, cancellationToken);
					}
					flag4 = true;
					await Task.Delay(2000, cancellationToken);
					continue;
				}
				if (text9.Contains("what's your birthday") || text9.Contains("ngày sinh") || text9.Contains("birthday (") || text9.Contains("date of birth") || text9.Contains("bao nhiêu tuổi"))
				{
					bool flag5 = text9.Contains("0 years old") || text9.Contains("1 years old") || text9.Contains("0 tuổi") || text9.Contains("1 tuổi") || text9.Contains("2026") || text9.Contains("2027");
					if (!flag4 | flag5)
					{
						CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Ngày sinh chưa mở hộp chọn - đang bấm vào ô Ngày sinh để mở 'Set date'...");
						UiElement uiElement12 = list.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("EditText") && P_0.Top >= (int)(280.0 * a) && P_0.Top <= (int)(600.0 * a)) || (P_0.ClassName.Contains("ViewGroup") && P_0.Top >= (int)(300.0 * a) && P_0.Bottom <= (int)(550.0 * a)) || (P_0.Top >= (int)(300.0 * a) && P_0.Bottom <= (int)(550.0 * a) && (P_0.ContentDesc.Contains("years old") || P_0.Text.Contains("years old") || P_0.ContentDesc.Contains("tuổi") || P_0.Text.Contains("tuổi"))));
						int x2 = ((uiElement12 != null && uiElement12.CenterX > 0) ? uiElement12.CenterX : ((int)(450.0 * A)));
						int y2 = ((uiElement12 != null && uiElement12.CenterY >= (int)(300.0 * a)) ? uiElement12.CenterY : ((int)(439.0 * a)));
						await AdbController.TapAsync(text, x2, y2, cancellationToken);
						await Task.Delay(1200, cancellationToken);
					}
					else
					{
						CS_0024_003C_003E8__locals58.m_3135("Đang xác nhận Ngày sinh (bấm Next)...");
						UiElement uiElement13 = list.FirstOrDefault((UiElement P_0) => !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase)));
						if (uiElement13 == null)
						{
							await AdbController.TapAsync(text, (int)(450.0 * A), (int)(575.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement13.CenterX, uiElement13.CenterY, cancellationToken);
						}
						await Task.Delay(2500, cancellationToken);
					}
					continue;
				}
				if (text9.Contains("how old are you") || text9.Contains("enter your age") || text9.Contains("bạn bao nhiêu tuổi"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Hỏi tuổi - đang điền tuổi (26)...");
					UiElement uiElement14 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Age", StringComparison.OrdinalIgnoreCase) || P_0.ClassName.Contains("EditText"));
					if (uiElement14 == null)
					{
						await AdbController.TapAsync(text, (int)(438.0 * A), (int)(407.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement14.CenterX, uiElement14.CenterY, cancellationToken);
					}
					await Task.Delay(300, cancellationToken);
					await AdbController.InputTextAsync(text, "26", cancellationToken);
					await Task.Delay(300, cancellationToken);
					await AdbController.KeyEventAsync(text, "111", cancellationToken);
					await Task.Delay(300, cancellationToken);
					UiElement uiElement15 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase)));
					if (uiElement15 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(515.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement15.CenterX, uiElement15.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if (text9.Contains("giới tính") || text9.Contains("what's your gender") || text9.Contains("gender") || text9.Contains("female") || text9.Contains("male"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Giới tính (" + item + ") - đang chọn...");
					bool A2 = string.Equals(item, "Nam", StringComparison.OrdinalIgnoreCase);
					UiElement uiElement16 = list.FirstOrDefault((UiElement P_0) => (A2 && (P_0.ContentDesc.Equals("Male", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Nam") || P_0.Text.Contains("Nam"))) || (!A2 && (P_0.ContentDesc.Equals("Female", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Nữ") || P_0.Text.Contains("Nữ"))));
					if (uiElement16 != null)
					{
						await AdbController.TapAsync(text, uiElement16.CenterX, uiElement16.CenterY, cancellationToken);
					}
					else if (!A2)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(379.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(492.0 * a), cancellationToken);
					}
					await Task.Delay(400, cancellationToken);
					UiElement uiElement17 = list.FirstOrDefault((UiElement P_0) => !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase)));
					if (uiElement17 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(817.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement17.CenterX, uiElement17.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if (text9.Contains("what's your mobile number") || text9.Contains("what's your email") || text9.Contains("enter an email") || text9.Contains("enter your email") || text9.Contains("enter your mobile number") || text9.Contains("enter your phone number") || text9.Contains("số di động") || text9.Contains("địa chỉ email") || text9.Contains("sign up with email") || text9.Contains("sign up with mobile number") || text9.Contains("confirm by mobile number") || text9.Contains("confirm by email") || (list.Any((UiElement P_0) => P_0.ClassName.Contains("EditText")) && list.Any((UiElement P_0) => P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("mobile", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase)) && !text9.Contains("password") && !text9.Contains("mật khẩu") && !text9.Contains("confirmation code") && !text9.Contains("mã xác nhận") && !text9.Contains("5-digit")))
				{
					bool flag6 = (text9.Contains("what's your mobile number") || text9.Contains("enter your mobile number") || text9.Contains("số di động") || text9.Contains("sign up with email") || text9.Contains("confirm by email") || list.Any((UiElement P_0) => P_0.ClassName.Contains("EditText") && (P_0.ContentDesc.Contains("mobile", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase)))) && !text9.Contains("what's your email") && !text9.Contains("enter an email") && !text9.Contains("enter your email") && !list.Any((UiElement P_0) => P_0.ClassName.Contains("EditText") && P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase));
					bool flag7 = (text9.Contains("what's your email") || text9.Contains("enter an email") || text9.Contains("enter your email") || text9.Contains("địa chỉ email") || text9.Contains("sign up with mobile number") || text9.Contains("confirm by mobile number") || list.Any((UiElement P_0) => P_0.ClassName.Contains("EditText") && P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase))) && !text9.Contains("what's your mobile number") && !text9.Contains("enter your mobile number") && !list.Any((UiElement P_0) => P_0.ClassName.Contains("EditText") && (P_0.ContentDesc.Contains("mobile", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase)));
					if (!flag2 & flag6)
					{
						CS_0024_003C_003E8__locals58.m_3135("Đang chuyển sang đăng ký bằng Email...");
						UiElement uiElement18 = list.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("email", StringComparison.OrdinalIgnoreCase)));
						if (uiElement18 == null)
						{
							await AdbController.TapAsync(text, (int)(450.0 * A), (int)(766.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement18.CenterX, uiElement18.CenterY, cancellationToken);
						}
						await Task.Delay(1500, cancellationToken);
						continue;
					}
					if (flag2 & flag7)
					{
						CS_0024_003C_003E8__locals58.m_3135("Đang chuyển sang đăng ký bằng Số di động...");
						UiElement uiElement19 = list.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Contains("mobile number", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("mobile number", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("số di động", StringComparison.OrdinalIgnoreCase)));
						if (uiElement19 == null)
						{
							await AdbController.TapAsync(text, (int)(450.0 * A), (int)(766.0 * a), cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement19.CenterX, uiElement19.CenterY, cancellationToken);
						}
						await Task.Delay(1500, cancellationToken);
						continue;
					}
					if ((text9.Contains("incorrect") || text9.Contains("including the country code") || text9.Contains("try entering your full number") || text9.Contains("không đúng") || text9.Contains("không hợp lệ") || text9.Contains("đã được sử dụng")) & flag2)
					{
						string text10 = text8;
						if (!text10.StartsWith("+"))
						{
							if (text10.StartsWith("0"))
							{
								text8 = "+84" + text10.Substring(1);
							}
							else
							{
								text8 = ((text10.Length != 10 || (!text10.StartsWith("3") && !text10.StartsWith("5") && !text10.StartsWith("7") && !text10.StartsWith("8") && !text10.StartsWith("9"))) ? ("+1" + text10) : ("+84" + text10));
							}
						}
						else
						{
							text8 = VerifyPhoneSettings.Load().BuildRandomPhonePreview();
							if (!text8.StartsWith("+") && (text8.StartsWith("0") || text8.Length == 10))
							{
								text8 = "+84" + (text8.StartsWith("0") ? text8.Substring(1) : text8);
							}
						}
						CS_0024_003C_003E8__locals58.m_3135($"SĐT ({text10}) bị Facebook yêu cầu mã quốc gia/từ chối - đổi sang: {text8}...");
					}
					else
					{
						CS_0024_003C_003E8__locals58.m_3135($"Phát hiện màn hình Thông tin liên hệ ({(flag2 ? "SĐT" : "Email")}) - đang điền: {text8}...");
					}
					string text11 = text8.Trim();
					if (flag2 && !text11.StartsWith("+") && VerifyPhoneSettings.Load().RandomInternationalFormat && text11.StartsWith("0"))
					{
						text11 = "+84" + text11.Substring(1);
					}
					UiElement uiElement20 = list.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText") || (P_0.ClassName.Contains("TextView") && P_0.Focused));
					if (uiElement20 == null)
					{
						await AdbController.TapAsync(text, (int)(414.0 * A), (int)(439.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement20.CenterX, uiElement20.CenterY, cancellationToken);
					}
					await Task.Delay(300, cancellationToken);
					await AdbController.InputTextAsync(text, text11, cancellationToken);
					await Task.Delay(300, cancellationToken);
					await AdbController.KeyEventAsync(text, "4", cancellationToken);
					await Task.Delay(500, cancellationToken);
					UiElement uiElement21 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase)));
					if (uiElement21 == null || uiElement21.CenterX <= 0 || uiElement21.CenterY <= 0)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(654.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement21.CenterX, uiElement21.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if ((text9.Contains("mật khẩu") || text9.Contains("create a password") || text9.Contains("password")) && !text9.Contains("confirmation code") && !text9.Contains("enter code"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Mật khẩu - đang điền mật khẩu...");
					UiElement uiElement22 = list.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText") || (P_0.ClassName.Contains("TextView") && P_0.Focused));
					if (uiElement22 == null)
					{
						await AdbController.TapAsync(text, (int)(414.0 * A), (int)(439.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement22.CenterX, uiElement22.CenterY, cancellationToken);
					}
					await Task.Delay(300, cancellationToken);
					await AdbController.InputTextAsync(text, item2, cancellationToken);
					await Task.Delay(300, cancellationToken);
					await AdbController.KeyEventAsync(text, "4", cancellationToken);
					await Task.Delay(500, cancellationToken);
					UiElement uiElement23 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View")) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && (P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase)));
					if (uiElement23 == null || uiElement23.CenterX <= 0 || uiElement23.CenterY <= 0)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(643.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement23.CenterX, uiElement23.CenterY, cancellationToken);
					}
					await Task.Delay(2500, cancellationToken);
					continue;
				}
				if (text9.Contains("save your login info") || text9.Contains("remember login info") || text9.Contains("lưu thông tin đăng nhập"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Lưu thông tin - đang xác nhận Tiếp...");
					UiElement uiElement24 = list.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("Save", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Save", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Lưu", StringComparison.OrdinalIgnoreCase));
					if (uiElement24 != null)
					{
						await AdbController.TapAsync(text, uiElement24.CenterX, uiElement24.CenterY, cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(642.0 * a), cancellationToken);
					}
					continue;
				}
				if (text9.Contains("tôi đồng ý") || text9.Contains("i agree") || text9.Contains("terms and policies") || text9.Contains("privacy policy") || text9.Contains("điều khoản"))
				{
					CS_0024_003C_003E8__locals58.m_3135("Phát hiện màn hình Điều khoản & Thoả thuận - đang bấm Tôi đồng ý...");
					UiElement uiElement25 = list.FirstOrDefault((UiElement P_0) => (P_0.ClassName.Contains("Button") && (P_0.ContentDesc.Equals("I agree", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("I agree", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase))) || P_0.ContentDesc.Trim().Equals("I agree", StringComparison.OrdinalIgnoreCase) || P_0.Text.Trim().Equals("I agree", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Trim().Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase) || P_0.Text.Trim().Equals("Tôi đồng ý", StringComparison.OrdinalIgnoreCase));
					if (uiElement25 == null)
					{
						await AdbController.TapAsync(text, (int)(450.0 * A), (int)(1428.0 * a), cancellationToken);
					}
					else
					{
						await AdbController.TapAsync(text, uiElement25.CenterX, uiElement25.CenterY, cancellationToken);
					}
					await Task.Delay(4000, cancellationToken);
					continue;
				}
				if (text9.Contains("nhập mã") || text9.Contains("enter code") || text9.Contains("mã xác nhận") || text9.Contains("confirmation code") || text9.Contains("xác nhận số") || text9.Contains("xác nhận email") || text9.Contains("chúng tôi đã gửi mã") || text9.Contains("resend code") || text9.Contains("confirm by email") || text9.Contains("send code to whatsapp") || text9.Contains("gửi lại mã") || text9.Contains("enter the confirmation code") || text9.Contains("to confirm your account") || text9.Contains("didn't get the code") || text9.Contains("didn’t get the code"))
				{
					flag3 = true;
					CS_0024_003C_003E8__locals58.m_3135("✓ Đã tới màn hình Nhập mã xác nhận (Confirmation screen)!");
					if (flag)
					{
						string text12 = await m_3086(text, cancellationToken);
						if (!string.IsNullOrWhiteSpace(text12))
						{
							nick.Uid = text12;
							CS_0024_003C_003E8__locals58.m_3135("✓ Đã trích xuất UID Facebook từ FB Lite: " + text12);
						}
					}
					if (!verifyOtp)
					{
						nick.Pass = item2;
						if (string.IsNullOrWhiteSpace(nick.Uid))
						{
							if (flag2)
							{
								nick.Uid = text8;
							}
							else
							{
								nick.Mail = text8;
							}
						}
						if (!flag2 && string.IsNullOrWhiteSpace(nick.Mail))
						{
							nick.Mail = text8;
						}
						nick.TinhTrang = "NOVERY";
						nick.TrangThai = "Đăng ký thành công (chờ xác minh)";
						CS_0024_003C_003E8__locals58.m_3135("✓ Đăng ký Novery thành công: " + (string.IsNullOrWhiteSpace(nick.Uid) ? text8 : nick.Uid) + " / " + item2);
						return new AiVisionRunResult
						{
							Success = true,
							TinhTrang = "NOVERY",
							Message = CS_0024_003C_003E8__locals58.a("Đăng ký Novery thành công: " + (string.IsNullOrWhiteSpace(nick.Uid) ? text8 : nick.Uid) + " | Pass: " + item2)
						};
					}
					CS_0024_003C_003E8__locals58.m_3135("✓ Đã tới màn hình Nhập mã - bắt đầu quá trình xác minh và lấy mã OTP...");
					break;
				}
				if (!text9.Contains("bảng tin") && !text9.Contains("news feed") && !text9.Contains("bạn đang nghĩ gì") && !text9.Contains("tìm kiếm"))
				{
					continue;
				}
				if (flag)
				{
					string text13 = await m_3086(text, cancellationToken);
					if (!string.IsNullOrWhiteSpace(text13))
					{
						nick.Uid = text13;
						CS_0024_003C_003E8__locals58.m_3135("✓ Đã trích xuất UID Facebook từ FB Lite: " + text13);
					}
				}
				nick.Pass = item2;
				if (string.IsNullOrWhiteSpace(nick.Uid))
				{
					if (flag2)
					{
						nick.Uid = text8;
					}
					else
					{
						nick.Mail = text8;
					}
				}
				if (!flag2 && string.IsNullOrWhiteSpace(nick.Mail))
				{
					nick.Mail = text8;
				}
				nick.TinhTrang = "LIVE";
				nick.TrangThai = "Đăng ký thành công (LIVE)";
				CS_0024_003C_003E8__locals58.m_3135("✓ Đăng ký LIVE thành công: " + (string.IsNullOrWhiteSpace(nick.Uid) ? text8 : nick.Uid) + " / " + item2);
				return new AiVisionRunResult
				{
					Success = true,
					TinhTrang = "LIVE",
					Message = CS_0024_003C_003E8__locals58.a("Đăng ký LIVE thành công: " + (string.IsNullOrWhiteSpace(nick.Uid) ? text8 : nick.Uid) + " | Pass: " + item2)
				};
			}
			if (!flag3)
			{
				return new AiVisionRunResult
				{
					Success = false,
					TinhTrang = "ERROR",
					Message = CS_0024_003C_003E8__locals58.a("Không thể hoàn thành các bước đăng ký tự động trên Android.")
				};
			}
			nick.Pass = item2;
			if (flag2)
			{
				nick.Uid = text8;
			}
			else
			{
				nick.Mail = text8;
			}
			if (verifyOtp)
			{
				return await m_3083(nick, text, text8, item2, flag2, !baitEnabled, (!baitEnabled) ? text8 : "", (string P_0) =>
				{
					CS_0024_003C_003E8__locals58.A.Add($"{CS_0024_003C_003E8__locals58.A.Count + 1}. {P_0}");
					CS_0024_003C_003E8__locals58.m_3133(new AiVisionStepLog
					{
						FlowStepIndex = CS_0024_003C_003E8__locals58.m_3134++,
						SubStep = 1,
						ActionSummary = P_0,
						Reason = "Reg Android"
					});
				}, (string P_0) => (CS_0024_003C_003E8__locals58.A.Count != 0) ? (P_0 + "\n\n— Nhật ký các bước —\n" + string.Join("\n", CS_0024_003C_003E8__locals58.A)) : P_0, cancellationToken, verifyMailTestClient, verifyPhoneTestClient, packageType);
			}
			nick.TinhTrang = "NOVERY";
			nick.TrangThai = "Đăng ký thành công (chờ xác minh)";
			return new AiVisionRunResult
			{
				Success = true,
				TinhTrang = "NOVERY",
				Message = CS_0024_003C_003E8__locals58.a("Hoàn tất bước đăng ký trên " + text4 + ".")
			};
		}
		catch (Exception ex3)
		{
			CS_0024_003C_003E8__locals58.m_3135("Lỗi: " + ex3.Message);
			return new AiVisionRunResult
			{
				Success = false,
				TinhTrang = "ERROR",
				Message = CS_0024_003C_003E8__locals58.a("Lỗi khi chạy trên Android: " + ex3.Message)
			};
		}
	}

	public static async Task<AiVisionRunResult> VerifyNickAsync(FacebookAccountRow nick, string packageType, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		C CS_0024_003C_003E8__locals20 = new C();
		CS_0024_003C_003E8__locals20.m_3144 = onStep;
		string text = nick.PhoneName;
		if (string.IsNullOrWhiteSpace(text))
		{
			text = (await AdbController.ListDevicesAsync(cancellationToken)).FirstOrDefault() ?? "";
			if (string.IsNullOrEmpty(text))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Nick chưa được gắn Phone Android và không tìm thấy thiết bị kết nối nào."
				};
			}
			nick.PhoneName = text;
		}
		bool flag = string.Equals(packageType, "Lite", StringComparison.OrdinalIgnoreCase);
		string text2 = (flag ? "com.facebook.lite" : "com.facebook.katana");
		string text3 = (flag ? "com.facebook.lite/.MainActivity" : "com.facebook.katana/.LoginActivity");
		string value = (flag ? "Facebook Lite" : "Facebook Katana");
		CS_0024_003C_003E8__locals20.m_3145 = 0;
		CS_0024_003C_003E8__locals20.A = new List<string>();
		CS_0024_003C_003E8__locals20.m_3146($"Bắt đầu Verify nick Novery trên {value} (Máy: {text})...");
		string text4 = ((!string.IsNullOrWhiteSpace(nick.Uid)) ? nick.Uid.Trim() : (nick.Mail?.Trim() ?? ""));
		string text5 = nick.Pass?.Trim() ?? "";
		if (string.IsNullOrWhiteSpace(text4) || string.IsNullOrWhiteSpace(text5))
		{
			return new AiVisionRunResult
			{
				Success = false,
				TinhTrang = "ERROR",
				Message = CS_0024_003C_003E8__locals20.a("Nick chưa có UID/Mail + Mật khẩu để đăng nhập.")
			};
		}
		try
		{
			await PhoneInitialSetupService.EnsureInitialSetupAsync(text, packageType, (string P_0) =>
			{
				CS_0024_003C_003E8__locals20.m_3146(P_0);
			}, cancellationToken);
			CS_0024_003C_003E8__locals20.m_3146("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(text, cancellationToken);
			if (!string.IsNullOrWhiteSpace(nick.Proxy))
			{
				CS_0024_003C_003E8__locals20.m_3146("Đang kết nối Proxy " + nick.Proxy + " qua Super Proxy...");
				if (!(await SuperProxyController.SetupAndStartProxyAsync(text, nick.Proxy, (string P_0) =>
				{
					CS_0024_003C_003E8__locals20.m_3146(P_0);
				}, cancellationToken)))
				{
					CS_0024_003C_003E8__locals20.m_3146("Cảnh báo: Kết nối proxy qua Super Proxy không thành công, tiếp tục chạy bằng mạng máy.");
				}
			}
			else
			{
				CS_0024_003C_003E8__locals20.m_3146("Không sử dụng Proxy -> Đang ngắt kết nối & reset sạch app Super Proxy...");
				await SuperProxyController.StopProxyAsync(text, (string P_0) =>
				{
					CS_0024_003C_003E8__locals20.m_3146(P_0);
				}, cancellationToken);
			}
			await AdbController.RunShellAsync(text, "pm clear " + text2, cancellationToken);
			await Task.Delay(800, cancellationToken);
			try
			{
				await AdbController.GrantAllAppPermissionsAsync(text, text2, cancellationToken);
			}
			catch
			{
			}
			await Task.Delay(300, cancellationToken);
			await AdbController.RunShellAsync(text, "am start -n " + text3, cancellationToken);
			await Task.Delay(3500, cancellationToken);
			bool flag2 = RegistrationChannelSettings.Load().Channel == "Phone";
			return await m_3083(nick, text, text4, text5, flag2, false, "", (string P_0) =>
			{
				CS_0024_003C_003E8__locals20.A.Add($"{CS_0024_003C_003E8__locals20.A.Count + 1}. {P_0}");
				CS_0024_003C_003E8__locals20.m_3144(new AiVisionStepLog
				{
					FlowStepIndex = CS_0024_003C_003E8__locals20.m_3145++,
					SubStep = 1,
					ActionSummary = P_0,
					Reason = "Verify Android"
				});
			}, (string P_0) => (CS_0024_003C_003E8__locals20.A.Count != 0) ? (P_0 + "\n\n— Nhật ký các bước —\n" + string.Join("\n", CS_0024_003C_003E8__locals20.A)) : P_0, cancellationToken, null, null, packageType);
		}
		catch (OperationCanceledException)
		{
			return new AiVisionRunResult
			{
				Success = false,
				TinhTrang = "ERROR",
				Message = CS_0024_003C_003E8__locals20.a("Đã dừng theo yêu cầu.")
			};
		}
		catch (Exception ex2)
		{
			return new AiVisionRunResult
			{
				Success = false,
				TinhTrang = "ERROR",
				Message = CS_0024_003C_003E8__locals20.a("Lỗi khi verify trên Android: " + ex2.Message)
			};
		}
	}

	private static async Task<AiVisionRunResult> m_3083(FacebookAccountRow P_0, string P_1, string P_2, string P_3, bool P_4, bool P_5, string P_6, Action<string> P_7, Func<string, string> P_8, CancellationToken P_9, IVerifyMailTestClient? existingMailClient = null, IVerifyPhoneTestClient? existingPhoneClient = null, string P_12 = "Katana")
	{
		c CS_0024_003C_003E8__locals65 = new c();
		CS_0024_003C_003E8__locals65.a = P_4;
		CS_0024_003C_003E8__locals65.m_3152 = P_0;
		CS_0024_003C_003E8__locals65.m_3153 = P_8;
		(int, int) tuple = await AdbController.GetScreenSizeAsync(P_1, P_9);
		int item = tuple.Item1;
		int item2 = tuple.Item2;
		CS_0024_003C_003E8__locals65.m_3155 = (double)item / 900.0;
		CS_0024_003C_003E8__locals65.m_3154 = (double)item2 / 1600.0;
		int num = 0;
		bool flag = false;
		CS_0024_003C_003E8__locals65.m_3149 = existingPhoneClient;
		CS_0024_003C_003E8__locals65.m_3151 = existingMailClient;
		ref Func<Task<string?>> reference = ref CS_0024_003C_003E8__locals65.A;
		Func<Task<string?>> func;
		if (existingPhoneClient != null)
		{
			func = existingPhoneClient.TryGetOtpAsync;
		}
		else
		{
			func = ((existingMailClient != null) ? new Func<Task<string>>(existingMailClient.TryGetOtpAsync) : null);
		}
		reference = func;
		ref Func<CancellationToken, Task<string>> reference2 = ref CS_0024_003C_003E8__locals65.m_3150;
		Func<CancellationToken, Task<string>> func2;
		if (existingPhoneClient != null)
		{
			func2 = existingPhoneClient.GetNewPhoneNumberAsync;
		}
		else
		{
			func2 = ((existingMailClient != null) ? new Func<CancellationToken, Task<string>>(existingMailClient.GetNewMailAddressAsync) : null);
		}
		reference2 = func2;
		int val = Math.Clamp(RegistrationRunSettings.Load().OtpWaitSeconds, 30, 300);
		CS_0024_003C_003E8__locals65.m_3148 = (CS_0024_003C_003E8__locals65.a ? (VerifyPhoneSettings.Load().Provider == "Random") : (VerifyMailSettings.Load().Provider == "Random"));
		D d2 = default;
		for (int i = 0; i < 60; i++)
		{
			P_9.ThrowIfCancellationRequested();
			await Task.Delay(1500, P_9);
			d2.A = await AdbController.DumpUiElementsAsync(P_1, P_9);
			if (d2.A.Count == 0)
			{
				await Task.Delay(1000, P_9);
				continue;
			}
			string text = string.Join(" ", d2.A.Select((UiElement uiElement21) => $"{uiElement21.Text} {uiElement21.ContentDesc} {uiElement21.ResourceId}")).ToLowerInvariant();
			if (text.Contains("checking info") || text.Contains("com.google.android.gms") || text.Contains("sign in with google") || text.Contains("đăng nhập bằng google") || text.Contains("choose an account") || text.Contains("chọn tài khoản") || text.Contains("use your google account") || text.Contains("google play services") || text.Contains("sign in - google accounts"))
			{
				P_7("Phát hiện màn hình Đăng nhập Google / Gmail - đang quay lại (Back) để về Facebook...");
				UiElement uiElement = m_3087(new string[5] { "Cancel", "Hủy", "Huỷ", "Dismiss", "None of the above" }, ref d2);
				if (uiElement == null)
				{
					await AdbController.KeyEventAsync(P_1, "4", P_9);
				}
				else
				{
					await AdbController.TapAsync(P_1, uiElement.CenterX, uiElement.CenterY, P_9);
				}
				await Task.Delay(1500, P_9);
				continue;
			}
			if (text.Contains("what's on your mind") || text.Contains("bạn đang nghĩ gì") || (text.Contains("marketplace") && text.Contains("notifications")) || text.Contains("what's on your mind?"))
			{
				CS_0024_003C_003E8__locals65.m_3152.TinhTrang = "LIVE";
				CS_0024_003C_003E8__locals65.m_3152.TrangThai = "LIVE";
				if (!string.IsNullOrEmpty(P_6))
				{
					if (CS_0024_003C_003E8__locals65.a)
					{
						CS_0024_003C_003E8__locals65.m_3152.Uid = P_6;
					}
					else
					{
						CS_0024_003C_003E8__locals65.m_3152.Mail = P_6;
					}
				}
				P_7("✓ Đã vào News Feed - đăng nhập + vượt xác minh thành công.");
				return new AiVisionRunResult
				{
					Success = true,
					TinhTrang = "LIVE",
					Message = CS_0024_003C_003E8__locals65.m_3153("Xác nhận LIVE thành công: " + P_2)
				};
			}
			if (text.Contains("you'll be logged out") || text.Contains("are you sure you want to leave") || text.Contains("bạn sẽ bị đăng xuất"))
			{
				UiElement uiElement2 = m_3087(new string[3] { "Cancel", "Huỷ", "Hủy" }, ref d2);
				if (uiElement2 != null)
				{
					await AdbController.TapAsync(P_1, uiElement2.CenterX, uiElement2.CenterY, P_9);
				}
				flag = true;
				P_7("Gặp dialog đăng xuất - bấm Cancel để giữ phiên.");
				continue;
			}
			if ((text.Contains("allow") && text.Contains("don't allow")) || text.Contains("permission_allow_button") || (text.Contains("cho phép") && text.Contains("từ chối")))
			{
				UiElement uiElement3 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ResourceId.Contains("permission_allow_button") || uiElement21.ResourceId.Contains("permission_allow_foreground_only_button") || uiElement21.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("While using the app", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Allow", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase));
				if (uiElement3 != null)
				{
					await AdbController.TapAsync(P_1, uiElement3.CenterX, uiElement3.CenterY, P_9);
					P_7("Cấp quyền (Allow).");
				}
				continue;
			}
			if (text.Contains("enter your password to log in") || text.Contains("nhập mật khẩu để đăng nhập"))
			{
				UiElement uiElement4 = m_3087(new string[1] { "OK" }, ref d2);
				if (uiElement4 != null)
				{
					await AdbController.TapAsync(P_1, uiElement4.CenterX, uiElement4.CenterY, P_9);
				}
				P_7("Dialog yêu cầu nhập mật khẩu - đóng để điền lại.");
				continue;
			}
			if (!d2.A.Any((UiElement uiElement21) => uiElement21.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase)) && (text.Contains("resend confirmation code") || text.Contains("gửi lại mã xác nhận") || (text.Contains("resend") && (text.Contains("change email") || text.Contains("confirm by") || text.Contains("change mobile"))) || (text.Contains("change email") && (text.Contains("mobile number") || text.Contains("log out") || text.Contains("đăng xuất"))) || (text.Contains("đổi email") && (text.Contains("số di động") || text.Contains("đăng xuất"))) || text.Contains("change mobile number") || (text.Contains("confirm by email") && (text.Contains("resend") || text.Contains("log out")))))
			{
				if (!P_5)
				{
					if (!(await CS_0024_003C_003E8__locals65.m_3157()))
					{
						return CS_0024_003C_003E8__locals65.m_3158("Cần đổi liên hệ để verify nhưng cổng đang để 'ảo random' - chọn cổng THẬT ở mục Xác minh rồi chạy lại.");
					}
					if (string.IsNullOrEmpty(P_6) && CS_0024_003C_003E8__locals65.m_3150 != null)
					{
						try
						{
							P_6 = await CS_0024_003C_003E8__locals65.m_3150(P_9);
							P_7("Đã lấy " + (CS_0024_003C_003E8__locals65.a ? "số" : "mail") + " mới từ cổng: " + P_6);
						}
						catch (Exception ex)
						{
							return CS_0024_003C_003E8__locals65.m_3159("Không lấy được " + (CS_0024_003C_003E8__locals65.a ? "số" : "mail") + " mới từ cổng verify: " + ex.Message);
						}
					}
					UiElement uiElement5 = (CS_0024_003C_003E8__locals65.a ? (a(new string[2] { "Change mobile number", "Confirm by mobile number" }, ref d2) ?? a(new string[2] { "mobile number", "số di động" }, ref d2)) : (a(new string[2] { "Change email", "Confirm by email" }, ref d2) ?? a(new string[1] { "email" }, ref d2)));
					if (uiElement5 != null)
					{
						await AdbController.TapAsync(P_1, uiElement5.CenterX, uiElement5.CenterY, P_9);
						P_7("Chọn " + (CS_0024_003C_003E8__locals65.a ? "Confirm by mobile number" : "Change email") + " trên menu.");
					}
					else if (!CS_0024_003C_003E8__locals65.a)
					{
						await AdbController.TapAsync(P_1, (int)(450.0 * CS_0024_003C_003E8__locals65.m_3155), (int)(480.0 * CS_0024_003C_003E8__locals65.m_3154), P_9);
					}
					else
					{
						await AdbController.TapAsync(P_1, (int)(450.0 * CS_0024_003C_003E8__locals65.m_3155), (int)(540.0 * CS_0024_003C_003E8__locals65.m_3154), P_9);
					}
					await Task.Delay(2500, P_9);
				}
				else
				{
					P_7("Menu tùy chọn đang che màn hình nhập mã - đang đóng menu...");
					UiElement uiElement6 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ContentDesc.Equals("Close", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Close", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("X", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("X", StringComparison.OrdinalIgnoreCase) || (uiElement21.ClassName.Contains("Button") && (uiElement21.ContentDesc.Contains("Close") || uiElement21.ContentDesc.Contains("Dismiss"))) || (uiElement21.ClassName.Contains("ImageView") && uiElement21.Top < (int)(600.0 * CS_0024_003C_003E8__locals65.m_3154) && uiElement21.Left < (int)(150.0 * CS_0024_003C_003E8__locals65.m_3155)));
					if (uiElement6 == null)
					{
						await AdbController.KeyEventAsync(P_1, "111", P_9);
						await AdbController.KeyEventAsync(P_1, "4", P_9);
					}
					else
					{
						await AdbController.TapAsync(P_1, uiElement6.CenterX, uiElement6.CenterY, P_9);
					}
					await Task.Delay(1500, P_9);
				}
				continue;
			}
			if ((text.Contains("confirm your mobile number") || (text.Contains("whatsapp") && text.Contains("send code"))) && !text.Contains("change mobile number") && !text.Contains("change email") && !text.Contains("log out"))
			{
				UiElement uiElement7 = ((CS_0024_003C_003E8__locals65.a & P_5) ? a(new string[1] { "Send code via SMS" }, ref d2) : null);
				if (uiElement7 == null)
				{
					uiElement7 = m_3087(new string[2] { "Continue", "Tiếp tục" }, ref d2) ?? a(new string[1] { "Send code via SMS" }, ref d2);
				}
				if (uiElement7 != null)
				{
					await AdbController.TapAsync(P_1, uiElement7.CenterX, uiElement7.CenterY, P_9);
					P_7((uiElement7.ContentDesc.Contains("SMS", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("SMS", StringComparison.OrdinalIgnoreCase)) ? "Màn xác nhận SĐT - bấm 'Send code via SMS'." : "Màn xác nhận SĐT - bấm Continue.");
				}
				await Task.Delay(2500, P_9);
				continue;
			}
			if (text.Contains("enter the confirmation code") || text.Contains("nhập mã xác nhận") || (text.Contains("confirmation code") && (text.Contains("5-digit") || text.Contains("we sent") || text.Contains("gửi mã") || text.Contains("chúng tôi đã gửi"))))
			{
				if (!P_5)
				{
					UiElement uiElement8 = a(new string[5] { "didn't get", "didn’t get", "get the code", "không nhận được mã", "chưa nhận được mã" }, ref d2);
					if (uiElement8 == null)
					{
						await AdbController.TapAsync(P_1, (int)(450.0 * CS_0024_003C_003E8__locals65.m_3155), (int)(679.0 * CS_0024_003C_003E8__locals65.m_3154), P_9);
					}
					else
					{
						await AdbController.TapAsync(P_1, uiElement8.CenterX, uiElement8.CenterY, P_9);
						P_7("Liên hệ mồi/cũ - bấm 'I didn't get the code' để đổi liên hệ.");
					}
					await Task.Delay(2500, P_9);
					continue;
				}
				if (!(await CS_0024_003C_003E8__locals65.m_3157()))
				{
					return CS_0024_003C_003E8__locals65.m_3158("Cổng verify để 'ảo random' - không đọc được mã.");
				}
				P_7($"Chờ đọc OTP cho {P_6} từ cổng {(CS_0024_003C_003E8__locals65.a ? "SMS" : "Mail")}...");
				string text2 = await m_3084(CS_0024_003C_003E8__locals65.A, Math.Min(val, 120), P_7, P_9);
				if (string.IsNullOrEmpty(text2))
				{
					return CS_0024_003C_003E8__locals65.m_3158($"Đã đổi liên hệ sang {P_6} nhưng không đọc được OTP từ cổng sau {Math.Min(val, 120)}s.");
				}
				UiElement uiElement9 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Contains("Confirmation code", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Contains("Confirmation code", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Contains("mã xác nhận", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Contains("mã xác nhận", StringComparison.OrdinalIgnoreCase)) ?? a(new string[1] { "Confirmation code" }, ref d2);
				if (uiElement9 == null)
				{
					await AdbController.TapAsync(P_1, (int)(450.0 * CS_0024_003C_003E8__locals65.m_3155), (int)(439.0 * CS_0024_003C_003E8__locals65.m_3154), P_9);
					await Task.Delay(300, P_9);
					await AdbController.InputTextAsync(P_1, text2, P_9);
					await Task.Delay(300, P_9);
				}
				else
				{
					await AdbController.TapAsync(P_1, uiElement9.CenterX, uiElement9.CenterY, P_9);
					await Task.Delay(300, P_9);
					await AdbController.InputTextAsync(P_1, text2, P_9);
					await Task.Delay(300, P_9);
				}
				await AdbController.KeyEventAsync(P_1, "111", P_9);
				await Task.Delay(600, P_9);
				UiElement uiElement10 = (await AdbController.DumpUiElementsAsync(P_1, P_9)).FirstOrDefault((UiElement uiElement21) => !uiElement21.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !uiElement21.Text.Equals("Back", StringComparison.OrdinalIgnoreCase) && (uiElement21.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Continue", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Confirm", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Confirm", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Tiếp", StringComparison.OrdinalIgnoreCase)));
				if (uiElement10 == null || uiElement10.CenterX <= 0 || uiElement10.CenterY <= 0)
				{
					await AdbController.TapAsync(P_1, (int)(450.0 * CS_0024_003C_003E8__locals65.m_3155), (int)(567.0 * CS_0024_003C_003E8__locals65.m_3154), P_9);
				}
				else
				{
					await AdbController.TapAsync(P_1, uiElement10.CenterX, uiElement10.CenterY, P_9);
				}
				P_7("Đã điền mã " + text2 + " + bấm Next - chờ chuyển form...");
				for (int num2 = 0; num2 < 10; num2++)
				{
					await Task.Delay(1500, P_9);
					string text3 = string.Join(" ", (await AdbController.DumpUiElementsAsync(P_1, P_9)).Select((UiElement uiElement21) => $"{uiElement21.Text} {uiElement21.ContentDesc} {uiElement21.ResourceId}")).ToLowerInvariant();
					if (!text3.Contains("enter the confirmation code") && !text3.Contains("confirmation code") && !text3.Contains("mã xác nhận"))
					{
						break;
					}
				}
				string text4;
				if (string.IsNullOrWhiteSpace(CS_0024_003C_003E8__locals65.m_3152.Uid))
				{
					text4 = (long.TryParse(P_2, out var _) ? P_2 : "");
				}
				else
				{
					text4 = CS_0024_003C_003E8__locals65.m_3152.Uid.Trim();
				}
				if (string.IsNullOrEmpty(text4))
				{
					try
					{
						bool flag2 = string.Equals(P_12, "Lite", StringComparison.OrdinalIgnoreCase);
						KatanaSessionResult katanaSessionResult = ((!flag2) ? (await AdbController.GetKatanaTokenAndCookieAsync(P_1, P_9)) : (await AdbController.GetFbLiteTokenAndCookieAsync(P_1, P_9)));
						KatanaSessionResult katanaSessionResult2 = katanaSessionResult;
						if (!katanaSessionResult2.Success)
						{
							katanaSessionResult = ((!flag2) ? (await AdbController.GetFbLiteTokenAndCookieAsync(P_1, P_9)) : (await AdbController.GetKatanaTokenAndCookieAsync(P_1, P_9)));
							KatanaSessionResult katanaSessionResult3 = katanaSessionResult;
							if (katanaSessionResult3.Success)
							{
								katanaSessionResult2 = katanaSessionResult3;
							}
						}
						if (katanaSessionResult2.Success && !string.IsNullOrEmpty(katanaSessionResult2.Uid))
						{
							text4 = katanaSessionResult2.Uid;
							CS_0024_003C_003E8__locals65.m_3152.Uid = katanaSessionResult2.Uid;
							if (!string.IsNullOrEmpty(katanaSessionResult2.Cookie))
							{
								CS_0024_003C_003E8__locals65.m_3152.Cookie = katanaSessionResult2.Cookie;
							}
							if (!string.IsNullOrEmpty(katanaSessionResult2.Token))
							{
								CS_0024_003C_003E8__locals65.m_3152.Token = katanaSessionResult2.Token;
							}
						}
					}
					catch
					{
					}
				}
				string text5 = "LIVE";
				if (!string.IsNullOrEmpty(text4))
				{
					text5 = await a(text4, P_9);
				}
				CS_0024_003C_003E8__locals65.m_3152.TinhTrang = text5;
				CS_0024_003C_003E8__locals65.m_3152.TrangThai = ((text5 == "LIVE") ? "Đăng ký LIVE thành công" : "Tài khoản DIE sau khi xác nhận");
				if (!string.IsNullOrEmpty(P_6))
				{
					if (CS_0024_003C_003E8__locals65.a)
					{
						CS_0024_003C_003E8__locals65.m_3152.Uid = P_6;
					}
					else
					{
						CS_0024_003C_003E8__locals65.m_3152.Mail = P_6;
					}
				}
				if (text5 == "LIVE")
				{
					P_7("✓ Đã chuyển form + Check Live bằng request: LIVE (" + ((!string.IsNullOrEmpty(P_6)) ? P_6 : P_2) + ")");
					return new AiVisionRunResult
					{
						Success = true,
						TinhTrang = "LIVE",
						Message = CS_0024_003C_003E8__locals65.m_3153("Đăng ký & Xác nhận LIVE thành công: " + ((!string.IsNullOrEmpty(P_6)) ? P_6 : P_2))
					};
				}
				P_7("✗ Đã chuyển form + Check Live bằng request: DIE (" + ((!string.IsNullOrEmpty(P_6)) ? P_6 : P_2) + ")");
				return new AiVisionRunResult
				{
					Success = false,
					TinhTrang = "DIE",
					Message = CS_0024_003C_003E8__locals65.m_3153("Xác nhận xong nhưng tài khoản DIE: " + ((!string.IsNullOrEmpty(P_6)) ? P_6 : P_2))
				};
			}
			if (!P_5 && d2.A.Any((UiElement uiElement21) => uiElement21.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase)) && !d2.A.Any((UiElement uiElement21) => uiElement21.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase)) && !text.Contains("confirmation code") && !text.Contains("5-digit") && !text.Contains("mã xác nhận") && !text.Contains("log in") && (text.Contains("mobile number") || text.Contains("phone") || text.Contains("email") || text.Contains("enter your") || text.Contains("enter an") || text.Contains("số di động") || text.Contains("địa chỉ email")))
			{
				if (!(await CS_0024_003C_003E8__locals65.m_3157()))
				{
					return CS_0024_003C_003E8__locals65.m_3158("Cổng verify để 'ảo random' - không đổi được liên hệ.");
				}
				if (string.IsNullOrEmpty(P_6) && CS_0024_003C_003E8__locals65.m_3150 != null)
				{
					try
					{
						P_6 = await CS_0024_003C_003E8__locals65.m_3150(P_9);
					}
					catch (Exception ex2)
					{
						return CS_0024_003C_003E8__locals65.m_3159("Không lấy được liên hệ mới từ cổng: " + ex2.Message);
					}
				}
				UiElement uiElement11 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ClassName.Contains("EditText", StringComparison.OrdinalIgnoreCase));
				if (uiElement11 != null && !string.IsNullOrEmpty(P_6))
				{
					await AdbController.TapAsync(P_1, uiElement11.CenterX, uiElement11.CenterY, P_9);
					await Task.Delay(300, P_9);
					await AdbController.InputTextAsync(P_1, P_6, P_9);
					await Task.Delay(300, P_9);
					P_7("Điền liên hệ mới: " + P_6);
				}
				await AdbController.KeyEventAsync(P_1, "111", P_9);
				await Task.Delay(800, P_9);
				UiElement uiElement12 = (await AdbController.DumpUiElementsAsync(P_1, P_9)).FirstOrDefault((UiElement uiElement21) => !uiElement21.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) && !uiElement21.Text.Equals("Back", StringComparison.OrdinalIgnoreCase) && (uiElement21.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Continue", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Save", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Save", StringComparison.OrdinalIgnoreCase)));
				if (uiElement12 != null && uiElement12.CenterX > 0 && uiElement12.CenterY > 0)
				{
					await AdbController.TapAsync(P_1, uiElement12.CenterX, uiElement12.CenterY, P_9);
				}
				P_5 = true;
				P_7("Đã đổi liên hệ + bấm Next - chờ màn nhập mã cho liên hệ mới.");
				await Task.Delay(3500, P_9);
				continue;
			}
			if (text.Contains("i already have a profile") || (text.Contains("join facebook") && text.Contains("get started")))
			{
				UiElement uiElement13 = a(new string[3] { "I already have a profile", "already have a profile", "already have" }, ref d2);
				if (uiElement13 != null)
				{
					await AdbController.TapAsync(P_1, uiElement13.CenterX, uiElement13.CenterY, P_9);
					P_7("Màn Join Facebook - bấm 'I already have a profile'.");
				}
				await Task.Delay(2500, P_9);
				continue;
			}
			if (text.Contains("use another profile") || text.Contains("log into another account"))
			{
				UiElement uiElement14 = a(new string[2] { "Use another profile", "Log into another account" }, ref d2);
				if (uiElement14 != null)
				{
					await AdbController.TapAsync(P_1, uiElement14.CenterX, uiElement14.CenterY, P_9);
					P_7("Bấm Use another profile.");
				}
				continue;
			}
			UiElement uiElement15 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ContentDesc.Contains("Mobile number or email", StringComparison.OrdinalIgnoreCase) || (uiElement21.ClassName.Contains("EditText") && (uiElement21.ContentDesc.Contains("email", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Contains("phone", StringComparison.OrdinalIgnoreCase))));
			UiElement uiElement16 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase) && uiElement21.ClassName.Contains("EditText"));
			if (uiElement15 == null)
			{
				uiElement16 = d2.A.FirstOrDefault((UiElement uiElement21) => uiElement21.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase));
			}
			if (uiElement15 != null && uiElement16 != null)
			{
				if (num >= 3)
				{
					return new AiVisionRunResult
					{
						Success = false,
						TinhTrang = "DIE",
						Message = CS_0024_003C_003E8__locals65.m_3153($"Sai mật khẩu / không đăng nhập được sau {3} lần: {P_2}")
					};
				}
				num++;
				P_7($"Điền form đăng nhập (lần {num}/{3}): {P_2}");
				await AdbController.TapAsync(P_1, uiElement15.CenterX, uiElement15.CenterY, P_9);
				await Task.Delay(300, P_9);
				await AdbController.InputTextAsync(P_1, P_2, P_9);
				await Task.Delay(300, P_9);
				await AdbController.TapAsync(P_1, uiElement16.CenterX, uiElement16.CenterY, P_9);
				await Task.Delay(300, P_9);
				await AdbController.InputTextAsync(P_1, P_3, P_9);
				await Task.Delay(300, P_9);
				await AdbController.KeyEventAsync(P_1, "111", P_9);
				await Task.Delay(1200, P_9);
				UiElement uiElement17 = (await AdbController.DumpUiElementsAsync(P_1, P_9)).FirstOrDefault((UiElement uiElement21) => uiElement21.ContentDesc.Equals("Log in", StringComparison.OrdinalIgnoreCase) || uiElement21.Text.Equals("Log in", StringComparison.OrdinalIgnoreCase) || uiElement21.ContentDesc.Equals("Đăng nhập", StringComparison.OrdinalIgnoreCase));
				if (uiElement17 != null && uiElement17.CenterX > 0 && uiElement17.CenterY > 0)
				{
					await AdbController.TapAsync(P_1, uiElement17.CenterX, uiElement17.CenterY, P_9);
				}
				await Task.Delay(4000, P_9);
				continue;
			}
			UiElement uiElement18 = m_3087(new string[10] { "Skip", "Skip for now", "Bỏ qua", "Not now", "Not Now", "Maybe later", "Để sau", "No thanks", "Không, cảm ơn", "Later" }, ref d2);
			if (uiElement18 != null)
			{
				await AdbController.TapAsync(P_1, uiElement18.CenterX, uiElement18.CenterY, P_9);
				flag = false;
				P_7("Bấm bỏ qua: " + ((!string.IsNullOrEmpty(uiElement18.Text)) ? uiElement18.Text : uiElement18.ContentDesc));
				continue;
			}
			UiElement uiElement19 = m_3087(new string[3] { "Close", "Đóng", "Dismiss" }, ref d2);
			if (uiElement19 != null && !flag)
			{
				await AdbController.TapAsync(P_1, uiElement19.CenterX, uiElement19.CenterY, P_9);
				P_7("Bấm X (Close).");
				continue;
			}
			UiElement uiElement20 = m_3087(new string[6] { "Continue", "Tiếp tục", "Tiếp", "OK", "Done", "Xong" }, ref d2);
			if (uiElement20 != null)
			{
				await AdbController.TapAsync(P_1, uiElement20.CenterX, uiElement20.CenterY, P_9);
				flag = false;
				P_7("Bấm: " + ((!string.IsNullOrEmpty(uiElement20.Text)) ? uiElement20.Text : uiElement20.ContentDesc));
			}
			else
			{
				P_7($"Màn chưa nhận diện được nút hành động (vòng {i + 1}).");
				d2 = default;
			}
		}
		CS_0024_003C_003E8__locals65.m_3152.TinhTrang = "NOVERY";
		return new AiVisionRunResult
		{
			Success = true,
			TinhTrang = "NOVERY",
			Message = CS_0024_003C_003E8__locals65.m_3153($"Đã tới màn hình xác nhận nhưng chưa hoàn tất xác minh sau {60} vòng (có thể vướng checkpoint/chưa nhận được OTP): {P_2}")
		};
	}

	private static async Task<string?> m_3084(Func<Task<string?>> tryGetOtp, int P_1, Action<string> P_2, CancellationToken P_3)
	{
		for (int i = 0; i < P_1; i += 5)
		{
			P_3.ThrowIfCancellationRequested();
			try
			{
				string text = await tryGetOtp();
				if (!string.IsNullOrWhiteSpace(text))
				{
					return text.Trim();
				}
			}
			catch
			{
			}
			await Task.Delay(5000, P_3);
			P_2($"...đang chờ mã OTP ({i + 5}/{P_1}s)");
		}
		return null;
	}

	private static (string HoTen, string GioiTinh, string MatKhau) m_3085(FacebookAccountRow P_0)
	{
		string item = ((!string.IsNullOrWhiteSpace(P_0.HoTen)) ? P_0.HoTen.Trim() : RandomFacebookIdentityGenerator.RandomFullName(RandomFacebookIdentityGenerator.RandomGender(), includeMiddleName: true));
		string item2 = ((!string.IsNullOrWhiteSpace(P_0.GioiTinh)) ? P_0.GioiTinh.Trim() : "Nam");
		string item3 = ((!string.IsNullOrWhiteSpace(P_0.Pass)) ? P_0.Pass.Trim() : RandomFacebookIdentityGenerator.RandomPassword(lower: true, upper: true, digits: true, special: false, 8, 12));
		return (HoTen: item, GioiTinh: item2, MatKhau: item3);
	}

	private static string[] a(string P_0)
	{
		string[] array = P_0.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
		if (array.Length != 0)
		{
			if (array.Length != 1)
			{
				string text = array[0];
				string text2 = string.Join(" ", array.Skip(1));
				return new string[2] { text, text2 };
			}
			return new string[2]
			{
				"Nguyen",
				array[0]
			};
		}
		return new string[2] { "Nguyen", "An" };
	}

	private static async Task<string?> m_3086(string P_0, CancellationToken P_1)
	{
		try
		{
			string text = await AdbController.RunShellCaptureAsync(P_0, "su 0 cat /data/data/com.facebook.lite/shared_prefs/com.facebook.lite.xml", P_1);
			if (string.IsNullOrWhiteSpace(text))
			{
				return null;
			}
			Match match = Regex.Match(text, "name=\"current_user_id\"\\s+value=\"(\\d+)\"");
			if (match.Success && match.Groups[1].Value != "0")
			{
				return match.Groups[1].Value;
			}
			Match match2 = Regex.Match(text, "consume_sso_from_fb4a_via_account_manager_(\\d+)");
			if (match2.Success && match2.Groups[1].Value != "0")
			{
				return match2.Groups[1].Value;
			}
		}
		catch
		{
		}
		return null;
	}

	private static async Task<string> a(string P_0, CancellationToken P_1 = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return "LIVE";
		}
		try
		{
			using HttpClient httpClient = new HttpClient
			{
				Timeout = TimeSpan.FromSeconds(15L)
			};
			using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, "https://graph.facebook.com/" + P_0.Trim() + "/picture?redirect=false");
			httpRequestMessage.Headers.Add("user-agent", "Mozilla/5.0");
			using HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(httpRequestMessage, P_1);
			return (await httpResponseMessage.Content.ReadAsStringAsync(P_1)).Contains("width") ? "LIVE" : "DIE";
		}
		catch
		{
			return "LIVE";
		}
	}

	[CompilerGenerated]
	internal static UiElement? m_3087(string[] kws, ref D P_1)
	{
		return P_1.A.FirstOrDefault((UiElement uiElement) => kws.Any((string value) => uiElement.Text.Equals(value, StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Equals(value, StringComparison.OrdinalIgnoreCase)));
	}

	[CompilerGenerated]
	internal static UiElement? a(string[] kws, ref D P_1)
	{
		return P_1.A.FirstOrDefault((UiElement uiElement) => kws.Any((string value) => uiElement.Text.Contains(value, StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains(value, StringComparison.OrdinalIgnoreCase)));
	}
}
