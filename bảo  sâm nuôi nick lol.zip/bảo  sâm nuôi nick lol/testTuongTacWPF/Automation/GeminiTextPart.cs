using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class GeminiTextPart
{
	[CompilerGenerated]
	private string A = "";

	[JsonPropertyName("text")]
	public string Text
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
