namespace testTuongTacWPF.Automation;

public static class AiVisionProviders
{
	public const string Claude = "Claude";

	public const string Gemini = "Gemini";

	public const string HHTechApi = "HHTechApi";

	public const string VietApi = "VietApi";

	public const string Custom = "Custom";

	public const string GeminiAntigravity = "GeminiAntigravity";
}
