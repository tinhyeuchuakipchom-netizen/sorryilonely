namespace testTuongTacWPF.Automation;

public enum BmBusinessNameMode
{
	RandomEnglish,
	RandomVietnamese,
	CustomList
}
