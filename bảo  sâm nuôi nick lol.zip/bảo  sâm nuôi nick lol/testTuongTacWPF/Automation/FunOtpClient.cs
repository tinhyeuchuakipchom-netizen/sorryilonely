using System;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class FunOtpClient : IVerifyPhoneTestClient
{
	private readonly string A;

	private readonly string a;

	private readonly string B;

	private readonly HttpClient m_5491 = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private string? b;

	public FunOtpClient(string apiKey, string service, string country)
	{
		A = apiKey;
		a = service;
		B = country;
	}

	public async Task<string> GetNewPhoneNumberAsync(CancellationToken ct = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(A))
		{
			throw new InvalidOperationException("Chưa nhập API Key cho funotp.com (xem ô \"API Key funotp.com\" bên dưới).");
		}
		if (string.IsNullOrWhiteSpace(a))
		{
			throw new InvalidOperationException("Chưa nhập ID thư mục/dịch vụ cho funotp.com (xem ô \"ID thư mục\" bên dưới).");
		}
		string text = await m_5491.GetStringAsync("https://funotp.com/api?action=number&service=" + a + "&apikey=" + A, ct);
		string value = Regex.Match(text, "numberno84\":\"(.*?)\"").Groups[1].Value;
		string value2 = Regex.Match(text, "id\":\"(.*?)\"").Groups[1].Value;
		if (string.IsNullOrEmpty(value) || string.IsNullOrEmpty(value2))
		{
			throw new InvalidOperationException("funotp.com không trả về số điện thoại (có thể hết số/sai API Key/sai ID thư mục): " + text);
		}
		b = value2;
		return (B.Contains("us", StringComparison.OrdinalIgnoreCase) ? "+1" : "+84") + value;
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (b == null)
		{
			throw new InvalidOperationException("Chưa lấy số điện thoại - bấm \"Thử lấy số\" trước.");
		}
		Match match = Regex.Match(await m_5491.GetStringAsync("https://funotp.com/api?action=code&id=" + b + "&apikey=" + A), "\\b(\\d{5})\\b");
		return match.Success ? match.Groups[1].Value : null;
	}
}
