using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;

namespace testTuongTacWPF.Automation;

public static class FacebookLanguageEnforcer
{
	private const string A = "https://www.facebook.com/settings?tab=language&locale=en_US";

	private const string a = "English (US)";

	private static readonly Regex m_4843 = new Regex("^(Account language|Ngôn ngữ(?: của)? tài khoản)", RegexOptions.IgnoreCase);

	public static async Task<bool> EnsureEnglishAsync(IPage page, Action<string, string> log, CancellationToken cancellationToken)
	{
		_ = 12;
		try
		{
			if (await m_4844(page))
			{
				return true;
			}
			log("Giao diện Facebook không phải tiếng Anh - đang tự chuyển sang English (US)...", "Ngôn ngữ");
			await page.GotoAsync("https://www.facebook.com/settings?tab=language&locale=en_US", new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(Random.Shared.Next(3000, 4500), cancellationToken);
			ILocator first = page.Locator("[role='button']").Filter(new LocatorFilterOptions
			{
				HasTextRegex = m_4843
			}).First;
			if (await first.CountAsync() == 0)
			{
				log("[Bỏ qua] Không tìm thấy mục đổi ngôn ngữ tài khoản trong Cài đặt Facebook.", "Ngôn ngữ");
				return false;
			}
			await FacebookFriendRequestActions.ClickRobustAsync(first, cancellationToken);
			await Task.Delay(Random.Shared.Next(2500, 4000), cancellationToken);
			ILocator first2 = page.GetByRole(AriaRole.Radio, new PageGetByRoleOptions
			{
				Name = "English (US)",
				Exact = false
			}).First;
			if (await first2.CountAsync() == 0)
			{
				log("[Bỏ qua] Không tìm thấy lựa chọn English (US) trong bảng chọn ngôn ngữ.", "Ngôn ngữ");
				return false;
			}
			await FacebookFriendRequestActions.ClickRobustAsync(first2, cancellationToken);
			await Task.Delay(Random.Shared.Next(4000, 6000), cancellationToken);
			if (await m_4844(page))
			{
				log("Đã chuyển giao diện Facebook sang English (US).", "Ngôn ngữ");
				return true;
			}
			await page.ReloadAsync(new PageReloadOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(Random.Shared.Next(2500, 4000), cancellationToken);
			bool flag = await m_4844(page);
			log(flag ? "Đã chuyển giao diện Facebook sang English (US)." : "[Bỏ qua] Chuyển ngôn ngữ xong nhưng giao diện vẫn chưa phải tiếng Anh.", "Ngôn ngữ");
			return flag;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			log("[Bỏ qua] Lỗi khi chuyển ngôn ngữ Facebook: " + ex2.Message, "Ngôn ngữ");
			return false;
		}
	}

	public static async Task<bool> EnsureEnglishForLoginPageAsync(IPage page, CancellationToken cancellationToken)
	{
		_ = 3;
		try
		{
			if (await m_4844(page))
			{
				return true;
			}
			Uri uri = new Uri(page.Url);
			string value = ((uri.Query.Length == 0) ? "?" : "&");
			string url = $"{uri.Scheme}://{uri.Host}{uri.AbsolutePath}{uri.Query}{value}locale=en_US";
			await page.GotoAsync(url, new PageGotoOptions
			{
				Timeout = 30000f,
				WaitUntil = WaitUntilState.DOMContentLoaded
			});
			await Task.Delay(Random.Shared.Next(1200, 2200), cancellationToken);
			return await m_4844(page);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
			return false;
		}
	}

	private static async Task<bool> m_4844(IPage P_0)
	{
		return ((await P_0.EvaluateAsync<string>("() => document.documentElement.lang || ''")) ?? "").StartsWith("en", StringComparison.OrdinalIgnoreCase);
	}
}
