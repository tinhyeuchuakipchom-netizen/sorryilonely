using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class ClaudeImageSource
{
	[CompilerGenerated]
	private string A = "base64";

	[CompilerGenerated]
	private string a = "image/png";

	[CompilerGenerated]
	private string B = "";

	[JsonPropertyName("type")]
	public string Type
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("media_type")]
	public string MediaType
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	[JsonPropertyName("data")]
	public string Data
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}
}
