using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class GeminiContent
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private object[] m_2882 = Array.Empty<object>();

	[JsonPropertyName("role")]
	public string Role
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("parts")]
	public object[] Parts
	{
		[CompilerGenerated]
		get
		{
			return m_2882;
		}
		[CompilerGenerated]
		set
		{
			m_2882 = value;
		}
	}
}
