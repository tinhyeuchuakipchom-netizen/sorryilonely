using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookKatanaPhoneInteractionService
{
	[CompilerGenerated]
	private static class m_4630
	{
		public static Func<UiElement, bool> A;

		public static Func<UiElement, bool> a;
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class m_4631
	{
		public static readonly m_4631 A = new m_4631();

		public static Func<UiElement, bool> m_4632;

		public static Func<UiElement, bool> a;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		public static Func<UiElement, bool> C;

		public static Func<UiElement, bool> c;

		public static Func<UiElement, bool> D;

		public static Func<UiElement, bool> d;

		public static Func<string, bool> m_4633;

		public static Func<string, string> m_4634;

		public static Func<UiElement, bool> E;

		public static Func<UiElement, bool> e;

		public static Func<UiElement, bool> F;

		public static Func<UiElement, bool> f;

		public static Func<UiElement, bool> G;

		public static Func<UiElement, bool> g;

		public static Func<string, bool> m_4635;

		public static Func<string, string> m_4636;

		public static Func<UiElement, bool> H;

		public static Func<UiElement, bool> h;

		public static Func<UiElement, bool> I;

		public static Func<UiElement, bool> i;

		public static Func<UiElement, bool> J;

		public static Func<UiElement, bool> j;

		public static Func<UiElement, bool> K;

		public static Func<string, bool> m_4637;

		public static Func<string, string> m_4638;

		public static Func<UiElement, bool> k;

		public static Func<UiElement, bool> L;

		public static Func<UiElement, bool> l;

		public static Func<UiElement, bool> M;

		internal bool m_4639(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("create a new post", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Create", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Make a post", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4640(UiElement P_0)
		{
			if (P_0.ContentDesc.Equals("Post", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Post", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.CenterY < 800;
			}
			return false;
		}

		internal bool m_4641(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("AutoCompleteTextView") && !P_0.ClassName.Contains("EditText") && !P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4642(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Photo/video", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Photo/video", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4643(UiElement P_0)
		{
			if (P_0.CenterY > 300 && P_0.CenterY < 1800 && (P_0.ClassName.Contains("ImageView") || P_0.ClassName.Contains("ViewGroup")))
			{
				return P_0.Right - P_0.Left > 100;
			}
			return false;
		}

		internal bool m_4644(UiElement P_0)
		{
			if (!P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4645(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("AutoCompleteTextView") && !P_0.ClassName.Contains("EditText"))
			{
				return P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4646(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("POST", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("POST", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.CenterY < 220)
				{
					return P_0.CenterX > 850;
				}
				return false;
			}
			return true;
		}

		internal bool m_4647(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_4648(string P_0)
		{
			return P_0.Trim();
		}

		internal bool m_4649(UiElement P_0)
		{
			if ((P_0.ContentDesc.Equals("Like", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Thích", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Like", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Thích", StringComparison.OrdinalIgnoreCase)) && !P_0.ContentDesc.Contains("Unlike", StringComparison.OrdinalIgnoreCase))
			{
				return !P_0.ContentDesc.Contains("Bỏ thích", StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}

		internal bool m_4650(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Comment", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Bình luận", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Comment", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Bình luận", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4651(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText") && !P_0.Text.Contains("comment", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("comment", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("bình luận", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4652(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Send", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Post", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Gửi", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Send", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Post", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4653(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Share", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Chia sẻ", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Share", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4654(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Share now", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Share now", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Share to Feed", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Share to Feed", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Chia sẻ ngay", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4655(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_4656(string P_0)
		{
			return P_0.Trim();
		}

		internal bool m_4657(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Groups", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Groups", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Nhóm", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Nhóm", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4658(UiElement P_0)
		{
			if ((P_0.ContentDesc.Contains("Join", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Join", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tham gia", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Tham gia", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Public group", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Public group", StringComparison.OrdinalIgnoreCase)) && P_0.CenterY > 320)
			{
				return P_0.CenterY < 2000;
			}
			return false;
		}

		internal bool m_4659(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("See group", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("See group", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Xem nhóm", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Xem nhóm", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4660(UiElement P_0)
		{
			if ((P_0.ContentDesc.Equals("Comment", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Bình luận", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Comment", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Bình luận", StringComparison.OrdinalIgnoreCase)) && P_0.CenterY > 250)
			{
				return P_0.CenterY < 2100;
			}
			return false;
		}

		internal bool m_4661(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText") && !P_0.Text.Contains("comment", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("comment", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("bình luận", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4662(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Send", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Post", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Send", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Post", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4663(UiElement P_0)
		{
			if (!P_0.Text.Replace('\u00a0', ' ').Trim().Equals("Confirm", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Replace('\u00a0', ' ').Trim().Equals("Confirm", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Replace('\u00a0', ' ').Trim().Equals("Xác nhận", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4664(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_4665(string P_0)
		{
			return P_0.Trim();
		}

		internal bool m_4666(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("People", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("People", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Mọi người", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Mọi người", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4667(UiElement P_0)
		{
			if (m_4629(P_0) && P_0.CenterY > 250)
			{
				return P_0.CenterY < 2050;
			}
			return false;
		}

		internal bool m_4668(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Create, Double tap", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Facebook logo", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Menu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Home, tab", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Groups", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Friends", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("feed_tab");
			}
			return true;
		}

		internal bool m_4669(UiElement P_0)
		{
			if (!P_0.Text.Equals("Not now", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Not now", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Skip", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Skip", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Close", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Close", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Cancel", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Cancel", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Don't allow", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Don't allow", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class B
	{
		public HashSet<string> A;

		internal bool m_4670(string P_0)
		{
			return !A.Contains(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class b
	{
		public string A;

		internal bool m_4671(UiElement P_0)
		{
			if (!A.Contains("LoggedOut", StringComparison.OrdinalIgnoreCase) && !A.Contains("LoginActivity", StringComparison.OrdinalIgnoreCase) && !P_0.ResourceId.Contains("login_password") && !P_0.ResourceId.Contains("m_login_password") && !P_0.ContentDesc.Equals("Mobile number or email", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Mobile number or email", StringComparison.OrdinalIgnoreCase) && (!P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) || P_0.CenterY <= 1000) && (!P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) || P_0.CenterY <= 1000))
			{
				return P_0.ContentDesc.Contains("Forgot Password", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	private const string A = "com.facebook.katana/.activity.FbMainTabActivity";

	public static async Task<AiVisionRunResult> PostToWallAsync(FacebookAccountRow account, PostCreationSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		string text = await m_4625(account, cancellationToken);
		if (string.IsNullOrEmpty(text))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Không tìm thấy thiết bị Android nào đang kết nối.",
				TinhTrang = "ERROR"
			};
		}
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (!(await m_4626(text, account, onStatus, cancellationToken)))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Không thể chuẩn bị app Facebook Katana hoặc nick chưa đăng nhập.",
					TinhTrang = "ERROR"
				};
			}
			int num = Math.Max(1, settings.PostCount);
			int num2 = 0;
			for (int i = 0; i < num; i++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				string text2 = ((num > 1) ? $"[Bài {i + 1}/{num}] " : "");
				string text3 = settings.PickContent();
				List<string> list = settings.PickMediaFiles();
				if (string.IsNullOrWhiteSpace(text3) && list.Count == 0)
				{
					text3 = "Hello! Have a great day everyone \ud83d\ude0a";
				}
				onStatus(text2 + "Đang mở giao diện tạo bài viết...");
				await AdbController.RunShellAsync(text, "am start -a android.intent.action.VIEW -d 'fb://feed' -p com.facebook.katana", cancellationToken);
				await Task.Delay(2500, cancellationToken);
				await m_4628(text, onStatus, cancellationToken);
				UiElement uiElement = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("create a new post", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Create", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Make a post", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase));
				if (uiElement == null)
				{
					await AdbController.TapAsync(text, 766, 140, cancellationToken);
					await Task.Delay(1500, cancellationToken);
				}
				else
				{
					await AdbController.TapAsync(text, uiElement.CenterX, uiElement.CenterY, cancellationToken);
					await Task.Delay(1500, cancellationToken);
				}
				UiElement uiElement2 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => (P_0.ContentDesc.Equals("Post", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Post", StringComparison.OrdinalIgnoreCase)) && P_0.CenterY < 800);
				if (uiElement2 != null)
				{
					await AdbController.TapAsync(text, uiElement2.CenterX, uiElement2.CenterY, cancellationToken);
					await Task.Delay(2000, cancellationToken);
				}
				List<UiElement> source = await AdbController.DumpUiElementsAsync(text, cancellationToken);
				if (source.FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("AutoCompleteTextView") || P_0.ClassName.Contains("EditText") || P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase)) == null)
				{
					onStatus(text2 + "Không tìm thấy ô nhập nội dung bài viết.");
					continue;
				}
				if (list.Count > 0)
				{
					onStatus($"{text2}Đang đẩy {list.Count} tệp media lên thiết bị...");
					string text4 = "/sdcard/Pictures/FastBox_Post";
					await AdbController.RunShellAsync(text, "mkdir -p " + text4, cancellationToken);
					List<string> list2 = new List<string>();
					foreach (string item in list)
					{
						if (File.Exists(item))
						{
							string fileName = Path.GetFileName(item);
							string text5 = text4 + "/" + fileName;
							await AdbController.PushFileAsync(text, item, text5, cancellationToken);
							await AdbController.RunShellAsync(text, "am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"file://" + text5 + "\"", cancellationToken);
							list2.Add(text5);
						}
					}
					if (list2.Count > 0)
					{
						onStatus(text2 + "Chọn tệp ảnh/video trong Facebook...");
						UiElement uiElement3 = source.FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Photo/video", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Photo/video", StringComparison.OrdinalIgnoreCase));
						if (uiElement3 != null)
						{
							await AdbController.TapAsync(text, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
							await Task.Delay(2500, cancellationToken);
							List<UiElement> list3 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).Where((UiElement P_0) => P_0.CenterY > 300 && P_0.CenterY < 1800 && (P_0.ClassName.Contains("ImageView") || P_0.ClassName.Contains("ViewGroup")) && P_0.Right - P_0.Left > 100).Take(list2.Count).ToList();
							foreach (UiElement item2 in list3)
							{
								await AdbController.TapAsync(text, item2.CenterX, item2.CenterY, cancellationToken);
								await Task.Delay(800, cancellationToken);
							}
							UiElement uiElement4 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.Text.Equals("Next", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Next", StringComparison.OrdinalIgnoreCase));
							if (uiElement4 != null)
							{
								await AdbController.TapAsync(text, uiElement4.CenterX, uiElement4.CenterY, cancellationToken);
								await Task.Delay(2000, cancellationToken);
							}
						}
					}
				}
				if (!string.IsNullOrWhiteSpace(text3))
				{
					onStatus(text2 + "Đang nhập nội dung bài viết...");
					UiElement? uiElement5 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("AutoCompleteTextView") || P_0.ClassName.Contains("EditText") || P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase));
					int x = uiElement5?.CenterX ?? 540;
					int y = uiElement5?.CenterY ?? 560;
					await AdbController.TapAsync(text, x, y, cancellationToken);
					await Task.Delay(800, cancellationToken);
					await AdbController.InputTextAsync(text, text3, cancellationToken);
					await Task.Delay(1500, cancellationToken);
				}
				UiElement? uiElement6 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("POST", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("POST", StringComparison.OrdinalIgnoreCase) || (P_0.CenterY < 220 && P_0.CenterX > 850));
				int x2 = uiElement6?.CenterX ?? 967;
				int y2 = uiElement6?.CenterY ?? 140;
				onStatus(text2 + "Bấm nút Đăng bài (POST)...");
				await AdbController.TapAsync(text, x2, y2, cancellationToken);
				await Task.Delay(6000, cancellationToken);
				await m_4628(text, onStatus, cancellationToken);
				num2++;
				onStatus(text2 + "Đã đăng thành công bài viết!");
				if (i < num - 1)
				{
					int num3 = settings.PickSpacingSeconds();
					onStatus($"Nghỉ {num3}s trước khi đăng bài kế tiếp...");
					await Task.Delay(num3 * 1000, cancellationToken);
				}
			}
			return new AiVisionRunResult
			{
				Success = (num2 > 0),
				Message = $"Đã đăng thành công {num2}/{num} bài viết lên Facebook Katana.",
				TinhTrang = "LIVE"
			};
		}
		catch (OperationCanceledException)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Đã dừng kịch bản theo yêu cầu.",
				TinhTrang = "ERROR"
			};
		}
		catch (Exception ex2)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Lỗi khi đăng bài: " + ex2.Message,
				TinhTrang = "ERROR"
			};
		}
	}

	public static async Task<AiVisionRunResult> BoostPostAsync(FacebookAccountRow account, PostBoostSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		string text = await m_4625(account, cancellationToken);
		if (string.IsNullOrEmpty(text))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Không tìm thấy thiết bị Android nào đang kết nối.",
				TinhTrang = "ERROR"
			};
		}
		List<string> list = (from P_0 in settings.PostLinks
			where !string.IsNullOrWhiteSpace(P_0)
			select P_0.Trim()).ToList();
		if (list.Count == 0)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Danh sách link bài viết cần nuôi đang trống.",
				TinhTrang = "ERROR"
			};
		}
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (!(await m_4626(text, account, onStatus, cancellationToken)))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Không thể chuẩn bị app Facebook Katana hoặc nick chưa đăng nhập.",
					TinhTrang = "ERROR"
				};
			}
			int num = 0;
			for (int num2 = 0; num2 < list.Count; num2++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				string text2 = list[num2];
				string text3 = ((list.Count > 1) ? $"[{num2 + 1}/{list.Count}] " : "");
				onStatus(text3 + "Đang mở link bài viết: " + text2 + "...");
				await AdbController.RunShellAsync(text, "am start -a android.intent.action.VIEW -d \"" + text2 + "\" -p com.facebook.katana", cancellationToken);
				await Task.Delay(4000, cancellationToken);
				await m_4628(text, onStatus, cancellationToken);
				int num3 = Random.Shared.Next(3, 6);
				onStatus($"{text3}Xem bài viết ({num3}s)...");
				await Task.Delay(num3 * 1000, cancellationToken);
				await AdbController.RunShellAsync(text, "input swipe 500 1200 500 900 400", cancellationToken);
				await Task.Delay(1500, cancellationToken);
				List<UiElement> source = await AdbController.DumpUiElementsAsync(text, cancellationToken);
				if (settings.AutoLike)
				{
					UiElement uiElement = source.FirstOrDefault((UiElement P_0) => (P_0.ContentDesc.Equals("Like", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Thích", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Like", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Thích", StringComparison.OrdinalIgnoreCase)) && !P_0.ContentDesc.Contains("Unlike", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Bỏ thích", StringComparison.OrdinalIgnoreCase));
					if (uiElement != null)
					{
						onStatus(text3 + "Bấm Thích bài viết...");
						await AdbController.TapAsync(text, uiElement.CenterX, uiElement.CenterY, cancellationToken);
						await Task.Delay(1500, cancellationToken);
					}
				}
				if (settings.AutoComment)
				{
					string text4 = settings.PickCommentText() ?? "Tuyệt vời!";
					UiElement uiElement2 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Comment", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Bình luận", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Comment", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Bình luận", StringComparison.OrdinalIgnoreCase));
					if (uiElement2 != null)
					{
						onStatus(text3 + "Mở khung bình luận...");
						await AdbController.TapAsync(text, uiElement2.CenterX, uiElement2.CenterY, cancellationToken);
						await Task.Delay(2500, cancellationToken);
						UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText") || P_0.Text.Contains("comment", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("comment", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("bình luận", StringComparison.OrdinalIgnoreCase));
						if (uiElement3 != null)
						{
							await AdbController.TapAsync(text, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
							await Task.Delay(800, cancellationToken);
							onStatus(text3 + "Nhập nội dung bình luận: \"" + text4 + "\"... ");
							await AdbController.InputTextAsync(text, text4, cancellationToken);
							await Task.Delay(1500, cancellationToken);
							UiElement uiElement4 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("Send", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Post", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Gửi", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Send", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Post", StringComparison.OrdinalIgnoreCase));
							if (uiElement4 == null)
							{
								await AdbController.RunShellAsync(text, "input keyevent 66", cancellationToken);
								await Task.Delay(2000, cancellationToken);
							}
							else
							{
								await AdbController.TapAsync(text, uiElement4.CenterX, uiElement4.CenterY, cancellationToken);
								await Task.Delay(3000, cancellationToken);
							}
						}
						await AdbController.RunShellAsync(text, "input keyevent 4", cancellationToken);
						await Task.Delay(1000, cancellationToken);
					}
				}
				if (settings.AutoShare)
				{
					UiElement uiElement5 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Share", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Chia sẻ", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Share", StringComparison.OrdinalIgnoreCase));
					if (uiElement5 != null)
					{
						onStatus(text3 + "Bấm nút Chia sẻ...");
						await AdbController.TapAsync(text, uiElement5.CenterX, uiElement5.CenterY, cancellationToken);
						await Task.Delay(2000, cancellationToken);
						UiElement uiElement6 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Share now", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Share now", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Share to Feed", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Share to Feed", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Chia sẻ ngay", StringComparison.OrdinalIgnoreCase));
						if (uiElement6 == null)
						{
							await AdbController.RunShellAsync(text, "input keyevent 4", cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement6.CenterX, uiElement6.CenterY, cancellationToken);
							await Task.Delay(3000, cancellationToken);
						}
					}
				}
				num++;
				onStatus(text3 + "Đã hoàn thành tương tác bài viết!");
				if (num2 < list.Count - 1)
				{
					int num4 = settings.PickSpacingSeconds();
					onStatus($"Nghỉ {num4}s trước bài tiếp theo...");
					await Task.Delay(num4 * 1000, cancellationToken);
				}
			}
			return new AiVisionRunResult
			{
				Success = (num > 0),
				Message = $"Đã tương tác thành công {num}/{list.Count} bài viết trên Facebook Katana.",
				TinhTrang = "LIVE"
			};
		}
		catch (OperationCanceledException)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Đã dừng kịch bản theo yêu cầu.",
				TinhTrang = "ERROR"
			};
		}
		catch (Exception ex2)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Lỗi nuôi bài viết: " + ex2.Message,
				TinhTrang = "ERROR"
			};
		}
	}

	public static async Task<AiVisionRunResult> SpamGroupAsync(FacebookAccountRow account, GroupSpamSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		string text = await m_4625(account, cancellationToken);
		if (string.IsNullOrEmpty(text))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Không tìm thấy thiết bị Android nào đang kết nối.",
				TinhTrang = "ERROR"
			};
		}
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (!(await m_4626(text, account, onStatus, cancellationToken)))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Không thể chuẩn bị app Facebook Katana hoặc nick chưa đăng nhập.",
					TinhTrang = "ERROR"
				};
			}
			List<string> list = (from P_0 in settings.GroupLinks
				where !string.IsNullOrWhiteSpace(P_0)
				select P_0.Trim()).ToList();
			if (list.Count == 0)
			{
				list.Add("https://m.facebook.com/groups");
			}
			int num = 0;
			for (int num2 = 0; num2 < list.Count; num2++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				string text2 = list[num2];
				string text3 = ((list.Count > 1) ? $"[{num2 + 1}/{list.Count}] " : "");
				string text4 = "nhom";
				if (!string.IsNullOrWhiteSpace(text2) && text2.Contains("facebook.com"))
				{
					string text5 = text2.TrimEnd('/').Split('/').LastOrDefault() ?? "";
					if (!string.IsNullOrWhiteSpace(text5) && !text5.Equals("groups", StringComparison.OrdinalIgnoreCase))
					{
						text4 = text5;
					}
				}
				onStatus(text3 + "Đang tìm kiếm nhóm Facebook: \"" + text4 + "\"...");
				await AdbController.RunShellAsync(text, "am start -a android.intent.action.VIEW -d \"fb://search?query=" + text4 + "\" -p com.facebook.katana", cancellationToken);
				await Task.Delay(2500, cancellationToken);
				await AdbController.RunShellAsync(text, "input keyevent 66", cancellationToken);
				await Task.Delay(3000, cancellationToken);
				await m_4628(text, onStatus, cancellationToken);
				UiElement uiElement = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Groups", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Groups", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Nhóm", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Nhóm", StringComparison.OrdinalIgnoreCase));
				if (uiElement != null)
				{
					onStatus(text3 + "Chuyển sang tab Nhóm (Groups)...");
					await AdbController.TapAsync(text, uiElement.CenterX, uiElement.CenterY, cancellationToken);
					await Task.Delay(2500, cancellationToken);
				}
				UiElement uiElement2 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => (P_0.ContentDesc.Contains("Join", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Join", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Tham gia", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Tham gia", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Public group", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Public group", StringComparison.OrdinalIgnoreCase)) && P_0.CenterY > 320 && P_0.CenterY < 2000);
				if (uiElement2 != null)
				{
					onStatus(text3 + "Mở nhóm từ kết quả tìm kiếm...");
					await AdbController.TapAsync(text, Math.Max(150, uiElement2.CenterX - 150), uiElement2.CenterY, cancellationToken);
					await Task.Delay(4000, cancellationToken);
					await m_4628(text, onStatus, cancellationToken);
				}
				UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("See group", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("See group", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Xem nhóm", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Xem nhóm", StringComparison.OrdinalIgnoreCase));
				if (uiElement3 != null)
				{
					onStatus(text3 + "Bấm xem nhóm...");
					await AdbController.TapAsync(text, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
					await Task.Delay(3000, cancellationToken);
				}
				UiElement uiElement4 = null;
				for (int num3 = 0; num3 < 5; num3++)
				{
					uiElement4 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => (P_0.ContentDesc.Equals("Comment", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Bình luận", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Comment", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Bình luận", StringComparison.OrdinalIgnoreCase)) && P_0.CenterY > 250 && P_0.CenterY < 2100);
					if (uiElement4 != null)
					{
						break;
					}
					onStatus($"{text3}Cuộn tìm bài viết trong nhóm ({num3 + 1}/5)...");
					await AdbController.RunShellAsync(text, "input swipe 500 1500 500 700 400", cancellationToken);
					await Task.Delay(2000, cancellationToken);
				}
				if (uiElement4 != null)
				{
					string text6 = settings.PickCommentText() ?? "Bài viết rất hữu ích \ud83d\udc4d";
					onStatus(text3 + "Mở bình luận bài viết trong nhóm...");
					await AdbController.TapAsync(text, uiElement4.CenterX, uiElement4.CenterY, cancellationToken);
					await Task.Delay(2500, cancellationToken);
					UiElement uiElement5 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ClassName.Contains("EditText") || P_0.Text.Contains("comment", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("comment", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("bình luận", StringComparison.OrdinalIgnoreCase));
					if (uiElement5 != null)
					{
						await AdbController.TapAsync(text, uiElement5.CenterX, uiElement5.CenterY, cancellationToken);
						await Task.Delay(800, cancellationToken);
						onStatus(text3 + "Nhập nội dung spam nhóm: \"" + text6 + "\"... ");
						await AdbController.InputTextAsync(text, text6, cancellationToken);
						await Task.Delay(1500, cancellationToken);
						UiElement uiElement6 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("Send", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Post", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Send", StringComparison.OrdinalIgnoreCase) || P_0.Text.Equals("Post", StringComparison.OrdinalIgnoreCase));
						if (uiElement6 == null)
						{
							await AdbController.RunShellAsync(text, "input keyevent 66", cancellationToken);
							await Task.Delay(2000, cancellationToken);
						}
						else
						{
							await AdbController.TapAsync(text, uiElement6.CenterX, uiElement6.CenterY, cancellationToken);
							await Task.Delay(3000, cancellationToken);
						}
					}
					await AdbController.RunShellAsync(text, "input keyevent 4", cancellationToken);
					num++;
					onStatus(text3 + "Đã bình luận vào nhóm thành công!");
				}
				else
				{
					onStatus(text3 + "Không tìm thấy bài viết để tương tác trong nhóm.");
				}
				if (num2 < list.Count - 1)
				{
					int num4 = Math.Max(5, settings.MinCommentSpacingSeconds);
					int num5 = Math.Max(num4, settings.MaxCommentSpacingSeconds);
					int num6 = Random.Shared.Next(num4, num5 + 1);
					onStatus($"Nghỉ {num6}s trước khi sang nhóm kế tiếp...");
					await Task.Delay(num6 * 1000, cancellationToken);
				}
			}
			return new AiVisionRunResult
			{
				Success = (num > 0),
				Message = $"Đã spam tương tác thành công {num}/{list.Count} nhóm trên Facebook Katana.",
				TinhTrang = "LIVE"
			};
		}
		catch (OperationCanceledException)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Đã dừng kịch bản theo yêu cầu.",
				TinhTrang = "ERROR"
			};
		}
		catch (Exception ex2)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Lỗi spam nhóm: " + ex2.Message,
				TinhTrang = "ERROR"
			};
		}
	}

	public static async Task<AiVisionRunResult> SendFriendRequestsAsync(FacebookAccountRow account, FriendRequestSettings settings, Action<string> onStatus, CancellationToken cancellationToken)
	{
		string text = await m_4625(account, cancellationToken);
		if (string.IsNullOrEmpty(text))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Không tìm thấy thiết bị Android nào đang kết nối.",
				TinhTrang = "ERROR"
			};
		}
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (!(await m_4626(text, account, onStatus, cancellationToken)))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Không thể chuẩn bị app Facebook Katana hoặc nick chưa đăng nhập.",
					TinhTrang = "ERROR"
				};
			}
			int num = ((settings.Action == FriendRequestAction.ConfirmIncoming) ? Math.Max(1, settings.MaxConfirmsPerRun) : Math.Max(1, settings.MaxRequestsPerRun));
			int num2 = 0;
			if (settings.Action == FriendRequestAction.ConfirmIncoming)
			{
				onStatus("Đang mở trang danh sách lời mời kết bạn gửi đến...");
				await AdbController.RunShellAsync(text, "am start -a android.intent.action.VIEW -d 'fb://facewebmodal/f?href=https://m.facebook.com/friends' -p com.facebook.katana", cancellationToken);
				await Task.Delay(3500, cancellationToken);
				await m_4628(text, onStatus, cancellationToken);
				for (int i = 0; i < num; i++)
				{
					cancellationToken.ThrowIfCancellationRequested();
					List<UiElement> list = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).Where((UiElement P_0) => P_0.Text.Replace('\u00a0', ' ').Trim().Equals("Confirm", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Replace('\u00a0', ' ').Trim().Equals("Confirm", StringComparison.OrdinalIgnoreCase) || P_0.Text.Replace('\u00a0', ' ').Trim().Equals("Xác nhận", StringComparison.OrdinalIgnoreCase)).ToList();
					if (list.Count == 0)
					{
						onStatus("Không còn lời mời kết bạn nào chờ xác nhận.");
						break;
					}
					UiElement uiElement = list[0];
					onStatus($"Bấm xác nhận lời mời kết bạn ({num2 + 1}/{num})...");
					await AdbController.TapAsync(text, uiElement.CenterX, uiElement.CenterY, cancellationToken);
					num2++;
					await Task.Delay(Random.Shared.Next(1500, 3000), cancellationToken);
				}
				return new AiVisionRunResult
				{
					Success = (num2 > 0),
					Message = $"Đã xác nhận {num2} lời mời kết bạn trên Facebook Katana.",
					TinhTrang = "LIVE"
				};
			}
			List<string> source = new List<string>();
			if (settings.Source == FriendRequestSource.NickFolder)
			{
				source = FacebookFriendRequestActions.LoadTargetsFromList(account, settings);
			}
			else if (settings.Source == FriendRequestSource.UidList)
			{
				source = (from P_0 in settings.Uids
					where !string.IsNullOrWhiteSpace(P_0)
					select P_0.Trim()).Distinct().ToList();
			}
			HashSet<string> A = FacebookFriendRequestActions.LoadSentUids(account);
			source = source.Where((string P_0) => !A.Contains(P_0)).ToList();
			if (source.Count > 0)
			{
				int i = Math.Min(num, source.Count);
				for (int num3 = 0; num3 < i; num3++)
				{
					cancellationToken.ThrowIfCancellationRequested();
					string text2 = source[num3];
					string text3 = ((i > 1) ? $"[{num3 + 1}/{i}] " : "");
					onStatus(text3 + "Đang mở trang cá nhân UID: " + text2 + "...");
					await AdbController.RunShellAsync(text, "am start -a android.intent.action.VIEW -d \"fb://profile/" + text2 + "\" -p com.facebook.katana", cancellationToken);
					await Task.Delay(3500, cancellationToken);
					await m_4628(text, onStatus, cancellationToken);
					List<UiElement> source2 = await AdbController.DumpUiElementsAsync(text, cancellationToken);
					UiElement uiElement2 = source2.FirstOrDefault(m_4629);
					if (uiElement2 != null)
					{
						onStatus(text3 + "Bấm gửi lời mời kết bạn...");
						await AdbController.TapAsync(text, uiElement2.CenterX, uiElement2.CenterY, cancellationToken);
						num2++;
						A.Add(text2);
						FacebookFriendRequestActions.SaveSentUids(account, A);
						await Task.Delay(2000, cancellationToken);
					}
					else
					{
						bool flag = source2.Any(a);
						onStatus(flag ? (text3 + "Đã là bạn bè hoặc đã gửi lời mời từ trước.") : (text3 + "Không tìm thấy nút Thêm bạn bè."));
					}
					if (num3 < i - 1)
					{
						int num4 = settings.PickDelaySeconds();
						onStatus($"Nghỉ {num4}s trước khi gửi người tiếp theo...");
						await Task.Delay(num4 * 1000, cancellationToken);
					}
				}
				return new AiVisionRunResult
				{
					Success = (num2 > 0),
					Message = $"Đã gửi thành công {num2}/{i} lời mời kết bạn theo UID trên Facebook Katana.",
					TinhTrang = "LIVE"
				};
			}
			onStatus("Đang mở trang tìm kiếm kết bạn...");
			await AdbController.RunShellAsync(text, "am start -a android.intent.action.VIEW -d 'fb://search?query=Nguyen' -p com.facebook.katana", cancellationToken);
			await Task.Delay(2500, cancellationToken);
			await AdbController.RunShellAsync(text, "input keyevent 66", cancellationToken);
			await Task.Delay(3000, cancellationToken);
			await m_4628(text, onStatus, cancellationToken);
			UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("People", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("People", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Contains("Mọi người", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Mọi người", StringComparison.OrdinalIgnoreCase));
			if (uiElement3 != null)
			{
				onStatus("Chuyển sang tab Mọi người (People)...");
				await AdbController.TapAsync(text, uiElement3.CenterX, uiElement3.CenterY, cancellationToken);
				await Task.Delay(2500, cancellationToken);
			}
			int num5 = 0;
			while (num2 < num && num5 < 15)
			{
				cancellationToken.ThrowIfCancellationRequested();
				List<UiElement> list2 = (await AdbController.DumpUiElementsAsync(text, cancellationToken)).Where((UiElement P_0) => m_4629(P_0) && P_0.CenterY > 250 && P_0.CenterY < 2050).ToList();
				if (list2.Count == 0)
				{
					onStatus("Cuộn tìm thêm người để kết bạn...");
					await AdbController.RunShellAsync(text, "input swipe 500 1500 500 600 400", cancellationToken);
					await Task.Delay(2000, cancellationToken);
					num5++;
					continue;
				}
				foreach (UiElement item in list2)
				{
					if (num2 < num)
					{
						onStatus($"Bấm kết bạn ({num2 + 1}/{num})...");
						await AdbController.TapAsync(text, item.CenterX, item.CenterY, cancellationToken);
						num2++;
						await Task.Delay(settings.PickDelaySeconds() * 1000, cancellationToken);
						continue;
					}
					break;
				}
				await AdbController.RunShellAsync(text, "input swipe 500 1500 500 600 400", cancellationToken);
				await Task.Delay(2000, cancellationToken);
				num5++;
			}
			return new AiVisionRunResult
			{
				Success = (num2 > 0),
				Message = $"Đã gửi thành công {num2}/{num} lời mời kết bạn trên Facebook Katana.",
				TinhTrang = "LIVE"
			};
		}
		catch (OperationCanceledException)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Đã dừng kịch bản theo yêu cầu.",
				TinhTrang = "ERROR"
			};
		}
		catch (Exception ex2)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Lỗi kết bạn: " + ex2.Message,
				TinhTrang = "ERROR"
			};
		}
	}

	private static async Task<string> m_4625(FacebookAccountRow P_0, CancellationToken P_1)
	{
		string text = P_0.PhoneName ?? "";
		if (string.IsNullOrWhiteSpace(text))
		{
			text = (await AdbController.ListDevicesAsync(P_1)).FirstOrDefault() ?? "";
			if (!string.IsNullOrEmpty(text))
			{
				P_0.PhoneName = text;
			}
		}
		return text;
	}

	private static async Task<bool> m_4626(string P_0, FacebookAccountRow P_1, Action<string> P_2, CancellationToken P_3)
	{
		P_2("Kiểm tra kết nối thiết bị...");
		if (!(await AdbController.RunShellCaptureAsync(P_0, "echo online", P_3)).Trim().Contains("online"))
		{
			return false;
		}
		await AdbController.EnsureEnglishLanguageAsync(P_0, P_3);
		P_2("Đảm bảo Facebook Katana đang hoạt động...");
		await AdbController.RunShellAsync(P_0, "am start -a android.intent.action.VIEW -d 'fb://feed' -p com.facebook.katana", P_3);
		await Task.Delay(2500, P_3);
		await m_4628(P_0, P_2, P_3);
		string text = await AdbController.RunShellCaptureAsync(P_0, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", P_3);
		if (!m_4627(await AdbController.DumpUiElementsAsync(P_0, P_3), text))
		{
			P_2("Tài khoản chưa đăng nhập trên Facebook Katana -> Tự động đăng nhập...");
			if (!(await FacebookKatanaPhoneLoginService.LoginAccountAsync(P_1, P_2, P_3)).Success)
			{
				return false;
			}
			await Task.Delay(3000, P_3);
			await m_4628(P_0, P_2, P_3);
		}
		return true;
	}

	private static bool m_4627(List<UiElement> P_0, string P_1)
	{
		if (P_0 == null || P_0.Count == 0)
		{
			return false;
		}
		if (P_0.Any((UiElement uiElement) => P_1.Contains("LoggedOut", StringComparison.OrdinalIgnoreCase) || P_1.Contains("LoginActivity", StringComparison.OrdinalIgnoreCase) || uiElement.ResourceId.Contains("login_password") || uiElement.ResourceId.Contains("m_login_password") || uiElement.ContentDesc.Equals("Mobile number or email", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Equals("Mobile number or email", StringComparison.OrdinalIgnoreCase) || (uiElement.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) && uiElement.CenterY > 1000) || (uiElement.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) && uiElement.CenterY > 1000) || uiElement.ContentDesc.Contains("Forgot Password", StringComparison.OrdinalIgnoreCase)))
		{
			return false;
		}
		if (P_1.Contains("com.facebook.katana"))
		{
			return true;
		}
		return P_0.Any((UiElement uiElement) => uiElement.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Create, Double tap", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Facebook logo", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Menu", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Home, tab", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Groups", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Friends", StringComparison.OrdinalIgnoreCase) || uiElement.ResourceId.Contains("feed_tab"));
	}

	private static async Task m_4628(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		_ = 2;
		try
		{
			UiElement uiElement = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement2) => uiElement2.Text.Equals("Not now", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Equals("Not now", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Equals("Skip", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Equals("Skip", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Equals("Close", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Equals("Close", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Equals("Cancel", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Equals("Cancel", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Equals("Don't allow", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Equals("Don't allow", StringComparison.OrdinalIgnoreCase));
			if (uiElement != null)
			{
				await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
				await Task.Delay(1200, P_2);
			}
		}
		catch
		{
		}
	}

	private static bool m_4629(UiElement P_0)
	{
		if (P_0 == null)
		{
			return false;
		}
		string text = (P_0.Text ?? string.Empty).Replace('\u00a0', ' ').Trim();
		string text2 = (P_0.ContentDesc ?? string.Empty).Replace('\u00a0', ' ').Trim();
		if (!text.Equals("Add friend", StringComparison.OrdinalIgnoreCase) && !text2.Equals("Add friend", StringComparison.OrdinalIgnoreCase) && !text.Equals("Thêm bạn bè", StringComparison.OrdinalIgnoreCase) && !text2.Equals("Thêm bạn bè", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Add friend", StringComparison.OrdinalIgnoreCase) && !text2.StartsWith("Add friend", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Thêm bạn bè", StringComparison.OrdinalIgnoreCase))
		{
			return text2.StartsWith("Thêm bạn bè", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static bool a(UiElement P_0)
	{
		if (P_0 == null)
		{
			return false;
		}
		string text = (P_0.Text ?? string.Empty).Replace('\u00a0', ' ').Trim();
		string text2 = (P_0.ContentDesc ?? string.Empty).Replace('\u00a0', ' ').Trim();
		if (!text.StartsWith("Cancel request", StringComparison.OrdinalIgnoreCase) && !text2.StartsWith("Cancel request", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("Hủy lời mời", StringComparison.OrdinalIgnoreCase) && !text2.StartsWith("Hủy lời mời", StringComparison.OrdinalIgnoreCase) && !text.Equals("Friends", StringComparison.OrdinalIgnoreCase) && !text2.Equals("Friends", StringComparison.OrdinalIgnoreCase) && !text.Equals("Bạn bè", StringComparison.OrdinalIgnoreCase))
		{
			return text2.Equals("Bạn bè", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}
}
