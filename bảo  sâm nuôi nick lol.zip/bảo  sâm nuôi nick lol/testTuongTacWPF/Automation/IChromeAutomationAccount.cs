namespace testTuongTacWPF.Automation;

public interface IChromeAutomationAccount
{
	string ProfileChrome { get; set; }

	string BrowserProfileId { get; set; }

	string Proxy { get; }

	string UserAgent { get; }

	string Cookie { get; set; }
}
