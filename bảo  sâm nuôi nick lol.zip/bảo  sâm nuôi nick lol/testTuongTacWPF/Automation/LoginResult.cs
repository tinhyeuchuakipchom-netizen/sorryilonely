using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class LoginResult
{
	[CompilerGenerated]
	private readonly bool A;

	[CompilerGenerated]
	private readonly string m_5604 = "ERROR";

	[CompilerGenerated]
	private readonly string a = "";

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		init
		{
			A = value;
		}
	}

	public string TinhTrang
	{
		[CompilerGenerated]
		get
		{
			return m_5604;
		}
		[CompilerGenerated]
		init
		{
			m_5604 = value;
		}
	}

	public string TrangThai
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		init
		{
			a = value;
		}
	}
}
