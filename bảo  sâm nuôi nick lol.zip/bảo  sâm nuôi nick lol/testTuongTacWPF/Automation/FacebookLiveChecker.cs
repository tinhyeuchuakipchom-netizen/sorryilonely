using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public static class FacebookLiveChecker
{
	public const string Live = "LIVE";

	public const string Die = "DIE";

	public const string Unknown = "";

	private static readonly HttpClient A = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(15L)
	};

	public static async Task<string> CheckAsync(string uid, CancellationToken cancellationToken = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(uid))
		{
			return "";
		}
		for (int i = 1; i <= 3; i++)
		{
			string text = await m_4865(uid.Trim(), cancellationToken);
			if (text != "")
			{
				return text;
			}
			if (i < 3)
			{
				try
				{
					await Task.Delay(1200 * i, cancellationToken);
				}
				catch (OperationCanceledException)
				{
					return "";
				}
			}
		}
		return "";
	}

	private static async Task<string> m_4865(string P_0, CancellationToken P_1)
	{
		_ = 1;
		try
		{
			using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, "https://graph.facebook.com/" + P_0 + "/picture?redirect=false");
			httpRequestMessage.Headers.Add("user-agent", "Mozilla/5.0");
			using HttpResponseMessage httpResponseMessage = await A.SendAsync(httpRequestMessage, P_1);
			string text = await httpResponseMessage.Content.ReadAsStringAsync(P_1);
			if (httpResponseMessage.IsSuccessStatusCode)
			{
				if (text.Contains("\"width\""))
				{
					return "LIVE";
				}
				if (text.Contains("rsrc.php"))
				{
					return "DIE";
				}
				return "";
			}
			if (httpResponseMessage.StatusCode == HttpStatusCode.BadRequest)
			{
				return "DIE";
			}
			return "";
		}
		catch (OperationCanceledException)
		{
			return "";
		}
		catch
		{
			return "";
		}
	}
}
