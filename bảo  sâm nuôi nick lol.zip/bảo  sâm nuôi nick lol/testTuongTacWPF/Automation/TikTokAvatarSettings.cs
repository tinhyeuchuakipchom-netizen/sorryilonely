using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class TikTokAvatarSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6307
	{
		public static readonly m_6307 A = new m_6307();

		public static Func<string, string> m_6309;

		internal string m_6310(string P_0)
		{
			return P_0;
		}
	}

	[CompilerGenerated]
	private sealed class m_6308
	{
		public string[] A;

		internal bool m_6311(string P_0)
		{
			return A.Contains(Path.GetExtension(P_0).ToLowerInvariant());
		}
	}

	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private bool m_6306 = true;

	[CompilerGenerated]
	private bool a;

	public string AvatarFolder
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool RandomOrder
	{
		[CompilerGenerated]
		get
		{
			return m_6306;
		}
		[CompilerGenerated]
		set
		{
			m_6306 = value;
		}
	}

	public bool DeleteAfterUse
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string? PickAvatarPath()
	{
		if (string.IsNullOrWhiteSpace(AvatarFolder) || !Directory.Exists(AvatarFolder))
		{
			return null;
		}
		string[] A = new string[3] { ".jpg", ".jpeg", ".png" };
		List<string> list = (from P_0 in Directory.EnumerateFiles(AvatarFolder)
			where A.Contains(Path.GetExtension(P_0).ToLowerInvariant())
			orderby P_0
			select P_0).ToList();
		if (list.Count == 0)
		{
			return null;
		}
		if (!RandomOrder)
		{
			return list[0];
		}
		return list[Random.Shared.Next(list.Count)];
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static TikTokAvatarSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new TikTokAvatarSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<TikTokAvatarSettings>(json) ?? new TikTokAvatarSettings();
		}
		catch
		{
			return new TikTokAvatarSettings();
		}
	}
}
