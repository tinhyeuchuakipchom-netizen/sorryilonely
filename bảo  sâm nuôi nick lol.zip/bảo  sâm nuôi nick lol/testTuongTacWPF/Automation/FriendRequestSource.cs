namespace testTuongTacWPF.Automation;

public enum FriendRequestSource
{
	NickFolder,
	UidList,
	GroupPosters
}
