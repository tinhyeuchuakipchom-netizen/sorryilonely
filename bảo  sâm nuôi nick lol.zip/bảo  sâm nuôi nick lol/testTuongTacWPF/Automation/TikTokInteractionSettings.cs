using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class TikTokInteractionSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6543
	{
		public static readonly m_6543 A = new m_6543();

		public static Func<string, bool> m_6545;

		public static Func<string, bool> a;

		internal bool m_6546(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal bool m_6547(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_6544
	{
		public string[] A;

		internal bool m_6548(string P_0)
		{
			return A.Contains(Path.GetExtension(P_0).ToLowerInvariant());
		}
	}

	[CompilerGenerated]
	private int A = 3;

	[CompilerGenerated]
	private int a = 8;

	[CompilerGenerated]
	private bool m_6534 = true;

	[CompilerGenerated]
	private int B = 30;

	[CompilerGenerated]
	private bool m_6535;

	[CompilerGenerated]
	private int b = 10;

	[CompilerGenerated]
	private List<string> m_6536 = new List<string> { "Hay quá \ud83d\ude0d", "Đỉnh thật sự", "Xem hoài không chán", "Video chất lượng \ud83d\udd25", "\ud83d\udd25\ud83d\udd25\ud83d\udd25" };

	[CompilerGenerated]
	private bool m_6537;

	[CompilerGenerated]
	private List<string> m_6538 = new List<string> { "❤\ufe0f", "\ud83d\ude0d", "\ud83d\udd25", "\ud83d\udc4f", "\ud83d\ude02", "\ud83d\udcaf", "\ud83e\udd70", "\ud83d\udc4d" };

	[CompilerGenerated]
	private bool m_6539;

	[CompilerGenerated]
	private string m_6540 = "";

	[CompilerGenerated]
	private bool C;

	[CompilerGenerated]
	private int m_6541 = 15;

	[CompilerGenerated]
	private bool c;

	[CompilerGenerated]
	private int m_6542 = 20;

	public int MinMinutes
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxMinutes
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool AutoLike
	{
		[CompilerGenerated]
		get
		{
			return m_6534;
		}
		[CompilerGenerated]
		set
		{
			m_6534 = value;
		}
	}

	public int LikeChancePercent
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public bool AutoComment
	{
		[CompilerGenerated]
		get
		{
			return m_6535;
		}
		[CompilerGenerated]
		set
		{
			m_6535 = value;
		}
	}

	public int CommentChancePercent
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public List<string> CommentTexts
	{
		[CompilerGenerated]
		get
		{
			return m_6536;
		}
		[CompilerGenerated]
		set
		{
			m_6536 = value;
		}
	}

	public bool AppendEmoji
	{
		[CompilerGenerated]
		get
		{
			return m_6537;
		}
		[CompilerGenerated]
		set
		{
			m_6537 = value;
		}
	}

	public List<string> CommentEmojis
	{
		[CompilerGenerated]
		get
		{
			return m_6538;
		}
		[CompilerGenerated]
		set
		{
			m_6538 = value;
		}
	}

	public bool CommentWithImage
	{
		[CompilerGenerated]
		get
		{
			return m_6539;
		}
		[CompilerGenerated]
		set
		{
			m_6539 = value;
		}
	}

	public string CommentImageFolder
	{
		[CompilerGenerated]
		get
		{
			return m_6540;
		}
		[CompilerGenerated]
		set
		{
			m_6540 = value;
		}
	}

	public bool AutoFollow
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int FollowChancePercent
	{
		[CompilerGenerated]
		get
		{
			return m_6541;
		}
		[CompilerGenerated]
		set
		{
			m_6541 = value;
		}
	}

	public bool AutoFavorite
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public int FavoriteChancePercent
	{
		[CompilerGenerated]
		get
		{
			return m_6542;
		}
		[CompilerGenerated]
		set
		{
			m_6542 = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static TikTokInteractionSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new TikTokInteractionSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<TikTokInteractionSettings>(json) ?? new TikTokInteractionSettings();
		}
		catch (JsonException)
		{
			return new TikTokInteractionSettings();
		}
	}

	public int PickDurationMinutes()
	{
		if (MinMinutes < MaxMinutes)
		{
			return Random.Shared.Next(MinMinutes, MaxMinutes + 1);
		}
		return MinMinutes;
	}

	public bool RollChance(int percent)
	{
		return Random.Shared.Next(0, 100) < percent;
	}

	public string? PickCommentText()
	{
		List<string> list = CommentTexts.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}

	public string? PickEmoji()
	{
		List<string> list = CommentEmojis.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}

	public string? BuildCommentText()
	{
		string text = PickCommentText();
		if (text == null)
		{
			return null;
		}
		if (AppendEmoji)
		{
			string text2 = PickEmoji();
			if (text2 != null)
			{
				text = text + " " + text2;
			}
		}
		return text;
	}

	public string? PickImagePath()
	{
		if (!CommentWithImage || string.IsNullOrWhiteSpace(CommentImageFolder) || !Directory.Exists(CommentImageFolder))
		{
			return null;
		}
		string[] A = new string[3] { ".jpg", ".jpeg", ".png" };
		List<string> list = (from P_0 in Directory.EnumerateFiles(CommentImageFolder)
			where A.Contains(Path.GetExtension(P_0).ToLowerInvariant())
			select P_0).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}
}
