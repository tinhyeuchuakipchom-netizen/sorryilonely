namespace testTuongTacWPF.Automation;

public static class LoginTypes
{
	public const string Cookie = "Cookie";

	public const string CookieThenUidPass = "CookieThenUidPass";

	public const string UidPass = "UidPass";

	public const string MailPass = "MailPass";
}
