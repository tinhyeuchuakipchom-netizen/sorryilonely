using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class DeviceControllerFactory
{
	[CompilerGenerated]
	private sealed class A
	{
		public string m_3939;

		internal bool m_3940(ProfileRow P_0)
		{
			return P_0.Name == m_3939;
		}
	}

	public static IDeviceController Resolve(IEnumerable<ProfileRow> profiles, string deviceIdentifier)
	{
		if (!(profiles.FirstOrDefault((ProfileRow P_0) => P_0.Name == deviceIdentifier)?.OS == "iOS"))
		{
			return new AdbDeviceController(deviceIdentifier);
		}
		return new IPhoneDeviceController();
	}
}
