using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookPagePostRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5034
	{
		public static readonly m_5034 A = new m_5034();

		public static Func<string, bool> m_5037;

		public static Func<string, string> m_5038;

		public static Func<string, bool> a;

		internal bool m_5039(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal string m_5040(string P_0)
		{
			return P_0.Trim();
		}

		internal bool B(string P_0)
		{
			if (!P_0.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase) && !P_0.EndsWith(".mov", StringComparison.OrdinalIgnoreCase) && !P_0.EndsWith(".avi", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.EndsWith(".mkv", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_5035
	{
		public Action<AiVisionStepLog> A;

		public int m_5041;

		internal void m_5042(string P_0)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_5041++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = "Đăng bài trên Page"
			});
		}

		internal void m_5043(string P_0, string P_1)
		{
			m_5042(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class m_5036
	{
		public ILocator[] A;

		internal async Task<ILocator?> m_5044(int P_0)
		{
			ILocator[] array = A;
			foreach (ILocator locator in array)
			{
				try
				{
					if (await locator.First.IsVisibleAsync())
					{
						return locator.First;
					}
				}
				catch
				{
				}
			}
			return null;
		}
	}

	private const string A = "https://www.facebook.com/?locale=en_US";

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, PagePostSettings settings, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken)
	{
		m_5035 CS_0024_003C_003E8__locals18 = new m_5035();
		CS_0024_003C_003E8__locals18.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings2 = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		CS_0024_003C_003E8__locals18.m_5041 = 0;
		AiVisionRunResult result;
		try
		{
			_ = 12;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await global::A.F.A(client, settings2, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await global::A.F.A(client, settings2, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals18.m_5042("Đang đăng nhập...");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings2, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals18.m_5042(P_0);
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để đăng bài trên Page: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					PostCreationSettings postCreationSettings = settings.Post ?? new PostCreationSettings();
					List<string> list = await m_5030(page2, settings, (string P_0) =>
					{
						CS_0024_003C_003E8__locals18.A(new AiVisionStepLog
						{
							FlowStepIndex = CS_0024_003C_003E8__locals18.m_5041++,
							SubStep = 1,
							ActionSummary = P_0,
							Reason = "Đăng bài trên Page"
						});
					}, cancellationToken);
					if (list.Count == 0)
					{
						CS_0024_003C_003E8__locals18.m_5042("Không tìm thấy Page nào để đăng bài.");
						result = new AiVisionRunResult
						{
							Success = false,
							Message = "Không tìm thấy Page nào trên tài khoản để đăng bài.",
							TinhTrang = "ERROR"
						};
					}
					else
					{
						CS_0024_003C_003E8__locals18.m_5042($"Bắt đầu đăng bài cho {list.Count} Page...");
						int num2 = 0;
						for (int num3 = 0; num3 < list.Count; num3++)
						{
							cancellationToken.ThrowIfCancellationRequested();
							string text = list[num3];
							CS_0024_003C_003E8__locals18.m_5042($"[{num3 + 1}/{list.Count}] Chuyển sang Page \"{text}\"...");
							if (!(await SwitchToPageAsync(page2, text, (string P_0) =>
							{
								CS_0024_003C_003E8__locals18.A(new AiVisionStepLog
								{
									FlowStepIndex = CS_0024_003C_003E8__locals18.m_5041++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = "Đăng bài trên Page"
								});
							}, cancellationToken)))
							{
								CS_0024_003C_003E8__locals18.m_5042("[Bỏ qua] Không chuyển được sang Page \"" + text + "\".");
								continue;
							}
							await Task.Delay(2500, cancellationToken);
							int num4 = Math.Max(1, settings.PostsPerPage);
							for (int num5 = 0; num5 < num4; num5++)
							{
								cancellationToken.ThrowIfCancellationRequested();
								string text2 = postCreationSettings.PickContent();
								List<string> list2 = postCreationSettings.PickMediaFiles();
								if (string.IsNullOrWhiteSpace(text2) && list2.Count == 0)
								{
									CS_0024_003C_003E8__locals18.m_5042("[Bỏ qua] Chưa cấu hình nội dung/media cho Page \"" + text + "\".");
									break;
								}
								CS_0024_003C_003E8__locals18.m_5042($"[{text}] Đăng bài [{num5 + 1}/{num4}]...");
								await PostSingleToPageAsync(page2, text, text2, list2, (string P_0) =>
								{
									CS_0024_003C_003E8__locals18.A(new AiVisionStepLog
									{
										FlowStepIndex = CS_0024_003C_003E8__locals18.m_5041++,
										SubStep = 1,
										ActionSummary = P_0,
										Reason = "Đăng bài trên Page"
									});
								}, cancellationToken);
								num2++;
								if (num5 < num4 - 1)
								{
									int num6 = postCreationSettings.PickSpacingSeconds();
									CS_0024_003C_003E8__locals18.m_5042($"Chờ {num6}s trước bài tiếp theo trên Page \"{text}\"...");
									await Task.Delay(num6 * 1000, cancellationToken);
								}
							}
							if (num3 < list.Count - 1 && settings.PageSwitchDelaySeconds > 0)
							{
								CS_0024_003C_003E8__locals18.m_5042($"Chờ {settings.PageSwitchDelaySeconds}s trước khi chuyển Page tiếp theo...");
								await Task.Delay(settings.PageSwitchDelaySeconds * 1000, cancellationToken);
							}
						}
						if (settings2.SaveNewCookieAfterLogin)
						{
							await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
						}
						result = new AiVisionRunResult
						{
							Success = (num2 > 0),
							Message = ((num2 > 0) ? $"Đã đăng thành công {num2} bài viết lên {list.Count} Page." : "Không đăng được bài nào trên Page."),
							TinhTrang = ((num2 > 0) ? "LIVE" : "ERROR")
						};
					}
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex2),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	private static async Task<List<string>> m_5030(IPage P_0, PagePostSettings P_1, Action<string> P_2, CancellationToken P_3)
	{
		List<string> list = P_1.TargetPageNames?.Where((string value) => !string.IsNullOrWhiteSpace(value)).Select((string text) => text.Trim()).Distinct(StringComparer.OrdinalIgnoreCase)
			.ToList() ?? new List<string>();
		if (list.Count > 0)
		{
			if (P_1.MaxPages > 0 && list.Count > P_1.MaxPages)
			{
				list = list.Take(P_1.MaxPages).ToList();
			}
			P_2($"Dùng danh sách {list.Count} Page từ cài đặt: {string.Join(", ", list)}");
			return list;
		}
		P_2("Quét danh sách các Page từ tài khoản...");
		List<string> list2 = await ScanPagesFromProfileMenuAsync(P_0, P_3);
		if (P_1.MaxPages > 0 && list2.Count > P_1.MaxPages)
		{
			list2 = list2.Take(P_1.MaxPages).ToList();
		}
		return list2;
	}

	public static async Task<List<string>> ScanPagesFromProfileMenuAsync(IPage page, CancellationToken cancellationToken)
	{
		List<string> list = new List<string>();
		try
		{
			if (!page.Url.Contains("facebook.com"))
			{
				await page.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
				{
					Timeout = 30000f,
					WaitUntil = WaitUntilState.DOMContentLoaded
				});
				await Task.Delay(2500, cancellationToken);
			}
			ILocator last = page.Locator("div[aria-label='Your profile'], div[aria-label='Trang cá nhân của bạn'], svg[aria-label='Your profile'], svg[aria-label='Trang cá nhân của bạn'], [role='banner'] div[role='button']").Last;
			if (await last.CountAsync() > 0)
			{
				await last.ClickAsync();
				await Task.Delay(2000, cancellationToken);
				ILocator locator = page.Locator("div[role='dialog'] [aria-label*='Switch to'], div[role='dialog'] [aria-label*='Chuyển sang']");
				int num = await locator.CountAsync();
				for (int i = 0; i < num; i++)
				{
					string text = ((await locator.Nth(i).GetAttributeAsync("aria-label")) ?? "").Replace("Switch to", "").Replace("Chuyển sang", "").Trim();
					if (!string.IsNullOrWhiteSpace(text) && !list.Contains(text, StringComparer.OrdinalIgnoreCase))
					{
						list.Add(text);
					}
				}
				ILocator first = page.Locator("div[role='dialog'] [aria-label='See all profiles'], div[role='dialog'] [aria-label='Xem tất cả trang cá nhân'], div[role='dialog'] div[role='button']:has-text('See all profiles'), div[role='dialog'] div[role='button']:has-text('Xem tất cả trang cá nhân'), div[role='dialog'] div[role='button']:has-text('See all'), div[role='dialog'] div[role='button']:has-text('Xem tất cả')").First;
				bool flag = await first.CountAsync() > 0;
				if (flag)
				{
					flag = await first.IsVisibleAsync();
				}
				if (flag)
				{
					await first.ClickAsync();
					await Task.Delay(2000, cancellationToken);
					ILocator locator2 = page.Locator("div[role='dialog'] div[role='button']:has(span), div[role='dialog'] div[role='listitem']:has(span)");
					int i = await locator2.CountAsync();
					for (int j = 0; j < i; j++)
					{
						string text2 = await locator2.Nth(j).InnerTextAsync();
						if (!string.IsNullOrWhiteSpace(text2))
						{
							string text3 = text2.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)[0].Trim();
							if (!string.IsNullOrWhiteSpace(text3) && !text3.Contains("See all", StringComparison.OrdinalIgnoreCase) && !text3.Contains("Xem tất cả", StringComparison.OrdinalIgnoreCase) && !text3.Contains("Switch profile", StringComparison.OrdinalIgnoreCase) && !text3.Contains("Chuyển trang", StringComparison.OrdinalIgnoreCase) && text3.Length < 60 && !list.Contains(text3, StringComparer.OrdinalIgnoreCase))
							{
								list.Add(text3);
							}
						}
					}
				}
				try
				{
					await page.Keyboard.PressAsync("Escape");
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public static async Task<bool> IsAlreadyActingAsPageAsync(IPage page, string pageName)
	{
		_ = 3;
		try
		{
			if (await page.Locator($"text=\"What's on your mind, {pageName}?\", text=\"{pageName} ơi, bạn đang nghĩ gì?\"").CountAsync() > 0)
			{
				return true;
			}
			if (await page.Locator($"div:has-text('acting as {pageName}'), div:has-text('Đang hoạt động dưới tên {pageName}'), div:has-text('Đã chuyển sang {pageName}')").CountAsync() > 0)
			{
				return true;
			}
			ILocator locator = page.Locator("[role='banner']");
			if (await locator.CountAsync() > 0 && ((await locator.Locator("div[role='button']").Last.GetAttributeAsync("aria-label")) ?? "").Contains(pageName, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	public static async Task<bool> SwitchToPageAsync(IPage page, string pageName, Action<string> log, CancellationToken cancellationToken)
	{
		_ = 20;
		try
		{
			if (await IsAlreadyActingAsPageAsync(page, pageName))
			{
				log("Đang ở sẵn danh tính Page \"" + pageName + "\".");
				return true;
			}
			if (!page.Url.StartsWith("https://www.facebook.com/", StringComparison.OrdinalIgnoreCase) || page.Url.Contains("/pages/"))
			{
				await page.GotoAsync("https://www.facebook.com/?locale=en_US", new PageGotoOptions
				{
					Timeout = 30000f,
					WaitUntil = WaitUntilState.DOMContentLoaded
				});
				await Task.Delay(2000, cancellationToken);
			}
			if (await IsAlreadyActingAsPageAsync(page, pageName))
			{
				return true;
			}
			ILocator last = page.Locator("div[aria-label='Your profile'], div[aria-label='Trang cá nhân của bạn'], svg[aria-label='Your profile'], svg[aria-label='Trang cá nhân của bạn'], [role='banner'] div[role='button']").Last;
			if (await last.CountAsync() == 0)
			{
				log("Không tìm thấy Avatar góc trên bên phải.");
				return false;
			}
			await last.ClickAsync();
			await Task.Delay(2000, cancellationToken);
			ILocator first = page.Locator($"div[role='dialog'] [aria-label*='Switch to {pageName}'], div[role='dialog'] [aria-label*='Chuyển sang {pageName}'], div[role='dialog'] [aria-label*='{pageName}'], div[role='dialog'] div[role='button']:has-text('{pageName}')").First;
			bool flag = await first.CountAsync() > 0;
			if (flag)
			{
				flag = await first.IsVisibleAsync();
			}
			if (flag)
			{
				log("Bấm chuyển sang \"" + pageName + "\"...");
				await first.ClickAsync();
				await Task.Delay(4000, cancellationToken);
				await m_5031(page, cancellationToken);
				return true;
			}
			ILocator first2 = page.Locator("div[role='dialog'] [aria-label='See all profiles'], div[role='dialog'] [aria-label='Xem tất cả trang cá nhân'], div[role='dialog'] div[role='button']:has-text('See all profiles'), div[role='dialog'] div[role='button']:has-text('Xem tất cả trang cá nhân'), div[role='dialog'] div[role='button']:has-text('See all'), div[role='dialog'] div[role='button']:has-text('Xem tất cả')").First;
			flag = await first2.CountAsync() > 0;
			if (flag)
			{
				flag = await first2.IsVisibleAsync();
			}
			if (flag)
			{
				await first2.ClickAsync();
				await Task.Delay(2000, cancellationToken);
				ILocator first3 = page.Locator($"div[role='dialog'] div[role='button']:has-text('{pageName}'), div[role='dialog'] div[role='listitem']:has-text('{pageName}')").First;
				flag = await first3.CountAsync() > 0;
				if (flag)
				{
					flag = await first3.IsVisibleAsync();
				}
				if (flag)
				{
					log("Chọn Page \"" + pageName + "\" trong danh sách...");
					await first3.ClickAsync();
					await Task.Delay(4000, cancellationToken);
					await m_5031(page, cancellationToken);
					return true;
				}
			}
		}
		catch (Exception ex)
		{
			log("Lỗi chuyển sang Page \"" + pageName + "\": " + ex.Message.Split('\n')[0]);
		}
		return false;
	}

	private static async Task m_5031(IPage P_0, CancellationToken P_1)
	{
		_ = 3;
		try
		{
			ILocator first = P_0.Locator("div[role='dialog'] div[role='button']:has-text('Switch'), div[role='dialog'] div[role='button']:has-text('Chuyển'), div[role='dialog'] div[role='button']:has-text('Chuyển ngay'), div[role='dialog'] div[role='button']:has-text('Use Page'), div[role='dialog'] div[role='button']:has-text('Dùng Trang')").First;
			bool flag = await first.CountAsync() > 0;
			if (flag)
			{
				flag = await first.IsVisibleAsync();
			}
			if (flag)
			{
				await first.ClickAsync();
				await Task.Delay(3000, P_1);
			}
		}
		catch
		{
		}
	}

	public static async Task PostSingleToPageAsync(IPage page, string pageName, string? content, List<string> mediaFiles, Action<string> log, CancellationToken cancellationToken)
	{
		log("Mở ô soạn bài của Page \"" + pageName + "\"...");
		ILocator locator = await a(page, cancellationToken);
		ILocator locator2 = locator.Locator("xpath=ancestor::*[@role='dialog'][1]");
		if (await locator2.CountAsync() == 0)
		{
			locator2 = page.Locator("body");
		}
		if (!string.IsNullOrWhiteSpace(content))
		{
			log($"Gõ nội dung bài ({content.Length} ký tự)...");
			await locator.ClickAsync(new LocatorClickOptions
			{
				Timeout = 5000f,
				Force = true
			});
			await Task.Delay(400, cancellationToken);
			await page.Keyboard.TypeAsync(content, new KeyboardTypeOptions
			{
				Delay = Random.Shared.Next(20, 50)
			});
			await Task.Delay(600, cancellationToken);
		}
		else
		{
			log("Không có nội dung chữ - đăng media đính kèm.");
		}
		if (mediaFiles.Count > 0)
		{
			log($"Đính kèm {mediaFiles.Count} file ảnh/video, đang nạp tệp...");
			ILocator first = locator2.Locator("input[type='file']").First;
			if (await first.CountAsync() == 0)
			{
				first = page.Locator("input[type='file']").First;
			}
			if (await first.CountAsync() == 0)
			{
				throw new Exception("Không tìm thấy ô chọn tệp (input[type=file]) để đính kèm ảnh/video.");
			}
			await first.SetInputFilesAsync(mediaFiles.ToArray());
			log("Đã nạp file, chờ Facebook xử lý ảnh/video...");
			await m_5033(page, locator2, mediaFiles, cancellationToken);
		}
		log("Bấm nút Đăng bài lên Page...");
		await m_5032(page, locator2, log, cancellationToken);
		await B(page, cancellationToken);
		log("Đã đăng thành công bài viết lên Page \"" + pageName + "\"!");
	}

	private static async Task<ILocator> a(IPage P_0, CancellationToken P_1)
	{
		m_5036 obj = new m_5036();
		obj.A = new ILocator[4]
		{
			P_0.Locator("[role='dialog'] [contenteditable='true'][role='textbox']"),
			P_0.Locator("[role='dialog'] [contenteditable='true']"),
			P_0.Locator("div[contenteditable='true'][role='textbox']"),
			P_0.Locator("div[contenteditable='true']")
		};
		ILocator locator = await obj.m_5044(1000);
		if (locator != null)
		{
			return locator;
		}
		Regex regex = new Regex("what's on your mind|bạn đang nghĩ gì|what are you thinking|create a post|create post|tạo bài viết|write something|viết gì đó", RegexOptions.IgnoreCase);
		ILocator[] array = new ILocator[4]
		{
			P_0.Locator("div[role='button']").Filter(new LocatorFilterOptions
			{
				HasTextRegex = regex
			}).First,
			P_0.GetByRole(AriaRole.Button, new PageGetByRoleOptions
			{
				NameRegex = regex
			}).First,
			P_0.GetByText(regex).First,
			P_0.Locator("[aria-label*='Create post'], [aria-label*='Tạo bài viết'], [aria-label*=\"What's on your mind\"], [aria-label*=\"bạn đang nghĩ gì\"]").First
		};
		ILocator[] array2 = array;
		foreach (ILocator locator2 in array2)
		{
			try
			{
				bool flag = await locator2.CountAsync() > 0;
				if (flag)
				{
					flag = await locator2.IsVisibleAsync();
				}
				if (flag)
				{
					await locator2.ClickAsync(new LocatorClickOptions
					{
						Timeout = 4000f,
						Force = true
					});
					await Task.Delay(1500, P_1);
					ILocator locator3 = await obj.m_5044(3000);
					if (locator3 != null)
					{
						return locator3;
					}
				}
			}
			catch
			{
			}
		}
		for (int i = 0; i < 6; i++)
		{
			ILocator locator4 = await obj.m_5044(500);
			if (locator4 != null)
			{
				return locator4;
			}
			await Task.Delay(500, P_1);
		}
		throw new Exception("Không mở được khung soạn bài trên Page.");
	}

	private static async Task m_5032(IPage P_0, ILocator P_1, Action<string> P_2, CancellationToken P_3)
	{
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "post", "đăng", "next", "tiếp", "share", "chia sẻ", "publish", "phát hành" };
		for (int i = 0; i < 5; i++)
		{
			P_3.ThrowIfCancellationRequested();
			if (await P_0.Locator("[role='dialog'] [contenteditable='true']").CountAsync() == 0)
			{
				break;
			}
			ILocator locator = null;
			string text = "";
			ILocator locator2 = P_1.Locator("[role='button']");
			for (int num = await locator2.CountAsync() - 1; num >= 0; num--)
			{
				ILocator locator3 = locator2.Nth(num);
				string text2 = ((await locator3.GetAttributeAsync("aria-label")) ?? "").Trim();
				string text3 = (await locator3.InnerTextAsync())?.Trim() ?? "";
				if (hashSet.Contains(text2) || hashSet.Contains(text3))
				{
					locator = locator3;
					text = ((!string.IsNullOrWhiteSpace(text2)) ? text2 : text3);
					break;
				}
			}
			if (locator == null)
			{
				string[] array = new string[6] { "Post", "Đăng", "Next", "Tiếp", "Share", "Chia sẻ" };
				foreach (string text2 in array)
				{
					ILocator locator3 = P_0.GetByText(text2, new PageGetByTextOptions
					{
						Exact = true
					});
					bool flag = await locator3.CountAsync() > 0;
					if (flag)
					{
						flag = await locator3.First.IsVisibleAsync();
					}
					if (flag)
					{
						locator = locator3.First;
						text = text2;
						break;
					}
				}
			}
			if (locator == null)
			{
				await Task.Delay(2000, P_3);
				if (await P_0.Locator("[role='dialog'] [contenteditable='true']").CountAsync() == 0)
				{
					break;
				}
				throw new Exception("Không tìm thấy nút Đăng/Tiếp (Post/Next) để hoàn tất.");
			}
			for (int num = 0; num < 30; num++)
			{
				if (((await locator.GetAttributeAsync("aria-disabled")) ?? "") != "true")
				{
					break;
				}
				await Task.Delay(1000, P_3);
			}
			P_2("Bấm \"" + text + "\"...");
			await locator.ClickAsync(new LocatorClickOptions
			{
				Timeout = 10000f
			});
			for (int num = 0; num < 30; num++)
			{
				await Task.Delay(1000, P_3);
				if (await P_0.Locator("[role='dialog'] [contenteditable='true']").CountAsync() == 0)
				{
					return;
				}
			}
		}
	}

	private static async Task B(IPage P_0, CancellationToken P_1)
	{
		_ = 4;
		try
		{
			await Task.Delay(2000, P_1);
			ILocator first = P_0.Locator("div[role='dialog'] [aria-label='Close'], div[role='dialog'] [aria-label='Đóng'], div[role='dialog'] div[role='button']:has-text('Not now'), div[role='dialog'] div[role='button']:has-text('Để sau'), div[role='dialog'] div[role='button']:has-text('Lúc khác')").First;
			bool flag = await first.CountAsync() > 0;
			if (flag)
			{
				flag = await first.IsVisibleAsync();
			}
			if (flag)
			{
				await first.ClickAsync();
				await Task.Delay(1000, P_1);
			}
		}
		catch
		{
		}
	}

	private static async Task m_5033(IPage P_0, ILocator P_1, List<string> P_2, CancellationToken P_3)
	{
		int num = (P_2.Any((string text3) => text3.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase) || text3.EndsWith(".mov", StringComparison.OrdinalIgnoreCase) || text3.EndsWith(".avi", StringComparison.OrdinalIgnoreCase) || text3.EndsWith(".mkv", StringComparison.OrdinalIgnoreCase)) ? 180 : 30);
		int num2 = 1500;
		int num3 = num * 1000 / num2;
		for (int num4 = 0; num4 < num3; num4++)
		{
			P_3.ThrowIfCancellationRequested();
			await Task.Delay(num2, P_3);
			ILocator locator = P_1.Locator("[role='button']");
			for (int num5 = await locator.CountAsync() - 1; num5 >= 0; num5--)
			{
				ILocator locator2 = locator.Nth(num5);
				string text = ((await locator2.GetAttributeAsync("aria-label")) ?? "").Trim();
				string text2 = (await locator2.InnerTextAsync())?.Trim() ?? "";
				if ((text.Equals("Post", StringComparison.OrdinalIgnoreCase) || text.Equals("Đăng", StringComparison.OrdinalIgnoreCase) || text2.Equals("Post", StringComparison.OrdinalIgnoreCase) || text2.Equals("Đăng", StringComparison.OrdinalIgnoreCase) || text.Equals("Next", StringComparison.OrdinalIgnoreCase) || text.Equals("Tiếp", StringComparison.OrdinalIgnoreCase) || text2.Equals("Next", StringComparison.OrdinalIgnoreCase) || text2.Equals("Tiếp", StringComparison.OrdinalIgnoreCase)) && ((await locator2.GetAttributeAsync("aria-disabled")) ?? "") != "true")
				{
					return;
				}
			}
		}
	}
}
