using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class AiVisionVariables
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3064
	{
		public static readonly m_3064 A = new m_3064();

		public static MatchEvaluator m_3068;

		public static MatchEvaluator a;

		public static MatchEvaluator B;

		public static MatchEvaluator b;

		internal string m_3069(Match P_0)
		{
			return m_3063(AiVisionVariables.a, 6);
		}

		internal string m_3070(Match P_0)
		{
			return m_3063(AiVisionVariables.A, 8);
		}

		internal string m_3071(Match P_0)
		{
			return m_3063(AiVisionVariables.B, 8);
		}

		internal string m_3072(Match P_0)
		{
			string value = P_0.Groups["type"].Value;
			char[] array;
			if (value == "So")
			{
				array = AiVisionVariables.a;
			}
			else
			{
				array = ((!(value == "Chu")) ? AiVisionVariables.B : AiVisionVariables.A);
			}
			char[] array2 = array;
			int num = int.Parse(P_0.Groups["length"].Value);
			return P_0.Groups["prefix"].Value + m_3063(array2, num) + P_0.Groups["suffix"].Value;
		}
	}

	[CompilerGenerated]
	private sealed class m_3065
	{
		public string A;

		internal string m_3073(Match P_0)
		{
			return PlaywrightHumanHelpers.Get2fa(A);
		}
	}

	[CompilerGenerated]
	private sealed class m_3066
	{
		public char[] A;

		internal char m_3074(int P_0)
		{
			return A[Random.Shared.Next(A.Length)];
		}
	}

	private static readonly char[] A = "abcdefghijklmnopqrstuvwxyz".ToCharArray();

	private static readonly char[] a = "0123456789".ToCharArray();

	private static readonly char[] B = A.Concat(a).ToArray();

	private static readonly Regex m_3060 = new Regex(Regex.Escape("{{RandomSo}}"));

	private static readonly Regex m_3061 = new Regex(Regex.Escape("{{RandomChu}}"));

	private static readonly Regex m_3062 = new Regex(Regex.Escape("{{RandomSoChu}}"));

	private static readonly Regex b = new Regex("\\{\\{Random\\|(?<type>So|Chu|SoChu)\\|(?<length>\\d+)\\|(?<prefix>[^|{}]*)\\|(?<suffix>[^|{}]*)\\}\\}");

	private static readonly Regex C = new Regex(Regex.Escape("{{TwoFaCode}}"));

	public static Dictionary<string, string> BuildMap(FacebookAccountRow nick)
	{
		return new Dictionary<string, string>
		{
			["{{Uid}}"] = nick.Uid,
			["{{Pass}}"] = nick.Pass,
			["{{Mail}}"] = nick.Mail,
			["{{PassMail}}"] = nick.PassMail,
			["{{MailKhoiPhuc}}"] = nick.MailKhoiPhuc,
			["{{HoTen}}"] = nick.HoTen,
			["{{TwoFA}}"] = nick.TwoFA,
			["{{GhiChu}}"] = nick.GhiChu,
			["{{Cookie}}"] = nick.Cookie,
			["{{Token}}"] = nick.Token,
			["{{PhoneName}}"] = nick.PhoneName,
			["{{Proxy}}"] = nick.Proxy
		};
	}

	public static Dictionary<string, string> BuildMap(PlatformAccountRow nick)
	{
		return new Dictionary<string, string>
		{
			["{{Uid}}"] = nick.Uid,
			["{{Pass}}"] = nick.Pass,
			["{{Mail}}"] = nick.Mail,
			["{{PassMail}}"] = nick.PassMail,
			["{{MailKhoiPhuc}}"] = nick.MailKhoiPhuc,
			["{{HoTen}}"] = "",
			["{{TwoFA}}"] = nick.TwoFA,
			["{{GhiChu}}"] = nick.GhiChu,
			["{{Cookie}}"] = nick.Cookie,
			["{{Token}}"] = nick.Token,
			["{{PhoneName}}"] = nick.PhoneName,
			["{{Proxy}}"] = nick.Proxy
		};
	}

	public static async Task ResolveVerifyVariablesAsync(Dictionary<string, string> variables, IEnumerable<AiVisionFlowStep> steps, CancellationToken ct = default(CancellationToken))
	{
		bool flag = false;
		bool flag2 = false;
		foreach (AiVisionFlowStep step in steps)
		{
			string text = step.Goal + step.Text + step.Url;
			if (text.Contains("{{VerifyMail}}"))
			{
				flag = true;
			}
			if (text.Contains("{{VerifyPhone}}"))
			{
				flag2 = true;
			}
		}
		if (flag)
		{
			try
			{
				VerifyMailSettings verifyMailSettings = VerifyMailSettings.Load();
				Dictionary<string, string> dictionary = variables;
				string value = ((!(verifyMailSettings.Provider == "Random")) ? (await verifyMailSettings.CreateClient().GetNewMailAddressAsync(ct)) : verifyMailSettings.BuildRandomMailPreview());
				dictionary["{{VerifyMail}}"] = value;
			}
			catch (Exception)
			{
				variables["{{VerifyMail}}"] = "";
			}
		}
		if (flag2)
		{
			try
			{
				VerifyPhoneSettings verifyPhoneSettings = VerifyPhoneSettings.Load();
				Dictionary<string, string> dictionary = variables;
				string value = ((!(verifyPhoneSettings.Provider == "Random")) ? (await verifyPhoneSettings.CreateClient().GetNewPhoneNumberAsync(ct)) : verifyPhoneSettings.BuildRandomPhonePreview());
				dictionary["{{VerifyPhone}}"] = value;
			}
			catch (Exception)
			{
				variables["{{VerifyPhone}}"] = "";
			}
		}
	}

	public static string Substitute(string template, IReadOnlyDictionary<string, string> variables)
	{
		string text = template;
		foreach (var (oldValue, newValue) in variables)
		{
			text = text.Replace(oldValue, newValue);
		}
		text = m_3060.Replace(text, delegate
		{
			return m_3063(a, 6);
		});
		text = m_3061.Replace(text, delegate
		{
			return m_3063(AiVisionVariables.A, 8);
		});
		text = m_3062.Replace(text, delegate
		{
			return m_3063(B, 8);
		});
		text = b.Replace(text, (Match P_0) =>
		{
			string value = P_0.Groups["type"].Value;
			char[] array = ((value == "So") ? a : ((!(value == "Chu")) ? B : AiVisionVariables.A));
			char[] array2 = array;
			int num = int.Parse(P_0.Groups["length"].Value);
			return P_0.Groups["prefix"].Value + m_3063(array2, num) + P_0.Groups["suffix"].Value;
		});
		text = AiVisionFileVariables.Substitute(text);
		if (variables.TryGetValue("{{TwoFA}}", out string A) && !string.IsNullOrWhiteSpace(A))
		{
			text = C.Replace(text, delegate
			{
				return PlaywrightHumanHelpers.Get2fa(A);
			});
		}
		return text;
	}

	private static string m_3063(char[] P_0, int P_1)
	{
		return new string(Enumerable.Range(0, P_1).Select((Func<int, char>)delegate
		{
			return P_0[Random.Shared.Next(P_0.Length)];
		}).ToArray());
	}

	public static string? FindPlaceholderForValue(string P_3059, IReadOnlyDictionary<string, string> variables)
	{
		if (string.IsNullOrEmpty(P_3059))
		{
			return null;
		}
		foreach (var (result, text3) in variables)
		{
			if (!string.IsNullOrEmpty(text3) && text3 == P_3059)
			{
				return result;
			}
		}
		return null;
	}
}
