using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class PostBoostSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6085
	{
		public static readonly m_6085 A = new m_6085();

		public static Func<string, bool> m_6086;

		internal bool m_6087(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	[CompilerGenerated]
	private List<string> A = new List<string>();

	[CompilerGenerated]
	private bool m_6081 = true;

	[CompilerGenerated]
	private bool a;

	[CompilerGenerated]
	private bool B;

	[CompilerGenerated]
	private List<string> m_6082 = new List<string> { "Hay quá \ud83d\ude0d", "Đẹp quá", "Thích cái này ghê", "Hữu ích quá", "\ud83d\udd25\ud83d\udd25\ud83d\udd25" };

	[CompilerGenerated]
	private int m_6083 = 20;

	[CompilerGenerated]
	private int m_6084 = 60;

	public List<string> PostLinks
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool AutoLike
	{
		[CompilerGenerated]
		get
		{
			return m_6081;
		}
		[CompilerGenerated]
		set
		{
			m_6081 = value;
		}
	}

	public bool AutoComment
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool AutoShare
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public List<string> CommentTexts
	{
		[CompilerGenerated]
		get
		{
			return m_6082;
		}
		[CompilerGenerated]
		set
		{
			m_6082 = value;
		}
	}

	public int MinSpacingSeconds
	{
		[CompilerGenerated]
		get
		{
			return m_6083;
		}
		[CompilerGenerated]
		set
		{
			m_6083 = value;
		}
	}

	public int MaxSpacingSeconds
	{
		[CompilerGenerated]
		get
		{
			return m_6084;
		}
		[CompilerGenerated]
		set
		{
			m_6084 = value;
		}
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static PostBoostSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new PostBoostSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<PostBoostSettings>(json) ?? new PostBoostSettings();
		}
		catch (JsonException)
		{
			return new PostBoostSettings();
		}
	}

	public string? PickCommentText()
	{
		List<string> list = CommentTexts.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}

	public int PickSpacingSeconds()
	{
		if (MinSpacingSeconds < MaxSpacingSeconds)
		{
			return Random.Shared.Next(MinSpacingSeconds, MaxSpacingSeconds + 1);
		}
		return MinSpacingSeconds;
	}
}
