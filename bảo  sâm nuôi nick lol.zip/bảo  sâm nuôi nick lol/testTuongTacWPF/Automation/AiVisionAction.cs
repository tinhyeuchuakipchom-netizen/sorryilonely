using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;
using A;

namespace testTuongTacWPF.Automation;

public class AiVisionAction
{
	[CompilerGenerated]
	private string A = "wait";

	[CompilerGenerated]
	private int? m_2858;

	[CompilerGenerated]
	private int m_2859;

	[CompilerGenerated]
	private int a;

	[CompilerGenerated]
	private int B;

	[CompilerGenerated]
	private int b;

	[CompilerGenerated]
	private string m_2860 = "";

	[CompilerGenerated]
	private string m_2861 = "";

	public string Action
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int? ElementIndex
	{
		[CompilerGenerated]
		get
		{
			return m_2858;
		}
		[CompilerGenerated]
		set
		{
			m_2858 = value;
		}
	}

	[JsonConverter(typeof(e))]
	public int X
	{
		[CompilerGenerated]
		get
		{
			return m_2859;
		}
		[CompilerGenerated]
		set
		{
			m_2859 = value;
		}
	}

	[JsonConverter(typeof(e))]
	public int Y
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	[JsonConverter(typeof(e))]
	public int X2
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	[JsonConverter(typeof(e))]
	public int Y2
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string Text
	{
		[CompilerGenerated]
		get
		{
			return m_2860;
		}
		[CompilerGenerated]
		set
		{
			m_2860 = value;
		}
	}

	public string Reason
	{
		[CompilerGenerated]
		get
		{
			return m_2861;
		}
		[CompilerGenerated]
		set
		{
			m_2861 = value;
		}
	}
}
