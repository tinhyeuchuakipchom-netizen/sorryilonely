using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class DongVanFbClient : IVerifyMailTestClient
{
	private readonly string A;

	private readonly string a;

	private readonly HttpClient m_3941 = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private string? B;

	private string? b;

	private string? C;

	public DongVanFbClient(string apiKey, string folderId)
	{
		A = apiKey;
		a = folderId;
	}

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(A))
		{
			throw new InvalidOperationException("Chưa nhập API Key cho dongvanfb.net (xem ô \"API Key dongvanfb.net\" bên dưới).");
		}
		if (string.IsNullOrWhiteSpace(a))
		{
			throw new InvalidOperationException("Chưa nhập ID thư mục/loại mail cho dongvanfb.net (xem ô \"ID thư mục\" bên dưới).");
		}
		if (!(await m_3941.GetStringAsync("https://api.dongvanfb.net/user/balance?apikey=" + A, ct)).Contains("true"))
		{
			throw new InvalidOperationException("Không kiểm tra được số dư dongvanfb.net (API Key sai hoặc hết tiền).");
		}
		InvalidOperationException ex = null;
		for (int i = 0; i < 15; i++)
		{
			ct.ThrowIfCancellationRequested();
			try
			{
				return await m_3942(ct);
			}
			catch (InvalidOperationException ex2)
			{
				ex = ex2;
			}
			await Task.Delay(5000, ct);
		}
		throw ex ?? new InvalidOperationException("Mua mail dongvanfb.net thất bại sau nhiều lần thử.");
	}

	private async Task<string> m_3942(CancellationToken P_0)
	{
		string text = await m_3941.GetStringAsync($"https://api.dongvanfb.net/user/buy?apikey={A}&account_type={a}&quality=1&type=full", P_0);
		if (!text.Contains("true"))
		{
			throw new InvalidOperationException("Mua mail dongvanfb.net thất bại: " + text);
		}
		Match match = Regex.Match(text, "(?<=list_data\":\\[\").*?(?=\"\\])");
		if (!match.Success)
		{
			throw new InvalidOperationException("Không đọc được dữ liệu mail vừa mua từ dongvanfb.net (có thể site đã đổi định dạng).");
		}
		string[] array = match.Value.Split('|');
		if (array.Length < 4)
		{
			throw new InvalidOperationException($"Dữ liệu mail dongvanfb.net thiếu trường (cần 4 phần email|password|refresh_token|client_id, chỉ có {array.Length}) - có thể site đã đổi định dạng \"list_data\".");
		}
		B = array[0];
		b = array[2];
		C = array[3];
		return B;
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (B == null || b == null || C == null)
		{
			throw new InvalidOperationException("Chưa lấy địa chỉ mail - bấm \"Thử lấy mail\" trước.");
		}
		string content = "{\"email\":\"" + B + "\",\"refresh_token\":\"" + b + "\",\"client_id\":\"" + C + "\",\"type\":\"facebook\"}";
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://tools.dongvanfb.net/api/graph_code")
		{
			Content = new StringContent(content, Encoding.UTF8, "application/json")
		};
		using HttpResponseMessage httpResponseMessage = await m_3941.SendAsync(request);
		string text = await httpResponseMessage.Content.ReadAsStringAsync();
		if (text.Contains("facebookmail.com"))
		{
			string text2 = m_3943(text);
			if (text2 != null)
			{
				return text2;
			}
		}
		using HttpRequestMessage request2 = new HttpRequestMessage(HttpMethod.Post, "https://tools.dongvanfb.net/api/get_messages_oauth2")
		{
			Content = new FormUrlEncodedContent(new Dictionary<string, string>
			{
				["email"] = B,
				["refresh_token"] = b,
				["client_id"] = C
			})
		};
		using HttpResponseMessage httpResponseMessage2 = await m_3941.SendAsync(request2);
		string text3 = await httpResponseMessage2.Content.ReadAsStringAsync();
		if (text3.Contains("true") && text3.Contains("facebookmail.com"))
		{
			return m_3943(text3);
		}
		return null;
	}

	private static string? m_3943(string P_0)
	{
		Match match = Regex.Match(P_0, "\\b(\\d{5,6})\\b");
		if (!match.Success)
		{
			return null;
		}
		return match.Groups[1].Value;
	}
}
