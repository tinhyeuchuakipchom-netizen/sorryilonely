namespace testTuongTacWPF.Automation;

public enum FriendRequestAction
{
	SendRequests,
	ConfirmIncoming
}
