using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using A;

namespace testTuongTacWPF.Automation;

public class TempMailOrgClient : IVerifyMailTestClient
{
	[CompilerGenerated]
	private sealed class m_6218
	{
		public Process A;

		internal void m_6222()
		{
			try
			{
				if (!A.HasExited)
				{
					A.Kill();
				}
			}
			catch
			{
			}
		}
	}

	private const string A = "C:\\Windows\\System32\\curl.exe";

	private const string a = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36";

	private const string B = "\"Not(A:Brand\";v=\"99.0.0.0\", \"Google Chrome\";v=\"133.0.6943.142\", \"Chromium\";v=\"133.0.6943.142\"";

	private readonly string? b;

	private string? C;

	private string? c;

	public TempMailOrgClient(string? proxy = null)
	{
		b = proxy;
	}

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		using JsonDocument jsonDocument = JsonDocument.Parse(await m_6216("POST", "https://web2.temp-mail.org/mailbox", null, ct));
		C = (jsonDocument.RootElement.TryGetProperty("mailbox", out var value) ? value.GetString() : null);
		c = (jsonDocument.RootElement.TryGetProperty("token", out var value2) ? value2.GetString() : null);
		if (string.IsNullOrWhiteSpace(C) || !C.Contains('@') || string.IsNullOrWhiteSpace(c))
		{
			throw new InvalidOperationException("Không tạo được hộp thư trên temp-mail.org (có thể site đã đổi API, hoặc bị Cloudflare chặn lần này - thử lại sau).");
		}
		return C;
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (c == null)
		{
			throw new InvalidOperationException("Chưa lấy địa chỉ mail - bấm \"Thử lấy mail\" trước.");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(await m_6216("GET", "https://web2.temp-mail.org/messages", c, default));
		if (!jsonDocument.RootElement.TryGetProperty("messages", out var value) || value.ValueKind != JsonValueKind.Array)
		{
			return null;
		}
		JsonElement? jsonElement = null;
		long num = -1L;
		foreach (JsonElement item in value.EnumerateArray())
		{
			long num2 = ((item.TryGetProperty("receivedAt", out var value2) && value2.TryGetInt64(out var value3)) ? value3 : 0);
			if (!jsonElement.HasValue || num2 >= num)
			{
				jsonElement = item;
				num = num2;
			}
		}
		if (!jsonElement.HasValue)
		{
			return null;
		}
		string text = f.A(jsonElement.Value.TryGetProperty("subject", out var value4) ? (value4.GetString() ?? "") : "");
		if (text != null)
		{
			return text;
		}
		JsonElement value5;
		return f.A(jsonElement.Value.TryGetProperty("bodyPreview", out value5) ? (value5.GetString() ?? "") : "");
	}

	private async Task<string> m_6216(string P_0, string P_1, string? bearerToken, CancellationToken P_3)
	{
		if (!File.Exists("C:\\Windows\\System32\\curl.exe"))
		{
			throw new InvalidOperationException("Không tìm thấy C:\\Windows\\System32\\curl.exe - máy này thiếu curl.exe có sẵn của Windows (10 1803+/11).");
		}
		ProcessStartInfo processStartInfo = new ProcessStartInfo("C:\\Windows\\System32\\curl.exe")
		{
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			UseShellExecute = false,
			CreateNoWindow = true
		};
		processStartInfo.ArgumentList.Add("-s");
		processStartInfo.ArgumentList.Add("-X");
		processStartInfo.ArgumentList.Add(P_0);
		processStartInfo.ArgumentList.Add(P_1);
		processStartInfo.ArgumentList.Add("-H");
		processStartInfo.ArgumentList.Add("Accept: text/html");
		processStartInfo.ArgumentList.Add("-H");
		processStartInfo.ArgumentList.Add("Accept-Language: en-US");
		processStartInfo.ArgumentList.Add("-H");
		processStartInfo.ArgumentList.Add("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36");
		processStartInfo.ArgumentList.Add("-H");
		processStartInfo.ArgumentList.Add("sec-ch-ua-full-version-list: \"Not(A:Brand\";v=\"99.0.0.0\", \"Google Chrome\";v=\"133.0.6943.142\", \"Chromium\";v=\"133.0.6943.142\"");
		processStartInfo.ArgumentList.Add("-H");
		processStartInfo.ArgumentList.Add("Referer: https://temp-mail.org/");
		processStartInfo.ArgumentList.Add("--max-time");
		processStartInfo.ArgumentList.Add("20");
		if (bearerToken != null)
		{
			processStartInfo.ArgumentList.Add("-H");
			processStartInfo.ArgumentList.Add("Authorization: Bearer " + bearerToken);
		}
		string text = m_6217(b);
		if (text != null)
		{
			processStartInfo.ArgumentList.Add("-x");
			processStartInfo.ArgumentList.Add(text);
		}
		Process A = Process.Start(processStartInfo) ?? throw new InvalidOperationException("Không khởi chạy được curl.exe.");
		try
		{
			using (P_3.Register(() =>
			{
				try
				{
					if (!A.HasExited)
					{
						A.Kill();
					}
				}
				catch
				{
				}
			}))
			{
				string result = await A.StandardOutput.ReadToEndAsync(P_3);
				await A.WaitForExitAsync(P_3);
				return result;
			}
		}
		finally
		{
			if (A != null)
			{
				((IDisposable)A).Dispose();
			}
		}
	}

	private static string? m_6217(string? P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return null;
		}
		ProxyParseResult proxyParseResult = ProxyParser.Parse(P_0);
		if (!proxyParseResult.IsValid)
		{
			throw new InvalidOperationException("Proxy không hợp lệ: " + proxyParseResult.Error);
		}
		string value = proxyParseResult.Scheme ?? "http";
		string value2 = ((proxyParseResult.User != null) ? (proxyParseResult.User + ":" + proxyParseResult.Pass + "@") : "");
		return $"{value}://{value2}{proxyParseResult.Host}:{proxyParseResult.Port}";
	}
}
