using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using A;

namespace testTuongTacWPF.Automation;

public class TemporaryMailClient : IVerifyMailTestClient
{
	private const string A = "https://temporarymail.com";

	private static readonly string[] m_6238 = new string[10] { "@AllFreeMail.net", "@AllWebEmails.com", "@EasyMailer.live", "@FusionInbox.com", "@HorizonsPost.com", "@InboxOrigin.com", "@MailMagnet.co", "@OpenMail.pro", "@SolarNyx.com", "@VertexInbox.com" };

	private readonly HttpClient m_6239 = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private readonly Random m_6240 = new Random();

	private string? a;

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		using HttpResponseMessage httpResponseMessage = await m_6239.GetAsync("https://temporarymail.com/api/?action=generateRandomName&value=0", ct);
		string text = f.A(await httpResponseMessage.Content.ReadAsStringAsync(ct), "{\"address\":\"", "\"");
		if (string.IsNullOrEmpty(text))
		{
			throw new InvalidOperationException("Không lấy được tên mail từ temporarymail.com (có thể site đã đổi API).");
		}
		string text2 = text + m_6238[m_6240.Next(m_6238.Length)];
		using HttpResponseMessage httpResponseMessage2 = await m_6239.GetAsync("https://temporarymail.com/api/?action=requestEmailAccess&key=&value=" + text2, ct);
		a = f.A(await httpResponseMessage2.Content.ReadAsStringAsync(ct), "secretKey\":\"", "\"");
		if (string.IsNullOrEmpty(a))
		{
			throw new InvalidOperationException("Không đăng ký được hộp thư trên temporarymail.com (có thể site đã đổi API).");
		}
		return text2;
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (a == null)
		{
			throw new InvalidOperationException("Chưa lấy địa chỉ mail - bấm \"Thử lấy mail\" trước.");
		}
		using HttpResponseMessage httpResponseMessage = await m_6239.GetAsync("https://temporarymail.com/api/?action=checkInbox&value=" + a);
		string text = f.A(await httpResponseMessage.Content.ReadAsStringAsync(), "id\":\"", "\"");
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		using HttpResponseMessage httpResponseMessage2 = await m_6239.GetAsync("https://temporarymail.com/view/?i=" + text + "&width=0");
		string text2 = await httpResponseMessage2.Content.ReadAsStringAsync();
		string text3 = f.A(text2, "letter-spacing: 5px\">", "<");
		return (!string.IsNullOrWhiteSpace(text3)) ? text3.Trim() : f.A(text2);
	}
}
