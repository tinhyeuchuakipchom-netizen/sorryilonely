using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookKatanaPageCreationService
{
	public class KatanaPageCreationStepResult
	{
		[CompilerGenerated]
		private bool A;

		[CompilerGenerated]
		private bool a;

		[CompilerGenerated]
		private string m_4520 = "";

		public bool Success
		{
			[CompilerGenerated]
			get
			{
				return A;
			}
			[CompilerGenerated]
			set
			{
				A = value;
			}
		}

		public bool IsLimitBlocked
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public string ErrorMessage
		{
			[CompilerGenerated]
			get
			{
				return m_4520;
			}
			[CompilerGenerated]
			set
			{
				m_4520 = value;
			}
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class m_4513
	{
		public static readonly m_4513 A = new m_4513();

		public static Func<UiElement, bool> m_4521;

		public static Func<UiElement, bool> a;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		public static Func<UiElement, bool> C;

		public static Func<UiElement, bool> c;

		public static Func<UiElement, bool> D;

		public static Func<UiElement, bool> d;

		public static Func<UiElement, bool> E;

		public static Func<UiElement, bool> e;

		public static Func<UiElement, bool> F;

		public static Func<UiElement, bool> f;

		public static Func<UiElement, bool> G;

		public static Func<UiElement, bool> g;

		public static Func<UiElement, bool> H;

		public static Func<UiElement, bool> h;

		public static Func<UiElement, string> m_4522;

		public static Func<UiElement, bool> I;

		public static Func<UiElement, bool> i;

		public static Func<UiElement, bool> J;

		public static Func<UiElement, bool> j;

		public static Func<UiElement, string> m_4523;

		public static Func<UiElement, bool> K;

		public static Func<UiElement, bool> k;

		public static Func<UiElement, bool> L;

		public static Func<UiElement, bool> l;

		public static Func<UiElement, bool> M;

		public static Func<UiElement, bool> m;

		public static Func<UiElement, bool> N;

		public static Func<UiElement, bool> n;

		public static Func<UiElement, bool> O;

		public static Func<UiElement, bool> o;

		public static Func<UiElement, bool> P;

		public static Func<UiElement, bool> p;

		public static Func<UiElement, bool> Q;

		public static Func<UiElement, bool> q;

		public static Func<UiElement, bool> R;

		internal bool m_4524(UiElement P_0)
		{
			if ((!P_0.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase) || P_0.CenterY >= 300) && !P_0.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Open profile switcher", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4525(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Menu, tab", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4526(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Facebook logo", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("conversation", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("search");
			}
			return true;
		}

		internal bool m_4527(UiElement P_0)
		{
			if ((!P_0.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase) || P_0.CenterY >= 300) && !P_0.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Open profile switcher", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4528(UiElement P_0)
		{
			if (P_0.CenterY < 400)
			{
				if (!P_0.Text.Equals("Create", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Create", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tạo", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Tạo", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("+ Create", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Contains("+ Create", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4529(UiElement P_0)
		{
			if (P_0.CenterY < 250)
			{
				if (!P_0.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Pages", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Search", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal bool m_4530(UiElement P_0)
		{
			if (!P_0.Text.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Page name", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("What do you want to name this Page", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4531(UiElement P_0)
		{
			if (!P_0.Text.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Page name", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4532(UiElement P_0)
		{
			return P_0.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_4533(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Tạo trang Facebook", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Tạo trang Facebook", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4534(UiElement P_0)
		{
			if (!P_0.Text.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4535(UiElement P_0)
		{
			if (!P_0.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Pages", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Trang", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Trang", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4536(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("See more", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("See more", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Xem thêm", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Xem thêm", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4537(UiElement P_0)
		{
			if (!P_0.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Pages", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Trang", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Trang", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4538(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("See less", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("See less", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4539(UiElement P_0)
		{
			if (!P_0.Text.Contains("Get started", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Page name", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Get started", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Page name", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal string m_4540(UiElement P_0)
		{
			return P_0.Text + " " + P_0.ContentDesc;
		}

		internal bool m_4541(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText") && !P_0.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Page name", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4542(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Personal blog", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Personal blog", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Blogger", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Blogger", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Product/service", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Product/service", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Art", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Art", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4543(UiElement P_0)
		{
			return P_0.ClassName.Contains("EditText");
		}

		internal bool m_4544(UiElement P_0)
		{
			if (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View"))
			{
				if (!P_0.Text.Equals("Create", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Create", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Tạo", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Equals("Tạo", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return false;
		}

		internal string m_4545(UiElement P_0)
		{
			return P_0.Text + " " + P_0.ContentDesc;
		}

		internal bool m_4546(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Creator", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Creator", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4547(UiElement P_0)
		{
			if (!P_0.ContentDesc.Equals("Close", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Close", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Đóng", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Đóng", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4548(UiElement P_0)
		{
			if (P_0.Text.Equals("Chats", StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals("Chats", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.CenterY < 200;
			}
			return false;
		}

		internal bool m_4549(UiElement P_0)
		{
			if (!P_0.Text.Equals("OK", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Save", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Not now", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Equals("Not now", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4550(UiElement P_0)
		{
			return P_0.Text.Contains("login info", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_4551(UiElement P_0)
		{
			if (!P_0.Text.Equals("Don't allow", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Equals("Không cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4552(UiElement P_0)
		{
			return P_0.ResourceId.Contains("permission");
		}

		internal bool m_4553(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("login_password") && !P_0.ResourceId.Contains("m_login_password") && !P_0.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Forgot Password", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Forgot Password", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4554(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Open profile switcher", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Menu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Home, tab", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Facebook logo", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Page name", StringComparison.OrdinalIgnoreCase) && !P_0.ResourceId.Contains("tab_bar"))
			{
				return P_0.ResourceId.Contains("feed_tab");
			}
			return true;
		}

		internal bool m_4555(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Promote Page", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Promote Page", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_4556(UiElement P_0)
		{
			return P_0.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_4557(UiElement P_0)
		{
			return P_0.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_4558(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("profile switcher", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Switch profile", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.CenterX > 750 && P_0.CenterY > 200)
				{
					return P_0.CenterY < 380;
				}
				return false;
			}
			return true;
		}

		internal bool r(UiElement P_0)
		{
			if (P_0.CenterY > 900 && P_0.CenterY < 1500 && !string.IsNullOrWhiteSpace(P_0.ContentDesc) && !P_0.ContentDesc.Contains("Create Facebook profile", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Accounts Center", StringComparison.OrdinalIgnoreCase))
			{
				return !P_0.ContentDesc.Contains("See all profiles", StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}

		internal bool S(UiElement P_0)
		{
			if (P_0.CenterY > 900 && P_0.CenterY < 1450 && !string.IsNullOrWhiteSpace(P_0.ContentDesc) && !P_0.ContentDesc.Contains("Create Facebook profile", StringComparison.OrdinalIgnoreCase))
			{
				return !P_0.ContentDesc.Contains("Accounts Center", StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_4514
	{
		public List<UiElement> A;

		internal bool m_4559(UiElement P_0)
		{
			if (!P_0.Text.Contains("Pages you manage", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Pages you manage", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Trang bạn quản lý", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Trang bạn quản lý", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) && P_0.CenterY < 200)
				{
					return A.Any((UiElement uiElement) => uiElement.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase));
				}
				return false;
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_4515
	{
		public string[] A;

		internal bool m_4560(UiElement P_0)
		{
			if (P_0.ClassName.Contains("Button") || P_0.ClassName.Contains("View"))
			{
				return A.Any((string value) => P_0.Text.Equals(value, StringComparison.OrdinalIgnoreCase) || P_0.ContentDesc.Equals(value, StringComparison.OrdinalIgnoreCase));
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class m_4516
	{
		public UiElement A;

		internal bool m_4561(string P_0)
		{
			if (!A.Text.Equals(P_0, StringComparison.OrdinalIgnoreCase))
			{
				return A.ContentDesc.Equals(P_0, StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	private const string A = "com.facebook.katana/.activity.FbMainTabActivity";

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow account, Action<string> onStatus, CancellationToken cancellationToken, PageCreationSettings pageSettings, int sequenceIndex)
	{
		string text = account.PhoneName;
		if (string.IsNullOrWhiteSpace(text))
		{
			List<string> list = await AdbController.ListDevicesAsync(cancellationToken);
			text = ((list.Count > 0) ? list[0] : "");
			if (string.IsNullOrEmpty(text))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Nick chưa gắn thiết bị Phone và không tìm thấy thiết bị Android nào đang kết nối.",
					TinhTrang = "ERROR"
				};
			}
			account.PhoneName = text;
		}
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			onStatus("Kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(text, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new AiVisionRunResult
				{
					Success = false,
					Message = "Thiết bị " + text + " không phản hồi.",
					TinhTrang = "OFFLINE"
				};
			}
			onStatus("Kiểm tra cài đặt ban đầu máy...");
			await PhoneInitialSetupService.EnsureInitialSetupAsync(text, "Katana", onStatus, cancellationToken);
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(text, cancellationToken);
			onStatus("Khởi chạy Facebook Katana...");
			await AdbController.RunShellAsync(text, "am start -n com.facebook.katana/.activity.FbMainTabActivity", cancellationToken);
			await Task.Delay(2500, cancellationToken);
			await b(text, onStatus, cancellationToken);
			string text2 = await AdbController.RunShellCaptureAsync(text, "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", cancellationToken);
			if (!m_4512(await AdbController.DumpUiElementsAsync(text, cancellationToken), text2))
			{
				onStatus("Tài khoản chưa đăng nhập trên Facebook Katana -> Tự động đăng nhập...");
				LoginResult loginResult = await FacebookKatanaPhoneLoginService.LoginAccountAsync(account, onStatus, cancellationToken);
				if (!loginResult.Success)
				{
					return new AiVisionRunResult
					{
						Success = false,
						Message = "Đăng nhập thất bại: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				await Task.Delay(3000, cancellationToken);
				await b(text, onStatus, cancellationToken);
			}
			else
			{
				onStatus("Phát hiện tài khoản đã đăng nhập sẵn trên Facebook Katana!");
			}
			await FacebookKatanaPhoneLoginService.EnsureFacebookAppLanguageEnglishAsync(text, onStatus, cancellationToken);
			int num = Math.Max(1, pageSettings.PageCount);
			int num2 = 0;
			List<string> list2 = new List<string>();
			for (int i = 0; i < num; i++)
			{
				cancellationToken.ThrowIfCancellationRequested();
				string text3 = ((num > 1) ? $"[{i + 1}/{num}] " : string.Empty);
				await b(text, onStatus, cancellationToken);
				onStatus(text3 + "Kiểm tra và chuyển về trang cá nhân nếu đang ở Page...");
				await C(text, onStatus, cancellationToken);
				await b(text, onStatus, cancellationToken);
				string text4 = pageSettings.BuildPageName(sequenceIndex + i);
				onStatus(text3 + "Chuẩn bị tạo Page: \"" + text4 + "\"...");
				if (!(await m_4509(text, onStatus, cancellationToken)))
				{
					onStatus(text3 + "Không thể mở tab Menu trên Facebook Katana.");
					if (num == 1)
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = "Không thể mở tab Menu trên Facebook Katana.",
							TinhTrang = "ERROR"
						};
					}
					continue;
				}
				if (!(await B(text, onStatus, cancellationToken)))
				{
					onStatus(text3 + "Không tìm thấy nút Tạo Page trong giao diện Facebook.");
					if (num == 1)
					{
						return new AiVisionRunResult
						{
							Success = false,
							Message = "Không tìm thấy nút Tạo Page trong giao diện Facebook.",
							TinhTrang = "ERROR"
						};
					}
					continue;
				}
				KatanaPageCreationStepResult katanaPageCreationStepResult = await m_4510(text, text4, onStatus, cancellationToken);
				if (katanaPageCreationStepResult.IsLimitBlocked)
				{
					onStatus(text3 + "Dừng kịch bản: Tài khoản bị giới hạn tạo Page từ Facebook (cần nghỉ ngơi).");
					return new AiVisionRunResult
					{
						Success = false,
						Message = "Bị giới hạn tạo Page: Facebook thông báo bạn đã tạo quá nhiều Trang gần đây (Cannot Create Page: You have attempted to create too many Pages recently). Cần cho nick nghỉ ngơi trước khi tạo tiếp.",
						TinhTrang = "LIMIT_PAGE"
					};
				}
				if (katanaPageCreationStepResult.Success)
				{
					num2++;
					list2.Add(text4);
					onStatus($"{text3}Đã tạo xong Page: \"{text4}\" ({num2}/{num}).");
				}
				else
				{
					onStatus(text3 + "Không xác nhận được tạo Page \"" + text4 + "\".");
				}
				if (i < num - 1)
				{
					int num3 = Math.Max(1, pageSettings.MinDelaySeconds);
					int num4 = Math.Max(num3, pageSettings.MaxDelaySeconds);
					int num5 = new Random().Next(num3, num4 + 1);
					onStatus($"Nghỉ {num5}s trước khi tạo Page tiếp theo...");
					await Task.Delay(num5 * 1000, cancellationToken);
				}
			}
			if (num2 > 0)
			{
				return new AiVisionRunResult
				{
					Success = true,
					Message = $"Tạo thành công {num2}/{num} Page ({string.Join(", ", list2)}) trên Android Katana.",
					TinhTrang = "LIVE"
				};
			}
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không tạo được Page nào trên Android Katana (0/{num}) - vui lòng kiểm tra lại thủ công.",
				TinhTrang = "ERROR"
			};
		}
		catch (OperationCanceledException)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Đã dừng kịch bản theo yêu cầu.",
				TinhTrang = "ERROR"
			};
		}
		catch (Exception ex2)
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Lỗi khi tạo Page trên Android: " + ex2.Message,
				TinhTrang = "ERROR"
			};
		}
	}

	private static async Task<bool> m_4509(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		P_1("Mở tab Menu...");
		for (int i = 1; i <= 3; i++)
		{
			await b(P_0, P_1, P_2);
			List<UiElement> source = await AdbController.DumpUiElementsAsync(P_0, P_2);
			if (source.Any((UiElement uiElement2) => (uiElement2.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase) && uiElement2.CenterY < 300) || uiElement2.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Open profile switcher", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase)))
			{
				return true;
			}
			UiElement uiElement = source.FirstOrDefault((UiElement uiElement2) => uiElement2.ContentDesc.Contains("Menu, tab", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase));
			if (uiElement != null)
			{
				await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
			}
			else
			{
				int y = (source.Any((UiElement uiElement2) => uiElement2.ContentDesc.Contains("Facebook logo", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("conversation", StringComparison.OrdinalIgnoreCase) || uiElement2.ResourceId.Contains("search")) ? 180 : 92);
				await AdbController.TapAsync(P_0, 825, y, P_2);
			}
			await Task.Delay(2000, P_2);
			if ((await AdbController.DumpUiElementsAsync(P_0, P_2)).Any((UiElement uiElement2) => (uiElement2.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase) && uiElement2.CenterY < 300) || uiElement2.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Open profile switcher", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase)))
			{
				return true;
			}
		}
		return false;
	}

	private static async Task<bool> a(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		await Task.Delay(1500, P_2);
		List<UiElement> source = await AdbController.DumpUiElementsAsync(P_0, P_2);
		UiElement uiElement = source.FirstOrDefault((UiElement uiElement3) => uiElement3.CenterY < 400 && (uiElement3.Text.Equals("Create", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Equals("Create", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Equals("Tạo", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Equals("Tạo", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("+ Create", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("+ Create", StringComparison.OrdinalIgnoreCase)));
		if (uiElement != null)
		{
			P_1("Bấm chip 'Create' trên thanh Pages...");
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
		}
		else
		{
			int num = 900;
			int num2 = 1600;
			try
			{
				var (num3, num4) = await AdbController.GetScreenSizeAsync(P_0, P_2);
				if (num3 > 0 && num4 > 0)
				{
					num = num3;
					num2 = num4;
				}
			}
			catch
			{
			}
			UiElement uiElement2 = source.FirstOrDefault((UiElement uiElement3) => uiElement3.CenterY < 250 && (uiElement3.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Equals("Pages", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Equals("Search", StringComparison.OrdinalIgnoreCase)));
			int num5 = (int)((double)num * 0.111);
			int num6 = ((uiElement2 != null) ? (uiElement2.CenterY + (int)((double)num2 * 0.058)) : ((int)((double)num2 * 0.116)));
			P_1($"Bấm chip Create trên màn hình Pages (toạ độ {num5}, {num6})...");
			await AdbController.TapAsync(P_0, num5, num6, P_2);
		}
		await Task.Delay(2500, P_2);
		return (await AdbController.DumpUiElementsAsync(P_0, P_2)).Any((UiElement uiElement3) => uiElement3.Text.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Equals("Page name", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("What do you want to name this Page", StringComparison.OrdinalIgnoreCase));
	}

	private static async Task<bool> B(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		P_1("Tìm nút Tạo Page...");
		await b(P_0, P_1, P_2);
		List<UiElement> A = await AdbController.DumpUiElementsAsync(P_0, P_2);
		if (A.Any((UiElement uiElement4) => uiElement4.Text.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Page name", StringComparison.OrdinalIgnoreCase)))
		{
			return true;
		}
		if (A.Any((UiElement uiElement4) => uiElement4.Text.Contains("Pages you manage", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Pages you manage", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("Trang bạn quản lý", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Trang bạn quản lý", StringComparison.OrdinalIgnoreCase) || (uiElement4.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) && uiElement4.CenterY < 200 && A.Any((UiElement uiElement5) => uiElement5.ContentDesc.Equals("Back", StringComparison.OrdinalIgnoreCase)))))
		{
			P_1("Đang ở màn hình quản lý Pages -> Bấm chip Create...");
			if (await a(P_0, P_1, P_2))
			{
				return true;
			}
		}
		UiElement uiElement = A.FirstOrDefault((UiElement uiElement4) => uiElement4.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Tạo trang Facebook", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("Tạo trang Facebook", StringComparison.OrdinalIgnoreCase));
		if (uiElement != null)
		{
			P_1("Bấm 'Create Facebook Page'...");
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
			await Task.Delay(2500, P_2);
			A = await AdbController.DumpUiElementsAsync(P_0, P_2);
			if (A.Any((UiElement uiElement4) => uiElement4.Text.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase)))
			{
				return true;
			}
		}
		UiElement uiElement2 = A.FirstOrDefault((UiElement uiElement4) => uiElement4.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Pages", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Trang", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Trang", StringComparison.OrdinalIgnoreCase));
		if (uiElement2 != null)
		{
			P_1("Bấm vào ô Pages trong Menu...");
			await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_2);
			if (await a(P_0, P_1, P_2))
			{
				return true;
			}
		}
		UiElement uiElement3 = A.FirstOrDefault((UiElement uiElement4) => uiElement4.ContentDesc.Contains("See more", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("See more", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Xem thêm", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("Xem thêm", StringComparison.OrdinalIgnoreCase));
		if (uiElement3 != null)
		{
			P_1("Bấm 'See more' để hiển thị ô Pages...");
			await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_2);
			await Task.Delay(1500, P_2);
			A = await AdbController.DumpUiElementsAsync(P_0, P_2);
			uiElement2 = A.FirstOrDefault((UiElement uiElement4) => uiElement4.Text.Equals("Pages", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Pages", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Trang", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Trang", StringComparison.OrdinalIgnoreCase));
			if (uiElement2 != null)
			{
				P_1("Bấm vào ô Pages...");
				await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_2);
				if (await a(P_0, P_1, P_2))
				{
					return true;
				}
			}
		}
		if (A.Any((UiElement uiElement4) => uiElement4.ContentDesc.Contains("See less", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("See less", StringComparison.OrdinalIgnoreCase)))
		{
			int num = 900;
			int num2 = 1600;
			try
			{
				var (num3, num4) = await AdbController.GetScreenSizeAsync(P_0, P_2);
				if (num3 > 0 && num4 > 0)
				{
					num = num3;
					num2 = num4;
				}
			}
			catch
			{
			}
			int x = (int)((double)num * 0.259);
			int y = (int)((double)num2 * 0.649);
			P_1("Bấm vào ô Pages theo toạ độ Menu...");
			await AdbController.TapAsync(P_0, x, y, P_2);
			if (await a(P_0, P_1, P_2))
			{
				return true;
			}
		}
		P_1("Mở thẳng danh sách Pages qua deeplink fb://pages...");
		await AdbController.RunShellAsync(P_0, "am start -a android.intent.action.VIEW -d \"fb://pages\"", P_2);
		if (await a(P_0, P_1, P_2))
		{
			return true;
		}
		P_1("Thử mở form tạo Page qua deeplink tạo trang trực tiếp...");
		await AdbController.RunShellAsync(P_0, "am start -a android.intent.action.VIEW -d \"fb://facewebmodal/f?href=https://m.facebook.com/pages/create\"", P_2);
		await Task.Delay(3000, P_2);
		A = await AdbController.DumpUiElementsAsync(P_0, P_2);
		if (A.Any((UiElement uiElement4) => uiElement4.Text.Contains("Get started", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Contains("Page name", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Get started", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Contains("Page name", StringComparison.OrdinalIgnoreCase)))
		{
			return true;
		}
		return false;
	}

	private static async Task<KatanaPageCreationStepResult> m_4510(string P_0, string P_1, Action<string> P_2, CancellationToken P_3)
	{
		bool success = false;
		int num = 15;
		for (int i = 1; i <= num; i++)
		{
			P_3.ThrowIfCancellationRequested();
			List<UiElement> list = await AdbController.DumpUiElementsAsync(P_0, P_3);
			if (list.Count == 0)
			{
				await Task.Delay(1500, P_3);
				continue;
			}
			string text = string.Join(" ", list.Select((UiElement uiElement13) => uiElement13.Text + " " + uiElement13.ContentDesc)).ToLowerInvariant();
			if (text.Contains("cannot create page") || text.Contains("too many pages") || text.Contains("attempted to create too many pages") || text.Contains("không thể tạo trang") || text.Contains("quá nhiều trang"))
			{
				P_2("Phát hiện cảnh báo giới hạn: Facebook báo đã tạo quá nhiều Trang gần đây (cần nghỉ ngơi)!");
				return new KatanaPageCreationStepResult
				{
					Success = false,
					IsLimitBlocked = true,
					ErrorMessage = "Bị giới hạn tạo Page: Facebook báo đã tạo quá nhiều Trang gần đây. Cần nghỉ ngơi trước khi tạo tiếp."
				};
			}
			if (text.Contains("get started with a page") || text.Contains("page name"))
			{
				UiElement uiElement = list.FirstOrDefault((UiElement uiElement13) => uiElement13.ClassName.Contains("EditText") || uiElement13.Text.Equals("Page name", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Equals("Page name", StringComparison.OrdinalIgnoreCase));
				if (uiElement != null)
				{
					P_2("Nhập tên Page: \"" + P_1 + "\"...");
					await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_3);
					await Task.Delay(400, P_3);
					await AdbController.ClearTextAsync(P_0, 30, P_3);
					await AdbController.InputTextAsync(P_0, P_1, P_3);
					await Task.Delay(500, P_3);
					await AdbController.HideKeyboardIfShownAsync(P_0, P_3);
					await Task.Delay(500, P_3);
					UiElement? uiElement2 = m_4511(await AdbController.DumpUiElementsAsync(P_0, P_3), "Next");
					int x = uiElement2?.CenterX ?? 450;
					int y = uiElement2?.CenterY ?? 1560;
					P_2("Bấm Next (Tiếp tục)...");
					await AdbController.TapAsync(P_0, x, y, P_3);
					await Task.Delay(3000, P_3);
					continue;
				}
			}
			if (text.Contains("what category best describes") || text.Contains("search for categories") || text.Contains("choose one category"))
			{
				P_2("Chọn danh mục Page (Personal blog / Blogger)...");
				UiElement uiElement3 = list.FirstOrDefault((UiElement uiElement13) => uiElement13.ContentDesc.Contains("Personal blog", StringComparison.OrdinalIgnoreCase) || uiElement13.Text.Contains("Personal blog", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Contains("Blogger", StringComparison.OrdinalIgnoreCase) || uiElement13.Text.Contains("Blogger", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Contains("Product/service", StringComparison.OrdinalIgnoreCase) || uiElement13.Text.Contains("Product/service", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Contains("Art", StringComparison.OrdinalIgnoreCase) || uiElement13.Text.Contains("Art", StringComparison.OrdinalIgnoreCase));
				if (uiElement3 != null)
				{
					await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_3);
					await Task.Delay(1000, P_3);
				}
				else
				{
					UiElement uiElement4 = list.FirstOrDefault((UiElement uiElement13) => uiElement13.ClassName.Contains("EditText"));
					if (uiElement4 != null)
					{
						await AdbController.TapAsync(P_0, uiElement4.CenterX, uiElement4.CenterY, P_3);
						await Task.Delay(300, P_3);
						await AdbController.InputTextAsync(P_0, "Personal blog", P_3);
						await Task.Delay(1000, P_3);
						await AdbController.HideKeyboardIfShownAsync(P_0, P_3);
						await Task.Delay(500, P_3);
					}
				}
				UiElement? uiElement5 = (await AdbController.DumpUiElementsAsync(P_0, P_3)).FirstOrDefault((UiElement uiElement13) => (uiElement13.ClassName.Contains("Button") || uiElement13.ClassName.Contains("View")) && (uiElement13.Text.Equals("Create", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Equals("Create", StringComparison.OrdinalIgnoreCase) || uiElement13.Text.Equals("Tạo", StringComparison.OrdinalIgnoreCase) || uiElement13.ContentDesc.Equals("Tạo", StringComparison.OrdinalIgnoreCase)));
				int x2 = uiElement5?.CenterX ?? 450;
				int y2 = uiElement5?.CenterY ?? 1560;
				P_2("Bấm nút Create (Tạo)...");
				await AdbController.TapAsync(P_0, x2, y2, P_3);
				await Task.Delay(4000, P_3);
				string text2 = string.Join(" ", (await AdbController.DumpUiElementsAsync(P_0, P_3)).Select((UiElement uiElement13) => uiElement13.Text + " " + uiElement13.ContentDesc)).ToLowerInvariant();
				if (text2.Contains("cannot create page") || text2.Contains("too many pages") || text2.Contains("attempted to create too many pages") || text2.Contains("try again later") || text2.Contains("quá nhiều trang") || text2.Contains("không thể tạo trang") || text2.Contains("thử lại sau"))
				{
					P_2("Phát hiện cảnh báo giới hạn: Facebook báo tạo quá nhiều Trang gần đây (cần nghỉ ngơi)!");
					return new KatanaPageCreationStepResult
					{
						Success = false,
						IsLimitBlocked = true,
						ErrorMessage = "Bị giới hạn tạo Page: Facebook báo bạn đã tạo quá nhiều Page gần đây. Cần nghỉ ngơi trước khi tạo tiếp."
					};
				}
			}
			else if (text.Contains("page type") || text.Contains("select the primary use for your page"))
			{
				P_2("Chọn loại Page (Creator)...");
				UiElement uiElement6 = list.FirstOrDefault((UiElement uiElement13) => uiElement13.ContentDesc.Contains("Creator", StringComparison.OrdinalIgnoreCase) || uiElement13.Text.Contains("Creator", StringComparison.OrdinalIgnoreCase));
				if (uiElement6 != null)
				{
					await AdbController.TapAsync(P_0, uiElement6.CenterX, uiElement6.CenterY, P_3);
					await Task.Delay(800, P_3);
				}
				UiElement? uiElement7 = m_4511(list, "Next");
				int x3 = uiElement7?.CenterX ?? 450;
				int y3 = uiElement7?.CenterY ?? 1416;
				await AdbController.TapAsync(P_0, x3, y3, P_3);
				await Task.Delay(3000, P_3);
			}
			else if (text.Contains("finish setting up your page") || text.Contains("success! you've created") || text.Contains("now add more details"))
			{
				success = true;
				P_2("Phát hiện thông báo tạo Page thành công! Đang hoàn tất thiết lập...");
				UiElement? uiElement8 = m_4511(list, "Next");
				int x4 = uiElement8?.CenterX ?? 450;
				int y4 = uiElement8?.CenterY ?? 1560;
				await AdbController.TapAsync(P_0, x4, y4, P_3);
				await Task.Delay(3000, P_3);
			}
			else if (text.Contains("customize your page") || text.Contains("upload cover photo") || text.Contains("upload profile photo"))
			{
				success = true;
				P_2("Bỏ qua bước tải ảnh đại diện / ảnh bìa...");
				UiElement? uiElement9 = m_4511(list, "Next");
				int x5 = uiElement9?.CenterX ?? 450;
				int y5 = uiElement9?.CenterY ?? 1560;
				await AdbController.TapAsync(P_0, x5, y5, P_3);
				await Task.Delay(3000, P_3);
			}
			else if (text.Contains("invite friends") || text.Contains("grow your presence by inviting"))
			{
				success = true;
				P_2("Bỏ qua bước mời bạn bè...");
				UiElement? uiElement10 = m_4511(list, "Next");
				int x6 = uiElement10?.CenterX ?? 450;
				int y6 = uiElement10?.CenterY ?? 1560;
				await AdbController.TapAsync(P_0, x6, y6, P_3);
				await Task.Delay(3000, P_3);
			}
			else
			{
				if (text.Contains("stay informed about your page") || text.Contains("marketing and promotional emails") || text.Contains("page notifications"))
				{
					P_2("Bấm Done hoàn tất tạo Page...");
					UiElement? uiElement11 = m_4511(list, "Done");
					int x7 = uiElement11?.CenterX ?? 450;
					int y7 = uiElement11?.CenterY ?? 1560;
					await AdbController.TapAsync(P_0, x7, y7, P_3);
					await Task.Delay(5000, P_3);
					return new KatanaPageCreationStepResult
					{
						Success = true
					};
				}
				if (text.Contains("professional dashboard") || text.Contains("edit cover photo") || text.Contains("0 followers") || text.Contains("add cover photo"))
				{
					P_2("Đã vào giao diện quản lý Page mới tạo!");
					return new KatanaPageCreationStepResult
					{
						Success = true
					};
				}
				UiElement uiElement12 = m_4511(list, "Next", "Done", "Tiếp tục", "Xong");
				if (uiElement12 != null)
				{
					await AdbController.TapAsync(P_0, uiElement12.CenterX, uiElement12.CenterY, P_3);
					await Task.Delay(3000, P_3);
				}
				else
				{
					await Task.Delay(2000, P_3);
				}
			}
		}
		return new KatanaPageCreationStepResult
		{
			Success = success
		};
	}

	private static UiElement? m_4511(List<UiElement> P_0, params string[] keywords)
	{
		return P_0.FirstOrDefault((UiElement uiElement) => (uiElement.ClassName.Contains("Button") || uiElement.ClassName.Contains("View")) && keywords.Any((string value) => uiElement.Text.Equals(value, StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Equals(value, StringComparison.OrdinalIgnoreCase)));
	}

	private static async Task b(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		_ = 10;
		try
		{
			List<UiElement> list = await AdbController.DumpUiElementsAsync(P_0, P_2);
			if (list.Count != 0)
			{
				UiElement uiElement = list.FirstOrDefault((UiElement uiElement4) => uiElement4.ContentDesc.Equals("Close", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Close", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Đóng", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Đóng", StringComparison.OrdinalIgnoreCase));
				if (uiElement != null && uiElement.CenterY < 300)
				{
					P_1("Phát hiện popup che màn hình -> Bấm Close...");
					await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
					await Task.Delay(1500, P_2);
				}
				if ((await AdbController.DumpUiElementsAsync(P_0, P_2)).Any((UiElement uiElement4) => (uiElement4.Text.Equals("Chats", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Chats", StringComparison.OrdinalIgnoreCase)) && uiElement4.CenterY < 200))
				{
					P_1("Đang ở màn hình tin nhắn Chats -> Nhấn Back quay về Facebook...");
					await AdbController.RunShellAsync(P_0, "input keyevent 4", P_2);
					await Task.Delay(1500, P_2);
				}
				list = await AdbController.DumpUiElementsAsync(P_0, P_2);
				UiElement uiElement2 = list.FirstOrDefault((UiElement uiElement4) => uiElement4.Text.Equals("OK", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Save", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Not now", StringComparison.OrdinalIgnoreCase) || uiElement4.ContentDesc.Equals("Not now", StringComparison.OrdinalIgnoreCase));
				if (uiElement2 != null && list.Any((UiElement uiElement4) => uiElement4.Text.Contains("login info", StringComparison.OrdinalIgnoreCase)))
				{
					P_1("Bỏ qua hộp thoại lưu thông tin đăng nhập...");
					await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_2);
					await Task.Delay(1500, P_2);
				}
				UiElement uiElement3 = list.FirstOrDefault((UiElement uiElement4) => uiElement4.Text.Equals("Don't allow", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Allow", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Cho phép", StringComparison.OrdinalIgnoreCase) || uiElement4.Text.Equals("Không cho phép", StringComparison.OrdinalIgnoreCase));
				if (uiElement3 != null && list.Any((UiElement uiElement4) => uiElement4.ResourceId.Contains("permission")))
				{
					await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_2);
					await Task.Delay(1000, P_2);
				}
			}
		}
		catch
		{
		}
	}

	private static bool m_4512(List<UiElement> P_0, string P_1)
	{
		if (P_0 == null || P_0.Count == 0)
		{
			return false;
		}
		bool flag = P_0.Any((UiElement uiElement) => uiElement.ResourceId.Contains("login_password") || uiElement.ResourceId.Contains("m_login_password") || uiElement.Text.Equals("Log In", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Equals("Log In", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Forgot Password", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Forgot Password", StringComparison.OrdinalIgnoreCase));
		if (flag)
		{
			return false;
		}
		if (P_0.Any((UiElement uiElement) => uiElement.ContentDesc.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("What's on your mind", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Search Facebook", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Open profile switcher", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Settings & privacy", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Menu", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Home, tab", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Facebook logo", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc.Contains("Get started with a Page", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Page name", StringComparison.OrdinalIgnoreCase) || uiElement.ResourceId.Contains("tab_bar") || uiElement.ResourceId.Contains("feed_tab")))
		{
			return true;
		}
		if (P_1.Contains("FbMainTabActivity") && !flag)
		{
			return true;
		}
		return false;
	}

	private static async Task C(string P_0, Action<string> P_1, CancellationToken P_2)
	{
		_ = 9;
		try
		{
			List<UiElement> source = await AdbController.DumpUiElementsAsync(P_0, P_2);
			bool flag = source.Any((UiElement uiElement3) => uiElement3.ContentDesc.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("Professional dashboard", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Promote Page", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("Promote Page", StringComparison.OrdinalIgnoreCase));
			bool flag2 = source.Any((UiElement uiElement3) => uiElement3.ContentDesc.Equals("Menu", StringComparison.OrdinalIgnoreCase)) && !source.Any((UiElement uiElement3) => uiElement3.ContentDesc.Contains("Create Facebook Page", StringComparison.OrdinalIgnoreCase));
			if (!(flag | flag2))
			{
				return;
			}
			P_1("Phát hiện đang ở giao diện Page -> Chuyển về Profile cá nhân chính...");
			await m_4509(P_0, P_1, P_2);
			await Task.Delay(1500, P_2);
			UiElement? uiElement = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement3) => uiElement3.ContentDesc.Contains("profile switcher", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Switch profile", StringComparison.OrdinalIgnoreCase) || (uiElement3.CenterX > 750 && uiElement3.CenterY > 200 && uiElement3.CenterY < 380));
			int x = uiElement?.CenterX ?? 810;
			int y = uiElement?.CenterY ?? 320;
			P_1("Bấm mở danh sách chuyển profile...");
			await AdbController.TapAsync(P_0, x, y, P_2);
			await Task.Delay(2000, P_2);
			source = await AdbController.DumpUiElementsAsync(P_0, P_2);
			UiElement uiElement2 = source.FirstOrDefault((UiElement uiElement3) => uiElement3.CenterY > 900 && uiElement3.CenterY < 1500 && !string.IsNullOrWhiteSpace(uiElement3.ContentDesc) && !uiElement3.ContentDesc.Contains("Create Facebook profile", StringComparison.OrdinalIgnoreCase) && !uiElement3.ContentDesc.Contains("Accounts Center", StringComparison.OrdinalIgnoreCase) && !uiElement3.ContentDesc.Contains("See all profiles", StringComparison.OrdinalIgnoreCase));
			if (uiElement2 == null)
			{
				List<UiElement> list = source.Where((UiElement uiElement3) => uiElement3.CenterY > 900 && uiElement3.CenterY < 1450 && !string.IsNullOrWhiteSpace(uiElement3.ContentDesc) && !uiElement3.ContentDesc.Contains("Create Facebook profile", StringComparison.OrdinalIgnoreCase) && !uiElement3.ContentDesc.Contains("Accounts Center", StringComparison.OrdinalIgnoreCase)).ToList();
				if (list.Count > 1)
				{
					uiElement2 = list[1];
				}
				else if (list.Count == 1)
				{
					uiElement2 = list[0];
				}
			}
			if (uiElement2 != null)
			{
				P_1("Chuyển sang profile cá nhân: \"" + uiElement2.ContentDesc + "\"...");
				await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_2);
				await Task.Delay(4000, P_2);
				await b(P_0, P_1, P_2);
			}
		}
		catch
		{
		}
	}
}
