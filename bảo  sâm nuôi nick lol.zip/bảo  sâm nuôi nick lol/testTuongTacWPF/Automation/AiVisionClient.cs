using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class AiVisionClient
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_2923
	{
		public static readonly m_2923 A = new m_2923();

		public static Func<string, int, string> m_2925;

		public static Func<UiElement, int, string> m_2926;

		internal string m_2927(string P_0, int P_1)
		{
			return $"{P_1 + 1}. {P_0}";
		}

		internal string m_2928(UiElement P_0, int P_1)
		{
			return $"{P_1}: \"{m_2920(P_0.Label, 50)}\"";
		}
	}

	[CompilerGenerated]
	private sealed class m_2924
	{
		public string A;

		public string a;

		public string B;

		internal HttpRequestMessage m_2929()
		{
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, A);
			httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", a);
			httpRequestMessage.Content = new StringContent(B, Encoding.UTF8, "application/json");
			return httpRequestMessage;
		}
	}

	[CompilerGenerated]
	private sealed class B
	{
		public string A;

		public string a;

		public string m_2930;

		public string b;

		internal HttpRequestMessage m_2931()
		{
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, A);
			m_2911(httpRequestMessage, a, m_2930);
			httpRequestMessage.Headers.Add("anthropic-version", "2023-06-01");
			httpRequestMessage.Content = new StringContent(b, Encoding.UTF8, "application/json");
			return httpRequestMessage;
		}
	}

	[CompilerGenerated]
	private sealed class b
	{
		public string A;

		public AiVisionSettings m_2932;

		public string a;

		internal HttpRequestMessage m_2933()
		{
			return new HttpRequestMessage(HttpMethod.Post, A)
			{
				Headers = { { "X-goog-api-key", m_2932.GoogleApiKey } },
				Content = new StringContent(a, Encoding.UTF8, "application/json")
			};
		}
	}

	[CompilerGenerated]
	private sealed class C
	{
		public string A;

		internal bool m_2934(CustomAiProvider P_0)
		{
			return P_0.Name == A;
		}
	}

	private static readonly HttpClient A = new HttpClient(new SocketsHttpHandler
	{
		PooledConnectionLifetime = TimeSpan.Zero
	});

	private const int m_2908 = 400;

	private const int a = 3;

	public static Task<AiVisionAction> DecideNextActionAsync(AiVisionSettings settings, byte[] screenshotPng, string goal, IReadOnlyList<string> history, IReadOnlyList<UiElement> elements, CancellationToken cancellationToken)
	{
		return DecideNextActionAsync(settings, screenshotPng, goal, history, elements, AiVisionTargetKind.Phone, cancellationToken);
	}

	public static Task<AiVisionAction> DecideNextActionAsync(AiVisionSettings settings, byte[] screenshotPng, string goal, IReadOnlyList<string> history, IReadOnlyList<UiElement> elements, AiVisionTargetKind target, CancellationToken cancellationToken)
	{
		return m_2909(settings, screenshotPng, goal, history, elements, target, cancellationToken);
	}

	private static async Task<AiVisionAction> m_2909(AiVisionSettings P_0, byte[] P_1, string P_2, IReadOnlyList<string> P_3, IReadOnlyList<UiElement> P_4, AiVisionTargetKind P_5, CancellationToken P_6)
	{
		string value = ((P_3.Count == 0) ? "(chưa làm bước nào)" : string.Join("\n", P_3.Select((string value4, int num2) => $"{num2 + 1}. {value4}")));
		bool flag = P_5 == AiVisionTargetKind.Phone;
		string value2 = (flag ? "điện thoại Android" : "trang web đang mở trong trình duyệt Chrome");
		string text = (flag ? "(không phát hiện được phần tử nào - có thể màn hình dạng WebView/game, chỉ dựa vào ảnh)" : "(không phát hiện được phần tử nào - chỉ dựa vào ảnh)");
		string value3 = ((P_4.Count == 0) ? text : string.Join("\n", P_4.Take(40).Select((UiElement uiElement, int value4) => $"{value4}: \"{m_2920(uiElement.Label, 50)}\"")));
		string text2 = (flag ? "tap|swipe|text|keyevent|wait|done" : "tap|text|keyevent|navigate|wait|done");
		bool flag2 = P_0.SendScreenshot || P_4.Count == 0;
		string text3 = $"Nhiệm vụ trên {value2}: {P_2}\n\nĐã làm:\n{value}\n\nPhần tử bấm được trên màn hình HIỆN TẠI (đánh số từ 0):\n{value3}\n\n" + (flag2 ? "Nhìn ảnh đính kèm + danh sách trên, quyết định 1 hành động DUY NHẤT tiếp theo. " : "KHÔNG có ảnh đính kèm lần này - chỉ dựa vào danh sách phần tử ở trên, quyết định 1 hành động DUY NHẤT tiếp theo. ") + "Chỉ trả lời đúng 1 JSON, không thêm chữ nào khác:\n{\"action\": \"" + text2 + "\", \"elementIndex\": null, \"x\": 0, \"y\": 0, \"x2\": 0, \"y2\": 0, \"text\": \"\", \"reason\": \"\"}\n- tap phần tử có trong danh sách: set đúng \"elementIndex\" (chính xác hơn đoán toạ độ), bỏ qua x/y.\n" + (flag2 ? "- tap chỗ KHÔNG có trong danh sách: \"elementIndex\": null, x/y theo thang TỈ LỆ 0-1000 so với ảnh (0=trái/trên, 1000=phải/dưới), KHÔNG dùng pixel thật.\n" : "- không có phần tử nào phù hợp trong danh sách để tap: KHÔNG đoán toạ độ tap (không có ảnh để tham chiếu) - trả về \"wait\" để chờ chụp lại, hoặc \"keyevent\"/\"navigate\" nếu phù hợp.\n") + (flag ? "- swipe: (x,y)→(x2,y2), luôn theo thang 0-1000 - vẫn dùng được dù không có ảnh, ước lượng theo mô tả mục tiêu (vd \"vuốt xuống\" ≈ (500,800)→(500,200)).\n" : "") + "- text: gõ \"text\" (chữ không dấu/số/ký tự cơ bản) - CHỈ khi bước TRƯỚC vừa tap đúng ô nhập, chưa chắc ô nào focus thì tap trước, đừng gõ ngay.\n" + (flag ? "- keyevent: phím cứng Android, \"text\" = tên keycode (BACK, HOME, ENTER...).\n" : "- keyevent: phím bàn phím, \"text\" = tên phím (Enter, Escape, Tab...).\n- navigate: mở thẳng URL trong \"text\" - chỉ khi biết chắc URL.\n") + "- wait: chờ tải/hiệu ứng xong rồi chụp lại.\n- done: đã xong mục tiêu.\n";
		byte[] screenshotPng = (flag2 ? m_2910(P_1) : null);
		List<string> list = ((P_0.PriorityTargets.Count > 0) ? P_0.PriorityTargets : new List<string> { "Claude" });
		AiVisionAction aiVisionAction = null;
		Exception ex = null;
		foreach (string item in list)
		{
			for (int num = 1; num <= 3; num++)
			{
				if (num > 1)
				{
					await Task.Delay(1500, P_6);
				}
				try
				{
					aiVisionAction = m_2922(await m_2914(P_0, item, screenshotPng, text3, P_6));
				}
				catch (Exception ex2) when (!(ex2 is OperationCanceledException))
				{
					ex = ex2;
					continue;
				}
				break;
			}
			if (aiVisionAction != null)
			{
				break;
			}
		}
		if (aiVisionAction == null)
		{
			throw new InvalidOperationException((list.Count != 1) ? $"Cả {list.Count} mục tiêu AI đã bật đều lỗi - lỗi gần nhất: {ex?.Message}" : (ex?.Message ?? "Không gọi được AI."));
		}
		return aiVisionAction;
	}

	private static byte[] m_2910(byte[] P_0)
	{
		try
		{
			BitmapFrame bitmapFrame = BitmapDecoder.Create(new MemoryStream(P_0), BitmapCreateOptions.None, BitmapCacheOption.OnLoad).Frames[0];
			double num = Math.Min(1.0, 400.0 / (double)Math.Max(bitmapFrame.PixelWidth, bitmapFrame.PixelHeight));
			BitmapSource source = ((num < 1.0) ? ((BitmapSource)new TransformedBitmap(bitmapFrame, new ScaleTransform(num, num))) : ((BitmapSource)bitmapFrame));
			JpegBitmapEncoder jpegBitmapEncoder = new JpegBitmapEncoder
			{
				QualityLevel = 40
			};
			jpegBitmapEncoder.Frames.Add(BitmapFrame.Create(source));
			using MemoryStream memoryStream = new MemoryStream();
			jpegBitmapEncoder.Save(memoryStream);
			return memoryStream.ToArray();
		}
		catch
		{
			return P_0;
		}
	}

	private static void m_2911(HttpRequestMessage P_0, string P_1, string P_2)
	{
		if (string.Equals(P_1, "HHTechAPI", StringComparison.OrdinalIgnoreCase))
		{
			P_0.Headers.Authorization = new AuthenticationHeaderValue("Bearer", P_2);
		}
		else
		{
			P_0.Headers.Add("x-api-key", P_2);
		}
	}

	private static async Task<string> m_2912(string P_0, string P_1, string P_2, string P_3, byte[]? screenshotPng, string P_5, CancellationToken P_6)
	{
		List<object> list = new List<object>();
		if (screenshotPng != null)
		{
			list.Add(new ClaudeImageContentBlock
			{
				Source = new ClaudeImageSource
				{
					MediaType = "image/jpeg",
					Data = Convert.ToBase64String(screenshotPng)
				}
			});
		}
		list.Add(new ClaudeTextContentBlock
		{
			Text = P_5
		});
		ClaudeRequest claudeRequest = new ClaudeRequest();
		claudeRequest.Model = P_2;
		claudeRequest.MaxTokens = 4096;
		claudeRequest.Messages = new object[1]
		{
			new ClaudeMessage
			{
				Role = "user",
				Content = list.ToArray()
			}
		};
		ClaudeRequest value = claudeRequest;
		string b2 = JsonSerializer.Serialize(value);
		using HttpResponseMessage httpResponseMessage = await m_2921(P_3, () =>
		{
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, P_0);
			m_2911(httpRequestMessage, P_3, P_1);
			httpRequestMessage.Headers.Add("anthropic-version", "2023-06-01");
			httpRequestMessage.Content = new StringContent(b2, Encoding.UTF8, "application/json");
			return httpRequestMessage;
		}, P_6);
		string text = await httpResponseMessage.Content.ReadAsStringAsync(P_6);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			throw new InvalidOperationException($"Lỗi gọi API AI Vision ({P_3}, {(int)httpResponseMessage.StatusCode}): {text}");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		string? text2 = jsonDocument.RootElement.GetProperty("content")[0].GetProperty("text").GetString();
		if (string.IsNullOrWhiteSpace(text2))
		{
			throw new InvalidOperationException("AI (" + P_3 + ") không trả về nội dung gì.");
		}
		return text2;
	}

	private static async Task<string> m_2913(AiVisionSettings P_0, byte[]? screenshotPng, string P_2, CancellationToken P_3)
	{
		List<object> list = new List<object>();
		if (screenshotPng != null)
		{
			list.Add(new GeminiInlineDataPart
			{
				InlineData = new GeminiInlineData
				{
					MimeType = "image/jpeg",
					Data = Convert.ToBase64String(screenshotPng)
				}
			});
		}
		list.Add(new GeminiTextPart
		{
			Text = P_2
		});
		GeminiRequest geminiRequest = new GeminiRequest();
		geminiRequest.Contents = new object[1]
		{
			new GeminiContent
			{
				Role = "user",
				Parts = list.ToArray()
			}
		};
		GeminiRequest value = geminiRequest;
		string A = "https://generativelanguage.googleapis.com/v1beta/models/" + Uri.EscapeDataString(P_0.GoogleModel) + ":generateContent";
		string a = JsonSerializer.Serialize(value);
		using HttpResponseMessage httpResponseMessage = await m_2921("Gemini", () => new HttpRequestMessage(HttpMethod.Post, A)
		{
			Headers = { { "X-goog-api-key", P_0.GoogleApiKey } },
			Content = new StringContent(a, Encoding.UTF8, "application/json")
		}, P_3);
		string text = await httpResponseMessage.Content.ReadAsStringAsync(P_3);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			throw new InvalidOperationException($"Lỗi gọi API AI Vision (Gemini, {(int)httpResponseMessage.StatusCode}): {text}");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		string? text2 = jsonDocument.RootElement.GetProperty("candidates")[0].GetProperty("content").GetProperty("parts")[0].GetProperty("text").GetString();
		if (string.IsNullOrWhiteSpace(text2))
		{
			throw new InvalidOperationException("AI (Gemini) không trả về nội dung gì.");
		}
		return text2;
	}

	private static async Task<string> m_2914(AiVisionSettings P_0, string P_1, byte[]? screenshotPng, string P_3, CancellationToken P_4)
	{
		switch (P_1)
		{
		case "Claude":
			return await m_2912("https://api.anthropic.com/v1/messages", P_0.ApiKey, P_0.Model, "Claude", screenshotPng, P_3, P_4);
		case "Gemini":
			return await m_2913(P_0, screenshotPng, P_3, P_4);
		case "HHTechApi":
			return await m_2912("https://hhtechapi.net/v1/messages", P_0.HHTechApiKey, P_0.HHTechModel, "HHTechAPI", screenshotPng, P_3, P_4);
		case "VietApi":
			return await m_2915("https://api.vietapi.tech/v1/chat/completions", P_0.VietApiKey, P_0.VietApiModel, "VietAPI", screenshotPng, P_3, P_4);
		case "Custom":
			return (!string.Equals(P_0.CustomFormat, "Anthropic", StringComparison.OrdinalIgnoreCase)) ? (await m_2915(P_0.CustomApiUrl, P_0.CustomApiKey, P_0.CustomModel, "Tuỳ chỉnh", screenshotPng, P_3, P_4)) : (await m_2912(P_0.CustomApiUrl, P_0.CustomApiKey, P_0.CustomModel, "Tuỳ chỉnh", screenshotPng, P_3, P_4));
		default:
			if (P_1.StartsWith("Custom:", StringComparison.Ordinal))
			{
				string A = P_1.Substring("Custom:".Length);
				CustomAiProvider customAiProvider = P_0.SavedCustomProviders.FirstOrDefault((CustomAiProvider customAiProvider2) => customAiProvider2.Name == A);
				if (customAiProvider == null)
				{
					throw new InvalidOperationException("Cấu hình Tuỳ chỉnh đã lưu \"" + A + "\" không còn tồn tại.");
				}
				return (!string.Equals(customAiProvider.Format, "Anthropic", StringComparison.OrdinalIgnoreCase)) ? (await m_2915(customAiProvider.ApiUrl, customAiProvider.ApiKey, customAiProvider.Model, "Tuỳ chỉnh (" + A + ")", screenshotPng, P_3, P_4)) : (await m_2912(customAiProvider.ApiUrl, customAiProvider.ApiKey, customAiProvider.Model, "Tuỳ chỉnh (" + A + ")", screenshotPng, P_3, P_4));
			}
			if (P_1.StartsWith("CliProxy:", StringComparison.Ordinal))
			{
				string text = P_1.Substring("CliProxy:".Length);
				if (!CliProxyApiController.IsExeAvailable)
				{
					throw new InvalidOperationException("Thiếu file cần thiết cho mục \"AI Đăng Nhập Trực Tiếp\" - liên hệ hỗ trợ.");
				}
				await CliProxyApiController.EnsureServerReadyAsync(P_4);
				return await m_2915(CliProxyApiController.LocalChatEndpointUrl, CliProxyApiController.GetLocalApiKey(), text, "AI Đăng Nhập Trực Tiếp (" + text + ")", screenshotPng, P_3, P_4);
			}
			throw new InvalidOperationException("Không nhận diện được mục tiêu AI \"" + P_1 + "\".");
		}
	}

	private static async Task<string> m_2915(string P_0, string P_1, string P_2, string P_3, byte[]? screenshotPng, string P_5, CancellationToken P_6)
	{
		List<object> list = new List<object>();
		if (screenshotPng != null)
		{
			list.Add(new OpenAiImageUrlContentBlock
			{
				ImageUrl = new OpenAiImageUrl
				{
					Url = "data:image/jpeg;base64," + Convert.ToBase64String(screenshotPng)
				}
			});
		}
		list.Add(new OpenAiTextContentBlock
		{
			Text = P_5
		});
		OpenAiChatRequest openAiChatRequest = new OpenAiChatRequest();
		openAiChatRequest.Model = P_2;
		openAiChatRequest.MaxTokens = 4096;
		openAiChatRequest.Messages = new object[1]
		{
			new OpenAiChatMessage
			{
				Role = "user",
				Content = list.ToArray()
			}
		};
		OpenAiChatRequest value = openAiChatRequest;
		string B = JsonSerializer.Serialize(value);
		using HttpResponseMessage httpResponseMessage = await m_2921(P_3, () =>
		{
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, P_0);
			httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", P_1);
			httpRequestMessage.Content = new StringContent(B, Encoding.UTF8, "application/json");
			return httpRequestMessage;
		}, P_6);
		string text = await httpResponseMessage.Content.ReadAsStringAsync(P_6);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			throw new InvalidOperationException($"Lỗi gọi API AI Vision ({P_3}, {(int)httpResponseMessage.StatusCode}): {text}");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		string? text2 = jsonDocument.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
		if (string.IsNullOrWhiteSpace(text2))
		{
			throw new InvalidOperationException("AI (" + P_3 + ") không trả về nội dung gì.");
		}
		return text2;
	}

	public static async Task<AiVisionTestResult> TestConnectionAsync(string provider, string apiKey, string model, CancellationToken cancellationToken, string? customUrl = null, string? customFormat = null)
	{
		if (string.IsNullOrWhiteSpace(apiKey))
		{
			return new AiVisionTestResult
			{
				Message = "Chưa nhập API Key."
			};
		}
		if (string.IsNullOrWhiteSpace(model))
		{
			return new AiVisionTestResult
			{
				Message = "Chưa nhập Model."
			};
		}
		if (provider == "Custom" && string.IsNullOrWhiteSpace(customUrl))
		{
			return new AiVisionTestResult
			{
				Message = "Chưa nhập Endpoint URL."
			};
		}
		Stopwatch stopwatch = Stopwatch.StartNew();
		try
		{
			string text;
			switch (provider)
			{
			case "Gemini":
				text = await m_2919(apiKey, model, cancellationToken);
				break;
			case "HHTechApi":
				text = await m_2917("https://hhtechapi.net/v1/messages", apiKey, model, "HHTechAPI", cancellationToken);
				break;
			case "VietApi":
				text = await m_2918("https://api.vietapi.tech/v1/chat/completions", apiKey, model, "VietAPI", cancellationToken);
				break;
			case "Custom":
			{
				string text2 = ((!string.Equals(customFormat, "Anthropic", StringComparison.OrdinalIgnoreCase)) ? (await m_2918(customUrl, apiKey, model, "Tuỳ chỉnh", cancellationToken)) : (await m_2917(customUrl, apiKey, model, "Tuỳ chỉnh", cancellationToken)));
				text = text2;
				break;
			}
			case "GeminiAntigravity":
				text = await m_2916(model, cancellationToken);
				break;
			default:
				text = await m_2917("https://api.anthropic.com/v1/messages", apiKey, model, "Claude", cancellationToken);
				break;
			}
			string text3 = text;
			stopwatch.Stop();
			return new AiVisionTestResult
			{
				Success = true,
				ElapsedSeconds = stopwatch.Elapsed.TotalSeconds,
				Message = "Trả lời: \"" + m_2920(text3.Trim(), 60) + "\""
			};
		}
		catch (Exception ex)
		{
			stopwatch.Stop();
			return new AiVisionTestResult
			{
				Success = false,
				ElapsedSeconds = stopwatch.Elapsed.TotalSeconds,
				Message = ex.Message
			};
		}
	}

	private static async Task<string> m_2916(string P_0, CancellationToken P_1)
	{
		if (!CliProxyApiController.IsExeAvailable)
		{
			throw new InvalidOperationException("Thiếu file cần thiết cho mục \"AI Đăng Nhập Trực Tiếp\" - liên hệ hỗ trợ.");
		}
		if (string.IsNullOrWhiteSpace(P_0))
		{
			throw new InvalidOperationException("Chưa chọn model nào để kiểm tra.");
		}
		await CliProxyApiController.EnsureServerReadyAsync(P_1);
		if (CliProxyApiController.ListLoggedInAccounts().Count == 0 && CliProxyApiController.ListClaudeAccounts().Count == 0)
		{
			throw new InvalidOperationException("Chưa đăng nhập tài khoản nào - bấm \"Đăng nhập Google (Antigravity)\" hoặc \"Đăng nhập Claude\" trước.");
		}
		return await m_2918(CliProxyApiController.LocalChatEndpointUrl, CliProxyApiController.GetLocalApiKey(), P_0, "AI Đăng Nhập Trực Tiếp (" + P_0 + ")", P_1);
	}

	private static async Task<string> m_2917(string P_0, string P_1, string P_2, string P_3, CancellationToken P_4)
	{
		ClaudeRequest claudeRequest = new ClaudeRequest();
		claudeRequest.Model = P_2;
		claudeRequest.MaxTokens = 16;
		claudeRequest.Messages = new object[1]
		{
			new ClaudeMessage
			{
				Role = "user",
				Content = new object[1]
				{
					new ClaudeTextContentBlock
					{
						Text = "Trả lời đúng 1 chữ: OK"
					}
				}
			}
		};
		string content = JsonSerializer.Serialize(claudeRequest);
		using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, P_0);
		m_2911(httpRequestMessage, P_3, P_1);
		httpRequestMessage.Headers.Add("anthropic-version", "2023-06-01");
		httpRequestMessage.Content = new StringContent(content, Encoding.UTF8, "application/json");
		using HttpResponseMessage httpResponseMessage = await A.SendAsync(httpRequestMessage, P_4);
		string text = await httpResponseMessage.Content.ReadAsStringAsync(P_4);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			throw new InvalidOperationException($"{P_3} trả lỗi {(int)httpResponseMessage.StatusCode}: {m_2920(text, 200)}");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		return jsonDocument.RootElement.GetProperty("content")[0].GetProperty("text").GetString() ?? "";
	}

	private static async Task<string> m_2918(string P_0, string P_1, string P_2, string P_3, CancellationToken P_4)
	{
		OpenAiChatRequest openAiChatRequest = new OpenAiChatRequest();
		openAiChatRequest.Model = P_2;
		openAiChatRequest.MaxTokens = 16;
		openAiChatRequest.Messages = new object[1]
		{
			new OpenAiChatMessage
			{
				Role = "user",
				Content = "Trả lời đúng 1 chữ: OK"
			}
		};
		string content = JsonSerializer.Serialize(openAiChatRequest);
		using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, P_0);
		httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", P_1);
		httpRequestMessage.Content = new StringContent(content, Encoding.UTF8, "application/json");
		using HttpResponseMessage httpResponseMessage = await A.SendAsync(httpRequestMessage, P_4);
		string text = await httpResponseMessage.Content.ReadAsStringAsync(P_4);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			throw new InvalidOperationException($"{P_3} trả lỗi {(int)httpResponseMessage.StatusCode}: {m_2920(text, 200)}");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		return jsonDocument.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString() ?? "";
	}

	private static async Task<string> m_2919(string P_0, string P_1, CancellationToken P_2)
	{
		GeminiRequest geminiRequest = new GeminiRequest();
		geminiRequest.Contents = new object[1]
		{
			new GeminiContent
			{
				Role = "user",
				Parts = new object[1]
				{
					new GeminiTextPart
					{
						Text = "Trả lời đúng 1 chữ: OK"
					}
				}
			}
		};
		string requestUri = "https://generativelanguage.googleapis.com/v1beta/models/" + Uri.EscapeDataString(P_1) + ":generateContent";
		string content = JsonSerializer.Serialize(geminiRequest);
		using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri);
		httpRequestMessage.Headers.Add("X-goog-api-key", P_0);
		httpRequestMessage.Content = new StringContent(content, Encoding.UTF8, "application/json");
		using HttpResponseMessage httpResponseMessage = await A.SendAsync(httpRequestMessage, P_2);
		string text = await httpResponseMessage.Content.ReadAsStringAsync(P_2);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			throw new InvalidOperationException($"Gemini trả lỗi {(int)httpResponseMessage.StatusCode}: {m_2920(text, 200)}");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		return jsonDocument.RootElement.GetProperty("candidates")[0].GetProperty("content").GetProperty("parts")[0].GetProperty("text").GetString() ?? "";
	}

	private static string m_2920(string P_0, int P_1)
	{
		if (P_0.Length > P_1)
		{
			return P_0.Substring(0, P_1) + "...";
		}
		return P_0;
	}

	private static async Task<HttpResponseMessage> m_2921(string P_0, Func<HttpRequestMessage> P_1, CancellationToken P_2)
	{
		for (int i = 1; i <= 3; i++)
		{
			P_2.ThrowIfCancellationRequested();
			try
			{
				using HttpRequestMessage request = P_1();
				HttpResponseMessage httpResponseMessage = await A.SendAsync(request, P_2);
				if ((httpResponseMessage.StatusCode != HttpStatusCode.TooManyRequests && httpResponseMessage.StatusCode < HttpStatusCode.InternalServerError) || i == 3)
				{
					return httpResponseMessage;
				}
				httpResponseMessage.Dispose();
			}
			catch (OperationCanceledException)
			{
				throw;
			}
			catch (HttpRequestException ex2) when (i == 3)
			{
				throw new InvalidOperationException($"Lỗi kết nối API AI Vision ({P_0}) sau {3} lần thử: {ex2.Message}", ex2);
			}
			catch (HttpRequestException)
			{
			}
			await Task.Delay(TimeSpan.FromSeconds(i * 2), P_2);
		}
		throw new InvalidOperationException($"Không gọi được API AI Vision ({P_0}) sau {3} lần thử.");
	}

	private static AiVisionAction m_2922(string P_0)
	{
		int num = P_0.IndexOf('{');
		int num2 = P_0.LastIndexOf('}');
		if (num < 0 || num2 <= num)
		{
			throw new InvalidOperationException("AI không trả về JSON hợp lệ: " + P_0);
		}
		string text = P_0.Substring(num, num2 - num + 1);
		return JsonSerializer.Deserialize<AiVisionAction>(text, new JsonSerializerOptions
		{
			PropertyNameCaseInsensitive = true
		}) ?? throw new InvalidOperationException("Không parse được hành động từ AI: " + text);
	}
}
