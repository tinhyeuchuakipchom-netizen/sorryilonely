namespace testTuongTacWPF.Automation;

public enum PageNameMode
{
	RandomVietnamese,
	RandomEnglish,
	CustomList
}
