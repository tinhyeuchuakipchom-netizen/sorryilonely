using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class BaoSamApiClient : IAntidetectBrowserClient
{
	private readonly BaoSamBrowserSettings A;

	private readonly HttpClient m_3264;

	private const string m_3265 = "--disable-notifications";

	private const int m_3266 = 3;

	public BaoSamApiClient(BaoSamBrowserSettings settings)
	{
		A = settings;
		SocketsHttpHandler handler = new SocketsHttpHandler
		{
			PooledConnectionLifetime = TimeSpan.Zero
		};
		m_3264 = new HttpClient(handler)
		{
			Timeout = TimeSpan.FromSeconds(60L)
		};
		m_3264.DefaultRequestHeaders.UserAgent.ParseAdd("FastBoxPhone/1.0");
	}

	public async Task<bool> CheckApiAliveAsync()
	{
		try
		{
			using HttpResponseMessage httpResponseMessage = await m_3268(A.ApiUrl + "/api/v1/profiles?page=1&page_size=1");
			return httpResponseMessage.IsSuccessStatusCode;
		}
		catch
		{
			return false;
		}
	}

	public async Task<List<string>> GetRunningProfileNamesAsync()
	{
		List<string> list = new List<string>();
		try
		{
			using HttpResponseMessage httpResponseMessage = await m_3268(A.ApiUrl + "/api/v1/profiles?page=1&page_size=500");
			string text = await httpResponseMessage.Content.ReadAsStringAsync();
			m_3267(httpResponseMessage, text);
			using JsonDocument jsonDocument = JsonDocument.Parse(text);
			if (!m_3271(jsonDocument.RootElement, "data", out var jsonElement))
			{
				return list;
			}
			JsonElement jsonElement2 = jsonElement;
			if (jsonElement2.ValueKind != JsonValueKind.Array && m_3271(jsonElement, "data", out var jsonElement3))
			{
				jsonElement2 = jsonElement3;
			}
			if (jsonElement2.ValueKind != JsonValueKind.Array)
			{
				return list;
			}
			foreach (JsonElement item in jsonElement2.EnumerateArray())
			{
				if (item.TryGetProperty("status", out var value) && string.Equals(value.GetString(), "running", StringComparison.OrdinalIgnoreCase) && item.TryGetProperty("name", out var value2))
				{
					string text2 = value2.GetString() ?? "";
					if (text2.Length > 0)
					{
						list.Add(text2);
					}
				}
			}
		}
		catch (Exception ex) when (!(ex is OperationCanceledException))
		{
		}
		return list;
	}

	public async Task<OmoBrowserProfile> CreateProfileAsync(string profileName, string proxy, string userAgentOverride)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>
		{
			["name"] = profileName,
			["raw_proxy"] = proxy ?? "",
			["browser_type"] = 1,
			["os_type"] = A.OsType,
			["webrtc_mode"] = A.WebrtcMode,
			["geolocation_mode"] = A.GeolocationMode,
			["canvas_mode"] = A.CanvasMode,
			["client_rect_mode"] = A.ClientRectMode,
			["webgl_image_mode"] = A.WebglImageMode,
			["webgl_metadata_mode"] = A.WebglMetadataMode,
			["audio_mode"] = A.AudioMode,
			["font_mode"] = A.FontMode,
			["is_masked_media"] = A.IsMaskedMedia,
			["timezone_base_on_ip"] = A.TimezoneBaseOnIp,
			["is_language_base_on_ip"] = A.IsLanguageBaseOnIp,
			["startup_urls"] = A.StartupUrls
		};
		if (A.WebrtcMode == 2 && !string.IsNullOrWhiteSpace(A.FixedWebrtcPublicIp))
		{
			dictionary["fixed_webrtc_public_ip"] = A.FixedWebrtcPublicIp;
		}
		if (!A.TimezoneBaseOnIp && !string.IsNullOrWhiteSpace(A.Timezone))
		{
			dictionary["timezone"] = A.Timezone;
		}
		if (!A.IsLanguageBaseOnIp && !string.IsNullOrWhiteSpace(A.FixedLanguage))
		{
			dictionary["fixed_language"] = A.FixedLanguage;
		}
		if (A.UseCustomUserAgent && !string.IsNullOrWhiteSpace(userAgentOverride))
		{
			dictionary["custom_user_agent"] = userAgentOverride;
		}
		else if (A.UseCustomUserAgent && !string.IsNullOrWhiteSpace(A.CustomUserAgent))
		{
			dictionary["custom_user_agent"] = A.CustomUserAgent;
		}
		using HttpResponseMessage httpResponseMessage = await m_3269(A.ApiUrl + "/api/v1/profiles/create", dictionary);
		string text = await httpResponseMessage.Content.ReadAsStringAsync();
		m_3267(httpResponseMessage, text);
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		if (!m_3271(jsonDocument.RootElement, "success", out var jsonElement) || jsonElement.ValueKind != JsonValueKind.True)
		{
			throw new InvalidOperationException("BaoSam Browser tạo profile thất bại: " + text);
		}
		if (!m_3271(jsonDocument.RootElement, "id", out var jsonElement2))
		{
			throw new InvalidOperationException("Không tìm thấy id profile trong phản hồi BaoSam Browser: " + text);
		}
		return new OmoBrowserProfile
		{
			ProfileId = jsonElement2.ToString()
		};
	}

	public async Task<OmoBrowserStartResult> StartProfileAsync(string profileId)
	{
		string stringToEscape = (string.IsNullOrWhiteSpace(A.AdditionArgs) ? "--disable-notifications" : ("--disable-notifications " + A.AdditionArgs));
		string text = $"{A.ApiUrl}/api/v1/profiles/start/{profileId}?addition_args={Uri.EscapeDataString(stringToEscape)}";
		int num = 1;
		while (true)
		{
			using (HttpResponseMessage httpResponseMessage = await m_3268(text))
			{
				string text2 = await httpResponseMessage.Content.ReadAsStringAsync();
				if (httpResponseMessage.StatusCode != HttpStatusCode.InternalServerError || num >= 3)
				{
					m_3267(httpResponseMessage, text2);
					using JsonDocument jsonDocument = JsonDocument.Parse(text2);
					string text3 = (m_3271(jsonDocument.RootElement, "websocket_debugging_url", out var jsonElement) ? jsonElement.ToString() : "");
					string text4 = "";
					if (m_3271(jsonDocument.RootElement, "remote_debugging_port", out var jsonElement2) && m_3270(jsonElement2, out var value))
					{
						text4 = $"http://127.0.0.1:{value}";
					}
					if (string.IsNullOrWhiteSpace(text3) && string.IsNullOrWhiteSpace(text4))
					{
						throw new InvalidOperationException("Không tìm thấy remote_debugging_port/websocket_debugging_url trong phản hồi BaoSam Browser start: " + text2);
					}
					nint windowHandle = IntPtr.Zero;
					if (m_3271(jsonDocument.RootElement, "window_handle", out var jsonElement3) && m_3270(jsonElement3, out var value2))
					{
						windowHandle = new IntPtr(value2);
					}
					return new OmoBrowserStartResult
					{
						RemoteDebuggingAddress = text4,
						WebSocketDebuggingUrl = text3,
						WindowHandle = windowHandle
					};
				}
				await StopProfileAsync(profileId);
				await Task.Delay(1500);
			}
			num++;
		}
	}

	public async Task StopProfileAsync(string profileId)
	{
		_ = 1;
		try
		{
			using CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(5L));
			using HttpResponseMessage httpResponseMessage = await m_3264.GetAsync(A.ApiUrl + "/api/v1/profiles/stop/" + profileId, cancellationTokenSource.Token);
			await httpResponseMessage.Content.ReadAsStringAsync();
		}
		catch
		{
		}
	}

	public async Task DeleteProfileAsync(string profileId, bool hard = false)
	{
		_ = 1;
		try
		{
			string value = (hard ? "hard" : "soft");
			using HttpResponseMessage httpResponseMessage = await m_3268($"{A.ApiUrl}/api/v1/profiles/delete/{profileId}?mode={value}");
			await httpResponseMessage.Content.ReadAsStringAsync();
		}
		catch
		{
		}
	}

	private static void m_3267(HttpResponseMessage P_0, string P_1)
	{
		if (P_0.IsSuccessStatusCode)
		{
			return;
		}
		string text = "";
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(P_1);
			if (m_3271(jsonDocument.RootElement, "message", out var jsonElement))
			{
				text = jsonElement.ToString();
			}
		}
		catch (JsonException)
		{
		}
		if (string.IsNullOrWhiteSpace(text))
		{
			throw new InvalidOperationException($"BaoSam Browser trả lỗi HTTP {(int)P_0.StatusCode}: {P_1}");
		}
		if (text.Contains("không tìm thấy hồ sơ", StringComparison.OrdinalIgnoreCase) || text.Contains("not found", StringComparison.OrdinalIgnoreCase))
		{
			throw new BrowserProfileNotFoundException(text);
		}
		throw new InvalidOperationException($"BaoSam Browser (HTTP {(int)P_0.StatusCode}): {text}");
	}

	private async Task<HttpResponseMessage> m_3268(string P_0)
	{
		Exception ex = null;
		for (int i = 1; i <= 3; i++)
		{
			try
			{
				return await m_3264.GetAsync(P_0);
			}
			catch (HttpRequestException ex2)
			{
				ex = ex2;
				if (i < 3)
				{
					await Task.Delay(500 * i);
				}
			}
		}
		throw ex;
	}

	private async Task<HttpResponseMessage> m_3269(string P_0, object P_1)
	{
		Exception ex = null;
		string content = JsonSerializer.Serialize(P_1);
		for (int i = 1; i <= 3; i++)
		{
			try
			{
				using StringContent stringContent = new StringContent(content, Encoding.UTF8);
				stringContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
				return await m_3264.PostAsync(P_0, stringContent);
			}
			catch (HttpRequestException ex2)
			{
				ex = ex2;
				if (i < 3)
				{
					await Task.Delay(500 * i);
				}
			}
		}
		throw ex;
	}

	private static bool m_3270(JsonElement P_0, out long P_1)
	{
		switch (P_0.ValueKind)
		{
		case JsonValueKind.Number:
			return P_0.TryGetInt64(out P_1);
		case JsonValueKind.String:
			return long.TryParse(P_0.GetString(), out P_1);
		default:
			P_1 = 0L;
			return false;
		}
	}

	private static bool m_3271(JsonElement P_0, string P_1, out JsonElement P_2)
	{
		if (P_0.ValueKind == JsonValueKind.Object)
		{
			if (P_0.TryGetProperty(P_1, out P_2))
			{
				return true;
			}
			foreach (JsonProperty item in P_0.EnumerateObject())
			{
				if (m_3271(item.Value, P_1, out P_2))
				{
					return true;
				}
			}
		}
		else if (P_0.ValueKind == JsonValueKind.Array)
		{
			foreach (JsonElement item2 in P_0.EnumerateArray())
			{
				if (m_3271(item2, P_1, out P_2))
				{
					return true;
				}
			}
		}
		P_2 = default;
		return false;
	}

	public static void KillAllChromes()
	{
		Process[] processesByName = Process.GetProcessesByName("chrome");
		foreach (Process process in processesByName)
		{
			try
			{
				process.Kill(entireProcessTree: true);
			}
			catch
			{
			}
		}
	}
}
