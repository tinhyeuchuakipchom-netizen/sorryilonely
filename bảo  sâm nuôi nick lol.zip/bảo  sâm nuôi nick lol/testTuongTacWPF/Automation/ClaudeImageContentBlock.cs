using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class ClaudeImageContentBlock
{
	[CompilerGenerated]
	private string A = "image";

	[CompilerGenerated]
	private ClaudeImageSource m_2873 = new ClaudeImageSource();

	[JsonPropertyName("type")]
	public string Type
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("source")]
	public ClaudeImageSource Source
	{
		[CompilerGenerated]
		get
		{
			return m_2873;
		}
		[CompilerGenerated]
		set
		{
			m_2873 = value;
		}
	}
}
