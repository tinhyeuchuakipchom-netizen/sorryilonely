using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using A;

namespace testTuongTacWPF.Automation;

public class TempMail100Client : IVerifyMailTestClient
{
	private const string A = "https://tempmail100.com";

	private readonly HttpClient m_6159 = new HttpClient(new HttpClientHandler())
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private string? a;

	public async Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken))
	{
		using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, "https://tempmail100.com/init");
		m_6160(httpRequestMessage);
		using HttpResponseMessage httpResponseMessage = await m_6159.SendAsync(httpRequestMessage, ct);
		a = f.A(await httpResponseMessage.Content.ReadAsStringAsync(ct), "\"token\":\"", "\"");
		if (string.IsNullOrEmpty(a))
		{
			throw new InvalidOperationException("Không lấy được token từ tempmail100.com (có thể site đã đổi API).");
		}
		using HttpRequestMessage httpRequestMessage2 = new HttpRequestMessage(HttpMethod.Post, "https://tempmail100.com/web/generate");
		m_6160(httpRequestMessage2);
		httpRequestMessage2.Headers.Add("Authorization", a);
		using HttpResponseMessage httpResponseMessage2 = await m_6159.SendAsync(httpRequestMessage2, ct);
		string text = f.A(await httpResponseMessage2.Content.ReadAsStringAsync(ct), "\"address\":\"", "\"");
		if (!text.Contains('@'))
		{
			throw new InvalidOperationException("Không lấy được địa chỉ mail từ tempmail100.com (có thể site đã đổi API).");
		}
		return text;
	}

	public async Task<string?> TryGetOtpAsync()
	{
		if (a == null)
		{
			throw new InvalidOperationException("Chưa lấy địa chỉ mail - bấm \"Thử lấy mail\" trước.");
		}
		using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, "https://tempmail100.com/web/emails");
		m_6160(httpRequestMessage);
		httpRequestMessage.Headers.Add("Authorization", a);
		using HttpResponseMessage httpResponseMessage = await m_6159.SendAsync(httpRequestMessage);
		string text = await httpResponseMessage.Content.ReadAsStringAsync();
		if (!text.Contains("uuid"))
		{
			return null;
		}
		string text2 = f.A(text, "\"uuid\":\"", "\"");
		if (string.IsNullOrEmpty(text2))
		{
			return null;
		}
		using HttpRequestMessage httpRequestMessage2 = new HttpRequestMessage(HttpMethod.Get, "https://tempmail100.com/emails/content/" + text2);
		m_6160(httpRequestMessage2);
		using HttpResponseMessage httpResponseMessage2 = await m_6159.SendAsync(httpRequestMessage2);
		return f.A(await httpResponseMessage2.Content.ReadAsStringAsync());
	}

	private static void m_6160(HttpRequestMessage P_0)
	{
		P_0.Headers.Add("Accept", "*/*");
		P_0.Headers.Add("Accept-Language", "vi");
		P_0.Headers.Add("Origin", "https://tempmail100.com");
		P_0.Headers.Add("Referer", "https://tempmail100.com/");
		P_0.Headers.Add("X-Requested-With", "XMLHttpRequest");
		P_0.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36");
	}
}
