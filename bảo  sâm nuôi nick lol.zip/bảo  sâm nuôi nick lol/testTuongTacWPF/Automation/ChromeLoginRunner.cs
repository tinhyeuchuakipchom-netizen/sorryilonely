using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public class ChromeLoginRunner : ILoginRunner
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3656
	{
		public static readonly m_3656 A = new m_3656();

		public static Action<string, string> m_3659;

		public static Func<Cookie, bool> m_3660;

		public static Func<BrowserContextCookiesResult, bool> m_3661;

		public static Func<BrowserContextCookiesResult, bool> a;

		public static Func<BrowserContextCookiesResult, bool> B;

		public static Func<BrowserContextCookiesResult, string> m_3662;

		public static Func<BrowserContextCookiesResult, string> m_3663;

		internal void m_3664(string P_0, string P_1)
		{
		}

		internal bool m_3665(Cookie P_0)
		{
			return P_0.Name == "c_user";
		}

		internal bool m_3666(BrowserContextCookiesResult P_0)
		{
			return P_0.Name == "c_user";
		}

		internal bool m_3667(BrowserContextCookiesResult P_0)
		{
			return P_0.Name == "c_user";
		}

		internal bool m_3668(BrowserContextCookiesResult P_0)
		{
			return P_0.Name == "c_user";
		}

		internal string b(BrowserContextCookiesResult P_0)
		{
			return P_0.Name + "=" + P_0.Value;
		}

		internal string C(BrowserContextCookiesResult P_0)
		{
			return P_0.Name + "=" + P_0.Value;
		}
	}

	[CompilerGenerated]
	private sealed class m_3657
	{
		public FacebookAccountRow A;

		internal void m_3669(string P_0, string P_1)
		{
			A.TrangThai = P_0;
		}
	}

	private const int A = 10;

	public async Task<LoginResult> LoginAsync(FacebookAccountRow nick, CancellationToken cancellationToken)
	{
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return a("Nick chưa gắn Chrome (chưa có Profile Chrome).");
		}
		cancellationToken.ThrowIfCancellationRequested();
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return a($"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.");
		}
		string browserProfileId = nick.BrowserProfileId;
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			OmoBrowserStartResult omoBrowserStartResult = await global::A.F.A(client, settings, nick);
			browserProfileId = nick.BrowserProfileId;
			using IPlaywright playwright = await Playwright.CreateAsync();
			(OmoBrowserStartResult, IBrowser) tuple = await global::A.F.A(client, settings, nick, playwright, omoBrowserStartResult, cancellationToken);
			omoBrowserStartResult = tuple.Item1;
			IBrowser item = tuple.Item2;
			browserProfileId = nick.BrowserProfileId;
			IBrowserContext browserContext = item.Contexts.FirstOrDefault();
			if (browserContext == null)
			{
				browserContext = await item.NewContextAsync();
			}
			IBrowserContext browserContext2 = browserContext;
			IPage page = browserContext2.Pages.FirstOrDefault();
			if (page == null)
			{
				page = await browserContext2.NewPageAsync();
			}
			IPage page2 = page;
			LoginResult loginResult = await m_3645(nick, settings, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
			{
				nick.TrangThai = P_0;
			});
			if (!string.IsNullOrWhiteSpace(browserProfileId) && (!loginResult.Success || settings.AutoCloseChromeAfterLogin))
			{
				await client.StopProfileAsync(browserProfileId);
			}
			return loginResult;
		}
		catch (OperationCanceledException)
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				await client.StopProfileAsync(browserProfileId);
			}
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Đã dừng theo yêu cầu."
			};
		}
		catch (Exception ex2)
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				await client.StopProfileAsync(browserProfileId);
			}
			return a("Lỗi trình duyệt/Playwright: " + m_3655(ex2));
		}
	}

	internal static async Task<IBrowser> m_3644(IPlaywright P_0, string P_1, CancellationToken P_2)
	{
		Exception ex = null;
		for (int j = 1; j <= 6; j++)
		{
			P_2.ThrowIfCancellationRequested();
			try
			{
				return await PlaywrightHumanHelpers.WithCancellationAsync(P_0.Chromium.ConnectOverCDPAsync(P_1), P_2);
			}
			catch (OperationCanceledException)
			{
				throw;
			}
			catch (Exception ex3)
			{
				ex = ex3;
				if (j < 6)
				{
					await Task.Delay(1000, P_2);
				}
			}
		}
		throw ex;
	}

	internal static async Task<LoginResult> m_3645(FacebookAccountRow P_0, IChromeEngineSettings P_1, IBrowserContext P_2, IPage P_3, nint P_4, CancellationToken P_5, Action<string, string>? log = null)
	{
		LoginResult loginResult = await m_3646(P_0, P_1, P_2, P_3, P_4, P_5);
		if (!loginResult.Success)
		{
			return loginResult;
		}
		if (!(await FacebookLanguageEnforcer.EnsureEnglishAsync(P_3, log ?? ((Action<string, string>)delegate
		{
		}), P_5)))
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Không thể chuyển giao diện Facebook sang English (US); dừng trước khi chạy kịch bản."
			};
		}
		return loginResult;
	}

	private static async Task<LoginResult> m_3646(FacebookAccountRow P_0, IChromeEngineSettings P_1, IBrowserContext P_2, IPage P_3, nint P_4, CancellationToken P_5)
	{
		bool flag = !string.IsNullOrWhiteSpace(P_0.Cookie);
		if (P_1.LoginType == "Cookie" || ((P_1.LoginType == "CookieThenUidPass") & flag))
		{
			if (!flag)
			{
				return a("Nick chưa có Cookie để đăng nhập.");
			}
			LoginResult loginResult = await a(P_0, P_1, P_2, P_3, P_4, P_5);
			if (loginResult.Success || P_1.LoginType == "Cookie")
			{
				return loginResult;
			}
		}
		return await B(P_0, P_1, P_2, P_3, P_4, P_5);
	}

	private static async Task<LoginResult> a(FacebookAccountRow P_0, IChromeEngineSettings P_1, IBrowserContext P_2, IPage P_3, nint P_4, CancellationToken P_5)
	{
		List<Cookie> list = m_3654(P_0.Cookie);
		if (list.Count == 0)
		{
			return a("Cookie của nick không đọc được (định dạng phải là name1=value1; name2=value2).");
		}
		try
		{
			await P_2.AddCookiesAsync(list);
			await PlaywrightHumanHelpers.WithCancellationAsync(P_3.GotoAsync("https://www.facebook.com/?locale=en_US"), P_5);
			await m_3647(P_3, P_4, P_5);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			return a("Lỗi khi áp cookie: " + m_3655(ex2));
		}
		if (!list.Any((Cookie cookie) => cookie.Name == "c_user"))
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Cookie không có c_user - cookie không hợp lệ."
			};
		}
		string text = await PlaywrightHumanHelpers.WithCancellationAsync(P_3.ContentAsync(), P_5);
		if (text.Contains("Password") && text.Contains("Email address or phone number"))
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "DIE",
				TrangThai = "Cookie hết hạn - Facebook yêu cầu đăng nhập lại."
			};
		}
		return await m_3649(P_0, P_1, P_2, P_3, P_5);
	}

	private static async Task<LoginResult> B(FacebookAccountRow P_0, IChromeEngineSettings P_1, IBrowserContext P_2, IPage P_3, nint P_4, CancellationToken P_5)
	{
		bool flag = P_1.LoginType == "MailPass";
		string text = (flag ? P_0.Mail : P_0.Uid);
		if (string.IsNullOrWhiteSpace(text) || string.IsNullOrWhiteSpace(P_0.Pass))
		{
			return a(flag ? "Nick chưa có Mail/Mật khẩu." : "Nick chưa có UID/Mật khẩu.");
		}
		await PlaywrightHumanHelpers.WithCancellationAsync(P_3.GotoAsync("https://www.facebook.com/?locale=en_US"), P_5);
		await m_3647(P_3, P_4, P_5);
		if ((await PlaywrightHumanHelpers.WithCancellationAsync(P_2.CookiesAsync(), P_5)).Any((BrowserContextCookiesResult browserContextCookiesResult) => browserContextCookiesResult.Name == "c_user"))
		{
			return await m_3649(P_0, P_1, P_2, P_3, P_5);
		}
		await FacebookLanguageEnforcer.EnsureEnglishForLoginPageAsync(P_3, P_5);
		if (!(await m_3648(P_3, P_5)))
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Không thể chuyển giao diện Facebook sang English trước khi đăng nhập."
			};
		}
		try
		{
			await PlaywrightHumanHelpers.SlowMouseMoveAsync(P_3, 200f, 300f);
			await Task.Delay(PlaywrightHumanHelpers.RandomDelay(200, 500), P_5);
			ILocator locator = P_3.Locator("input[name='email']").Or(P_3.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions
			{
				Name = "Email address or phone number"
			})).Or(P_3.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions
			{
				Name = "Email address or mobile number"
			}));
			await locator.ClickAsync();
			await PlaywrightHumanHelpers.SlowTypeAsync(locator, text);
			await PlaywrightHumanHelpers.SlowMouseMoveAsync(P_3, 200f, 370f);
			await Task.Delay(PlaywrightHumanHelpers.RandomDelay(200, 500), P_5);
			ILocator locator2 = P_3.Locator("input[name='pass']").Or(P_3.GetByLabel("Password"));
			await locator2.ClickAsync();
			await PlaywrightHumanHelpers.SlowTypeAsync(locator2, P_0.Pass);
			await Task.Delay(PlaywrightHumanHelpers.RandomDelay(500, 1000), P_5);
			await PlaywrightHumanHelpers.SlowMouseMoveAsync(P_3, 200f, 430f);
			await Task.Delay(PlaywrightHumanHelpers.RandomDelay(200, 500), P_5);
			await P_3.GetByRole(AriaRole.Button, new PageGetByRoleOptions
			{
				Name = "Log In"
			}).ClickAsync();
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception ex2)
		{
			return a("Lỗi khi điền form đăng nhập: " + m_3655(ex2));
		}
		return await m_3649(P_0, P_1, P_2, P_3, P_5);
	}

	private static async Task m_3647(IPage P_0, nint P_1, CancellationToken P_2)
	{
		_ = 1;
		try
		{
			await Task.Delay(1200, P_2);
			global::A.G.a(P_1);
			await Task.Delay(300, P_2);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
		}
	}

	private static async Task<bool> m_3648(IPage P_0, CancellationToken P_1)
	{
		try
		{
			return (await PlaywrightHumanHelpers.WithCancellationAsync(P_0.ContentAsync(), P_1)).Contains("lang=\"en\"", StringComparison.OrdinalIgnoreCase);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
			return true;
		}
	}

	private static async Task<LoginResult> m_3649(FacebookAccountRow P_0, IChromeEngineSettings P_1, IBrowserContext P_2, IPage P_3, CancellationToken P_4)
	{
		await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_3, AriaRole.Button, new string[1] { "Dismiss" }, 3000);
		for (int j = 0; j < 3; j++)
		{
			P_4.ThrowIfCancellationRequested();
			Task task = m_3650(P_2, P_4);
			Task task2 = P_3.Locator("#email_container img").WaitForAsync();
			Task task3 = P_3.GetByText("The password that you've").WaitForAsync();
			Task task4 = P_3.GetByRole(AriaRole.Button, new PageGetByRoleOptions
			{
				Name = "Try Another Way"
			}).WaitForAsync();
			Task task5 = P_3.GetByText("Go to your authentication app").WaitForAsync();
			Task task6 = P_3.Locator("#arkose-captcha").WaitForAsync();
			Task task7 = P_3.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions
			{
				Name = "Enter characters"
			}).WaitForAsync();
			Task task8 = P_3.GetByRole(AriaRole.Textbox, new PageGetByRoleOptions
			{
				Name = "Enter the"
			}).WaitForAsync();
			Task task9 = Task.Delay(-1, P_4);
			InlineArray9<Task> buffer = default;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 0) = task;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 1) = task2;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 2) = task3;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 3) = task4;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 4) = task5;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 5) = task6;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 6) = task7;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 7) = task8;
			global::A.H.a<InlineArray9<Task>, Task>(ref buffer, 8) = task9;
			Task task10 = await Task.WhenAny(global::A.H.m_6821<InlineArray9<Task>, Task>(in buffer, 9));
			if (task10 == task9)
			{
				P_4.ThrowIfCancellationRequested();
			}
			if (task10 == task)
			{
				return await m_3652(P_0, P_1, P_2, P_3);
			}
			if (task10 == task2 || task10 == task3)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Sai mật khẩu."
				};
			}
			if (task10 == task4 || task10 == task5)
			{
				LoginResult loginResult = await m_3651(P_0, P_3, P_4);
				if (loginResult != null)
				{
					return loginResult;
				}
			}
			else if ((task10 == task6 || task10 == task7 || task10 == task8) && !(await a(P_3, P_4)))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Chờ giải captcha quá lâu, cần xử lý thủ công."
				};
			}
		}
		return new LoginResult
		{
			Success = false,
			TinhTrang = "ERROR",
			TrangThai = "Không xác định được kết quả đăng nhập sau nhiều lần chờ."
		};
	}

	private static async Task m_3650(IBrowserContext P_0, CancellationToken P_1)
	{
		while (true)
		{
			P_1.ThrowIfCancellationRequested();
			if ((await P_0.CookiesAsync()).Any((BrowserContextCookiesResult browserContextCookiesResult) => browserContextCookiesResult.Name == "c_user"))
			{
				break;
			}
			await Task.Delay(500, P_1);
		}
	}

	private static async Task<LoginResult?> m_3651(FacebookAccountRow P_0, IPage P_1, CancellationToken P_2)
	{
		string text = await m_3653(P_1);
		if (!text.Contains("enter the 6-digit code", StringComparison.OrdinalIgnoreCase) && !text.Contains("mã gồm 6 chữ số", StringComparison.OrdinalIgnoreCase))
		{
			await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_1, AriaRole.Button, new string[2] { "Thử cách khác", "Try Another Way" }, 3000);
			if (!(await PlaywrightHumanHelpers.CheckFirstVisibleAsync(P_1, AriaRole.Radio, new string[2] { "Ứng dụng xác thực", "Authentication app" }, 4000)))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Không tìm thấy tuỳ chọn xác thực bằng ứng dụng (2FA)."
				};
			}
			await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_1, AriaRole.Button, new string[2] { "Tiếp tục", "Continue" }, 3000);
		}
		string text2 = PlaywrightHumanHelpers.Get2fa(P_0.TwoFA);
		if (string.IsNullOrEmpty(text2))
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Facebook yêu cầu 2FA nhưng nick chưa có mã 2FA hợp lệ."
			};
		}
		try
		{
			ILocator first = P_1.Locator("input[type='text'], input[type='number'], input[type='tel'], input:not([type])").First;
			await first.ClickAsync();
			await PlaywrightHumanHelpers.SlowTypeAsync(first, text2);
		}
		catch (Exception ex)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi khi nhập mã 2FA: " + ex.Message
			};
		}
		await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_1, AriaRole.Button, new string[2] { "Tiếp tục", "Continue" }, 3000);
		await Task.Delay(2000, P_2);
		await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_1, AriaRole.Button, new string[2] { "Lưu", "Save" });
		await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_1, AriaRole.Button, new string[2] { "Tin cậy thiết bị này", "Trust this device" }, 3000);
		return null;
	}

	private static async Task<bool> a(IPage P_0, CancellationToken P_1)
	{
		for (int j = 0; j < 10; j++)
		{
			P_1.ThrowIfCancellationRequested();
			try
			{
				if (!string.IsNullOrEmpty(await P_0.GetByRole(AriaRole.Textbox).First.InputValueAsync()))
				{
					await PlaywrightHumanHelpers.ClickFirstVisibleAsync(P_0, AriaRole.Button, new string[2] { "Continue", "Tiếp tục" });
					await Task.Delay(3000, P_1);
					return true;
				}
			}
			catch (OperationCanceledException)
			{
				throw;
			}
			catch
			{
			}
			await Task.Delay(10000, P_1);
		}
		return false;
	}

	private static async Task<LoginResult> m_3652(FacebookAccountRow P_0, IChromeEngineSettings P_1, IBrowserContext P_2, IPage P_3)
	{
		if (await PlaywrightHumanHelpers.IsAnyVisibleAsync(P_3, AriaRole.Button, new string[2] { "Log in", "Log In" }))
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Sai mật khẩu."
			};
		}
		if (P_1.SaveNewCookieAfterLogin)
		{
			await RefreshCookieAsync(P_0, P_2);
		}
		return new LoginResult
		{
			Success = true,
			TinhTrang = "LIVE",
			TrangThai = $"Đăng nhập thành công lúc {DateTime.Now:HH:mm:ss dd/MM}."
		};
	}

	public static async Task RefreshCookieAsync(FacebookAccountRow nick, IBrowserContext context)
	{
		try
		{
			IReadOnlyList<BrowserContextCookiesResult> source = await context.CookiesAsync();
			BrowserContextCookiesResult browserContextCookiesResult = source.FirstOrDefault((BrowserContextCookiesResult P_0) => P_0.Name == "c_user");
			if (browserContextCookiesResult != null)
			{
				nick.Cookie = string.Join("; ", source.Select((BrowserContextCookiesResult P_0) => P_0.Name + "=" + P_0.Value));
				string text = browserContextCookiesResult.Value?.Trim() ?? "";
				if (text.Length > 0 && nick.Uid != text)
				{
					nick.Uid = text;
				}
			}
		}
		catch
		{
		}
	}

	public static async Task RefreshCookieAsync(IChromeAutomationAccount nick, IBrowserContext context)
	{
		try
		{
			IReadOnlyList<BrowserContextCookiesResult> readOnlyList = await context.CookiesAsync();
			if (readOnlyList.Count > 0)
			{
				nick.Cookie = string.Join("; ", readOnlyList.Select((BrowserContextCookiesResult P_0) => P_0.Name + "=" + P_0.Value));
			}
		}
		catch
		{
		}
	}

	private static async Task<string> m_3653(IPage P_0)
	{
		try
		{
			return await P_0.InnerTextAsync("body");
		}
		catch
		{
			return "";
		}
	}

	private static List<Cookie> m_3654(string P_0)
	{
		List<Cookie> list = new List<Cookie>();
		string[] array = P_0.Split(';');
		for (int j = 0; j < array.Length; j++)
		{
			string[] array2 = array[j].Split('=', 2);
			if (array2.Length == 2)
			{
				list.Add(new Cookie
				{
					Name = array2[0].Trim(),
					Value = array2[1].Trim(),
					Domain = ".facebook.com",
					Path = "/",
					Secure = true,
					HttpOnly = false
				});
			}
		}
		return list;
	}

	private static LoginResult a(string P_0)
	{
		return new LoginResult
		{
			Success = false,
			TinhTrang = "ERROR",
			TrangThai = P_0
		};
	}

	internal static string m_3655(Exception P_0)
	{
		List<string> list = new List<string> { P_0.Message };
		for (Exception innerException = P_0.InnerException; innerException != null; innerException = innerException.InnerException)
		{
			list.Add(innerException.Message);
		}
		return string.Join(" → ", list);
	}
}
