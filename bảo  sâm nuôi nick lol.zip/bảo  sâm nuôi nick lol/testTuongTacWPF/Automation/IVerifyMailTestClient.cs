using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public interface IVerifyMailTestClient
{
	Task<string> GetNewMailAddressAsync(CancellationToken ct = default(CancellationToken));

	Task<string?> TryGetOtpAsync();
}
