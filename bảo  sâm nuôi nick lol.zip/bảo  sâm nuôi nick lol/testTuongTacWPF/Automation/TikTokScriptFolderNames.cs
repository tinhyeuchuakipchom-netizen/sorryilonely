namespace testTuongTacWPF.Automation;

public static class TikTokScriptFolderNames
{
	public const string Login = "Đăng nhập";

	public const string Interaction = "Tương tác";

	public const string Like = "Thả tim";

	public const string Comment = "Bình luận";

	public const string Follow = "Follow (Sub)";

	public const string Share = "Chia sẻ";

	public const string UpdateAvatar = "Cập nhật Avatar";
}
