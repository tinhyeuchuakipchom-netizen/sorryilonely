using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class AdbDeviceController : IDeviceController
{
	private readonly string A;

	public AdbDeviceController(string deviceSerial)
	{
		A = deviceSerial;
	}

	public Task<byte[]> ScreenshotAsync(CancellationToken cancellationToken)
	{
		return AdbController.ScreenshotAsync(A, cancellationToken);
	}

	public Task<(int Width, int Height)> GetScreenSizeAsync(CancellationToken cancellationToken)
	{
		return AdbController.GetScreenSizeAsync(A, cancellationToken);
	}

	public Task<List<UiElement>> DumpUiElementsAsync(CancellationToken cancellationToken)
	{
		return AdbController.DumpUiElementsAsync(A, cancellationToken);
	}

	public Task TapAsync(int x, int y, CancellationToken cancellationToken)
	{
		return AdbController.TapAsync(A, x, y, cancellationToken);
	}

	public Task SwipeAsync(int x1, int y1, int x2, int y2, int durationMs, CancellationToken cancellationToken)
	{
		return AdbController.SwipeAsync(A, x1, y1, x2, y2, durationMs, cancellationToken);
	}

	public Task InputTextAsync(string text, CancellationToken cancellationToken)
	{
		return AdbController.InputTextAsync(A, text, cancellationToken);
	}

	public Task KeyEventAsync(string keycode, CancellationToken cancellationToken)
	{
		return AdbController.KeyEventAsync(A, keycode, cancellationToken);
	}
}
