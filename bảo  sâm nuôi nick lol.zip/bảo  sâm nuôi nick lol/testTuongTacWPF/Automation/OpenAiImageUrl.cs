using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class OpenAiImageUrl
{
	[CompilerGenerated]
	private string A = "";

	[JsonPropertyName("url")]
	public string Url
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
