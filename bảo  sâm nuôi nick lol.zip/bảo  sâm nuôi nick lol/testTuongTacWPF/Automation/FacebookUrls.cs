using System;
using System.Text.RegularExpressions;

namespace testTuongTacWPF.Automation;

public static class FacebookUrls
{
	private const string A = "locale=en_US";

	public const string Home = "https://www.facebook.com/?locale=en_US";

	public const string MobileHome = "https://m.facebook.com/?locale=en_US";

	public static string WithEnglishLocale(string? url)
	{
		if (string.IsNullOrWhiteSpace(url))
		{
			return url ?? "";
		}
		string text = url.Trim();
		if (!Uri.TryCreate(text, UriKind.Absolute, out Uri result))
		{
			return text;
		}
		if (text.Contains("locale=", StringComparison.OrdinalIgnoreCase))
		{
			return Regex.Replace(text, "(?i)(?<=[?&])locale=[^&#]*", "locale=en_US");
		}
		string obj = (string.IsNullOrEmpty(result.Fragment) ? text : text.Substring(0, text.IndexOf('#')));
		string text2 = (obj.Contains('?') ? "&" : "?");
		return obj + text2 + "locale=en_US" + result.Fragment;
	}
}
