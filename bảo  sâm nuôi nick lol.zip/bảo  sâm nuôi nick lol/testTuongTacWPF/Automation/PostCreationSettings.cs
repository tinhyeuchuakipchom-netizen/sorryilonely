using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class PostCreationSettings
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6108
	{
		public static readonly m_6108 A = new m_6108();

		public static Func<string, bool> m_6110;

		public static Func<string, int> m_6111;

		internal bool m_6112(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}

		internal int a(string P_0)
		{
			return Random.Shared.Next();
		}
	}

	[CompilerGenerated]
	private sealed class m_6109
	{
		public string[] A;

		internal bool m_6113(string P_0)
		{
			return A.Contains(Path.GetExtension(P_0).ToLowerInvariant());
		}
	}

	[CompilerGenerated]
	private List<string> A = new List<string>();

	[CompilerGenerated]
	private bool m_6099;

	[CompilerGenerated]
	private string m_6100 = "";

	[CompilerGenerated]
	private int m_6101 = 1;

	[CompilerGenerated]
	private int a = 3;

	[CompilerGenerated]
	private bool m_6102;

	[CompilerGenerated]
	private string m_6103 = "";

	[CompilerGenerated]
	private string B = "Keep";

	[CompilerGenerated]
	private int m_6104 = 1;

	[CompilerGenerated]
	private int b = 60;

	[CompilerGenerated]
	private int C = 180;

	private static readonly string[] m_6105 = new string[6] { ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp" };

	private static readonly string[] m_6106 = new string[6] { ".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v" };

	public List<string> Contents
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool AttachImage
	{
		[CompilerGenerated]
		get
		{
			return m_6099;
		}
		[CompilerGenerated]
		set
		{
			m_6099 = value;
		}
	}

	public string ImageFolder
	{
		[CompilerGenerated]
		get
		{
			return m_6100;
		}
		[CompilerGenerated]
		set
		{
			m_6100 = value;
		}
	}

	public int MinImages
	{
		[CompilerGenerated]
		get
		{
			return m_6101;
		}
		[CompilerGenerated]
		set
		{
			m_6101 = value;
		}
	}

	public int MaxImages
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public bool AttachVideo
	{
		[CompilerGenerated]
		get
		{
			return m_6102;
		}
		[CompilerGenerated]
		set
		{
			m_6102 = value;
		}
	}

	public string VideoFolder
	{
		[CompilerGenerated]
		get
		{
			return m_6103;
		}
		[CompilerGenerated]
		set
		{
			m_6103 = value;
		}
	}

	public string Audience
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int PostCount
	{
		[CompilerGenerated]
		get
		{
			return m_6104;
		}
		[CompilerGenerated]
		set
		{
			m_6104 = value;
		}
	}

	public int MinSpacingSeconds
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int MaxSpacingSeconds
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public (string ViLabel, string[] Match)? AudienceInfo()
	{
		return Audience switch
		{
			"Public" => ((string ViLabel, string[] Match)?)("Công khai", new string[2] { "Public", "Công khai" }), 
			"Friends" => ("Bạn bè", new string[2] { "Friends", "Bạn bè" }), 
			"OnlyMe" => ("Chỉ mình tôi", new string[2] { "Only me", "Chỉ mình tôi" }), 
			_ => null, 
		};
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static PostCreationSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new PostCreationSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<PostCreationSettings>(json) ?? new PostCreationSettings();
		}
		catch (JsonException)
		{
			return new PostCreationSettings();
		}
	}

	public string? PickContent()
	{
		List<string> list = Contents.Where((string P_0) => !string.IsNullOrWhiteSpace(P_0)).ToList();
		if (list.Count != 0)
		{
			return list[Random.Shared.Next(list.Count)];
		}
		return null;
	}

	public int PickSpacingSeconds()
	{
		if (MinSpacingSeconds < MaxSpacingSeconds)
		{
			return Random.Shared.Next(MinSpacingSeconds, MaxSpacingSeconds + 1);
		}
		return MinSpacingSeconds;
	}

	public List<string> PickMediaFiles()
	{
		List<string> list = new List<string>();
		if (AttachImage)
		{
			List<string> list2 = m_6107(ImageFolder, m_6105);
			if (list2.Count > 0)
			{
				int num = Math.Max(1, Math.Min(MinImages, MaxImages));
				int num2 = Math.Max(num, Math.Max(MinImages, MaxImages));
				int count = Math.Min(list2.Count, Random.Shared.Next(num, num2 + 1));
				list.AddRange(list2.OrderBy(delegate
				{
					return Random.Shared.Next();
				}).Take(count));
			}
		}
		if (AttachVideo)
		{
			List<string> list3 = m_6107(VideoFolder, m_6106);
			if (list3.Count > 0)
			{
				list.Add(list3[Random.Shared.Next(list3.Count)]);
			}
		}
		return list;
	}

	private static List<string> m_6107(string P_0, string[] P_1)
	{
		if (string.IsNullOrWhiteSpace(P_0) || !Directory.Exists(P_0))
		{
			return new List<string>();
		}
		try
		{
			return (from path in Directory.EnumerateFiles(P_0)
				where P_1.Contains(Path.GetExtension(path).ToLowerInvariant())
				select path).ToList();
		}
		catch (Exception)
		{
			return new List<string>();
		}
	}
}
