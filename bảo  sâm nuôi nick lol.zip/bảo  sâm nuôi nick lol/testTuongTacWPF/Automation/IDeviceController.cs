using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public interface IDeviceController
{
	Task<byte[]> ScreenshotAsync(CancellationToken cancellationToken);

	Task<(int Width, int Height)> GetScreenSizeAsync(CancellationToken cancellationToken);

	Task<List<UiElement>> DumpUiElementsAsync(CancellationToken cancellationToken);

	Task TapAsync(int x, int y, CancellationToken cancellationToken);

	Task SwipeAsync(int x1, int y1, int x2, int y2, int durationMs, CancellationToken cancellationToken);

	Task InputTextAsync(string text, CancellationToken cancellationToken);

	Task KeyEventAsync(string keycode, CancellationToken cancellationToken);
}
