using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public class PhoneLoginRunner : ILoginRunner
{
	[CompilerGenerated]
	private sealed class m_6012
	{
		public PhoneLoginRunner A;

		public FacebookAccountRow m_6013;

		internal void m_6014(AiVisionStepLog P_0)
		{
			if (A.m_6011 != null && !string.IsNullOrEmpty(P_0.ActionSummary))
			{
				A.m_6011(P_0.ActionSummary);
			}
			else if (!string.IsNullOrEmpty(P_0.ActionSummary))
			{
				m_6013.TrangThai = P_0.ActionSummary;
			}
		}
	}

	private readonly string A;

	private readonly Action<string>? m_6011;

	public PhoneLoginRunner(string packageType = "Katana", Action<string>? onStatusUpdate = null)
	{
		A = (string.IsNullOrWhiteSpace(packageType) ? "Katana" : packageType);
		m_6011 = onStatusUpdate;
	}

	public async Task<LoginResult> LoginAsync(FacebookAccountRow nick, CancellationToken cancellationToken)
	{
		if (string.IsNullOrWhiteSpace(nick.PhoneName))
		{
			List<string> list = await AdbController.ListDevicesAsync(cancellationToken);
			string text = ((list.Count > 0) ? list[0] : "");
			if (string.IsNullOrEmpty(text))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Nick chưa gắn Phone và không tìm thấy thiết bị Android nào đang kết nối."
				};
			}
			nick.PhoneName = text;
		}
		cancellationToken.ThrowIfCancellationRequested();
		if (string.Equals(A, "Katana", StringComparison.OrdinalIgnoreCase))
		{
			return await FacebookKatanaPhoneLoginService.LoginAccountAsync(nick, m_6011, cancellationToken);
		}
		AiVisionRunResult aiVisionRunResult = await AndroidFacebookRegistrationRunner.VerifyNickAsync(nick, A, (AiVisionStepLog P_0) =>
		{
			if (m_6011 != null && !string.IsNullOrEmpty(P_0.ActionSummary))
			{
				m_6011(P_0.ActionSummary);
			}
			else if (!string.IsNullOrEmpty(P_0.ActionSummary))
			{
				nick.TrangThai = P_0.ActionSummary;
			}
		}, cancellationToken);
		string tinhTrang;
		if (string.IsNullOrEmpty(aiVisionRunResult.TinhTrang))
		{
			tinhTrang = (aiVisionRunResult.Success ? "LIVE" : "ERROR");
		}
		else
		{
			tinhTrang = aiVisionRunResult.TinhTrang;
		}
		if (aiVisionRunResult.Success)
		{
			try
			{
				KatanaSessionResult katanaSessionResult = ((!string.Equals(A, "Lite", StringComparison.OrdinalIgnoreCase)) ? (await AdbController.GetKatanaTokenAndCookieAsync(nick.PhoneName, cancellationToken)) : (await AdbController.GetFbLiteTokenAndCookieAsync(nick.PhoneName, cancellationToken)));
				KatanaSessionResult katanaSessionResult2 = katanaSessionResult;
				if (katanaSessionResult2.Success)
				{
					if (!string.IsNullOrEmpty(katanaSessionResult2.Uid))
					{
						nick.Uid = katanaSessionResult2.Uid;
					}
					if (!string.IsNullOrEmpty(katanaSessionResult2.Token))
					{
						nick.Token = katanaSessionResult2.Token;
					}
					if (!string.IsNullOrEmpty(katanaSessionResult2.Cookie))
					{
						nick.Cookie = katanaSessionResult2.Cookie;
					}
				}
			}
			catch
			{
			}
		}
		return new LoginResult
		{
			Success = aiVisionRunResult.Success,
			TinhTrang = tinhTrang,
			TrangThai = ((!string.IsNullOrEmpty(aiVisionRunResult.Message)) ? aiVisionRunResult.Message : (aiVisionRunResult.Success ? "Đăng nhập thành công." : "Đăng nhập thất bại."))
		};
	}
}
