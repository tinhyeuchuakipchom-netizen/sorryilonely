using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class IPhoneMarkStepsAdapter : IMarkStepsDeviceAdapter
{
	private int A;

	private int a;

	public async Task<byte[]> CaptureScreenshotAsync(CancellationToken cancellationToken)
	{
		byte[] array = (await IPhoneController.ScreenshotAsync()) ?? throw new InvalidOperationException("Không chụp được màn hình iPhone (kiểm tra WebDriverAgent còn chạy không).");
		if (m_5761(array, out var num, out var num2))
		{
			A = num;
			a = num2;
		}
		return array;
	}

	public Task<List<UiElement>> DumpElementsAsync(CancellationToken cancellationToken)
	{
		return IPhoneController.DumpUiElementsAsync();
	}

	public async Task<(int X, int Y)> ToDeviceCoordinatesAsync(int pixelX, int pixelY, CancellationToken cancellationToken)
	{
		if (A <= 0 || a <= 0)
		{
			return (X: pixelX, Y: pixelY);
		}
		(int, int)? tuple = await IPhoneController.GetScreenSizeAsync();
		if (!tuple.HasValue)
		{
			return (X: pixelX, Y: pixelY);
		}
		double num = (double)tuple.Value.Item1 / (double)A;
		double num2 = (double)tuple.Value.Item2 / (double)a;
		return (X: (int)Math.Round((double)pixelX * num), Y: (int)Math.Round((double)pixelY * num2));
	}

	private static bool m_5761(byte[] P_0, out int P_1, out int P_2)
	{
		P_1 = (P_2 = 0);
		if (P_0.Length < 24 || P_0[0] != 137 || P_0[1] != 80 || P_0[2] != 78 || P_0[3] != 71)
		{
			return false;
		}
		P_1 = (P_0[16] << 24) | (P_0[17] << 16) | (P_0[18] << 8) | P_0[19];
		P_2 = (P_0[20] << 24) | (P_0[21] << 16) | (P_0[22] << 8) | P_0[23];
		if (P_1 > 0)
		{
			return P_2 > 0;
		}
		return false;
	}

	public async Task TapAsync(int x, int y, CancellationToken cancellationToken)
	{
		if (!(await IPhoneController.TapAsync(x, y)))
		{
			throw new InvalidOperationException($"Không gửi được thao tác chạm ({x},{y}) tới iPhone.");
		}
	}

	public async Task SwipeAsync(int x1, int y1, int x2, int y2, CancellationToken cancellationToken)
	{
		if (!(await IPhoneController.SwipeAsync(x1, y1, x2, y2)))
		{
			throw new InvalidOperationException($"Không gửi được thao tác vuốt ({x1},{y1})→({x2},{y2}) tới iPhone.");
		}
	}

	public async Task TypeTextAsync(string text, CancellationToken cancellationToken)
	{
		if (!(await IPhoneController.TypeTextReplacingAsync(text)))
		{
			throw new InvalidOperationException("Không gõ được chữ vào iPhone (có thể chưa ô nào đang nhận focus).");
		}
	}
}
