using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class AiVisionRunResult
{
	[CompilerGenerated]
	private bool A;

	[CompilerGenerated]
	private string m_5845 = "";

	[CompilerGenerated]
	private string? a;

	public bool Success
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Message
	{
		[CompilerGenerated]
		get
		{
			return m_5845;
		}
		[CompilerGenerated]
		set
		{
			m_5845 = value;
		}
	}

	public string? TinhTrang
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
