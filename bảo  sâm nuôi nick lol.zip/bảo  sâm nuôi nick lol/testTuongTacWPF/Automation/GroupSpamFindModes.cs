namespace testTuongTacWPF.Automation;

public static class GroupSpamFindModes
{
	public const string Scroll = "Scroll";

	public const string RefreshWait = "RefreshWait";
}
