using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class CustomPlatformEntry
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	public string Key
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Label
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}
}
