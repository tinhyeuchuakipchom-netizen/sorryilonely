using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using A;

namespace testTuongTacWPF.Automation;

public static class PhoneInitialSetupService
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5943
	{
		public static readonly m_5943 A = new m_5943();

		public static Action<string> m_5947;

		public static Func<string, string> m_5948;

		internal void m_5949(string P_0)
		{
		}

		internal string a(string P_0)
		{
			return "\"" + P_0 + "\"";
		}
	}

	private static readonly string A = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dulieu", "apk");

	private const string a = "https://d.apkpure.com/b/APK/com.zhiliaoapp.musically?version=latest";

	private static readonly (string ApkFile, string PackageName, string DisplayName)[] m_5938 = new (string, string, string)[8]
	{
		("superproxy.apk", "com.scheler.superproxy", "SuperProxy"),
		("app-deviceinfohw.apk", "ru.andr7e.deviceinfohw", "Device Info HW"),
		("1111.apk", "com.cloudflare.onedotonedotonedotone", "1.1.1.1"),
		("fbkatana.apk", "com.facebook.katana", "Facebook Katana"),
		("fblite.apk", "com.facebook.lite", "Facebook Lite"),
		("tiktok.apk", "com.zhiliaoapp.musically", "TikTok"),
		("adbchangelanguage.apk", "net.sanapeli.adbchangelanguage", "Đổi ngôn ngữ (ADB Change Language)"),
		("ADBKeyboard.apk", "com.android.adbkeyboard", "ADB Keyboard (hỗ trợ gõ tiếng Việt)")
	};

	private const string B = "com.android.adbkeyboard";

	private const string b = "com.android.adbkeyboard/.AdbIME";

	public static string GetApkPath(string apkFile)
	{
		string text = Path.Combine(A, apkFile);
		if (File.Exists(text))
		{
			return text;
		}
		InlineArray7<string> buffer = default;
		H.a<InlineArray7<string>, string>(ref buffer, 0) = AppDomain.CurrentDomain.BaseDirectory;
		H.a<InlineArray7<string>, string>(ref buffer, 1) = "..";
		H.a<InlineArray7<string>, string>(ref buffer, 2) = "..";
		H.a<InlineArray7<string>, string>(ref buffer, 3) = "..";
		H.a<InlineArray7<string>, string>(ref buffer, 4) = "dulieu";
		H.a<InlineArray7<string>, string>(ref buffer, 5) = "apk";
		H.a<InlineArray7<string>, string>(ref buffer, 6) = apkFile;
		string text2 = Path.Combine(H.m_6821<InlineArray7<string>, string>(in buffer, 7));
		if (File.Exists(text2))
		{
			return text2;
		}
		string text3 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dulieu", "apk", apkFile);
		if (File.Exists(text3))
		{
			return text3;
		}
		return text;
	}

	public static async Task<string> EnsureTikTokApkDownloadedAsync(Action<string>? onStatus = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		string apkPath = GetApkPath("tiktok.apk");
		if (File.Exists(apkPath) && new FileInfo(apkPath).Length > 52428800)
		{
			return apkPath;
		}
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dulieu", "apk");
		Directory.CreateDirectory(text);
		string text2 = Path.Combine(text, "tiktok.apk");
		onStatus?.Invoke("Đang tải phiên bản TikTok APK mới nhất...");
		try
		{
			using HttpClient httpClient = new HttpClient(new SocketsHttpHandler
			{
				PooledConnectionLifetime = TimeSpan.FromMinutes(5L)
			})
			{
				Timeout = TimeSpan.FromMinutes(10L)
			};
			httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
			using HttpResponseMessage httpResponseMessage = await httpClient.GetAsync("https://d.apkpure.com/b/APK/com.zhiliaoapp.musically?version=latest", HttpCompletionOption.ResponseHeadersRead, cancellationToken);
			httpResponseMessage.EnsureSuccessStatusCode();
			long? contentLength = httpResponseMessage.Content.Headers.ContentLength;
			string result;
			await using (Stream stream = await httpResponseMessage.Content.ReadAsStreamAsync(cancellationToken))
			{
				string text4;
				await using (FileStream fileStream = new FileStream(text2, FileMode.Create, FileAccess.Write, FileShare.None))
				{
					byte[] array = new byte[131072];
					long num = 0L;
					DateTime now = DateTime.Now;
					while (true)
					{
						int num3;
						int num2 = (num3 = await stream.ReadAsync(array.AsMemory(0, array.Length), cancellationToken));
						if (num3 <= 0)
						{
							break;
						}
						await fileStream.WriteAsync(array.AsMemory(0, num2), cancellationToken);
						num += num2;
						if ((DateTime.Now - now).TotalMilliseconds > 800.0)
						{
							now = DateTime.Now;
							if (contentLength.HasValue && contentLength.Value > 0)
							{
								double value = (double)num / 1048576.0;
								double value2 = (double)contentLength.Value / 1048576.0;
								int value3 = (int)(num * 100 / contentLength.Value);
								onStatus?.Invoke($"Đang tải TikTok APK: {value:F1}/{value2:F1} MB ({value3}%)...");
							}
							else
							{
								double value4 = (double)num / 1048576.0;
								onStatus?.Invoke($"Đang tải TikTok APK: {value4:F1} MB...");
							}
						}
					}
					onStatus?.Invoke("Đã tải xong TikTok APK.");
					try
					{
						InlineArray6<string> buffer = default;
						H.a<InlineArray6<string>, string>(ref buffer, 0) = AppDomain.CurrentDomain.BaseDirectory;
						H.a<InlineArray6<string>, string>(ref buffer, 1) = "..";
						H.a<InlineArray6<string>, string>(ref buffer, 2) = "..";
						H.a<InlineArray6<string>, string>(ref buffer, 3) = "..";
						H.a<InlineArray6<string>, string>(ref buffer, 4) = "dulieu";
						H.a<InlineArray6<string>, string>(ref buffer, 5) = "apk";
						string text3 = Path.Combine(H.m_6821<InlineArray6<string>, string>(in buffer, 6));
						if (Directory.Exists(text3))
						{
							File.Copy(text2, Path.Combine(text3, "tiktok.apk"), overwrite: true);
						}
					}
					catch
					{
					}
					text4 = text2;
				}
				result = text4;
			}
			return result;
		}
		catch (Exception ex)
		{
			onStatus?.Invoke("Lỗi tải TikTok APK: " + ex.Message);
			throw;
		}
	}

	public static async Task<bool> IsInitialSetupNeededAsync(string deviceSerial, string platformOrPackage = "All", CancellationToken cancellationToken = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(deviceSerial))
		{
			return false;
		}
		if (!(await IsPackageInstalledAsync(deviceSerial, "com.scheler.superproxy", cancellationToken)))
		{
			return true;
		}
		if (!(await IsPackageInstalledAsync(deviceSerial, "com.android.adbkeyboard", cancellationToken)))
		{
			return true;
		}
		if (!(await IsPackageInstalledAsync(deviceSerial, "net.sanapeli.adbchangelanguage", cancellationToken)))
		{
			return true;
		}
		if (platformOrPackage.Equals("All", StringComparison.OrdinalIgnoreCase) || platformOrPackage.IndexOf("Face", StringComparison.OrdinalIgnoreCase) >= 0 || platformOrPackage.IndexOf("Katana", StringComparison.OrdinalIgnoreCase) >= 0 || platformOrPackage.IndexOf("Lite", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			bool flag = await IsPackageInstalledAsync(deviceSerial, "com.facebook.katana", cancellationToken);
			if (!flag)
			{
				flag = await IsPackageInstalledAsync(deviceSerial, "com.facebook.lite", cancellationToken);
			}
			if (!flag)
			{
				return true;
			}
		}
		if (platformOrPackage.Equals("All", StringComparison.OrdinalIgnoreCase) || platformOrPackage.IndexOf("TikTok", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			bool flag = await IsPackageInstalledAsync(deviceSerial, "com.zhiliaoapp.musically", cancellationToken);
			if (!flag)
			{
				flag = await IsPackageInstalledAsync(deviceSerial, "com.ss.android.ugc.trill", cancellationToken);
			}
			bool flag2 = flag;
			if (!flag2)
			{
				flag2 = await IsPackageInstalledAsync(deviceSerial, "com.zhiliaoapp.musically.go", cancellationToken);
			}
			if (!flag2)
			{
				return true;
			}
		}
		return false;
	}

	public static async Task<bool> EnsureInitialSetupAsync(string deviceSerial, string platformOrPackage, Action<string>? onStatus, CancellationToken cancellationToken = default(CancellationToken))
	{
		if (string.IsNullOrWhiteSpace(deviceSerial))
		{
			return false;
		}
		if (await IsInitialSetupNeededAsync(deviceSerial, platformOrPackage, cancellationToken))
		{
			onStatus?.Invoke("Phát hiện máy chưa cài đặt lần đầu hoặc thiếu ứng dụng, đang tiến hành Cài đặt ban đầu...");
			await RunAsync(deviceSerial, onStatus ?? ((Action<string>)delegate
			{
			}), cancellationToken);
			return true;
		}
		return false;
	}

	public static async Task RunAsync(string deviceSerial, Action<string> onStatus, CancellationToken cancellationToken)
	{
		onStatus("Đang mở Cài đặt Wifi...");
		await m_5941(deviceSerial, "am start -a android.settings.WIFI_SETTINGS", cancellationToken);
		onStatus("Đang tắt khoá màn hình...");
		await m_5941(deviceSerial, "locksettings set-disabled true", cancellationToken);
		(string ApkFile, string PackageName, string DisplayName)[] array = m_5938;
		for (int i = 0; i < array.Length; i++)
		{
			var (text, packageName, text2) = array[i];
			cancellationToken.ThrowIfCancellationRequested();
			onStatus("Đang kiểm tra " + text2 + "...");
			bool flag = await IsPackageInstalledAsync(deviceSerial, packageName, cancellationToken);
			if (flag)
			{
				continue;
			}
			string text3 = GetApkPath(text);
			if (text.Equals("tiktok.apk", StringComparison.OrdinalIgnoreCase) && !File.Exists(text3))
			{
				try
				{
					text3 = await EnsureTikTokApkDownloadedAsync(onStatus, cancellationToken);
				}
				catch (Exception ex)
				{
					onStatus("Tải TikTok thất bại: " + ex.Message);
				}
			}
			if (!File.Exists(text3))
			{
				bool flag2 = text == "fblite.apk";
				if (flag2)
				{
					flag2 = await IsPackageInstalledAsync(deviceSerial, "com.facebook.katana", cancellationToken);
				}
				if (!flag2)
				{
					onStatus($"Thiếu file {text} - bỏ qua {text2}.");
				}
				continue;
			}
			for (int j = 1; j <= 3; j++)
			{
				if (flag)
				{
					break;
				}
				onStatus($"Đang cài {text2} (lần {j})...");
				await m_5940(deviceSerial, text3, cancellationToken);
				await Task.Delay(2000, cancellationToken);
				flag = await IsPackageInstalledAsync(deviceSerial, packageName, cancellationToken);
			}
			if (!flag)
			{
				onStatus("Không cài được " + text2 + " - kiểm tra lại máy.");
			}
		}
		onStatus("Đang đổi ngôn ngữ máy sang Tiếng Anh (app ADB Change Language)...");
		await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
		onStatus("Đang tắt xoay màn hình + giữ sáng màn hình...");
		await m_5941(deviceSerial, "settings put system accelerometer_rotation 0", cancellationToken);
		await m_5941(deviceSerial, "svc power stayon true", cancellationToken);
		onStatus("Đang xoá dữ liệu cũ SuperProxy/1.1.1.1...");
		await m_5941(deviceSerial, "pm clear com.cloudflare.onedotonedotonedotone", cancellationToken);
		await m_5941(deviceSerial, "pm clear com.scheler.superproxy", cancellationToken);
		onStatus("Đang kích hoạt ADB Keyboard...");
		await m_5939(deviceSerial, cancellationToken);
		onStatus("Đang cấp quyền ứng dụng...");
		try
		{
			await AdbController.GrantAllAppPermissionsAsync(deviceSerial, "com.facebook.katana", cancellationToken);
		}
		catch
		{
		}
		try
		{
			await AdbController.GrantAllAppPermissionsAsync(deviceSerial, "com.facebook.lite", cancellationToken);
		}
		catch
		{
		}
		try
		{
			await AdbController.GrantAllAppPermissionsAsync(deviceSerial, "com.scheler.superproxy", cancellationToken);
		}
		catch
		{
		}
		try
		{
			await AdbController.GrantAllAppPermissionsAsync(deviceSerial, "com.zhiliaoapp.musically", cancellationToken);
		}
		catch
		{
		}
		try
		{
			await AdbController.GrantAllAppPermissionsAsync(deviceSerial, "com.ss.android.ugc.trill", cancellationToken);
		}
		catch
		{
		}
		onStatus("Cài đặt ban đầu hoàn tất.");
	}

	private static async Task m_5939(string P_0, CancellationToken P_1)
	{
		string text = (await m_5941(P_0, "settings get secure enabled_input_methods", P_1)).Trim();
		string text2;
		if (string.IsNullOrEmpty(text) || text.Equals("null", StringComparison.OrdinalIgnoreCase))
		{
			text2 = "com.android.adbkeyboard/.AdbIME:com.android.inputmethod.pinyin/.InputService";
		}
		else
		{
			text2 = ((!text.Contains("com.android.adbkeyboard/.AdbIME", StringComparison.OrdinalIgnoreCase)) ? ("com.android.adbkeyboard/.AdbIME:" + text) : text);
		}
		await m_5941(P_0, "settings put secure enabled_input_methods \"" + text2 + "\"", P_1);
		await m_5941(P_0, "settings put secure default_input_method com.android.adbkeyboard/.AdbIME", P_1);
		await m_5941(P_0, "ime enable com.android.adbkeyboard/.AdbIME", P_1);
		await m_5941(P_0, "ime set com.android.adbkeyboard/.AdbIME", P_1);
	}

	public static async Task<bool> IsPackageInstalledAsync(string deviceSerial, string packageName, CancellationToken cancellationToken = default(CancellationToken))
	{
		return (await m_5941(deviceSerial, "pm list packages " + packageName, cancellationToken)).Contains(packageName, StringComparison.OrdinalIgnoreCase);
	}

	private static async Task m_5940(string P_0, string P_1, CancellationToken P_2)
	{
		string path = (P_1.EndsWith(".apk", StringComparison.OrdinalIgnoreCase) ? Path.Combine(Path.GetDirectoryName(P_1) ?? "", Path.GetFileNameWithoutExtension(P_1) + "_splits") : P_1);
		string text2;
		if (Directory.Exists(path) && Directory.GetFiles(path, "*.apk").Length != 0)
		{
			string[] files = Directory.GetFiles(path, "*.apk");
			string text = string.Join(" ", files.Select((string text3) => "\"" + text3 + "\""));
			text2 = "-s " + P_0 + " install-multiple -r -d " + text;
		}
		else
		{
			text2 = $"-s {P_0} install -r -d \"{P_1}\"";
		}
		using Process process = m_5942(text2);
		await process.StandardOutput.ReadToEndAsync(P_2);
		await process.StandardError.ReadToEndAsync(P_2);
		await process.WaitForExitAsync(P_2);
	}

	private static async Task<string> m_5941(string P_0, string P_1, CancellationToken P_2)
	{
		using Process process = m_5942("-s " + P_0 + " shell " + P_1);
		string result = await process.StandardOutput.ReadToEndAsync(P_2);
		await process.StandardError.ReadToEndAsync(P_2);
		await process.WaitForExitAsync(P_2);
		return result;
	}

	private static Process m_5942(string P_0)
	{
		return Process.Start(new ProcessStartInfo
		{
			FileName = AdbController.AdbExePath,
			Arguments = P_0,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			UseShellExecute = false,
			CreateNoWindow = true
		}) ?? throw new InvalidOperationException("Không khởi động được adb.exe.");
	}
}
