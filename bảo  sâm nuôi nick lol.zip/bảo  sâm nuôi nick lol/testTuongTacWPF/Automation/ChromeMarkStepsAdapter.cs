using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;

namespace testTuongTacWPF.Automation;

public class ChromeMarkStepsAdapter : IMarkStepsDeviceAdapter
{
	private sealed class m_3803
	{
		public bool A;

		public Action<LiveRecordedAction>? m_3805;

		public string? m_3806;
	}

	private sealed class m_3804
	{
		[CompilerGenerated]
		private string m_3807 = "";

		[CompilerGenerated]
		private int m_3808;

		[CompilerGenerated]
		private int a;

		[CompilerGenerated]
		private string? m_3809;

		[CompilerGenerated]
		private string? B;

		[CompilerGenerated]
		private string? b;

		[CompilerGenerated]
		private string? C;

		[CompilerGenerated]
		private int m_3810;

		[CompilerGenerated]
		private int m_3811;

		[CompilerGenerated]
		private string? c;

		public string A
		{
			[CompilerGenerated]
			get
			{
				return m_3807;
			}
			[CompilerGenerated]
			set
			{
				m_3807 = value;
			}
		}

		[SpecialName]
		[CompilerGenerated]
		public int m_3812()
		{
			return m_3808;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3813(int P_0)
		{
			m_3808 = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public int m_3814()
		{
			return a;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3815(int P_0)
		{
			a = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public string? m_3816()
		{
			return m_3809;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3817(string? P_0)
		{
			m_3809 = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public string? m_3818()
		{
			return B;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3819(string? P_0)
		{
			B = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public string? m_3820()
		{
			return b;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3821(string? P_0)
		{
			b = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public string? D()
		{
			return C;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3822(string? P_0)
		{
			C = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public int d()
		{
			return m_3810;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3823(int P_0)
		{
			m_3810 = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public int E()
		{
			return m_3811;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3824(int P_0)
		{
			m_3811 = P_0;
		}

		[SpecialName]
		[CompilerGenerated]
		public string? e()
		{
			return c;
		}

		[SpecialName]
		[CompilerGenerated]
		public void m_3825(string? P_0)
		{
			c = P_0;
		}
	}

	[CompilerGenerated]
	private sealed class B
	{
		public m_3803 A;

		public ChromeMarkStepsAdapter m_3826;

		internal void m_3827(string P_0)
		{
			try
			{
				m_3804 obj = JsonSerializer.Deserialize<m_3804>(P_0, m_3801);
				if (obj != null)
				{
					LiveRecordedActionKind kind = obj.A switch
					{
						"text" => LiveRecordedActionKind.Text, 
						"scroll" => LiveRecordedActionKind.Scroll, 
						"keypress" => LiveRecordedActionKind.KeyPress, 
						_ => LiveRecordedActionKind.Tap, 
					};
					A.m_3805?.Invoke(new LiveRecordedAction
					{
						Kind = kind,
						X = obj.m_3812(),
						Y = obj.m_3814(),
						Value = (obj.m_3816() ?? obj.e()),
						ResourceId = obj.m_3818(),
						ContentDesc = obj.m_3820(),
						ElementText = obj.D(),
						DeltaX = obj.d(),
						DeltaY = obj.E()
					});
				}
			}
			catch
			{
			}
		}

		internal async void m_3828(object? _, IFrame P_1)
		{
			if (P_1 != m_3826.A.MainFrame)
			{
				return;
			}
			if (A.m_3805 != null && P_1.Url != A.m_3806 && P_1.Url != "about:blank")
			{
				A.m_3806 = P_1.Url;
				A.m_3805(new LiveRecordedAction
				{
					Kind = LiveRecordedActionKind.Navigate,
					Url = P_1.Url
				});
			}
			try
			{
				await m_3826.A.EvaluateAsync("() => {\n            if (window.__aiVisionListenerInstalled) return;\n            window.__aiVisionListenerInstalled = true;\n            window.__aiVisionRecording = window.__aiVisionRecording || false;\n\n            function isTextEntry(el) {\n                if (!el) return false;\n                if (el.isContentEditable) return true;\n                const tag = el.tagName;\n                if (tag === 'TEXTAREA') return true;\n                if (tag === 'INPUT') {\n                    const t = (el.type || 'text').toLowerCase();\n                    return ['text','email','password','search','tel','url','number'].includes(t);\n                }\n                return false;\n            }\n\n            function getElementInfo(el) {\n                if (!el) return { id: '', ariaLabel: '', text: '' };\n                let cur = el;\n                // Đi lên tối đa 3 cấp để tìm phần tử có id/aria-label ý nghĩa (text button thường wrap trong span)\n                for (let i = 0; i < 3 && cur; i++) {\n                    const id = cur.id || '';\n                    const ariaLabel = (cur.getAttribute && cur.getAttribute('aria-label')) || '';\n                    const text = (cur.innerText || cur.value || cur.placeholder || '').toString().trim().slice(0, 80);\n                    if (id || ariaLabel || text) return { id, ariaLabel, text };\n                    cur = cur.parentElement;\n                }\n                return { id: '', ariaLabel: '', text: '' };\n            }\n\n            const debounceTimers = new WeakMap();\n            const lastSentValue = new WeakMap();\n\n            function sendText(el) {\n                const value = el.isContentEditable ? el.innerText : el.value;\n                if (lastSentValue.get(el) === value) return;\n                lastSentValue.set(el, value);\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'text', value: value }));\n            }\n\n            document.addEventListener('click', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const info = getElementInfo(e.target);\n                window.__aiVisionLiveEvent(JSON.stringify({\n                    kind: 'tap',\n                    x: Math.round(e.clientX), y: Math.round(e.clientY),\n                    id: info.id, ariaLabel: info.ariaLabel, text: info.text\n                }));\n            }, true);\n\n            document.addEventListener('input', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                debounceTimers.set(el, setTimeout(function () { sendText(el); }, 800));\n            }, true);\n\n            document.addEventListener('change', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                sendText(el);\n            }, true);\n\n            // Lăn chuột — debounce 120ms để gộp nhiều notch liên tiếp thành 1 bước\n            let wheelTimer = null;\n            let wheelAccX = 0, wheelAccY = 0, wheelLastX = 0, wheelLastY = 0;\n            document.addEventListener('wheel', function (e) {\n                if (!window.__aiVisionRecording) return;\n                wheelAccX += e.deltaX;\n                wheelAccY += e.deltaY;\n                wheelLastX = Math.round(e.clientX);\n                wheelLastY = Math.round(e.clientY);\n                clearTimeout(wheelTimer);\n                wheelTimer = setTimeout(function () {\n                    const dx = Math.round(wheelAccX);\n                    const dy = Math.round(wheelAccY);\n                    wheelAccX = 0; wheelAccY = 0;\n                    if (dx !== 0 || dy !== 0)\n                        window.__aiVisionLiveEvent(JSON.stringify({ kind: 'scroll', x: wheelLastX, y: wheelLastY, deltaX: dx, deltaY: dy }));\n                }, 120);\n            }, { capture: true, passive: true });\n\n            // Phím bàn phím — chỉ ghi các phím điều hướng/tác vụ, bỏ qua phím ký tự (đã có 'input' lo)\n            const RECORD_KEYS = new Set(['Tab','Enter','Escape','ArrowUp','ArrowDown','ArrowLeft','ArrowRight',\n                'Backspace','Delete','Home','End','PageUp','PageDown','F5']);\n            document.addEventListener('keydown', function (e) {\n                if (!window.__aiVisionRecording) return;\n                if (!RECORD_KEYS.has(e.key)) return;\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'keypress', key: e.key }));\n            }, true);\n        }");
				await m_3826.A.EvaluateAsync("window.__aiVisionRecording = " + ((A.m_3805 != null) ? "true" : "false") + ";");
			}
			catch
			{
			}
		}
	}

	private readonly IPage A;

	private static readonly ConditionalWeakTable<IPage, m_3803> m_3800 = new ConditionalWeakTable<IPage, m_3803>();

	private static readonly JsonSerializerOptions m_3801 = new JsonSerializerOptions
	{
		PropertyNameCaseInsensitive = true
	};

	private const string m_3802 = "__aiVisionLiveEvent";

	private const string a = "() => {\n            if (window.__aiVisionListenerInstalled) return;\n            window.__aiVisionListenerInstalled = true;\n            window.__aiVisionRecording = window.__aiVisionRecording || false;\n\n            function isTextEntry(el) {\n                if (!el) return false;\n                if (el.isContentEditable) return true;\n                const tag = el.tagName;\n                if (tag === 'TEXTAREA') return true;\n                if (tag === 'INPUT') {\n                    const t = (el.type || 'text').toLowerCase();\n                    return ['text','email','password','search','tel','url','number'].includes(t);\n                }\n                return false;\n            }\n\n            function getElementInfo(el) {\n                if (!el) return { id: '', ariaLabel: '', text: '' };\n                let cur = el;\n                // Đi lên tối đa 3 cấp để tìm phần tử có id/aria-label ý nghĩa (text button thường wrap trong span)\n                for (let i = 0; i < 3 && cur; i++) {\n                    const id = cur.id || '';\n                    const ariaLabel = (cur.getAttribute && cur.getAttribute('aria-label')) || '';\n                    const text = (cur.innerText || cur.value || cur.placeholder || '').toString().trim().slice(0, 80);\n                    if (id || ariaLabel || text) return { id, ariaLabel, text };\n                    cur = cur.parentElement;\n                }\n                return { id: '', ariaLabel: '', text: '' };\n            }\n\n            const debounceTimers = new WeakMap();\n            const lastSentValue = new WeakMap();\n\n            function sendText(el) {\n                const value = el.isContentEditable ? el.innerText : el.value;\n                if (lastSentValue.get(el) === value) return;\n                lastSentValue.set(el, value);\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'text', value: value }));\n            }\n\n            document.addEventListener('click', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const info = getElementInfo(e.target);\n                window.__aiVisionLiveEvent(JSON.stringify({\n                    kind: 'tap',\n                    x: Math.round(e.clientX), y: Math.round(e.clientY),\n                    id: info.id, ariaLabel: info.ariaLabel, text: info.text\n                }));\n            }, true);\n\n            document.addEventListener('input', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                debounceTimers.set(el, setTimeout(function () { sendText(el); }, 800));\n            }, true);\n\n            document.addEventListener('change', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                sendText(el);\n            }, true);\n\n            // Lăn chuột — debounce 120ms để gộp nhiều notch liên tiếp thành 1 bước\n            let wheelTimer = null;\n            let wheelAccX = 0, wheelAccY = 0, wheelLastX = 0, wheelLastY = 0;\n            document.addEventListener('wheel', function (e) {\n                if (!window.__aiVisionRecording) return;\n                wheelAccX += e.deltaX;\n                wheelAccY += e.deltaY;\n                wheelLastX = Math.round(e.clientX);\n                wheelLastY = Math.round(e.clientY);\n                clearTimeout(wheelTimer);\n                wheelTimer = setTimeout(function () {\n                    const dx = Math.round(wheelAccX);\n                    const dy = Math.round(wheelAccY);\n                    wheelAccX = 0; wheelAccY = 0;\n                    if (dx !== 0 || dy !== 0)\n                        window.__aiVisionLiveEvent(JSON.stringify({ kind: 'scroll', x: wheelLastX, y: wheelLastY, deltaX: dx, deltaY: dy }));\n                }, 120);\n            }, { capture: true, passive: true });\n\n            // Phím bàn phím — chỉ ghi các phím điều hướng/tác vụ, bỏ qua phím ký tự (đã có 'input' lo)\n            const RECORD_KEYS = new Set(['Tab','Enter','Escape','ArrowUp','ArrowDown','ArrowLeft','ArrowRight',\n                'Backspace','Delete','Home','End','PageUp','PageDown','F5']);\n            document.addEventListener('keydown', function (e) {\n                if (!window.__aiVisionRecording) return;\n                if (!RECORD_KEYS.has(e.key)) return;\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'keypress', key: e.key }));\n            }, true);\n        }";

	public bool SupportsLiveRecording => true;

	public ChromeMarkStepsAdapter(IPage page)
	{
		A = page;
	}

	public async Task StartLiveRecordingAsync(Action<LiveRecordedAction> onActionCaptured, CancellationToken cancellationToken)
	{
		m_3803 A = m_3800.GetOrCreateValue(this.A);
		A.m_3805 = onActionCaptured;
		A.m_3806 = this.A.Url;
		if (!A.A)
		{
			await this.A.ExposeFunctionAsync("__aiVisionLiveEvent", (string P_0) =>
			{
				try
				{
					m_3804 obj = JsonSerializer.Deserialize<m_3804>(P_0, m_3801);
					if (obj != null)
					{
						LiveRecordedActionKind kind = obj.A switch
						{
							"text" => LiveRecordedActionKind.Text, 
							"scroll" => LiveRecordedActionKind.Scroll, 
							"keypress" => LiveRecordedActionKind.KeyPress, 
							_ => LiveRecordedActionKind.Tap, 
						};
						A.m_3805?.Invoke(new LiveRecordedAction
						{
							Kind = kind,
							X = obj.m_3812(),
							Y = obj.m_3814(),
							Value = (obj.m_3816() ?? obj.e()),
							ResourceId = obj.m_3818(),
							ContentDesc = obj.m_3820(),
							ElementText = obj.D(),
							DeltaX = obj.d(),
							DeltaY = obj.E()
						});
					}
				}
				catch
				{
				}
			});
			this.A.FrameNavigated += async (object? _, IFrame P_1) =>
			{
				if (P_1 != this.A.MainFrame)
				{
					return;
				}
				if (A.m_3805 != null && P_1.Url != A.m_3806 && P_1.Url != "about:blank")
				{
					A.m_3806 = P_1.Url;
					A.m_3805(new LiveRecordedAction
					{
						Kind = LiveRecordedActionKind.Navigate,
						Url = P_1.Url
					});
				}
				try
				{
					await this.A.EvaluateAsync("() => {\n            if (window.__aiVisionListenerInstalled) return;\n            window.__aiVisionListenerInstalled = true;\n            window.__aiVisionRecording = window.__aiVisionRecording || false;\n\n            function isTextEntry(el) {\n                if (!el) return false;\n                if (el.isContentEditable) return true;\n                const tag = el.tagName;\n                if (tag === 'TEXTAREA') return true;\n                if (tag === 'INPUT') {\n                    const t = (el.type || 'text').toLowerCase();\n                    return ['text','email','password','search','tel','url','number'].includes(t);\n                }\n                return false;\n            }\n\n            function getElementInfo(el) {\n                if (!el) return { id: '', ariaLabel: '', text: '' };\n                let cur = el;\n                // Đi lên tối đa 3 cấp để tìm phần tử có id/aria-label ý nghĩa (text button thường wrap trong span)\n                for (let i = 0; i < 3 && cur; i++) {\n                    const id = cur.id || '';\n                    const ariaLabel = (cur.getAttribute && cur.getAttribute('aria-label')) || '';\n                    const text = (cur.innerText || cur.value || cur.placeholder || '').toString().trim().slice(0, 80);\n                    if (id || ariaLabel || text) return { id, ariaLabel, text };\n                    cur = cur.parentElement;\n                }\n                return { id: '', ariaLabel: '', text: '' };\n            }\n\n            const debounceTimers = new WeakMap();\n            const lastSentValue = new WeakMap();\n\n            function sendText(el) {\n                const value = el.isContentEditable ? el.innerText : el.value;\n                if (lastSentValue.get(el) === value) return;\n                lastSentValue.set(el, value);\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'text', value: value }));\n            }\n\n            document.addEventListener('click', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const info = getElementInfo(e.target);\n                window.__aiVisionLiveEvent(JSON.stringify({\n                    kind: 'tap',\n                    x: Math.round(e.clientX), y: Math.round(e.clientY),\n                    id: info.id, ariaLabel: info.ariaLabel, text: info.text\n                }));\n            }, true);\n\n            document.addEventListener('input', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                debounceTimers.set(el, setTimeout(function () { sendText(el); }, 800));\n            }, true);\n\n            document.addEventListener('change', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                sendText(el);\n            }, true);\n\n            // Lăn chuột — debounce 120ms để gộp nhiều notch liên tiếp thành 1 bước\n            let wheelTimer = null;\n            let wheelAccX = 0, wheelAccY = 0, wheelLastX = 0, wheelLastY = 0;\n            document.addEventListener('wheel', function (e) {\n                if (!window.__aiVisionRecording) return;\n                wheelAccX += e.deltaX;\n                wheelAccY += e.deltaY;\n                wheelLastX = Math.round(e.clientX);\n                wheelLastY = Math.round(e.clientY);\n                clearTimeout(wheelTimer);\n                wheelTimer = setTimeout(function () {\n                    const dx = Math.round(wheelAccX);\n                    const dy = Math.round(wheelAccY);\n                    wheelAccX = 0; wheelAccY = 0;\n                    if (dx !== 0 || dy !== 0)\n                        window.__aiVisionLiveEvent(JSON.stringify({ kind: 'scroll', x: wheelLastX, y: wheelLastY, deltaX: dx, deltaY: dy }));\n                }, 120);\n            }, { capture: true, passive: true });\n\n            // Phím bàn phím — chỉ ghi các phím điều hướng/tác vụ, bỏ qua phím ký tự (đã có 'input' lo)\n            const RECORD_KEYS = new Set(['Tab','Enter','Escape','ArrowUp','ArrowDown','ArrowLeft','ArrowRight',\n                'Backspace','Delete','Home','End','PageUp','PageDown','F5']);\n            document.addEventListener('keydown', function (e) {\n                if (!window.__aiVisionRecording) return;\n                if (!RECORD_KEYS.has(e.key)) return;\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'keypress', key: e.key }));\n            }, true);\n        }");
					await this.A.EvaluateAsync("window.__aiVisionRecording = " + ((A.m_3805 != null) ? "true" : "false") + ";");
				}
				catch
				{
				}
			};
			A.A = true;
		}
		await this.A.EvaluateAsync("() => {\n            if (window.__aiVisionListenerInstalled) return;\n            window.__aiVisionListenerInstalled = true;\n            window.__aiVisionRecording = window.__aiVisionRecording || false;\n\n            function isTextEntry(el) {\n                if (!el) return false;\n                if (el.isContentEditable) return true;\n                const tag = el.tagName;\n                if (tag === 'TEXTAREA') return true;\n                if (tag === 'INPUT') {\n                    const t = (el.type || 'text').toLowerCase();\n                    return ['text','email','password','search','tel','url','number'].includes(t);\n                }\n                return false;\n            }\n\n            function getElementInfo(el) {\n                if (!el) return { id: '', ariaLabel: '', text: '' };\n                let cur = el;\n                // Đi lên tối đa 3 cấp để tìm phần tử có id/aria-label ý nghĩa (text button thường wrap trong span)\n                for (let i = 0; i < 3 && cur; i++) {\n                    const id = cur.id || '';\n                    const ariaLabel = (cur.getAttribute && cur.getAttribute('aria-label')) || '';\n                    const text = (cur.innerText || cur.value || cur.placeholder || '').toString().trim().slice(0, 80);\n                    if (id || ariaLabel || text) return { id, ariaLabel, text };\n                    cur = cur.parentElement;\n                }\n                return { id: '', ariaLabel: '', text: '' };\n            }\n\n            const debounceTimers = new WeakMap();\n            const lastSentValue = new WeakMap();\n\n            function sendText(el) {\n                const value = el.isContentEditable ? el.innerText : el.value;\n                if (lastSentValue.get(el) === value) return;\n                lastSentValue.set(el, value);\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'text', value: value }));\n            }\n\n            document.addEventListener('click', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const info = getElementInfo(e.target);\n                window.__aiVisionLiveEvent(JSON.stringify({\n                    kind: 'tap',\n                    x: Math.round(e.clientX), y: Math.round(e.clientY),\n                    id: info.id, ariaLabel: info.ariaLabel, text: info.text\n                }));\n            }, true);\n\n            document.addEventListener('input', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                debounceTimers.set(el, setTimeout(function () { sendText(el); }, 800));\n            }, true);\n\n            document.addEventListener('change', function (e) {\n                if (!window.__aiVisionRecording) return;\n                const el = e.target;\n                if (!isTextEntry(el)) return;\n                clearTimeout(debounceTimers.get(el));\n                sendText(el);\n            }, true);\n\n            // Lăn chuột — debounce 120ms để gộp nhiều notch liên tiếp thành 1 bước\n            let wheelTimer = null;\n            let wheelAccX = 0, wheelAccY = 0, wheelLastX = 0, wheelLastY = 0;\n            document.addEventListener('wheel', function (e) {\n                if (!window.__aiVisionRecording) return;\n                wheelAccX += e.deltaX;\n                wheelAccY += e.deltaY;\n                wheelLastX = Math.round(e.clientX);\n                wheelLastY = Math.round(e.clientY);\n                clearTimeout(wheelTimer);\n                wheelTimer = setTimeout(function () {\n                    const dx = Math.round(wheelAccX);\n                    const dy = Math.round(wheelAccY);\n                    wheelAccX = 0; wheelAccY = 0;\n                    if (dx !== 0 || dy !== 0)\n                        window.__aiVisionLiveEvent(JSON.stringify({ kind: 'scroll', x: wheelLastX, y: wheelLastY, deltaX: dx, deltaY: dy }));\n                }, 120);\n            }, { capture: true, passive: true });\n\n            // Phím bàn phím — chỉ ghi các phím điều hướng/tác vụ, bỏ qua phím ký tự (đã có 'input' lo)\n            const RECORD_KEYS = new Set(['Tab','Enter','Escape','ArrowUp','ArrowDown','ArrowLeft','ArrowRight',\n                'Backspace','Delete','Home','End','PageUp','PageDown','F5']);\n            document.addEventListener('keydown', function (e) {\n                if (!window.__aiVisionRecording) return;\n                if (!RECORD_KEYS.has(e.key)) return;\n                window.__aiVisionLiveEvent(JSON.stringify({ kind: 'keypress', key: e.key }));\n            }, true);\n        }");
		await this.A.EvaluateAsync("window.__aiVisionRecording = true;");
	}

	public async Task StopLiveRecordingAsync(CancellationToken cancellationToken)
	{
		if (m_3800.TryGetValue(A, out m_3803 value))
		{
			value.m_3805 = null;
		}
		try
		{
			await A.EvaluateAsync("window.__aiVisionRecording = false;");
		}
		catch
		{
		}
	}

	public async Task<byte[]> CaptureScreenshotAsync(CancellationToken cancellationToken)
	{
		return await A.ScreenshotAsync(new PageScreenshotOptions
		{
			Type = ScreenshotType.Png
		});
	}

	public async Task<(int X, int Y)> ToDeviceCoordinatesAsync(int pixelX, int pixelY, CancellationToken cancellationToken)
	{
		try
		{
			double num = await A.EvaluateAsync<double>("window.devicePixelRatio");
			if (num > 1.0)
			{
				return (X: (int)Math.Round((double)pixelX / num), Y: (int)Math.Round((double)pixelY / num));
			}
		}
		catch
		{
		}
		return (X: pixelX, Y: pixelY);
	}

	public Task<List<UiElement>> DumpElementsAsync(CancellationToken cancellationToken)
	{
		return ChromeAiVisionRunner.m_3470(A);
	}

	public async Task TapAsync(int x, int y, CancellationToken cancellationToken)
	{
		await A.Mouse.ClickAsync(x, y);
	}

	public async Task SwipeAsync(int x1, int y1, int x2, int y2, CancellationToken cancellationToken)
	{
		await A.Mouse.MoveAsync(x1, y1);
		await A.Mouse.DownAsync();
		await A.Mouse.MoveAsync(x2, y2, new MouseMoveOptions
		{
			Steps = 12
		});
		await A.Mouse.UpAsync();
	}

	public async Task TypeTextAsync(string text, CancellationToken cancellationToken)
	{
		await A.Keyboard.TypeAsync(text);
	}
}
