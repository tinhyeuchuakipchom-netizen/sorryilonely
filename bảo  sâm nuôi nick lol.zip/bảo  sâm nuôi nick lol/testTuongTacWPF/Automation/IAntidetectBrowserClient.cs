using System.Collections.Generic;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public interface IAntidetectBrowserClient
{
	Task<bool> CheckApiAliveAsync();

	Task<List<string>> GetRunningProfileNamesAsync();

	Task<OmoBrowserProfile> CreateProfileAsync(string profileName, string proxy, string userAgentOverride);

	Task<OmoBrowserStartResult> StartProfileAsync(string profileId);

	Task StopProfileAsync(string profileId);

	Task DeleteProfileAsync(string profileId, bool hard = false);
}
