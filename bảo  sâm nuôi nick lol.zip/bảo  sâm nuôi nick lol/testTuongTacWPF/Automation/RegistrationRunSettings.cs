using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class RegistrationRunSettings
{
	[CompilerGenerated]
	private int A = 1500;

	[CompilerGenerated]
	private int a = 1;

	[CompilerGenerated]
	private int B = 200;

	[CompilerGenerated]
	private bool m_6128;

	[CompilerGenerated]
	private bool m_6129;

	[CompilerGenerated]
	private bool m_6130;

	[CompilerGenerated]
	private int b = 60;

	[CompilerGenerated]
	private int C = 5;

	private static readonly string m_6131 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "registration_run_settings.json");

	public int ActionDelayMs
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int SubmitRetryCount
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int OtpWaitSeconds
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public bool BaitEnabled
	{
		[CompilerGenerated]
		get
		{
			return m_6128;
		}
		[CompilerGenerated]
		set
		{
			m_6128 = value;
		}
	}

	public bool BaitUsePhone
	{
		[CompilerGenerated]
		get
		{
			return m_6129;
		}
		[CompilerGenerated]
		set
		{
			m_6129 = value;
		}
	}

	public bool SaveNoveryWhenNoOtp
	{
		[CompilerGenerated]
		get
		{
			return m_6130;
		}
		[CompilerGenerated]
		set
		{
			m_6130 = value;
		}
	}

	public int PageTimeoutSeconds
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public int PageTimeoutMs => PageTimeoutSeconds * 1000;

	public int LiveCheckDelaySeconds
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int LiveCheckDelayMs => LiveCheckDelaySeconds * 1000;

	public static RegistrationRunSettings Load()
	{
		try
		{
			if (!File.Exists(m_6131))
			{
				return new RegistrationRunSettings();
			}
			return JsonSerializer.Deserialize<RegistrationRunSettings>(File.ReadAllText(m_6131)) ?? new RegistrationRunSettings();
		}
		catch
		{
			return new RegistrationRunSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(m_6131));
		File.WriteAllText(m_6131, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}

	public void Clamp()
	{
		if (ActionDelayMs < 0)
		{
			ActionDelayMs = 0;
		}
		if (ActionDelayMs > 60000)
		{
			ActionDelayMs = 60000;
		}
		if (SubmitRetryCount < 1)
		{
			SubmitRetryCount = 1;
		}
		if (SubmitRetryCount > 20)
		{
			SubmitRetryCount = 20;
		}
		if (OtpWaitSeconds < 10)
		{
			OtpWaitSeconds = 10;
		}
		if (OtpWaitSeconds > 600)
		{
			OtpWaitSeconds = 600;
		}
		if (PageTimeoutSeconds < 10)
		{
			PageTimeoutSeconds = 10;
		}
		if (PageTimeoutSeconds > 300)
		{
			PageTimeoutSeconds = 300;
		}
		if (LiveCheckDelaySeconds < 0)
		{
			LiveCheckDelaySeconds = 0;
		}
		if (LiveCheckDelaySeconds > 120)
		{
			LiveCheckDelaySeconds = 120;
		}
	}
}
