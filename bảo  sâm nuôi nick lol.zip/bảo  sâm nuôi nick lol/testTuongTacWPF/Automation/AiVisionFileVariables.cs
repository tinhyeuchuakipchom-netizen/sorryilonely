using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace testTuongTacWPF.Automation;

public static class AiVisionFileVariables
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_3021
	{
		public static readonly m_3021 A = new m_3021();

		public static MatchEvaluator m_3022;

		public static Func<string, object> m_3023;

		public static Func<string, bool> m_3024;

		internal string m_3025(Match P_0)
		{
			return m_3020(P_0.Groups["path"].Value, P_0.Groups["mode"].Value, P_0.Groups["take"].Value == "delete");
		}

		internal object m_3026(string P_0)
		{
			return new object();
		}

		internal bool a(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	private static readonly Regex A = new Regex("\\{\\{File\\|(?<path>[^|{}]+)\\|(?<mode>random|sequential)\\|(?<take>delete|keep)\\}\\}");

	private static readonly ConcurrentDictionary<string, object> m_3019 = new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

	public static string BuildPlaceholder(string path, bool random, bool deleteOnTake)
	{
		return $"{{{{File|{path}|{(random ? "random" : "sequential")}|{(deleteOnTake ? "delete" : "keep")}}}}}";
	}

	public static string Substitute(string template)
	{
		return A.Replace(template, (Match P_0) => m_3020(P_0.Groups["path"].Value, P_0.Groups["mode"].Value, P_0.Groups["take"].Value == "delete"));
	}

	private static string m_3020(string P_0, string P_1, bool P_2)
	{
		lock (m_3019.GetOrAdd(P_0, delegate
		{
			return new object();
		}))
		{
			try
			{
				if (!File.Exists(P_0))
				{
					return "";
				}
				List<string> list = (from value in File.ReadAllLines(P_0)
					where !string.IsNullOrWhiteSpace(value)
					select value).ToList();
				if (list.Count == 0)
				{
					return "";
				}
				bool flag = P_1 == "random";
				if (P_2)
				{
					int index = (flag ? Random.Shared.Next(list.Count) : 0);
					string result = list[index].Trim();
					list.RemoveAt(index);
					File.WriteAllLines(P_0, list);
					return result;
				}
				if (flag)
				{
					return list[Random.Shared.Next(list.Count)].Trim();
				}
				string path = P_0 + ".pos";
				int num = 0;
				if (File.Exists(path) && int.TryParse(File.ReadAllText(path).Trim(), out var result2))
				{
					num = result2;
				}
				if (num < 0 || num >= list.Count)
				{
					num = 0;
				}
				string result3 = list[num].Trim();
				File.WriteAllText(path, (num + 1).ToString());
				return result3;
			}
			catch
			{
				return "";
			}
		}
	}
}
