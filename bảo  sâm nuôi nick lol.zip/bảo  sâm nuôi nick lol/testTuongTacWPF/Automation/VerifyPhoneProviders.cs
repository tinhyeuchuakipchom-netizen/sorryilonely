namespace testTuongTacWPF.Automation;

public static class VerifyPhoneProviders
{
	public const string FunOtp = "FunOtp";

	public const string Random = "Random";
}
