namespace testTuongTacWPF.Automation;

public enum MessagingTarget
{
	OpenChromeNicks,
	PostCommenters
}
