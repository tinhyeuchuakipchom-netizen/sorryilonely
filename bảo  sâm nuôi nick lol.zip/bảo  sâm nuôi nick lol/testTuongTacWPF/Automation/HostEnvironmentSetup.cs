using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace testTuongTacWPF.Automation;

public static class HostEnvironmentSetup
{
	private static readonly string A = Path.Combine(AppContext.BaseDirectory, "setup", "node-v16.15.0-x64.msi");

	public static bool IsNodeInstalled()
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Node.js");
			if (registryKey != null)
			{
				return true;
			}
		}
		catch
		{
		}
		try
		{
			using Process process = Process.Start(new ProcessStartInfo
			{
				FileName = "where",
				Arguments = "node",
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				UseShellExecute = false,
				CreateNoWindow = true
			});
			if (process == null)
			{
				return false;
			}
			process.WaitForExit(3000);
			return process.ExitCode == 0;
		}
		catch
		{
			return false;
		}
	}

	public static async Task EnsureNodeInstalledAsync()
	{
		try
		{
			if (IsNodeInstalled() || !File.Exists(A))
			{
				return;
			}
			ProcessStartInfo startInfo = new ProcessStartInfo
			{
				FileName = "msiexec.exe",
				Arguments = "/i \"" + A + "\" /quiet /norestart",
				UseShellExecute = true,
				Verb = "runas"
			};
			using Process process = Process.Start(startInfo);
			if (process != null)
			{
				await process.WaitForExitAsync();
			}
		}
		catch
		{
		}
	}
}
