using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class CreateRunThreadsSettings
{
	[CompilerGenerated]
	private string A = "RegNick";

	[CompilerGenerated]
	private string a = "Chrome";

	[CompilerGenerated]
	private string B = "Android";

	[CompilerGenerated]
	private string b = "Katana";

	[CompilerGenerated]
	private string C = "WebMobile";

	[CompilerGenerated]
	private int m_3923 = 5;

	[CompilerGenerated]
	private bool m_3924 = true;

	[CompilerGenerated]
	private int m_3925 = 5;

	[CompilerGenerated]
	private List<string> m_3926 = new List<string>();

	[CompilerGenerated]
	private int m_3927;

	[CompilerGenerated]
	private string c = "";

	[CompilerGenerated]
	private string D = "None";

	[CompilerGenerated]
	private string d = "";

	[CompilerGenerated]
	private bool m_3928 = true;

	[CompilerGenerated]
	private bool m_3929 = true;

	[CompilerGenerated]
	private bool m_3930 = true;

	[CompilerGenerated]
	private string E = "VI";

	[CompilerGenerated]
	private bool m_3931 = true;

	[CompilerGenerated]
	private string e = "";

	[CompilerGenerated]
	private bool m_3932 = true;

	[CompilerGenerated]
	private bool m_3933 = true;

	[CompilerGenerated]
	private bool m_3934 = true;

	[CompilerGenerated]
	private bool m_3935;

	[CompilerGenerated]
	private int m_3936 = 8;

	[CompilerGenerated]
	private int m_3937 = 12;

	public string Mode
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Platform
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string PhoneOs
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string AndroidPackageType
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string RequestApiType
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public int RequestThreads
	{
		[CompilerGenerated]
		get
		{
			return m_3923;
		}
		[CompilerGenerated]
		set
		{
			m_3923 = value;
		}
	}

	public bool AndroidDeviceRoot
	{
		[CompilerGenerated]
		get
		{
			return m_3924;
		}
		[CompilerGenerated]
		set
		{
			m_3924 = value;
		}
	}

	public int ChromeThreads
	{
		[CompilerGenerated]
		get
		{
			return m_3925;
		}
		[CompilerGenerated]
		set
		{
			m_3925 = value;
		}
	}

	public List<string> PhoneNames
	{
		[CompilerGenerated]
		get
		{
			return m_3926;
		}
		[CompilerGenerated]
		set
		{
			m_3926 = value;
		}
	}

	public int ScriptId
	{
		[CompilerGenerated]
		get
		{
			return m_3927;
		}
		[CompilerGenerated]
		set
		{
			m_3927 = value;
		}
	}

	public string ScriptName
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string ProxyMode
	{
		[CompilerGenerated]
		get
		{
			return D;
		}
		[CompilerGenerated]
		set
		{
			D = value;
		}
	}

	public string ProxyList
	{
		[CompilerGenerated]
		get
		{
			return d;
		}
		[CompilerGenerated]
		set
		{
			d = value;
		}
	}

	public bool RandomGender
	{
		[CompilerGenerated]
		get
		{
			return m_3928;
		}
		[CompilerGenerated]
		set
		{
			m_3928 = value;
		}
	}

	public bool RandomName
	{
		[CompilerGenerated]
		get
		{
			return m_3929;
		}
		[CompilerGenerated]
		set
		{
			m_3929 = value;
		}
	}

	public bool IncludeMiddleName
	{
		[CompilerGenerated]
		get
		{
			return m_3930;
		}
		[CompilerGenerated]
		set
		{
			m_3930 = value;
		}
	}

	public string NameLanguage
	{
		[CompilerGenerated]
		get
		{
			return E;
		}
		[CompilerGenerated]
		set
		{
			E = value;
		}
	}

	public bool RandomPassword
	{
		[CompilerGenerated]
		get
		{
			return m_3931;
		}
		[CompilerGenerated]
		set
		{
			m_3931 = value;
		}
	}

	public string PasswordPrefix
	{
		[CompilerGenerated]
		get
		{
			return e;
		}
		[CompilerGenerated]
		set
		{
			e = value;
		}
	}

	public bool PasswordLower
	{
		[CompilerGenerated]
		get
		{
			return m_3932;
		}
		[CompilerGenerated]
		set
		{
			m_3932 = value;
		}
	}

	public bool PasswordUpper
	{
		[CompilerGenerated]
		get
		{
			return m_3933;
		}
		[CompilerGenerated]
		set
		{
			m_3933 = value;
		}
	}

	public bool PasswordDigits
	{
		[CompilerGenerated]
		get
		{
			return m_3934;
		}
		[CompilerGenerated]
		set
		{
			m_3934 = value;
		}
	}

	public bool PasswordSpecial
	{
		[CompilerGenerated]
		get
		{
			return m_3935;
		}
		[CompilerGenerated]
		set
		{
			m_3935 = value;
		}
	}

	public int PasswordMinLength
	{
		[CompilerGenerated]
		get
		{
			return m_3936;
		}
		[CompilerGenerated]
		set
		{
			m_3936 = value;
		}
	}

	public int PasswordMaxLength
	{
		[CompilerGenerated]
		get
		{
			return m_3937;
		}
		[CompilerGenerated]
		set
		{
			m_3937 = value;
		}
	}

	private static string m_3938(string P_0)
	{
		string text = P_0.ToLowerInvariant();
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			text = text.Replace(oldChar, '_');
		}
		text = text.Replace(' ', '_');
		return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "create_run_threads_" + text + ".json");
	}

	public static CreateRunThreadsSettings Load(string pageKey)
	{
		try
		{
			string path = m_3938(pageKey);
			if (!File.Exists(path))
			{
				return new CreateRunThreadsSettings();
			}
			return JsonSerializer.Deserialize<CreateRunThreadsSettings>(File.ReadAllText(path)) ?? new CreateRunThreadsSettings();
		}
		catch
		{
			return new CreateRunThreadsSettings();
		}
	}

	public void Save(string pageKey)
	{
		try
		{
			string path = m_3938(pageKey);
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			File.WriteAllText(path, JsonSerializer.Serialize(this, new JsonSerializerOptions
			{
				WriteIndented = true
			}));
		}
		catch
		{
		}
	}
}
