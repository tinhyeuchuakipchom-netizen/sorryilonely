using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Automation;

public class OmoBrowserProfile
{
	[CompilerGenerated]
	private string A = "";

	public string ProfileId
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
