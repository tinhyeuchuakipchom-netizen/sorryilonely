namespace testTuongTacWPF.Automation;

public static class ChromeScriptFolderNames
{
	public const string Login = "Đăng nhập";

	public const string CreatePage = "Tạo Page";

	public const string FeedBrowsing = "Nuôi nick";

	public const string GroupSpam = "Spam nhóm";

	public const string PostBoost = "Nuôi bài viết";

	public const string FriendRequest = "Kết bạn";

	public const string Messaging = "Nhắn tin";

	public const string CreatePost = "Đăng bài viết";

	public const string PostToPage = "Đăng bài trên page";

	public const string CreateBm = "Tạo BM";
}
