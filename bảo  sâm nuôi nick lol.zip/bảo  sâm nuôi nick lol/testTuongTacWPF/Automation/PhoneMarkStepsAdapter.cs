using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public class PhoneMarkStepsAdapter : IMarkStepsDeviceAdapter
{
	private readonly string A;

	public PhoneMarkStepsAdapter(string deviceSerial)
	{
		A = deviceSerial;
	}

	public Task<byte[]> CaptureScreenshotAsync(CancellationToken cancellationToken)
	{
		return AdbController.ScreenshotAsync(A, cancellationToken);
	}

	public Task<List<UiElement>> DumpElementsAsync(CancellationToken cancellationToken)
	{
		return AdbController.DumpUiElementsAsync(A, cancellationToken);
	}

	public Task TapAsync(int x, int y, CancellationToken cancellationToken)
	{
		return AdbController.TapAsync(A, x, y, cancellationToken);
	}

	public Task SwipeAsync(int x1, int y1, int x2, int y2, CancellationToken cancellationToken)
	{
		return AdbController.SwipeAsync(A, x1, y1, x2, y2, 400, cancellationToken);
	}

	public Task TypeTextAsync(string text, CancellationToken cancellationToken)
	{
		return AdbController.InputTextAsync(A, text, cancellationToken);
	}
}
