using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using A;

namespace testTuongTacWPF.Automation;

public static class IPhoneController
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_5650
	{
		public static readonly m_5650 A = new m_5650();

		public static Func<Rune, string> m_5661;

		internal string m_5662(Rune P_0)
		{
			return P_0.ToString();
		}
	}

	[CompilerGenerated]
	private sealed class m_5651
	{
		public StringBuilder A;

		internal void m_5663(object P_0, DataReceivedEventArgs P_1)
		{
			if (P_1.Data != null)
			{
				A.AppendLine(P_1.Data);
			}
		}

		internal void a(object P_0, DataReceivedEventArgs P_1)
		{
			if (P_1.Data != null)
			{
				A.AppendLine(P_1.Data);
			}
		}
	}

	[CompilerGenerated]
	private sealed class m_5652
	{
		public string A;

		internal void m_5664(object P_0, DataReceivedEventArgs P_1)
		{
			if (P_1.Data != null)
			{
				m_5632(A, P_1.Data);
			}
		}

		internal void a(object P_0, DataReceivedEventArgs P_1)
		{
			if (P_1.Data != null)
			{
				m_5632(A, P_1.Data);
			}
		}
	}

	private static readonly string A = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dulieu", "iphone");

	public const int WdaPort = 8100;

	private static Process? m_5620;

	private static Process? a;

	private static Process? B;

	private const int m_5621 = 40;

	private static readonly Dictionary<string, Queue<string>> m_5622 = new Dictionary<string, Queue<string>>();

	private static string? m_5623;

	private static bool m_5624;

	private const int m_5625 = 20;

	private const int m_5626 = 3000;

	private static string m_5627 = "";

	private const int b = 5000;

	private static readonly HttpClient m_5628 = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private static string? m_5629;

	private static readonly HashSet<string> m_5630 = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"Button", "Icon", "Cell", "Link", "SearchField", "TextField", "SecureTextField", "Switch", "Tab", "Key",
		"MenuItem", "PickerWheel", "Slider", "Image"
	};

	private const int C = 60;

	public static string IosExePath => Path.Combine(A, "ios.exe");

	public static string WdaIpaPath => Path.Combine(A, "WebDriverAgent.ipa");

	public static string AppleCertPath => Path.Combine(A, "AppleServerAuthenticationCA.cer");

	public static string WdaBaseUrl => $"http://127.0.0.1:{8100}";

	public static bool IsToolAvailable => File.Exists(IosExePath);

	public static bool TunnelUsingUserspace => m_5624;

	private static async Task<(int ExitCode, string Output)> m_5631(string P_0, int P_1 = 60000)
	{
		if (!IsToolAvailable)
		{
			return (ExitCode: -1, Output: "Không tìm thấy " + IosExePath);
		}
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = IosExePath,
			Arguments = P_0,
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true,
			WorkingDirectory = IPhoneController.A,
			StandardOutputEncoding = Encoding.UTF8,
			StandardErrorEncoding = Encoding.UTF8
		};
		try
		{
			using Process process = new Process
			{
				StartInfo = startInfo
			};
			StringBuilder A = new StringBuilder();
			process.OutputDataReceived += (object obj2, DataReceivedEventArgs e2) =>
			{
				if (e2.Data != null)
				{
					A.AppendLine(e2.Data);
				}
			};
			process.ErrorDataReceived += (object obj2, DataReceivedEventArgs e2) =>
			{
				if (e2.Data != null)
				{
					A.AppendLine(e2.Data);
				}
			};
			process.Start();
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			using CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(P_1);
			try
			{
				await process.WaitForExitAsync(cancellationTokenSource.Token);
			}
			catch (OperationCanceledException)
			{
				try
				{
					process.Kill(entireProcessTree: true);
				}
				catch
				{
				}
				return (ExitCode: -1, Output: A?.ToString() + "\n(quá thời gian chờ)");
			}
			return (ExitCode: process.ExitCode, Output: A.ToString());
		}
		catch (Exception ex2)
		{
			return (ExitCode: -1, Output: ex2.Message);
		}
	}

	private static void m_5632(string P_0, string P_1)
	{
		if (string.IsNullOrWhiteSpace(P_1))
		{
			return;
		}
		lock (m_5622)
		{
			if (!m_5622.TryGetValue(P_0, out Queue<string> value))
			{
				value = (m_5622[P_0] = new Queue<string>());
			}
			value.Enqueue(P_1.Trim());
			while (value.Count > 40)
			{
				value.Dequeue();
			}
		}
	}

	private static void m_5633(string P_0)
	{
		lock (m_5622)
		{
			m_5622.Remove(P_0);
		}
	}

	private static string m_5634(string P_0)
	{
		lock (m_5622)
		{
			Queue<string> value;
			return (m_5622.TryGetValue(P_0, out value) && value.Count > 0) ? string.Join(" | ", value) : "(không có log)";
		}
	}

	private static string m_5635(string P_0, int P_1 = 15)
	{
		lock (m_5622)
		{
			if (!m_5622.TryGetValue(P_0, out Queue<string> value) || value.Count == 0)
			{
				return "(không có log)";
			}
			string[] array = value.ToArray();
			int num = Math.Max(0, array.Length - P_1);
			return string.Join(" | ", array[num..]);
		}
	}

	private static int m_5636(string P_0)
	{
		lock (m_5622)
		{
			Queue<string> value;
			return m_5622.TryGetValue(P_0, out value) ? value.Count : 0;
		}
	}

	private static Process? m_5637(string P_0, string P_1)
	{
		if (!IsToolAvailable)
		{
			return null;
		}
		try
		{
			Process process = new Process();
			process.StartInfo = new ProcessStartInfo
			{
				FileName = IosExePath,
				Arguments = P_0,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				CreateNoWindow = true,
				WorkingDirectory = A,
				StandardOutputEncoding = Encoding.UTF8,
				StandardErrorEncoding = Encoding.UTF8
			};
			process.OutputDataReceived += (object obj2, DataReceivedEventArgs e2) =>
			{
				if (e2.Data != null)
				{
					m_5632(P_1, e2.Data);
				}
			};
			process.ErrorDataReceived += (object obj2, DataReceivedEventArgs e2) =>
			{
				if (e2.Data != null)
				{
					m_5632(P_1, e2.Data);
				}
			};
			process.Start();
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			return process;
		}
		catch
		{
			return null;
		}
	}

	public static async Task<List<string>> ListDevicesAsync()
	{
		List<string> list = new List<string>();
		var (num, text) = await m_5631("list", 20000);
		if (num != 0)
		{
			return list;
		}
		string[] array = text.Split('\n');
		foreach (string text2 in array)
		{
			if (text2.IndexOf("\"deviceList\"", StringComparison.OrdinalIgnoreCase) < 0)
			{
				continue;
			}
			try
			{
				using JsonDocument jsonDocument = JsonDocument.Parse(text2.Trim());
				if (!jsonDocument.RootElement.TryGetProperty("deviceList", out var value))
				{
					continue;
				}
				foreach (JsonElement item in value.EnumerateArray())
				{
					string text3 = item.GetString();
					if (!string.IsNullOrWhiteSpace(text3))
					{
						list.Add(text3);
					}
				}
			}
			catch
			{
			}
		}
		return list;
	}

	[SpecialName]
	private static bool m_5638()
	{
		return File.Exists(Path.Combine(A, "wintun.dll"));
	}

	private static bool m_5639()
	{
		try
		{
			using WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent();
			return new WindowsPrincipal(ntIdentity).IsInRole(WindowsBuiltInRole.Administrator);
		}
		catch
		{
			return false;
		}
	}

	public static bool StartTunnel(string? udid = null)
	{
		StopTunnel();
		m_5633("tunnel");
		m_5623 = udid;
		m_5624 = !m_5638() || !m_5639();
		return m_5640(udid, m_5624);
	}

	private static bool m_5640(string? P_0, bool P_1)
	{
		string text = "tunnel start";
		if (!string.IsNullOrWhiteSpace(P_0))
		{
			text = text + " --udid=" + P_0;
		}
		if (P_1)
		{
			text += " --userspace";
		}
		m_5620 = m_5637(text, "tunnel");
		return m_5620 != null;
	}

	public static async Task<(bool Ready, string? Error)> WaitForTunnelAsync(int timeoutMs = 30000, string? udid = null)
	{
		if (m_5620 == null || m_5620.HasExited)
		{
			StartTunnel(udid);
		}
		if (m_5620 == null)
		{
			return (Ready: false, Error: "Không khởi chạy được tiến trình tunnel (thiếu ios.exe?).");
		}
		if (udid == null)
		{
			udid = m_5623;
		}
		for (int l = 0; l < timeoutMs; l += 1500)
		{
			if (!m_5624 && m_5641())
			{
				m_5624 = true;
				m_5633("tunnel");
				m_5640(udid, true);
				await Task.Delay(2000);
			}
			else if (m_5620 == null || m_5620.HasExited)
			{
				string text = m_5634("tunnel");
				if (m_5624 || !text.Contains("elevated privileges", StringComparison.OrdinalIgnoreCase))
				{
					return (Ready: false, Error: $"Kênh liên lạc với iPhone (tunnel) tắt ngay sau khi mở (mã {m_5620?.ExitCode}). " + "Rút/cắm lại cáp USB rồi thử lại; nếu vẫn vậy thì đóng hẳn tool và mở lại.\n--- Log tunnel ---\n" + m_5635("tunnel"));
				}
				m_5624 = true;
				m_5633("tunnel");
				m_5640(udid, true);
				await Task.Delay(2000);
			}
			else
			{
				var (num, text2) = await m_5631("tunnel ls", 8000);
				text2.Trim();
				if (num == 0 && m_5642(text2, udid))
				{
					return (Ready: true, Error: null);
				}
				await Task.Delay(1500);
			}
		}
		string value = (m_5624 ? "Đã dùng chế độ userspace (không cần wintun.dll)." : "Đang dùng chế độ kernel (đã thấy wintun.dll).");
		return (Ready: false, Error: $"Không mở được kênh liên lạc với iPhone sau {timeoutMs / 1000}s. {value}" + "\nKiểm tra: cáp USB phải cắm chắc, iPhone đã bấm Tin cậy máy tính, và màn hình đang mở khoá.");
	}

	private static bool m_5641()
	{
		string text = m_5634("tunnel");
		if (!text.Contains("wintun.dll", StringComparison.OrdinalIgnoreCase))
		{
			return text.Contains("could not setup tunnel interface", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static bool m_5642(string P_0, string? udid)
	{
		if (string.IsNullOrWhiteSpace(P_0))
		{
			return false;
		}
		bool flag = P_0.Contains("\"address\"", StringComparison.OrdinalIgnoreCase);
		bool flag2 = P_0.Contains("rsdPort", StringComparison.OrdinalIgnoreCase);
		if (!flag || !flag2)
		{
			return false;
		}
		if (!string.IsNullOrWhiteSpace(udid))
		{
			return P_0.Contains(udid, StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static async Task<(bool Reachable, string? Error)> m_5643(string? P_0 = null)
	{
		var (num, text) = await m_5631("tunnel ls", 8000);
		if (num != 0 || string.IsNullOrWhiteSpace(text))
		{
			return (Reachable: false, Error: "Không đọc được danh sách kênh liên lạc (tunnel ls).");
		}
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(text);
			foreach (JsonElement item in jsonDocument.RootElement.EnumerateArray())
			{
				string text2 = (item.TryGetProperty("address", out var value) ? value.GetString() : null);
				int num2;
				if (item.TryGetProperty("rsdPort", out var value2))
				{
					int @int = value2.GetInt32();
					num2 = @int;
				}
				else
				{
					num2 = 0;
				}
				int num3 = num2;
				string text3 = (item.TryGetProperty("udid", out var value3) ? value3.GetString() : null);
				if ((!string.IsNullOrWhiteSpace(P_0) && text3 != P_0) || string.IsNullOrWhiteSpace(text2) || num3 <= 0)
				{
					continue;
				}
				using TcpClient tcpClient = new TcpClient();
				CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(3000);
				try
				{
					await tcpClient.ConnectAsync(text2, num3, cancellationTokenSource.Token);
					return (Reachable: true, Error: null);
				}
				catch
				{
					return (Reachable: false, Error: $"Tunnel có kênh nhưng kết nối TCP tới RSD thất bại ({text2}:{num3}).\n" + "Thử: bấm Dọn tiến trình iOS (Kill All) rồi khởi động lại; nếu vẫn lỗi, rút/cắm cáp USB.");
				}
			}
		}
		catch
		{
		}
		return (Reachable: true, Error: null);
	}

	public static void StopTunnel()
	{
		try
		{
			Process process = m_5620;
			if (process != null && !process.HasExited)
			{
				m_5620.Kill(entireProcessTree: true);
			}
		}
		catch
		{
		}
		m_5620 = null;
	}

	public static Task<(int ExitCode, string Output)> MountDeveloperImageAsync(string? udid = null)
	{
		return m_5631("image auto" + m_5644(udid), 180000);
	}

	private static string m_5644(string? udid)
	{
		if (!string.IsNullOrWhiteSpace(udid))
		{
			return " --udid=" + udid;
		}
		return "";
	}

	public static async Task<string?> FindWdaBundleIdAsync(string? udid = null)
	{
		var (num, text) = await m_5631("apps --list" + m_5644(udid), 30000);
		if (num != 0)
		{
			return null;
		}
		string[] array = text.Split(',', '\n');
		for (int l = 0; l < array.Length; l++)
		{
			string text2 = array[l].Trim().Trim(new char[4] { '[', ']', '"', ' ' });
			if (text2.Contains("WebDriverAgentRunner", StringComparison.OrdinalIgnoreCase) && text2.Contains("xctrunner", StringComparison.OrdinalIgnoreCase))
			{
				string text3 = text2.Split(' ')[0].Trim();
				if (text3.Length > 0)
				{
					return text3;
				}
			}
		}
		return null;
	}

	public static async Task<(bool Success, string Message)> StartWdaAsync(string? udid = null)
	{
		string text = await FindWdaBundleIdAsync(udid);
		if (text == null)
		{
			return (Success: false, Message: "Chưa cài WebDriverAgent trên máy này (xem bước 6 trong hướng dẫn).");
		}
		if (string.IsNullOrWhiteSpace(udid))
		{
			udid = (await ListDevicesAsync()).FirstOrDefault();
		}
		m_5627 = m_5644(udid);
		StopWda();
		await m_5631("kill " + text + m_5627, 15000);
		await Task.Delay(2000);
		var (flag, text2) = await WaitForTunnelAsync(20000, udid);
		if (!flag)
		{
			return (Success: false, Message: "Mất kênh liên lạc với iPhone trước khi khởi động WebDriverAgent: " + text2);
		}
		var (flag2, item) = await m_5643(udid);
		if (!flag2)
		{
			return (Success: false, Message: item);
		}
		m_5633("runwda");
		m_5633("forward");
		string text3 = $"runwda --bundleid={text} --testrunnerbundleid={text} --xctestconfig=WebDriverAgentRunner.xctest{m_5627} -v";
		a = m_5637(text3, "runwda");
		if (a == null)
		{
			return (Success: false, Message: "Không khởi chạy được WebDriverAgent.");
		}
		await Task.Delay(8000);
		if (a.HasExited)
		{
			string text4 = m_5634("runwda");
			string value = m_5635("runwda");
			string text5 = c(text4);
			if (text4.Contains("got capabilities", StringComparison.OrdinalIgnoreCase) && !text4.Contains("Process started", StringComparison.OrdinalIgnoreCase))
			{
				string text6 = text5;
				text5 = text6 + await d(udid);
			}
			string value2 = D(text4);
			return (Success: false, Message: $"Phiên WebDriverAgent (runwda) đã tự thoát (mã {a.ExitCode}) - WDA trên máy không còn chạy.\nMáy: {udid ?? "(chưa xác định)"} | iOS: {value2} | Bundle: {text}\n" + text5 + $"\n--- Log runwda ({m_5636("runwda")} dòng, hiển thị cuối) ---\n{value}");
		}
		if (!m_5645())
		{
			return (Success: false, Message: "Không khởi chạy được tiến trình forward cổng WebDriverAgent.");
		}
		bool flag3 = false;
		for (int l = 1; l <= 20; l++)
		{
			if (a.HasExited)
			{
				string value = m_5634("runwda");
				if (!value.Contains("missing tunnel address", StringComparison.OrdinalIgnoreCase) || flag3)
				{
					string text7 = c(value);
					if (value.Contains("got capabilities", StringComparison.OrdinalIgnoreCase) && !value.Contains("Process started", StringComparison.OrdinalIgnoreCase))
					{
						string text4 = text7;
						text7 = text4 + await d(udid);
					}
					string value3 = D(value);
					string value4 = m_5635("runwda");
					return (Success: false, Message: $"Phiên WebDriverAgent (runwda) đã tự thoát (mã {a.ExitCode}) - WDA trên máy không còn chạy.\nMáy: {udid ?? "(chưa xác định)"} | iOS: {value3} | Bundle: {text}\n" + text7 + $"\n--- Log runwda (dòng {Math.Max(1, m_5636("runwda") - 14)}-{m_5636("runwda")}) ---\n{value4}");
				}
				flag3 = true;
				StartTunnel(udid);
				var (flag4, text8) = await WaitForTunnelAsync(20000, udid);
				if (!flag4)
				{
					return (Success: false, Message: "Mất kênh liên lạc với iPhone và mở lại không được: " + text8);
				}
				m_5633("runwda");
				a = m_5637(text3, "runwda");
				if (a == null)
				{
					return (Success: false, Message: "Không khởi chạy lại được WebDriverAgent sau khi dựng lại tunnel.");
				}
			}
			else
			{
				if (B == null || B.HasExited)
				{
					m_5645();
				}
				var (flag5, text9) = await m_5646();
				if (flag5)
				{
					return (Success: true, Message: "WebDriverAgent đã sẵn sàng tại " + WdaBaseUrl);
				}
				if (text9 != null && E(text9))
				{
					m_5645();
				}
				await Task.Delay(3000);
			}
		}
		int value5 = 60;
		return (Success: false, Message: $"WebDriverAgent chạy trên máy (thấy \"Automation Running\") nhưng PC không nối được sau {value5}s.\n" + "Thường do WDA bị iOS đình chỉ (tắt Tối ưu pin / để máy sáng màn hình, đừng bấm Home ra khỏi WDA), hoặc chứng chỉ ký WDA đã hết hạn (ký lại bằng Sideloadly). Thử rút/cắm lại cáp USB rồi bấm lại.");
	}

	private static bool m_5645()
	{
		try
		{
			Process process = B;
			if (process != null && !process.HasExited)
			{
				B.Kill(entireProcessTree: true);
			}
		}
		catch
		{
		}
		B = m_5637($"forward {8100} {8100}{m_5627}", "forward");
		return B != null;
	}

	private static string c(string P_0)
	{
		if (P_0.Contains("got capabilities", StringComparison.OrdinalIgnoreCase) && !P_0.Contains("Process started", StringComparison.OrdinalIgnoreCase) && !P_0.Contains("Running tests", StringComparison.OrdinalIgnoreCase) && !P_0.Contains("testRunnerReady", StringComparison.OrdinalIgnoreCase))
		{
			return "App WDA chưa kịp bật lên trên máy. Làm lần lượt: (1) mở đa nhiệm trên iPhone, vuốt bỏ app WebDriverAgent nếu vẫn còn chạy, (2) đảm bảo màn hình iPhone đang mở khoá, rồi bấm khởi động lại. Nếu vẫn lỗi: chứng chỉ ký WDA đã hết hạn - ký và cài lại bằng Sideloadly (xem bước 6).";
		}
		if (P_0.Contains("could not connect to RSD", StringComparison.OrdinalIgnoreCase))
		{
			return "Kênh liên lạc (tunnel) vẫn chạy nhưng không kết nối được tới dịch vụ trên iPhone (RSD). Thử lần lượt:\n1. Bấm nút Dọn tiến trình iOS (Kill All) rồi bấm khởi động lại.\n2. Nếu vẫn lỗi: rút cáp USB, chờ 5 giây, cắm lại, bấm Dọn tiến trình iOS rồi khởi động lại.\n3. Nếu vẫn lỗi: khởi động lại iPhone rồi thử lại.";
		}
		if (P_0.Contains("testRunnerReady", StringComparison.OrdinalIgnoreCase) || P_0.Contains("didFailToBootstrap", StringComparison.OrdinalIgnoreCase) || P_0.Contains("Failed to load the test bundle", StringComparison.OrdinalIgnoreCase))
		{
			return "App WDA bật được nhưng iOS từ chối nạp bộ kiểm thử bên trong - gần như luôn là do CHỮ KÝ, không phải do phiên bản iOS. Làm lần lượt:\n1. Ký và cài lại bằng Sideloadly (bước 6), dùng ĐÚNG Apple ID đã dùng lần trước.\n2. Trên iPhone vào Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị → chọn hồ sơ của Apple ID đó → bấm Tin cậy.\n3. Xoá hẳn app WebDriverAgent trên iPhone rồi cài lại từ đầu (chứng chỉ cũ còn sót lại thường làm bản cài mới không nạp được bundle).\n4. Mở đa nhiệm, vuốt bỏ WebDriverAgent, mở khoá màn hình rồi bấm khởi động lại.";
		}
		return "Nếu màn hình iPhone đang khoá hãy mở khoá rồi thử lại; nếu vừa ký/cài lại WDA thì kiểm tra chứng chỉ còn hạn không.";
	}

	private static string D(string P_0)
	{
		Match match = Regex.Match(P_0, "\"version\"\\s*:\\s*\"([0-9.]+)\"");
		if (!match.Success)
		{
			return "(không rõ)";
		}
		return match.Groups[1].Value;
	}

	private static async Task<string> d(string? udid)
	{
		(int, string) tuple = await m_5631("devmode get" + m_5644(udid), 20000);
		int item = tuple.Item1;
		string text = tuple.Item2.Trim();
		if (item == 0 && text.Contains("true", StringComparison.OrdinalIgnoreCase))
		{
			return "\nChế độ nhà phát triển trên máy: ĐÃ BẬT - lỗi không nằm ở đây, xem tiếp log phía trên.";
		}
		if (item == 0 && text.Contains("false", StringComparison.OrdinalIgnoreCase))
		{
			var (value, text2) = await m_5631("devmode enable" + m_5644(udid), 30000);
			return "\nTÌM RA NGUYÊN NHÂN: Chế độ nhà phát triển trên iPhone đang TẮT.\n" + $"Đã gửi lệnh bật (ios devmode enable, mã {value}): {text2.Trim()}\n" + "BÂY GIỜ BẮT BUỘC: khởi động lại iPhone → mở khoá → bấm BẬT ở hộp thoại hiện ra → nhập mã khoá màn hình, xong quay lại bấm khởi động lần nữa.";
		}
		return "\nKhông hỏi được trạng thái Chế độ nhà phát triển (devmode get: " + ((text.Length == 0) ? "rỗng" : text) + "). Kiểm tra tay: Cài đặt → Riêng tư & Bảo mật → Chế độ nhà phát triển → gạt Bật → khởi động lại máy.";
	}

	private static bool E(string P_0)
	{
		if (!P_0.Contains("forcibly closed", StringComparison.OrdinalIgnoreCase) && !P_0.Contains("existing connection was", StringComparison.OrdinalIgnoreCase) && !P_0.Contains("connection was aborted", StringComparison.OrdinalIgnoreCase))
		{
			return P_0.Contains("transport connection", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static async Task<(bool Ready, string? Error)> m_5646()
	{
		try
		{
			using CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(5000);
			string text = await m_5628.GetStringAsync(WdaBaseUrl + "/status", cancellationTokenSource.Token);
			using JsonDocument jsonDocument = JsonDocument.Parse(text);
			bool num = jsonDocument.RootElement.TryGetProperty("value", out var value) && value.TryGetProperty("ready", out var value2) && value2.ValueKind == JsonValueKind.True;
			return (Ready: num, Error: num ? null : ("WDA phản hồi nhưng \"ready\" != true (JSON: " + text + ")"));
		}
		catch (Exception ex)
		{
			string item = ((ex.InnerException != null) ? (ex.Message + " — " + ex.InnerException.Message) : ex.Message);
			return (Ready: false, Error: item);
		}
	}

	public static void StopWda()
	{
		try
		{
			Process process = B;
			if (process != null && !process.HasExited)
			{
				B.Kill(entireProcessTree: true);
			}
		}
		catch
		{
		}
		B = null;
		try
		{
			Process process = a;
			if (process != null && !process.HasExited)
			{
				a.Kill(entireProcessTree: true);
			}
		}
		catch
		{
		}
		a = null;
		Process[] processesByName = Process.GetProcessesByName("ios");
		foreach (Process process2 in processesByName)
		{
			if (m_5620 == null || process2.Id != m_5620.Id)
			{
				try
				{
					process2.Kill(entireProcessTree: true);
				}
				catch
				{
				}
			}
		}
	}

	public static void StopAll()
	{
		StopWda();
		StopTunnel();
	}

	public static (int Killed, int Failed) KillAllIosProcesses()
	{
		int num = 0;
		int num2 = 0;
		Process[] processesByName = Process.GetProcessesByName("ios");
		foreach (Process process in processesByName)
		{
			try
			{
				process.Kill(entireProcessTree: true);
				process.WaitForExit(3000);
				num++;
			}
			catch
			{
				num2++;
			}
		}
		m_5620 = null;
		a = null;
		B = null;
		return (Killed: num, Failed: num2);
	}

	public static async Task<bool> IsWdaReadyAsync()
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await m_5628.GetStringAsync(WdaBaseUrl + "/status"));
			JsonElement value;
			JsonElement value2;
			return jsonDocument.RootElement.TryGetProperty("value", out value) && value.TryGetProperty("ready", out value2) && value2.ValueKind == JsonValueKind.True;
		}
		catch
		{
			return false;
		}
	}

	public static async Task<byte[]?> ScreenshotAsync()
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await m_5628.GetStringAsync(WdaBaseUrl + "/screenshot"));
			string text = jsonDocument.RootElement.GetProperty("value").GetString();
			return (text == null) ? null : Convert.FromBase64String(text);
		}
		catch
		{
			return null;
		}
	}

	private static async Task<string?> c()
	{
		if (!string.IsNullOrEmpty(m_5629))
		{
			return m_5629;
		}
		try
		{
			StringContent content = new StringContent("{\"capabilities\":{\"alwaysMatch\":{}}}", Encoding.UTF8, "application/json");
			using JsonDocument jsonDocument = JsonDocument.Parse(await (await m_5628.PostAsync(WdaBaseUrl + "/session", content)).Content.ReadAsStringAsync());
			JsonElement value2;
			JsonElement value3;
			if (jsonDocument.RootElement.TryGetProperty("sessionId", out var value) && value.ValueKind == JsonValueKind.String)
			{
				m_5629 = value.GetString();
			}
			else if (jsonDocument.RootElement.TryGetProperty("value", out value2) && value2.TryGetProperty("sessionId", out value3))
			{
				m_5629 = value3.GetString();
			}
			return m_5629;
		}
		catch
		{
			return null;
		}
	}

	public static async Task<bool> TapAsync(double x, double y)
	{
		string text = await c();
		if (text == null)
		{
			return false;
		}
		try
		{
			StringContent content = new StringContent($"{{\"x\":{x},\"y\":{y}}}", Encoding.UTF8, "application/json");
			return (await m_5628.PostAsync(WdaBaseUrl + "/session/" + text + "/wda/tap", content)).IsSuccessStatusCode;
		}
		catch
		{
			return false;
		}
	}

	public static async Task<bool> SwipeAsync(double fromX, double fromY, double toX, double toY, double durationSeconds = 0.4)
	{
		string text = await c();
		if (text == null)
		{
			return false;
		}
		try
		{
			int num = Math.Max(1, (int)(durationSeconds * 1000.0 / 6.0));
			List<object> list = new List<object>
			{
				new a<string, int, int, int>("pointerMove", 0, (int)Math.Round(fromX), (int)Math.Round(fromY)),
				new B<string, int>("pointerDown", 0),
				new b<string, int>("pause", 50)
			};
			for (int l = 1; l <= 6; l++)
			{
				double num2 = (double)l / 6.0;
				list.Add(new a<string, int, int, int>("pointerMove", num, (int)Math.Round(fromX + (toX - fromX) * num2), (int)Math.Round(fromY + (toY - fromY) * num2)));
			}
			list.Add(new B<string, int>("pointerUp", 0));
			StringContent content = new StringContent(JsonSerializer.Serialize(new C<object[]>(new object[1]
			{
				new c<string, string, D<string>, List<object>>("pointer", "finger1", new D<string>("touch"), list)
			})), Encoding.UTF8, "application/json");
			return (await m_5628.PostAsync(WdaBaseUrl + "/session/" + text + "/actions", content)).IsSuccessStatusCode;
		}
		catch
		{
			return false;
		}
	}

	public static async Task<(int Width, int Height)?> GetScreenSizeAsync()
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await m_5628.GetStringAsync(WdaBaseUrl + "/window/size"));
			JsonElement property = jsonDocument.RootElement.GetProperty("value");
			return (property.GetProperty("width").GetInt32(), property.GetProperty("height").GetInt32());
		}
		catch
		{
			return null;
		}
	}

	public static async Task<List<UiElement>> DumpUiElementsAsync()
	{
		List<UiElement> list = new List<UiElement>();
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await m_5628.GetStringAsync(WdaBaseUrl + "/source?format=json"));
			if (jsonDocument.RootElement.TryGetProperty("value", out var value))
			{
				m_5647(value, list);
			}
		}
		catch
		{
		}
		return list;
	}

	private static void m_5647(JsonElement P_0, List<UiElement> P_1)
	{
		if (P_1.Count >= 60)
		{
			return;
		}
		string text = m_5648(P_0, "type") ?? "";
		bool flag = m_5648(P_0, "isVisible") == "1";
		bool flag2 = m_5648(P_0, "isEnabled") != "0";
		if ((m_5630.Contains(text) & flag & flag2) && P_0.TryGetProperty("rect", out var value))
		{
			int num = m_5649(value, "x");
			int num2 = m_5649(value, "y");
			int num3 = m_5649(value, "width");
			int num4 = m_5649(value, "height");
			if (num3 > 0 && num4 > 0)
			{
				string text2 = m_5648(P_0, "label");
				string text3 = m_5648(P_0, "value");
				string text4 = m_5648(P_0, "name");
				P_1.Add(new UiElement
				{
					Text = ((!string.IsNullOrWhiteSpace(text2)) ? text2 : (text3 ?? "")),
					ContentDesc = (text4 ?? ""),
					ResourceId = (text4 ?? ""),
					ClassName = text,
					Focused = (m_5648(P_0, "isFocused") == "1"),
					Left = num,
					Top = num2,
					Right = num + num3,
					Bottom = num2 + num4
				});
			}
		}
		if (!P_0.TryGetProperty("children", out var value2) || value2.ValueKind != JsonValueKind.Array)
		{
			return;
		}
		foreach (JsonElement item in value2.EnumerateArray())
		{
			if (P_1.Count >= 60)
			{
				break;
			}
			m_5647(item, P_1);
		}
	}

	private static string? m_5648(JsonElement P_0, string P_1)
	{
		if (!P_0.TryGetProperty(P_1, out var value) || value.ValueKind != JsonValueKind.String)
		{
			return null;
		}
		return value.GetString();
	}

	private static int m_5649(JsonElement P_0, string P_1)
	{
		if (!P_0.TryGetProperty(P_1, out var value))
		{
			return 0;
		}
		if (value.ValueKind == JsonValueKind.Number)
		{
			return (int)value.GetDouble();
		}
		return 0;
	}

	public static async Task<bool> TypeTextReplacingAsync(string text)
	{
		string text2 = await c();
		if (text2 == null)
		{
			return false;
		}
		await e(text2);
		return await InputTextAsync(text);
	}

	private static async Task e(string P_0)
	{
		_ = 1;
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await m_5628.GetStringAsync(WdaBaseUrl + "/session/" + P_0 + "/element/active"));
			JsonElement property = jsonDocument.RootElement.GetProperty("value");
			string value2;
			if (property.TryGetProperty("ELEMENT", out var value))
			{
				value2 = value.GetString();
			}
			else
			{
				value2 = (property.TryGetProperty("element-6066-11e4-a52e-4f735466cecf", out var value3) ? value3.GetString() : null);
			}
			if (string.IsNullOrEmpty(value2))
			{
				return;
			}
			StringContent content = new StringContent("{}", Encoding.UTF8, "application/json");
			await m_5628.PostAsync($"{WdaBaseUrl}/session/{P_0}/element/{value2}/clear", content);
		}
		catch
		{
		}
	}

	public static async Task<bool> InputTextAsync(string text)
	{
		string text2 = await c();
		if (text2 == null)
		{
			return false;
		}
		try
		{
			StringContent content = new StringContent(JsonSerializer.Serialize(new d<string[]>((from P_0 in text.EnumerateRunes()
				select P_0.ToString()).ToArray())), Encoding.UTF8, "application/json");
			return (await m_5628.PostAsync(WdaBaseUrl + "/session/" + text2 + "/wda/keys", content)).IsSuccessStatusCode;
		}
		catch
		{
			return false;
		}
	}

	public static async Task<bool> KeyEventAsync(string keycode)
	{
		string text = keycode.Trim().ToUpperInvariant();
		bool flag;
		switch (text)
		{
		case "66":
		case "ENTER":
		case "KEYCODE_ENTER":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (flag)
		{
			return await InputTextAsync("\n");
		}
		switch (text)
		{
		case "67":
		case "DEL":
		case "KEYCODE_DEL":
		case "BACKSPACE":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (flag)
		{
			return await InputTextAsync("\b");
		}
		switch (text)
		{
		case "3":
		case "HOME":
		case "KEYCODE_HOME":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (flag)
		{
			return await F("home");
		}
		return true;
	}

	private static async Task<bool> F(string P_0)
	{
		string text = await c();
		if (text == null)
		{
			return false;
		}
		try
		{
			StringContent content = new StringContent("{\"name\":\"" + P_0 + "\"}", Encoding.UTF8, "application/json");
			return (await m_5628.PostAsync(WdaBaseUrl + "/session/" + text + "/wda/pressButton", content)).IsSuccessStatusCode;
		}
		catch
		{
			return false;
		}
	}
}
