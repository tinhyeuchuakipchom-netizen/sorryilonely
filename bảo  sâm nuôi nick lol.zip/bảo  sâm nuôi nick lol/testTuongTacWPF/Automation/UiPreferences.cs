using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class UiPreferences
{
	public const string DefaultTheme = "Neon";

	[CompilerGenerated]
	private string A = "Neon";

	[CompilerGenerated]
	private bool m_6767;

	[CompilerGenerated]
	private bool a;

	[CompilerGenerated]
	private string m_6768 = "VI";

	[CompilerGenerated]
	private Dictionary<string, int> m_6769 = new Dictionary<string, int>();

	[CompilerGenerated]
	private bool B;

	[CompilerGenerated]
	private List<CustomPlatformEntry> m_6770 = new List<CustomPlatformEntry>();

	[CompilerGenerated]
	private List<string> m_6771 = new List<string>();

	[CompilerGenerated]
	private Dictionary<string, string> m_6772 = new Dictionary<string, string>();

	private static readonly string m_6773 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "ui_preferences.json");

	public string Theme
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public bool ThemeForcedToNeonV1
	{
		[CompilerGenerated]
		get
		{
			return m_6767;
		}
		[CompilerGenerated]
		set
		{
			m_6767 = value;
		}
	}

	public bool HoTenColumnNextToPassV1
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string Language
	{
		[CompilerGenerated]
		get
		{
			return m_6768;
		}
		[CompilerGenerated]
		set
		{
			m_6768 = value;
		}
	}

	public Dictionary<string, int> LastSelectedFolderId
	{
		[CompilerGenerated]
		get
		{
			return m_6769;
		}
		[CompilerGenerated]
		set
		{
			m_6769 = value;
		}
	}

	public bool HasSeenVietnameseInputNotice
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public List<CustomPlatformEntry> CustomPlatforms
	{
		[CompilerGenerated]
		get
		{
			return m_6770;
		}
		[CompilerGenerated]
		set
		{
			m_6770 = value;
		}
	}

	public List<string> HiddenBuiltInPlatforms
	{
		[CompilerGenerated]
		get
		{
			return m_6771;
		}
		[CompilerGenerated]
		set
		{
			m_6771 = value;
		}
	}

	public Dictionary<string, string> RenamedBuiltInPlatforms
	{
		[CompilerGenerated]
		get
		{
			return m_6772;
		}
		[CompilerGenerated]
		set
		{
			m_6772 = value;
		}
	}

	public static UiPreferences Load()
	{
		try
		{
			if (!File.Exists(m_6773))
			{
				return new UiPreferences();
			}
			UiPreferences uiPreferences = JsonSerializer.Deserialize<UiPreferences>(File.ReadAllText(m_6773)) ?? new UiPreferences();
			if (!ThemeManager.IsKnownTheme(uiPreferences.Theme))
			{
				uiPreferences.Theme = "Neon";
			}
			return uiPreferences;
		}
		catch
		{
			return new UiPreferences();
		}
	}

	public void Save()
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(m_6773));
			File.WriteAllText(m_6773, JsonSerializer.Serialize(this, new JsonSerializerOptions
			{
				WriteIndented = true
			}));
		}
		catch
		{
		}
	}
}
