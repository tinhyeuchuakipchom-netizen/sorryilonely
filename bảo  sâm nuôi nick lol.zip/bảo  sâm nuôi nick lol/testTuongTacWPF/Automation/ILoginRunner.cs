using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public interface ILoginRunner
{
	Task<LoginResult> LoginAsync(FacebookAccountRow nick, CancellationToken cancellationToken);
}
