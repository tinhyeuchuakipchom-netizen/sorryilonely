using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using A;
using Microsoft.Playwright;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class FacebookPageCreationRunner
{
	public class PageCreateSingleResult
	{
		[CompilerGenerated]
		private bool A;

		[CompilerGenerated]
		private bool a;

		public bool Success
		{
			[CompilerGenerated]
			get
			{
				return A;
			}
			[CompilerGenerated]
			set
			{
				A = value;
			}
		}

		public bool IsLimitBlocked
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public static implicit operator bool(PageCreateSingleResult res)
		{
			return res?.Success ?? false;
		}
	}

	[CompilerGenerated]
	private sealed class m_4982
	{
		public Action<AiVisionStepLog> A;

		public int m_4985;

		internal void m_4986(string P_0)
		{
			A(new AiVisionStepLog
			{
				FlowStepIndex = m_4985++,
				SubStep = 1,
				ActionSummary = P_0,
				Reason = "Tạo Page"
			});
		}

		internal void m_4987(string P_0, string P_1)
		{
			m_4986(P_0);
		}
	}

	private const string A = "https://www.facebook.com/pages/creation/?locale=en_US";

	private const string a = "Blogger";

	public static async Task<AiVisionRunResult> RunAsync(FacebookAccountRow nick, Action<AiVisionStepLog> onStep, CancellationToken cancellationToken, PageCreationSettings pageSettings, int sequenceIndex)
	{
		m_4982 CS_0024_003C_003E8__locals9 = new m_4982();
		CS_0024_003C_003E8__locals9.A = onStep;
		if (string.IsNullOrWhiteSpace(nick.ProfileChrome))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = "Nick chưa gắn Chrome (chưa có Profile Chrome).",
				TinhTrang = "ERROR"
			};
		}
		ActiveBrowserEngine activeBrowserEngine = BrowserEngineFactory.CreateActiveClient();
		IAntidetectBrowserClient client = activeBrowserEngine.Client;
		IChromeEngineSettings settings = activeBrowserEngine.Settings;
		if (!(await client.CheckApiAliveAsync()))
		{
			return new AiVisionRunResult
			{
				Success = false,
				Message = $"Không kết nối được {activeBrowserEngine.DisplayName} tại {activeBrowserEngine.ApiUrl}. Mở {activeBrowserEngine.DisplayName} lên, bật Local API và kiểm tra Cài đặt {activeBrowserEngine.DisplayName}.",
				TinhTrang = "ERROR"
			};
		}
		string browserProfileId = nick.BrowserProfileId;
		CS_0024_003C_003E8__locals9.m_4985 = 0;
		AiVisionRunResult result;
		try
		{
			_ = 8;
			try
			{
				cancellationToken.ThrowIfCancellationRequested();
				OmoBrowserStartResult omoBrowserStartResult = await F.A(client, settings, nick);
				browserProfileId = nick.BrowserProfileId;
				using IPlaywright playwright = await Playwright.CreateAsync();
				(OmoBrowserStartResult, IBrowser) tuple = await F.A(client, settings, nick, playwright, omoBrowserStartResult, cancellationToken);
				omoBrowserStartResult = tuple.Item1;
				IBrowser item = tuple.Item2;
				browserProfileId = nick.BrowserProfileId;
				IBrowserContext browserContext = item.Contexts.FirstOrDefault();
				if (browserContext == null)
				{
					browserContext = await item.NewContextAsync();
				}
				IBrowserContext browserContext2 = browserContext;
				IPage page = browserContext2.Pages.FirstOrDefault();
				if (page == null)
				{
					page = await browserContext2.NewPageAsync();
				}
				IPage page2 = page;
				CS_0024_003C_003E8__locals9.m_4986("Đang đăng nhập...");
				LoginResult loginResult = await ChromeLoginRunner.m_3645(nick, settings, browserContext2, page2, omoBrowserStartResult.WindowHandle, cancellationToken, (string P_0, string P_1) =>
				{
					CS_0024_003C_003E8__locals9.m_4986(P_0);
				});
				if (!loginResult.Success)
				{
					result = new AiVisionRunResult
					{
						Success = false,
						Message = "Chưa đăng nhập được để tạo Page: " + loginResult.TrangThai,
						TinhTrang = loginResult.TinhTrang
					};
				}
				else
				{
					int num2 = Math.Max(1, pageSettings.PageCount);
					int num3 = 0;
					int num4 = 0;
					while (true)
					{
						if (num4 < num2)
						{
							cancellationToken.ThrowIfCancellationRequested();
							CS_0024_003C_003E8__locals9.m_4986($"[{num4 + 1}/{num2}] Đang tiến hành tạo Page...");
							PageCreateSingleResult pageCreateSingleResult = await CreateSinglePageOnPageAsync(page2, pageSettings, sequenceIndex + num4, (string P_0) =>
							{
								CS_0024_003C_003E8__locals9.A(new AiVisionStepLog
								{
									FlowStepIndex = CS_0024_003C_003E8__locals9.m_4985++,
									SubStep = 1,
									ActionSummary = P_0,
									Reason = "Tạo Page"
								});
							}, cancellationToken);
							if (pageCreateSingleResult.IsLimitBlocked)
							{
								CS_0024_003C_003E8__locals9.m_4986("Cảnh báo: Tài khoản bị giới hạn tạo Page từ Facebook (cần nghỉ ngơi).");
								result = new AiVisionRunResult
								{
									Success = false,
									Message = "Bị giới hạn tạo Page: Facebook thông báo bạn đã tạo quá nhiều Trang gần đây (Cannot Create Page: You have attempted to create too many Pages recently). Cần cho nick nghỉ ngơi trước khi tạo tiếp.",
									TinhTrang = "LIMIT_PAGE"
								};
								break;
							}
							if (pageCreateSingleResult.Success)
							{
								num3++;
							}
							if (num4 < num2 - 1)
							{
								int num5 = Math.Max(1, pageSettings.MinDelaySeconds);
								int num6 = Math.Max(num5, pageSettings.MaxDelaySeconds);
								int num7 = Random.Shared.Next(num5, num6 + 1);
								CS_0024_003C_003E8__locals9.m_4986($"Đã tạo xong {num4 + 1}/{num2} Page. Nghỉ {num7}s trước khi tạo Page tiếp theo...");
								await Task.Delay(num7 * 1000, cancellationToken);
							}
							num4++;
							continue;
						}
						if (settings.SaveNewCookieAfterLogin)
						{
							await ChromeLoginRunner.RefreshCookieAsync(nick, browserContext2);
						}
						result = ((num3 > 0) ? new AiVisionRunResult
						{
							Success = true,
							Message = $"Đã tạo thành công {num3}/{num2} Page trên Chrome.",
							TinhTrang = "LIVE"
						} : new AiVisionRunResult
						{
							Success = false,
							Message = $"Không tạo được Page nào (0/{num2}) - kiểm tra lại thủ công.",
							TinhTrang = "ERROR"
						});
						break;
					}
				}
			}
			catch (OperationCanceledException)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Đã dừng theo yêu cầu.",
					TinhTrang = "ERROR"
				};
			}
			catch (Exception ex2)
			{
				result = new AiVisionRunResult
				{
					Success = false,
					Message = "Lỗi trình duyệt/Playwright: " + ChromeLoginRunner.m_3655(ex2),
					TinhTrang = "ERROR"
				};
			}
		}
		finally
		{
			if (!string.IsNullOrWhiteSpace(browserProfileId))
			{
				try
				{
					await client.StopProfileAsync(browserProfileId);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	public static async Task<PageCreateSingleResult> CreateSinglePageOnPageAsync(IPage page, PageCreationSettings pageSettings, int sequenceIndex, Action<string> log, CancellationToken cancellationToken)
	{
		string text = pageSettings.BuildPageName(sequenceIndex);
		log("Đang tạo Page \"" + text + "\"...");
		await page.GotoAsync("https://www.facebook.com/pages/creation/?locale=en_US", new PageGotoOptions
		{
			Timeout = 30000f,
			WaitUntil = WaitUntilState.DOMContentLoaded
		});
		await Task.Delay(2000, cancellationToken);
		ILocator first = page.Locator("input[type='text']").First;
		await first.ScrollIntoViewIfNeededAsync();
		await first.ClickAsync();
		await PlaywrightHumanHelpers.SlowTypeAsync(first, text);
		ILocator byLabel = page.GetByLabel("Category (required)");
		await byLabel.ScrollIntoViewIfNeededAsync();
		await byLabel.ClickAsync();
		await PlaywrightHumanHelpers.SlowTypeAsync(byLabel, "Blogger");
		await Task.Delay(1000, cancellationToken);
		ILocator byRole = page.GetByRole(AriaRole.Option, new PageGetByRoleOptions
		{
			Name = "Blogger",
			Exact = true
		});
		if (await byRole.CountAsync() == 0)
		{
			log("Không tìm thấy category \"Blogger\" trong danh sách gợi ý - Facebook có thể đã đổi luồng.");
			return new PageCreateSingleResult
			{
				Success = false
			};
		}
		await byRole.First.ClickAsync();
		await Task.Delay(500, cancellationToken);
		cancellationToken.ThrowIfCancellationRequested();
		await page.GetByRole(AriaRole.Button, new PageGetByRoleOptions
		{
			Name = "Create Page",
			Exact = true
		}).ClickAsync();
		await Task.Delay(3000, cancellationToken);
		string text2 = await m_4980(page);
		if (text2.Contains("cannot create page", StringComparison.OrdinalIgnoreCase) || text2.Contains("too many pages", StringComparison.OrdinalIgnoreCase) || text2.Contains("attempted to create too many pages", StringComparison.OrdinalIgnoreCase) || text2.Contains("tạo quá nhiều trang", StringComparison.OrdinalIgnoreCase) || text2.Contains("không thể tạo trang", StringComparison.OrdinalIgnoreCase))
		{
			log("Phát hiện lỗi giới hạn: Facebook báo đã tạo quá nhiều Trang gần đây.");
			return new PageCreateSingleResult
			{
				Success = false,
				IsLimitBlocked = true
			};
		}
		bool flag = text2.Contains("Success! You've created", StringComparison.OrdinalIgnoreCase);
		if (flag)
		{
			log("Đã tạo Page \"" + text + "\" thành công.");
		}
		else
		{
			log("Không xác nhận được đã tạo Page \"" + text + "\".");
		}
		return new PageCreateSingleResult
		{
			Success = flag
		};
	}

	private static async Task<string> m_4980(IPage P_0)
	{
		try
		{
			return await P_0.InnerTextAsync("body");
		}
		catch
		{
			return "";
		}
	}

	private static string m_4981(string P_0, int P_1)
	{
		if (P_0.Length > P_1)
		{
			return P_0.Substring(0, P_1) + "...";
		}
		return P_0;
	}
}
