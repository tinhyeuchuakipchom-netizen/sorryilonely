using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class VerifyMailSettings
{
	[CompilerGenerated]
	private string A = "TenMinuteMail";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string C = "RandomString";

	[CompilerGenerated]
	private bool m_6788 = true;

	[CompilerGenerated]
	private bool m_6789 = true;

	[CompilerGenerated]
	private int m_6790 = 7;

	[CompilerGenerated]
	private int m_6791 = 11;

	[CompilerGenerated]
	private bool m_6792;

	[CompilerGenerated]
	private bool m_6793 = true;

	[CompilerGenerated]
	private int m_6794 = 1985;

	[CompilerGenerated]
	private int m_6795 = 2005;

	[CompilerGenerated]
	private string c = "gmail.com";

	private static readonly string D = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FastBoxPhone", "verify_mail_settings.json");

	public string Provider
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string Proxy
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string DongVanApiKey
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string DongVanFolderId
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string RandomMailStyle
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public bool RandomMailLower
	{
		[CompilerGenerated]
		get
		{
			return m_6788;
		}
		[CompilerGenerated]
		set
		{
			m_6788 = value;
		}
	}

	public bool RandomMailDigits
	{
		[CompilerGenerated]
		get
		{
			return m_6789;
		}
		[CompilerGenerated]
		set
		{
			m_6789 = value;
		}
	}

	public int RandomMailMinLength
	{
		[CompilerGenerated]
		get
		{
			return m_6790;
		}
		[CompilerGenerated]
		set
		{
			m_6790 = value;
		}
	}

	public int RandomMailMaxLength
	{
		[CompilerGenerated]
		get
		{
			return m_6791;
		}
		[CompilerGenerated]
		set
		{
			m_6791 = value;
		}
	}

	public bool RandomMailDotSeparator
	{
		[CompilerGenerated]
		get
		{
			return m_6792;
		}
		[CompilerGenerated]
		set
		{
			m_6792 = value;
		}
	}

	public bool RandomMailAddSuffix
	{
		[CompilerGenerated]
		get
		{
			return m_6793;
		}
		[CompilerGenerated]
		set
		{
			m_6793 = value;
		}
	}

	public int RandomMailBirthYearMin
	{
		[CompilerGenerated]
		get
		{
			return m_6794;
		}
		[CompilerGenerated]
		set
		{
			m_6794 = value;
		}
	}

	public int RandomMailBirthYearMax
	{
		[CompilerGenerated]
		get
		{
			return m_6795;
		}
		[CompilerGenerated]
		set
		{
			m_6795 = value;
		}
	}

	public string RandomMailDomain
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string BuildRandomMailPreview()
	{
		string fullName = RandomFacebookIdentityGenerator.RandomFullName(RandomFacebookIdentityGenerator.RandomGender(), includeMiddleName: true);
		string randomMailStyle = RandomMailStyle;
		if (!(randomMailStyle == "FromName"))
		{
			if (randomMailStyle == "NameYear")
			{
				return RandomFacebookIdentityGenerator.RandomEmailFromName(fullName, RandomMailDotSeparator, RandomMailAddSuffix, Random.Shared.Next(RandomMailBirthYearMin, RandomMailBirthYearMax + 1), RandomMailDomain);
			}
			return RandomFacebookIdentityGenerator.RandomEmailAddress(RandomMailLower, RandomMailDigits, RandomMailMinLength, RandomMailMaxLength, RandomMailDomain);
		}
		return RandomFacebookIdentityGenerator.RandomEmailFromName(fullName, RandomMailDotSeparator, RandomMailAddSuffix, null, RandomMailDomain);
	}

	public IVerifyMailTestClient CreateClient()
	{
		return Provider switch
		{
			"TempMailOrg" => (IVerifyMailTestClient)new TempMailOrgClient(Proxy), 
			"Tmailor" => new TmailorClient(Proxy), 
			"TempMail100" => new TempMail100Client(), 
			"TempMailIo" => new TempMailIoClient(Proxy), 
			"TemporaryMail" => new TemporaryMailClient(), 
			"DongVanFb" => new DongVanFbClient(DongVanApiKey, DongVanFolderId), 
			"Random" => throw new InvalidOperationException("Cổng \"Mail ảo random\" không có client thật - dùng BuildRandomMailPreview() thay vì CreateClient()."), 
			_ => new TenMinuteMailClient(), 
		};
	}

	public static VerifyMailSettings Load()
	{
		try
		{
			if (!File.Exists(D))
			{
				return new VerifyMailSettings();
			}
			return JsonSerializer.Deserialize<VerifyMailSettings>(File.ReadAllText(D)) ?? new VerifyMailSettings();
		}
		catch
		{
			return new VerifyMailSettings();
		}
	}

	public void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(D));
		File.WriteAllText(D, JsonSerializer.Serialize(this, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
	}
}
