using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using testTuongTacWPF.Models;

namespace testTuongTacWPF.Automation;

public static class TikTokPhoneLoginService
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_6555
	{
		public static readonly m_6555 A = new m_6555();

		public static Func<UiElement, bool> m_6558;

		public static Func<UiElement, bool> a;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		public static Func<UiElement, bool> C;

		public static Func<UiElement, bool> c;

		public static Func<UiElement, bool> D;

		public static Func<UiElement, bool> d;

		public static Func<UiElement, bool> E;

		public static Func<UiElement, bool> e;

		public static Func<UiElement, bool> F;

		public static Func<UiElement, bool> f;

		public static Func<UiElement, bool> G;

		public static Func<UiElement, bool> g;

		public static Func<UiElement, bool> H;

		public static Func<UiElement, bool> h;

		public static Func<UiElement, bool> I;

		public static Func<UiElement, bool> i;

		public static Func<UiElement, bool> J;

		public static Func<UiElement, bool> j;

		public static Func<UiElement, bool> K;

		public static Func<UiElement, bool> k;

		public static Func<UiElement, bool> L;

		public static Func<UiElement, bool> l;

		public static Func<UiElement, bool> M;

		public static Func<UiElement, bool> m;

		public static Func<UiElement, bool> N;

		public static Func<UiElement, bool> n;

		public static Func<UiElement, bool> O;

		public static Func<UiElement, bool> o;

		public static Func<UiElement, bool> P;

		public static Func<UiElement, bool> p;

		public static Func<UiElement, bool> Q;

		public static Func<UiElement, bool> q;

		public static Func<UiElement, bool> R;

		public static Func<UiElement, bool> r;

		public static Func<UiElement, bool> S;

		public static Func<UiElement, bool> s;

		public static Func<UiElement, bool> T;

		public static Func<UiElement, bool> t;

		public static Func<UiElement, bool> U;

		public static Func<UiElement, bool> u;

		public static Func<UiElement, bool> V;

		public static Func<UiElement, bool> v;

		public static Func<UiElement, bool> W;

		public static Func<UiElement, bool> w;

		internal bool m_6559(UiElement P_0)
		{
			if (!(P_0.ContentDesc == "Home"))
			{
				return P_0.Text == "Home";
			}
			return true;
		}

		internal bool m_6560(UiElement P_0)
		{
			if (!P_0.Text.Contains("Agree and continue", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Đồng ý", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("ezl");
			}
			return true;
		}

		internal bool m_6561(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("permission_allow_button") && !string.Equals(P_0.Text, "ALLOW", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Cho phép", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "While using the app", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6562(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Skip", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase) && !P_0.ResourceId.Contains("d28"))
			{
				return P_0.ResourceId.Contains("skip");
			}
			return true;
		}

		internal bool m_6563(UiElement P_0)
		{
			if (!P_0.Text.Contains("Choose what you like", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Choose your interests", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("bạn thích", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("sở thích", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6564(UiElement P_0)
		{
			if (!P_0.Text.Contains("Update TikTok", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Update available", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Cập nhật TikTok", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6565(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Not now", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Later", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Cancel", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Để sau", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6566(UiElement P_0)
		{
			if (!P_0.Text.Contains("Sync contacts", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Find contacts", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Connect with friends", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Đồng bộ danh bạ", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6567(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Don't allow", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Not now", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Skip", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Không cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6568(UiElement P_0)
		{
			if (!P_0.Text.Contains("precise location", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("location_permission");
			}
			return true;
		}

		internal bool m_6569(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Allow", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6570(UiElement P_0)
		{
			if (!P_0.Text.Contains("Swipe up for more", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Swipe up to start watching", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Swipe up", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Vuốt lên", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6571(UiElement P_0)
		{
			if (!(P_0.ContentDesc == "Home") && !(P_0.ContentDesc == "Profile") && !(P_0.Text == "Home") && !(P_0.Text == "Profile") && !(P_0.Text == "Hồ sơ") && !P_0.ContentDesc.Contains("Use phone"))
			{
				return P_0.Text.Contains("Log in to TikTok");
			}
			return true;
		}

		internal bool m_6572(UiElement P_0)
		{
			if (!P_0.Text.Contains("Choose what you like", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Choose your interests", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6573(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Skip", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("d28");
			}
			return true;
		}

		internal bool m_6574(UiElement P_0)
		{
			if (!P_0.Text.Contains("Swipe up", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Vuốt lên", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6575(UiElement P_0)
		{
			if (!P_0.ContentDesc.Contains("Use phone / email / username", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Use phone / email / username", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Use phone", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Use phone", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Sử dụng số điện thoại", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Sử dụng số điện thoại", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6576(UiElement P_0)
		{
			if (P_0.Text.Contains("Log in", StringComparison.OrdinalIgnoreCase))
			{
				if (!P_0.Text.Contains("Already have", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.ContentDesc.Contains("Log in");
				}
				return true;
			}
			return false;
		}

		internal bool m_6577(UiElement P_0)
		{
			if (!string.Equals(P_0.ContentDesc, "Profile", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Profile", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.ContentDesc, "Hồ sơ", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Hồ sơ", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.ContentDesc, "Me", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Me", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("oly");
			}
			return true;
		}

		internal bool m_6578(UiElement P_0)
		{
			if (!P_0.Text.Contains("Email", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Email", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Username", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Username", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ContentDesc.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6579(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText") && !P_0.Text.Contains("Email", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("username", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("tên người dùng", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Focused;
			}
			return true;
		}

		internal bool m_6580(UiElement P_0)
		{
			return P_0.Text.Contains("Email", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_6581(UiElement P_0)
		{
			return P_0.Text.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_6582(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("f77") && !P_0.ResourceId.Contains("f78") && !P_0.ResourceId.Contains("dxn") && !P_0.Text.Contains("Enter password", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Nhập mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Show password", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Hide password", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Hiển thị mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.ContentDesc.Contains("Ẩn mật khẩu", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Show password", StringComparison.OrdinalIgnoreCase))
			{
				if (P_0.ClassName.Contains("EditText"))
				{
					if (!P_0.Text.Equals("Password", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Equals("Mật khẩu", StringComparison.OrdinalIgnoreCase))
					{
						return P_0.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase);
					}
					return true;
				}
				return false;
			}
			return true;
		}

		internal bool m_6583(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("f78") && (!P_0.ClassName.Contains("EditText") || P_0.Text.Contains("Enter password", StringComparison.OrdinalIgnoreCase) || P_0.Text.Contains("Nhập mật khẩu", StringComparison.OrdinalIgnoreCase)) && !string.Equals(P_0.Text, "Password", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Mật khẩu", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6584(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("fmf") && !P_0.ResourceId.Contains("e_7") && !string.Equals(P_0.Text, "Continue", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Tiếp tục", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6585(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("fmf") && !P_0.ResourceId.Contains("e_7") && !string.Equals(P_0.Text, "Continue", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Tiếp tục", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Log in", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Đăng nhập", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6586(UiElement P_0)
		{
			if (!P_0.Text.Contains("precise location", StringComparison.OrdinalIgnoreCase) && !P_0.ResourceId.Contains("location_permission"))
			{
				return P_0.ResourceId.Contains("permission_allow_button");
			}
			return true;
		}

		internal bool m_6587(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Allow", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Cho phép", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "While using the app", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6588(UiElement P_0)
		{
			if (!P_0.Text.Contains("Save login info", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Save your login info", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Lưu thông tin", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6589(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Save", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Lưu", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Not now", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Để sau", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "OK", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6590(UiElement P_0)
		{
			if (!P_0.Text.Contains("Sync contacts", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Find contacts", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Connect with friends", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Đồng bộ danh bạ", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6591(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Don't allow", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Not now", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Skip", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase))
			{
				return string.Equals(P_0.Text, "Không cho phép", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6592(UiElement P_0)
		{
			if (!P_0.Text.Contains("Swipe up for more", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Swipe up to start watching", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Swipe up", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Vuốt lên", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6593(UiElement P_0)
		{
			if (!P_0.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Two-step verification", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Xác minh 2 bước", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Enter code", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Nhập mã", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6594(UiElement P_0)
		{
			if (!P_0.ClassName.Contains("EditText"))
			{
				return P_0.Focused;
			}
			return true;
		}

		internal bool m_6595(UiElement P_0)
		{
			if (!P_0.Text.Contains("Drag the slider", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Kéo thanh trượt", StringComparison.OrdinalIgnoreCase) && !P_0.ClassName.Contains("lynx", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.ResourceId.Contains("captcha", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6596(UiElement P_0)
		{
			if (!(P_0.ContentDesc == "Home"))
			{
				return P_0.Text == "Home";
			}
			return true;
		}

		internal bool m_6597(UiElement P_0)
		{
			if (!(P_0.ContentDesc == "Profile") && !(P_0.Text == "Profile"))
			{
				return P_0.Text == "Hồ sơ";
			}
			return true;
		}

		internal bool m_6598(UiElement P_0)
		{
			if (!P_0.Text.Contains("Log in to TikTok") && !P_0.Text.Contains("Sign up") && !P_0.Text.Contains("Use phone") && !P_0.Text.Contains("Enter password"))
			{
				return P_0.Text.Contains("Nhập mật khẩu");
			}
			return true;
		}

		internal bool m_6599(UiElement P_0)
		{
			if (P_0.ResourceId.Contains("fmf") || string.Equals(P_0.Text, "Continue", StringComparison.OrdinalIgnoreCase) || string.Equals(P_0.Text, "Log in", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Enabled;
			}
			return false;
		}

		internal bool m_6600(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("ibz") && !P_0.ResourceId.Contains("error") && !P_0.ResourceId.Contains("toast") && !P_0.Text.Contains("match", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("exist", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("incorrect", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("không đúng", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("không tồn tại", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Too many attempts", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Maximum number of attempts", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Try again later", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("No internet", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Network is unreachable", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Network error", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Text.Contains("Something went wrong", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}

		internal bool m_6601(UiElement P_0)
		{
			return P_0.Text == "Following";
		}

		internal bool m_6602(UiElement P_0)
		{
			return P_0.Text == "Followers";
		}

		internal bool m_6603(UiElement P_0)
		{
			return P_0.Text.StartsWith("@");
		}

		internal bool m_6604(UiElement P_0)
		{
			return P_0.ResourceId.Contains("t4g");
		}
	}

	[CompilerGenerated]
	private sealed class m_6556
	{
		public List<UiElement> A;

		internal bool m_6605(UiElement P_0)
		{
			if (!string.Equals(P_0.Text, "Edit", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Edit profile", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Sửa hồ sơ", StringComparison.OrdinalIgnoreCase) && !string.Equals(P_0.Text, "Chỉnh sửa hồ sơ", StringComparison.OrdinalIgnoreCase) && !(P_0.ContentDesc == "Profile menu") && !P_0.ResourceId.Contains("upload_work"))
			{
				if (A.Any((UiElement uiElement) => uiElement.Text == "Following"))
				{
					return A.Any((UiElement uiElement) => uiElement.Text == "Followers");
				}
				return false;
			}
			return true;
		}
	}

	[CompilerGenerated]
	private sealed class m_6557
	{
		public PlatformAccountRow A;

		public Action<string> m_6606;

		internal void m_6607(string P_0)
		{
			A.TrangThai = P_0;
			m_6606(P_0);
		}
	}

	[CompilerGenerated]
	private sealed class b
	{
		public List<UiElement> A;

		internal bool m_6608(UiElement P_0)
		{
			if (!P_0.Text.Contains("Email or username", StringComparison.OrdinalIgnoreCase) && !P_0.Text.Contains("Email / Tên người dùng", StringComparison.OrdinalIgnoreCase) && (!P_0.Text.Contains("Phone", StringComparison.OrdinalIgnoreCase) || !A.Any((UiElement uiElement) => uiElement.Text.Contains("Email", StringComparison.OrdinalIgnoreCase))))
			{
				if (P_0.Text.Contains("Số điện thoại", StringComparison.OrdinalIgnoreCase))
				{
					return A.Any((UiElement uiElement) => uiElement.Text.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase));
				}
				return false;
			}
			return true;
		}
	}

	private static readonly string[] A = new string[2] { "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" };

	public static async Task<LoginResult> LoginAccountAsync(PlatformAccountRow account, Action<string> onStatus, CancellationToken cancellationToken)
	{
		if (string.IsNullOrWhiteSpace(account.PhoneName))
		{
			LoginResult loginResult = new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Nick chưa được gắn Phone"
			};
			account.TrangThai = loginResult.TrangThai;
			account.TinhTrang = loginResult.TinhTrang;
			return loginResult;
		}
		account.TrangThai = "Bắt đầu đăng nhập TikTok...";
		account.TinhTrang = "";
		LoginResult loginResult2 = await LoginAsync(account.PhoneName, account.Uid, account.Pass, account.TwoFA, account.Proxy, (string P_0) =>
		{
			account.TrangThai = P_0;
			onStatus(P_0);
		}, cancellationToken);
		account.TrangThai = loginResult2.TrangThai;
		account.TinhTrang = loginResult2.TinhTrang;
		return loginResult2;
	}

	public static async Task<LoginResult> LoginAsync(string deviceSerial, string uid, string pass, string? twoFA, string? proxy, Action<string> onStatus, CancellationToken cancellationToken)
	{
		_ = 30;
		try
		{
			onStatus("Đang kiểm tra kết nối thiết bị...");
			if (!(await AdbController.RunShellCaptureAsync(deviceSerial, "echo online", cancellationToken)).Trim().Contains("online"))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "OFFLINE",
					TrangThai = "Thiết bị " + deviceSerial + " không phản hồi"
				};
			}
			onStatus("Kiểm tra kết nối internet của máy...");
			bool flag = await AdbController.CheckInternetAsync(deviceSerial, cancellationToken);
			if (!flag)
			{
				onStatus("Thiết bị chưa có internet, đang thử kích hoạt Wi-Fi...");
				await AdbController.RunShellAsync(deviceSerial, "svc wifi enable", cancellationToken);
				await Task.Delay(4000, cancellationToken);
				flag = await AdbController.CheckInternetAsync(deviceSerial, cancellationToken);
			}
			if (!flag)
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "NO_INTERNET",
					TrangThai = "Thiết bị không có kết nối internet (ping 8.8.8.8 thất bại). Vui lòng kết nối Wi-Fi/4G cho máy."
				};
			}
			onStatus("Kiểm tra app TikTok & cấu hình máy...");
			await PhoneInitialSetupService.EnsureInitialSetupAsync(deviceSerial, "TikTok", onStatus, cancellationToken);
			onStatus("Đang thiết lập ngôn ngữ máy sang Tiếng Anh (English)...");
			await AdbController.EnsureEnglishLanguageAsync(deviceSerial, cancellationToken);
			string text = await m_6549(deviceSerial, cancellationToken);
			try
			{
				await AdbController.GrantAllAppPermissionsAsync(deviceSerial, text, cancellationToken);
			}
			catch
			{
			}
			(int ScreenWidth, int ScreenHeight) screenSize;
			try
			{
				screenSize = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			}
			catch
			{
				screenSize = (ScreenWidth: 900, ScreenHeight: 1600);
			}
			onStatus("Đang mở ứng dụng TikTok...");
			await AdbController.RunShellAsync(deviceSerial, "am start -n " + text + "/com.ss.android.ugc.aweme.splash.SplashActivity", cancellationToken);
			await Task.Delay(3500, cancellationToken);
			await m_6550(deviceSerial, screenSize, onStatus, cancellationToken);
			onStatus("Kiểm tra trạng thái tài khoản...");
			var (flag2, text2, text3) = await a(deviceSerial, cancellationToken);
			if (!flag2 && (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).Any((UiElement P_0) => P_0.ContentDesc == "Home" || P_0.Text == "Home"))
			{
				int x = (int)((double)screenSize.ScreenWidth * 0.9);
				int y = (int)((double)screenSize.ScreenHeight * 0.97);
				await AdbController.TapAsync(deviceSerial, x, y, cancellationToken);
				await Task.Delay(2000, cancellationToken);
				(flag2, text2, text3) = await a(deviceSerial, cancellationToken);
			}
			if (flag2)
			{
				string text4;
				if (string.IsNullOrWhiteSpace(text2))
				{
					text4 = ((!string.IsNullOrWhiteSpace(text3)) ? text3 : uid);
				}
				else
				{
					text4 = text2;
				}
				return new LoginResult
				{
					Success = true,
					TinhTrang = "LIVE",
					TrangThai = "Tài khoản đã đăng nhập sẵn (" + text4 + ")"
				};
			}
			onStatus("Đang vào mục Hồ sơ / Đăng nhập...");
			if (!(await a(deviceSerial, screenSize, onStatus, cancellationToken)))
			{
				await AdbController.SwipeAsync(deviceSerial, screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.75), screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.25), 300, cancellationToken);
				await Task.Delay(1000, cancellationToken);
				await a(deviceSerial, screenSize, onStatus, cancellationToken);
			}
			onStatus("Đang chọn đăng nhập qua Email / Username...");
			await m_6551(deviceSerial, screenSize, cancellationToken);
			await Task.Delay(1500, cancellationToken);
			onStatus("Đang nhập tài khoản: " + uid + "...");
			if (!(await m_6552(deviceSerial, uid, screenSize, cancellationToken)))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Không tìm thấy ô nhập Email / Username"
				};
			}
			onStatus("Bấm Tiếp tục...");
			await a(deviceSerial, screenSize, cancellationToken);
			await Task.Delay(2500, cancellationToken);
			onStatus("Đang nhập mật khẩu...");
			if (!(await a(deviceSerial, pass, screenSize, cancellationToken)))
			{
				string text5 = m_6554(await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken));
				if (!string.IsNullOrEmpty(text5))
				{
					string tinhTrang = "ERROR";
					string text6 = text5.ToLowerInvariant();
					if (text6.Contains("no internet") || text6.Contains("network"))
					{
						tinhTrang = "NO_INTERNET";
					}
					else if (text6.Contains("exist") || text6.Contains("couldn't find") || text6.Contains("không tồn tại"))
					{
						tinhTrang = "KHONG_TON_TAI";
					}
					else if (text6.Contains("too many attempts") || text6.Contains("maximum number of attempts") || text6.Contains("try again later"))
					{
						tinhTrang = "SPAM";
					}
					return new LoginResult
					{
						Success = false,
						TinhTrang = tinhTrang,
						TrangThai = text5
					};
				}
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = "Không chuyển được sang màn hình nhập mật khẩu"
				};
			}
			onStatus("Bấm Đăng nhập...");
			await a(deviceSerial, screenSize, cancellationToken);
			onStatus("Đang kiểm tra kết quả đăng nhập...");
			return await m_6553(deviceSerial, uid, twoFA, screenSize, onStatus, cancellationToken);
		}
		catch (OperationCanceledException)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "",
				TrangThai = "Đã dừng đăng nhập"
			};
		}
		catch (Exception ex2)
		{
			return new LoginResult
			{
				Success = false,
				TinhTrang = "ERROR",
				TrangThai = "Lỗi: " + ex2.Message
			};
		}
	}

	private static async Task<string> m_6549(string P_0, CancellationToken P_1)
	{
		string[] array;
		try
		{
			string text = await AdbController.RunShellCaptureAsync(P_0, "dumpsys window | grep mCurrentFocus", P_1);
			array = A;
			foreach (string text2 in array)
			{
				if (text.Contains(text2, StringComparison.OrdinalIgnoreCase))
				{
					return text2;
				}
			}
		}
		catch
		{
		}
		string text3 = await AdbController.RunShellCaptureAsync(P_0, "pm list packages", P_1);
		array = A;
		foreach (string text4 in array)
		{
			if (text3.Contains(text4, StringComparison.OrdinalIgnoreCase))
			{
				return text4;
			}
		}
		return A[0];
	}

	private static async Task m_6550(string P_0, (int ScreenWidth, int ScreenHeight) screenSize, Action<string> P_2, CancellationToken P_3)
	{
		for (int i = 0; i < 10 && !P_3.IsCancellationRequested; i++)
		{
			List<UiElement> list = await AdbController.DumpUiElementsAsync(P_0, P_3);
			if (list.Count == 0)
			{
				await Task.Delay(1000, P_3);
				continue;
			}
			UiElement uiElement = list.FirstOrDefault((UiElement uiElement7) => uiElement7.Text.Contains("Agree and continue", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Đồng ý", StringComparison.OrdinalIgnoreCase) || uiElement7.ResourceId.Contains("ezl"));
			if (uiElement != null)
			{
				P_2("Chấp thuận điều khoản dịch vụ (Agree and continue)...");
				await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_3);
				await Task.Delay(2000, P_3);
				continue;
			}
			UiElement uiElement2 = list.FirstOrDefault((UiElement uiElement7) => uiElement7.ResourceId.Contains("permission_allow_button") || string.Equals(uiElement7.Text, "ALLOW", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Cho phép", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "While using the app", StringComparison.OrdinalIgnoreCase));
			if (uiElement2 != null)
			{
				P_2("Cấp quyền hệ thống (Allow)...");
				await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_3);
				await Task.Delay(1500, P_3);
				continue;
			}
			UiElement uiElement3 = list.FirstOrDefault((UiElement uiElement7) => string.Equals(uiElement7.Text, "Skip", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase) || uiElement7.ResourceId.Contains("d28") || uiElement7.ResourceId.Contains("skip"));
			if (uiElement3 != null)
			{
				P_2("Bỏ qua chọn sở thích (Skip)...");
				await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_3);
				await Task.Delay(2000, P_3);
				continue;
			}
			if (list.Any((UiElement uiElement7) => uiElement7.Text.Contains("Choose what you like", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Choose your interests", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("bạn thích", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("sở thích", StringComparison.OrdinalIgnoreCase)))
			{
				P_2("Bỏ qua chọn sở thích (toạ độ Skip)...");
				int x = (int)((double)screenSize.ScreenWidth * 0.27);
				int y = (int)((double)screenSize.ScreenHeight * 0.93);
				await AdbController.TapAsync(P_0, x, y, P_3);
				await Task.Delay(2000, P_3);
				continue;
			}
			if (list.FirstOrDefault((UiElement uiElement7) => uiElement7.Text.Contains("Update TikTok", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Update available", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Cập nhật TikTok", StringComparison.OrdinalIgnoreCase)) != null)
			{
				UiElement uiElement4 = list.FirstOrDefault((UiElement uiElement7) => string.Equals(uiElement7.Text, "Not now", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Later", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Cancel", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Để sau", StringComparison.OrdinalIgnoreCase));
				if (uiElement4 != null)
				{
					P_2("Bỏ qua cập nhật TikTok (Not now)...");
					await AdbController.TapAsync(P_0, uiElement4.CenterX, uiElement4.CenterY, P_3);
					await Task.Delay(1500, P_3);
					continue;
				}
			}
			if (list.FirstOrDefault((UiElement uiElement7) => uiElement7.Text.Contains("Sync contacts", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Find contacts", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Connect with friends", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Đồng bộ danh bạ", StringComparison.OrdinalIgnoreCase)) != null)
			{
				UiElement uiElement5 = list.FirstOrDefault((UiElement uiElement7) => string.Equals(uiElement7.Text, "Don't allow", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Not now", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Skip", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Không cho phép", StringComparison.OrdinalIgnoreCase));
				if (uiElement5 != null)
				{
					P_2("Bỏ qua đồng bộ danh bạ...");
					await AdbController.TapAsync(P_0, uiElement5.CenterX, uiElement5.CenterY, P_3);
					await Task.Delay(1500, P_3);
					continue;
				}
			}
			if (list.FirstOrDefault((UiElement uiElement7) => uiElement7.Text.Contains("precise location", StringComparison.OrdinalIgnoreCase) || uiElement7.ResourceId.Contains("location_permission")) != null)
			{
				UiElement uiElement6 = list.FirstOrDefault((UiElement uiElement7) => string.Equals(uiElement7.Text, "Allow", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement7.Text, "Cho phép", StringComparison.OrdinalIgnoreCase));
				if (uiElement6 != null)
				{
					P_2("Chấp thuận quyền vị trí (Allow)...");
					await AdbController.TapAsync(P_0, uiElement6.CenterX, uiElement6.CenterY, P_3);
					await Task.Delay(1500, P_3);
					continue;
				}
			}
			if (list.Any((UiElement uiElement7) => uiElement7.Text.Contains("Swipe up for more", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Swipe up to start watching", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Swipe up", StringComparison.OrdinalIgnoreCase) || uiElement7.Text.Contains("Vuốt lên", StringComparison.OrdinalIgnoreCase)))
			{
				P_2("Vuốt qua hướng dẫn (Swipe up to start watching)...");
				await AdbController.SwipeAsync(P_0, screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.7), screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.25), 300, P_3);
				await Task.Delay(1500, P_3);
				continue;
			}
			if (list.Any((UiElement uiElement7) => uiElement7.ContentDesc == "Home" || uiElement7.ContentDesc == "Profile" || uiElement7.Text == "Home" || uiElement7.Text == "Profile" || uiElement7.Text == "Hồ sơ" || uiElement7.ContentDesc.Contains("Use phone") || uiElement7.Text.Contains("Log in to TikTok")))
			{
				break;
			}
			await Task.Delay(1000, P_3);
		}
	}

	private static async Task<bool> a(string P_0, (int ScreenWidth, int ScreenHeight) screenSize, Action<string> P_2, CancellationToken P_3)
	{
		for (int i = 0; i < 6; i++)
		{
			string text = await AdbController.RunShellCaptureAsync(P_0, "dumpsys window | grep mCurrentFocus", P_3);
			if (text.Contains("SignUpOrLoginActivity"))
			{
				return true;
			}
			List<UiElement> source = await AdbController.DumpUiElementsAsync(P_0, P_3);
			if (source.Any((UiElement uiElement5) => uiElement5.Text.Contains("Choose what you like", StringComparison.OrdinalIgnoreCase) || uiElement5.Text.Contains("Choose your interests", StringComparison.OrdinalIgnoreCase)))
			{
				UiElement uiElement = source.FirstOrDefault((UiElement uiElement5) => string.Equals(uiElement5.Text, "Skip", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement5.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase) || uiElement5.ResourceId.Contains("d28"));
				if (uiElement != null)
				{
					await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_3);
				}
				else
				{
					int x = (int)((double)screenSize.ScreenWidth * 0.27);
					int y = (int)((double)screenSize.ScreenHeight * 0.93);
					await AdbController.TapAsync(P_0, x, y, P_3);
				}
				await Task.Delay(2000, P_3);
				continue;
			}
			if (source.Any((UiElement uiElement5) => uiElement5.Text.Contains("Swipe up", StringComparison.OrdinalIgnoreCase) || uiElement5.Text.Contains("Vuốt lên", StringComparison.OrdinalIgnoreCase)))
			{
				await AdbController.SwipeAsync(P_0, screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.7), screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.25), 300, P_3);
				await Task.Delay(1500, P_3);
				continue;
			}
			UiElement uiElement2 = source.FirstOrDefault((UiElement uiElement5) => uiElement5.ContentDesc.Contains("Use phone / email / username", StringComparison.OrdinalIgnoreCase) || uiElement5.Text.Contains("Use phone / email / username", StringComparison.OrdinalIgnoreCase) || uiElement5.ContentDesc.Contains("Use phone", StringComparison.OrdinalIgnoreCase) || uiElement5.Text.Contains("Use phone", StringComparison.OrdinalIgnoreCase) || uiElement5.ContentDesc.Contains("Sử dụng số điện thoại", StringComparison.OrdinalIgnoreCase) || uiElement5.Text.Contains("Sử dụng số điện thoại", StringComparison.OrdinalIgnoreCase));
			if (uiElement2 != null)
			{
				await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_3);
				await Task.Delay(2000, P_3);
				return true;
			}
			if (text.Contains("I18nSignUpActivity"))
			{
				int x2 = (int)((double)screenSize.ScreenWidth * 0.5);
				int y2 = (int)((double)screenSize.ScreenHeight * 0.36);
				await AdbController.TapAsync(P_0, x2, y2, P_3);
				await Task.Delay(2000, P_3);
				return true;
			}
			UiElement uiElement3 = source.FirstOrDefault((UiElement uiElement5) => uiElement5.Text.Contains("Log in", StringComparison.OrdinalIgnoreCase) && (uiElement5.Text.Contains("Already have", StringComparison.OrdinalIgnoreCase) || uiElement5.ContentDesc.Contains("Log in")));
			if (uiElement3 != null)
			{
				await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_3);
				await Task.Delay(1500, P_3);
				continue;
			}
			UiElement uiElement4 = source.FirstOrDefault((UiElement uiElement5) => string.Equals(uiElement5.ContentDesc, "Profile", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement5.Text, "Profile", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement5.ContentDesc, "Hồ sơ", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement5.Text, "Hồ sơ", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement5.ContentDesc, "Me", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement5.Text, "Me", StringComparison.OrdinalIgnoreCase) || uiElement5.ResourceId.Contains("oly"));
			if (uiElement4 != null)
			{
				await AdbController.TapAsync(P_0, uiElement4.CenterX, uiElement4.CenterY, P_3);
			}
			else
			{
				int x3 = (int)((double)screenSize.ScreenWidth * 0.9);
				int y3 = (int)((double)screenSize.ScreenHeight * 0.97);
				await AdbController.TapAsync(P_0, x3, y3, P_3);
			}
			await Task.Delay(2500, P_3);
		}
		return false;
	}

	private static async Task m_6551(string P_0, (int ScreenWidth, int ScreenHeight) screenSize, CancellationToken P_2)
	{
		UiElement uiElement = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement2) => uiElement2.Text.Contains("Email", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Email", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Contains("Username", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Username", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase) || uiElement2.ContentDesc.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase));
		if (uiElement != null)
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
			return;
		}
		int x = (int)((double)screenSize.ScreenWidth * 0.73);
		int y = (int)((double)screenSize.ScreenHeight * 0.12);
		await AdbController.TapAsync(P_0, x, y, P_2);
	}

	private static async Task<bool> m_6552(string P_0, string P_1, (int ScreenWidth, int ScreenHeight) screenSize, CancellationToken P_3)
	{
		for (int i = 0; i < 5; i++)
		{
			UiElement uiElement = (await AdbController.DumpUiElementsAsync(P_0, P_3)).FirstOrDefault((UiElement uiElement2) => uiElement2.ClassName.Contains("EditText") || uiElement2.Text.Contains("Email", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Contains("username", StringComparison.OrdinalIgnoreCase) || uiElement2.Text.Contains("tên người dùng", StringComparison.OrdinalIgnoreCase) || uiElement2.Focused);
			if (uiElement != null)
			{
				int centerX = uiElement.CenterX;
				int centerY = uiElement.CenterY;
				await AdbController.TapAsync(P_0, centerX, centerY, P_3);
				await Task.Delay(500, P_3);
				await AdbController.ClearTextAsync(P_0, 60, P_3);
				await AdbController.InputTextAsync(P_0, P_1, P_3);
				await Task.Delay(800, P_3);
				return true;
			}
			await Task.Delay(1000, P_3);
		}
		return false;
	}

	private static async Task<bool> a(string P_0, string P_1, (int ScreenWidth, int ScreenHeight) screenSize, CancellationToken P_3)
	{
		for (int i = 0; i < 12; i++)
		{
			List<UiElement> A = await AdbController.DumpUiElementsAsync(P_0, P_3);
			bool flag = A.Any((UiElement uiElement3) => uiElement3.Text.Contains("Email or username", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("Email / Tên người dùng", StringComparison.OrdinalIgnoreCase) || (uiElement3.Text.Contains("Phone", StringComparison.OrdinalIgnoreCase) && A.Any((UiElement uiElement4) => uiElement4.Text.Contains("Email", StringComparison.OrdinalIgnoreCase))) || (uiElement3.Text.Contains("Số điện thoại", StringComparison.OrdinalIgnoreCase) && A.Any((UiElement uiElement4) => uiElement4.Text.Contains("Tên người dùng", StringComparison.OrdinalIgnoreCase))));
			if (A.Any((UiElement uiElement3) => uiElement3.ResourceId.Contains("f77") || uiElement3.ResourceId.Contains("f78") || uiElement3.ResourceId.Contains("dxn") || uiElement3.Text.Contains("Enter password", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("Nhập mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Show password", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Hide password", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Hiển thị mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Ẩn mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Contains("Show password", StringComparison.OrdinalIgnoreCase) || (uiElement3.ClassName.Contains("EditText") && (uiElement3.Text.Equals("Password", StringComparison.OrdinalIgnoreCase) || uiElement3.Text.Equals("Mật khẩu", StringComparison.OrdinalIgnoreCase) || uiElement3.ContentDesc.Contains("Password", StringComparison.OrdinalIgnoreCase)))) && !flag)
			{
				UiElement? uiElement = A.FirstOrDefault((UiElement uiElement3) => uiElement3.ResourceId.Contains("f78") || (uiElement3.ClassName.Contains("EditText") && !uiElement3.Text.Contains("Enter password", StringComparison.OrdinalIgnoreCase) && !uiElement3.Text.Contains("Nhập mật khẩu", StringComparison.OrdinalIgnoreCase)) || string.Equals(uiElement3.Text, "Password", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement3.Text, "Mật khẩu", StringComparison.OrdinalIgnoreCase));
				int x = uiElement?.CenterX ?? ((int)((double)screenSize.ScreenWidth * 0.47));
				int y = uiElement?.CenterY ?? ((int)((double)screenSize.ScreenHeight * 0.25));
				await AdbController.TapAsync(P_0, x, y, P_3);
				await Task.Delay(500, P_3);
				await AdbController.ClearTextAsync(P_0, 60, P_3);
				await AdbController.InputTextAsync(P_0, P_1, P_3);
				await Task.Delay(800, P_3);
				return true;
			}
			if (flag && i >= 2)
			{
				await AdbController.HideKeyboardIfShownAsync(P_0, P_3);
				await Task.Delay(300, P_3);
				UiElement uiElement2 = A.FirstOrDefault((UiElement uiElement3) => uiElement3.ResourceId.Contains("fmf") || uiElement3.ResourceId.Contains("e_7") || string.Equals(uiElement3.Text, "Continue", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement3.Text, "Tiếp tục", StringComparison.OrdinalIgnoreCase));
				if (uiElement2 == null)
				{
					await AdbController.RunShellAsync(P_0, "input keyevent 66", P_3);
				}
				else
				{
					await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_3);
				}
			}
			if (!string.IsNullOrEmpty(m_6554(A)))
			{
				return false;
			}
			await Task.Delay(1000, P_3);
		}
		return false;
	}

	private static async Task a(string P_0, (int ScreenWidth, int ScreenHeight) screenSize, CancellationToken P_2)
	{
		await AdbController.HideKeyboardIfShownAsync(P_0, P_2);
		await Task.Delay(400, P_2);
		UiElement uiElement = (await AdbController.DumpUiElementsAsync(P_0, P_2)).FirstOrDefault((UiElement uiElement2) => uiElement2.ResourceId.Contains("fmf") || uiElement2.ResourceId.Contains("e_7") || string.Equals(uiElement2.Text, "Continue", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement2.Text, "Tiếp tục", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement2.Text, "Log in", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement2.Text, "Đăng nhập", StringComparison.OrdinalIgnoreCase));
		if (uiElement != null)
		{
			await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_2);
			return;
		}
		int x = (int)((double)screenSize.ScreenWidth * 0.5);
		int y = (int)((double)screenSize.ScreenHeight * 0.93);
		await AdbController.TapAsync(P_0, x, y, P_2);
	}

	private static async Task<LoginResult> m_6553(string P_0, string P_1, string? twoFA, (int ScreenWidth, int ScreenHeight) screenSize, Action<string> P_4, CancellationToken P_5)
	{
		for (int i = 0; i < 15; i++)
		{
			await Task.Delay(2000, P_5);
			List<UiElement> list = await AdbController.DumpUiElementsAsync(P_0, P_5);
			if (list.Count == 0)
			{
				string text = await AdbController.GetCurrentFocusedActivityAsync(P_0, P_5);
				if ((text.Contains("SplashActivity") || text.Contains("MainActivity")) && !text.Contains("SignUpOrLoginActivity") && !text.Contains("I18nSignUpActivity"))
				{
					P_4("Phát hiện màn hình chính, đang chuyển sang Profile để xác nhận tài khoản...");
					int x = (int)((double)screenSize.ScreenWidth * 0.9);
					int y = (int)((double)screenSize.ScreenHeight * 0.97);
					await AdbController.TapAsync(P_0, x, y, P_5);
					await Task.Delay(2000, P_5);
					var (flag, text2, text3) = await a(P_0, P_5);
					if (flag)
					{
						string text4;
						if (string.IsNullOrWhiteSpace(text2))
						{
							text4 = ((!string.IsNullOrWhiteSpace(text3)) ? text3 : P_1);
						}
						else
						{
							text4 = text2;
						}
						return new LoginResult
						{
							Success = true,
							TinhTrang = "LIVE",
							TrangThai = "Đăng nhập TikTok thành công (" + text4 + ")"
						};
					}
				}
				continue;
			}
			if (list.FirstOrDefault((UiElement uiElement6) => uiElement6.Text.Contains("precise location", StringComparison.OrdinalIgnoreCase) || uiElement6.ResourceId.Contains("location_permission") || uiElement6.ResourceId.Contains("permission_allow_button")) != null)
			{
				UiElement uiElement = list.FirstOrDefault((UiElement uiElement6) => string.Equals(uiElement6.Text, "Allow", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Cho phép", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "While using the app", StringComparison.OrdinalIgnoreCase));
				if (uiElement != null)
				{
					P_4("Chấp thuận quyền hệ thống sau đăng nhập (Allow)...");
					await AdbController.TapAsync(P_0, uiElement.CenterX, uiElement.CenterY, P_5);
					await Task.Delay(1500, P_5);
					continue;
				}
			}
			if (list.FirstOrDefault((UiElement uiElement6) => uiElement6.Text.Contains("Save login info", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Save your login info", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Lưu thông tin", StringComparison.OrdinalIgnoreCase)) != null)
			{
				UiElement uiElement2 = list.FirstOrDefault((UiElement uiElement6) => string.Equals(uiElement6.Text, "Save", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Lưu", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Not now", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Để sau", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "OK", StringComparison.OrdinalIgnoreCase));
				if (uiElement2 != null)
				{
					P_4("Đóng hộp thoại lưu đăng nhập...");
					await AdbController.TapAsync(P_0, uiElement2.CenterX, uiElement2.CenterY, P_5);
					await Task.Delay(1500, P_5);
					continue;
				}
			}
			if (list.FirstOrDefault((UiElement uiElement6) => uiElement6.Text.Contains("Sync contacts", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Find contacts", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Connect with friends", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Đồng bộ danh bạ", StringComparison.OrdinalIgnoreCase)) != null)
			{
				UiElement uiElement3 = list.FirstOrDefault((UiElement uiElement6) => string.Equals(uiElement6.Text, "Don't allow", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Not now", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Skip", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Bỏ qua", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Không cho phép", StringComparison.OrdinalIgnoreCase));
				if (uiElement3 != null)
				{
					P_4("Bỏ qua đồng bộ danh bạ...");
					await AdbController.TapAsync(P_0, uiElement3.CenterX, uiElement3.CenterY, P_5);
					await Task.Delay(1500, P_5);
					continue;
				}
			}
			if (list.Any((UiElement uiElement6) => uiElement6.Text.Contains("Swipe up for more", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Swipe up to start watching", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Swipe up", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Vuốt lên", StringComparison.OrdinalIgnoreCase)))
			{
				P_4("Vuốt qua hướng dẫn sau đăng nhập...");
				await AdbController.SwipeAsync(P_0, screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.7), screenSize.ScreenWidth / 2, (int)((double)screenSize.ScreenHeight * 0.25), 300, P_5);
				await Task.Delay(1500, P_5);
				continue;
			}
			string text5 = m_6554(list);
			if (!string.IsNullOrEmpty(text5))
			{
				string text6 = text5.ToLowerInvariant();
				if (text6.Contains("no internet") || text6.Contains("network is unreachable") || text6.Contains("network unavailable") || text6.Contains("network error") || text6.Contains("không có kết nối internet") || text6.Contains("mất kết nối"))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "NO_INTERNET",
						TrangThai = "Mạng thiết bị không có internet: " + text5
					};
				}
				if (text6.Contains("match") || text6.Contains("incorrect") || text6.Contains("wrong password") || text6.Contains("không khớp") || text6.Contains("không đúng") || text6.Contains("sai mật khẩu"))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "SAI_MK",
						TrangThai = "Sai tài khoản hoặc mật khẩu: " + text5
					};
				}
				if (text6.Contains("does not exist") || text6.Contains("not exist") || text6.Contains("couldn't find") || text6.Contains("không tồn tại") || text6.Contains("không tìm thấy tài khoản"))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "KHONG_TON_TAI",
						TrangThai = "Tài khoản không tồn tại: " + text5
					};
				}
				if (text6.Contains("too many attempts") || text6.Contains("maximum number of attempts") || text6.Contains("try again later") || text6.Contains("thử lại sau"))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "SPAM",
						TrangThai = "Bị giới hạn thử lại (Spam): " + text5
					};
				}
				if (text6.Contains("suspended") || text6.Contains("banned") || text6.Contains("đình chỉ") || text6.Contains("bị khóa"))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "DIE",
						TrangThai = "Tài khoản bị khóa: " + text5
					};
				}
				if (text6.Contains("reset password") || text6.Contains("đặt lại mật khẩu"))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "RESET_PASS",
						TrangThai = "Yêu cầu đặt lại mật khẩu: " + text5
					};
				}
				return new LoginResult
				{
					Success = false,
					TinhTrang = "ERROR",
					TrangThai = text5
				};
			}
			if (list.Any((UiElement uiElement6) => uiElement6.Text.Contains("6-digit code", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Two-step verification", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Xác minh 2 bước", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Enter code", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Nhập mã", StringComparison.OrdinalIgnoreCase)))
			{
				P_4("Phát hiện màn hình xác thực 2FA...");
				if (string.IsNullOrWhiteSpace(twoFA))
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "2FA",
						TrangThai = "Yêu cầu mã 2FA nhưng tài khoản chưa có 2FA key"
					};
				}
				string text7 = PlaywrightHumanHelpers.Get2fa(twoFA);
				if (string.IsNullOrEmpty(text7) || text7.Length != 6)
				{
					return new LoginResult
					{
						Success = false,
						TinhTrang = "2FA",
						TrangThai = "Mã 2FA tính toán không hợp lệ"
					};
				}
				P_4("Nhập mã 2FA: " + text7 + "...");
				UiElement uiElement4 = list.FirstOrDefault((UiElement uiElement6) => uiElement6.ClassName.Contains("EditText") || uiElement6.Focused);
				if (uiElement4 != null)
				{
					await AdbController.TapAsync(P_0, uiElement4.CenterX, uiElement4.CenterY, P_5);
					await Task.Delay(300, P_5);
				}
				await AdbController.InputTextAsync(P_0, text7, P_5);
				await Task.Delay(1000, P_5);
				await a(P_0, screenSize, P_5);
				await Task.Delay(3000, P_5);
				continue;
			}
			if (list.Any((UiElement uiElement6) => uiElement6.Text.Contains("Drag the slider", StringComparison.OrdinalIgnoreCase) || uiElement6.Text.Contains("Kéo thanh trượt", StringComparison.OrdinalIgnoreCase) || uiElement6.ClassName.Contains("lynx", StringComparison.OrdinalIgnoreCase) || uiElement6.ResourceId.Contains("captcha", StringComparison.OrdinalIgnoreCase)))
			{
				return new LoginResult
				{
					Success = false,
					TinhTrang = "CAPTCHA",
					TrangThai = "Gặp Captcha xác minh dạng kéo hình"
				};
			}
			var (flag2, text8, text9) = await a(P_0, P_5);
			if (flag2)
			{
				string text10;
				if (string.IsNullOrWhiteSpace(text8))
				{
					text10 = ((!string.IsNullOrWhiteSpace(text9)) ? text9 : P_1);
				}
				else
				{
					text10 = text8;
				}
				return new LoginResult
				{
					Success = true,
					TinhTrang = "LIVE",
					TrangThai = "Đăng nhập TikTok thành công (" + text10 + ")"
				};
			}
			bool flag3 = list.Any((UiElement uiElement6) => uiElement6.ContentDesc == "Home" || uiElement6.Text == "Home");
			bool flag4 = list.Any((UiElement uiElement6) => uiElement6.ContentDesc == "Profile" || uiElement6.Text == "Profile" || uiElement6.Text == "Hồ sơ");
			bool flag5 = list.Any((UiElement uiElement6) => uiElement6.Text.Contains("Log in to TikTok") || uiElement6.Text.Contains("Sign up") || uiElement6.Text.Contains("Use phone") || uiElement6.Text.Contains("Enter password") || uiElement6.Text.Contains("Nhập mật khẩu"));
			if ((flag3 | flag4) && !flag5)
			{
				P_4("Chuyển sang mục Profile để xác nhận tài khoản...");
				int x2 = (int)((double)screenSize.ScreenWidth * 0.9);
				int y2 = (int)((double)screenSize.ScreenHeight * 0.97);
				await AdbController.TapAsync(P_0, x2, y2, P_5);
				await Task.Delay(2000, P_5);
				var (flag6, text11, text12) = await a(P_0, P_5);
				if (flag6)
				{
					string text13;
					if (string.IsNullOrWhiteSpace(text11))
					{
						text13 = ((!string.IsNullOrWhiteSpace(text12)) ? text12 : P_1);
					}
					else
					{
						text13 = text11;
					}
					return new LoginResult
					{
						Success = true,
						TinhTrang = "LIVE",
						TrangThai = "Đăng nhập TikTok thành công (" + text13 + ")"
					};
				}
				return new LoginResult
				{
					Success = true,
					TinhTrang = "LIVE",
					TrangThai = "Đăng nhập TikTok thành công"
				};
			}
			if (i == 1 || i == 3)
			{
				UiElement uiElement5 = list.FirstOrDefault((UiElement uiElement6) => (uiElement6.ResourceId.Contains("fmf") || string.Equals(uiElement6.Text, "Continue", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement6.Text, "Log in", StringComparison.OrdinalIgnoreCase)) && uiElement6.Enabled);
				if (uiElement5 != null)
				{
					await AdbController.HideKeyboardIfShownAsync(P_0, P_5);
					await AdbController.TapAsync(P_0, uiElement5.CenterX, uiElement5.CenterY, P_5);
				}
			}
		}
		int x3 = (int)((double)screenSize.ScreenWidth * 0.9);
		int y3 = (int)((double)screenSize.ScreenHeight * 0.97);
		await AdbController.TapAsync(P_0, x3, y3, P_5);
		await Task.Delay(2000, P_5);
		var (flag7, text14, text15) = await a(P_0, P_5);
		if (flag7)
		{
			string text16;
			if (string.IsNullOrWhiteSpace(text14))
			{
				text16 = ((!string.IsNullOrWhiteSpace(text15)) ? text15 : P_1);
			}
			else
			{
				text16 = text14;
			}
			return new LoginResult
			{
				Success = true,
				TinhTrang = "LIVE",
				TrangThai = "Đăng nhập TikTok thành công (" + text16 + ")"
			};
		}
		return new LoginResult
		{
			Success = false,
			TinhTrang = "CHECK",
			TrangThai = "Đã gửi lệnh đăng nhập, cần kiểm tra lại trạng thái trên máy"
		};
	}

	private static string? m_6554(List<UiElement> P_0)
	{
		return P_0.FirstOrDefault((UiElement uiElement) => uiElement.ResourceId.Contains("ibz") || uiElement.ResourceId.Contains("error") || uiElement.ResourceId.Contains("toast") || uiElement.Text.Contains("match", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("exist", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("incorrect", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("không đúng", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("không tồn tại", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Too many attempts", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Maximum number of attempts", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Try again later", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("No internet", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Network is unreachable", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Network error", StringComparison.OrdinalIgnoreCase) || uiElement.Text.Contains("Something went wrong", StringComparison.OrdinalIgnoreCase))?.Text;
	}

	private static async Task<(bool LoggedIn, string? Handle, string? Name)> a(string P_0, CancellationToken P_1)
	{
		List<UiElement> A = await AdbController.DumpUiElementsAsync(P_0, P_1);
		if (A.Count == 0)
		{
			return (LoggedIn: false, Handle: null, Name: null);
		}
		if (A.Any((UiElement uiElement) => string.Equals(uiElement.Text, "Edit", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement.Text, "Edit profile", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement.Text, "Sửa hồ sơ", StringComparison.OrdinalIgnoreCase) || string.Equals(uiElement.Text, "Chỉnh sửa hồ sơ", StringComparison.OrdinalIgnoreCase) || uiElement.ContentDesc == "Profile menu" || uiElement.ResourceId.Contains("upload_work") || (A.Any((UiElement uiElement2) => uiElement2.Text == "Following") && A.Any((UiElement uiElement2) => uiElement2.Text == "Followers"))))
		{
			string item = A.FirstOrDefault((UiElement uiElement) => uiElement.Text.StartsWith("@"))?.Text;
			string item2 = A.FirstOrDefault((UiElement uiElement) => uiElement.ResourceId.Contains("t4g"))?.Text;
			return (LoggedIn: true, Handle: item, Name: item2);
		}
		return (LoggedIn: false, Handle: null, Name: null);
	}

	private static async Task<bool> B(string P_0, CancellationToken P_1)
	{
		return (await a(P_0, P_1)).Item1;
	}
}
