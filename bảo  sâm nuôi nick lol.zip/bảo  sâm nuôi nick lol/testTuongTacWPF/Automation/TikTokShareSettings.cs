using System;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace testTuongTacWPF.Automation;

public class TikTokShareSettings
{
	[CompilerGenerated]
	private int A = 3;

	[CompilerGenerated]
	private int a = 6;

	[CompilerGenerated]
	private int B = 4;

	[CompilerGenerated]
	private int b = 8;

	[CompilerGenerated]
	private string m_6302 = "Repost";

	public int MinCount
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public int MaxCount
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public int MinDelaySec
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public int MaxDelaySec
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string ShareType
	{
		[CompilerGenerated]
		get
		{
			return m_6302;
		}
		[CompilerGenerated]
		set
		{
			m_6302 = value;
		}
	}

	public int PickCount()
	{
		if (MinCount < MaxCount)
		{
			return Random.Shared.Next(MinCount, MaxCount + 1);
		}
		return MinCount;
	}

	public int PickDelaySec()
	{
		if (MinDelaySec < MaxDelaySec)
		{
			return Random.Shared.Next(MinDelaySec, MaxDelaySec + 1);
		}
		return MinDelaySec;
	}

	public string ToJson()
	{
		return JsonSerializer.Serialize(this);
	}

	public static TikTokShareSettings FromJson(string? json)
	{
		if (string.IsNullOrWhiteSpace(json))
		{
			return new TikTokShareSettings();
		}
		try
		{
			return JsonSerializer.Deserialize<TikTokShareSettings>(json) ?? new TikTokShareSettings();
		}
		catch
		{
			return new TikTokShareSettings();
		}
	}
}
