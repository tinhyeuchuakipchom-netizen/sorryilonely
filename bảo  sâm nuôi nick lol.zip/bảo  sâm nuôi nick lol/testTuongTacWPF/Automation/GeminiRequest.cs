using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class GeminiRequest
{
	[CompilerGenerated]
	private object[] A = Array.Empty<object>();

	[JsonPropertyName("contents")]
	public object[] Contents
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}
}
