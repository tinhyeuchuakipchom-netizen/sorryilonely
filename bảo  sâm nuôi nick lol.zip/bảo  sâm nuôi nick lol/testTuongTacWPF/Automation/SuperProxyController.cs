using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace testTuongTacWPF.Automation;

public static class SuperProxyController
{
	public class ProxyConfig
	{
		[CompilerGenerated]
		private string A = "HTTP";

		[CompilerGenerated]
		private string a = "";

		[CompilerGenerated]
		private int m_6137 = 8080;

		[CompilerGenerated]
		private string B = "";

		[CompilerGenerated]
		private string b = "";

		public string Protocol
		{
			[CompilerGenerated]
			get
			{
				return A;
			}
			[CompilerGenerated]
			set
			{
				A = value;
			}
		}

		public string Host
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public int Port
		{
			[CompilerGenerated]
			get
			{
				return m_6137;
			}
			[CompilerGenerated]
			set
			{
				m_6137 = value;
			}
		}

		public string Username
		{
			[CompilerGenerated]
			get
			{
				return B;
			}
			[CompilerGenerated]
			set
			{
				B = value;
			}
		}

		public string Password
		{
			[CompilerGenerated]
			get
			{
				return b;
			}
			[CompilerGenerated]
			set
			{
				b = value;
			}
		}

		public static ProxyConfig Parse(string raw)
		{
			ProxyConfig proxyConfig = new ProxyConfig();
			if (string.IsNullOrWhiteSpace(raw))
			{
				return proxyConfig;
			}
			string text = raw.Trim();
			if (text.StartsWith("socks5://", StringComparison.OrdinalIgnoreCase))
			{
				proxyConfig.Protocol = "SOCKS5";
				text = text.Substring(9);
			}
			else if (text.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
			{
				proxyConfig.Protocol = "HTTP";
				text = text.Substring(7);
			}
			else if (text.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
			{
				proxyConfig.Protocol = "HTTP";
				text = text.Substring(8);
			}
			if (text.Contains("@"))
			{
				string[] array = text.Split('@', 2);
				string text2 = array[0];
				string obj = array[1];
				string[] array2 = text2.Split(':', 2);
				proxyConfig.Username = array2[0];
				if (array2.Length > 1)
				{
					proxyConfig.Password = array2[1];
				}
				string[] array3 = obj.Split(':', 2);
				proxyConfig.Host = array3[0];
				if (array3.Length > 1 && int.TryParse(array3[1], out var result))
				{
					proxyConfig.Port = result;
				}
				return proxyConfig;
			}
			string[] array4 = text.Split(':', StringSplitOptions.TrimEntries);
			if (array4.Length >= 2)
			{
				proxyConfig.Host = array4[0];
				if (int.TryParse(array4[1], out var result2))
				{
					proxyConfig.Port = result2;
				}
				if (array4.Length >= 4)
				{
					proxyConfig.Username = array4[2];
					proxyConfig.Password = array4[3];
				}
			}
			else
			{
				proxyConfig.Host = text;
			}
			return proxyConfig;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class a
	{
		public static readonly a A = new a();

		public static Func<UiElement, bool> m_6138;

		public static Func<UiElement, bool> m_6139;

		public static Func<UiElement, bool> B;

		public static Func<UiElement, bool> b;

		internal bool m_6140(UiElement P_0)
		{
			return P_0.ContentDesc.Contains("Add proxy", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_6141(UiElement P_0)
		{
			return P_0.ContentDesc.Equals("SOCKS5", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_6142(UiElement P_0)
		{
			return P_0.ContentDesc.Equals("Start", StringComparison.OrdinalIgnoreCase);
		}

		internal bool m_6143(UiElement P_0)
		{
			if (!P_0.ResourceId.Contains("button1"))
			{
				return P_0.Text.Equals("OK", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	public const string PackageName = "com.scheler.superproxy";

	public const string MainActivity = "com.scheler.superproxy/.activity.MainActivity";

	public static async Task<bool> SetupAndStartProxyAsync(string deviceSerial, string proxyRaw, Action<string>? logCallback = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		ProxyConfig proxyConfig = ProxyConfig.Parse(proxyRaw);
		if (string.IsNullOrWhiteSpace(proxyConfig.Host) || proxyConfig.Port <= 0)
		{
			logCallback?.Invoke("Địa chỉ Proxy không hợp lệ.");
			return false;
		}
		logCallback?.Invoke($"[SuperProxy] Đang cài đặt proxy {proxyConfig.Protocol} {proxyConfig.Host}:{proxyConfig.Port} trên máy {deviceSerial}...");
		try
		{
			await AdbController.RunShellAsync(deviceSerial, "pm clear com.scheler.superproxy", cancellationToken);
			await Task.Delay(500, cancellationToken);
			await AdbController.RunShellAsync(deviceSerial, "am start -n com.scheler.superproxy/.activity.MainActivity", cancellationToken);
			await Task.Delay(1800, cancellationToken);
			(int, int) tuple = await AdbController.GetScreenSizeAsync(deviceSerial, cancellationToken);
			int item = tuple.Item1;
			int item2 = tuple.Item2;
			double num = (double)item / 900.0;
			double num2 = (double)item2 / 1600.0;
			UiElement uiElement = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Contains("Add proxy", StringComparison.OrdinalIgnoreCase));
			if (uiElement == null)
			{
				await AdbController.TapAsync(deviceSerial, (int)(737.0 * num), (int)(1292.0 * num2), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, (uiElement.Left + uiElement.Right) / 2, (uiElement.Top + uiElement.Bottom) / 2, cancellationToken);
			}
			await Task.Delay(1200, cancellationToken);
			if (proxyConfig.Protocol.Equals("SOCKS5", StringComparison.OrdinalIgnoreCase))
			{
				await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(432.0 * num2), cancellationToken);
				await Task.Delay(600, cancellationToken);
				UiElement uiElement2 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("SOCKS5", StringComparison.OrdinalIgnoreCase));
				if (uiElement2 == null)
				{
					await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(656.0 * num2), cancellationToken);
				}
				else
				{
					await AdbController.TapAsync(deviceSerial, (uiElement2.Left + uiElement2.Right) / 2, (uiElement2.Top + uiElement2.Bottom) / 2, cancellationToken);
				}
				await Task.Delay(600, cancellationToken);
			}
			await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(592.0 * num2), cancellationToken);
			await Task.Delay(300, cancellationToken);
			await AdbController.InputTextAsync(deviceSerial, proxyConfig.Host, cancellationToken);
			await Task.Delay(300, cancellationToken);
			await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(752.0 * num2), cancellationToken);
			await Task.Delay(300, cancellationToken);
			await AdbController.InputTextAsync(deviceSerial, proxyConfig.Port.ToString(), cancellationToken);
			await Task.Delay(300, cancellationToken);
			if (!string.IsNullOrEmpty(proxyConfig.Username))
			{
				await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(912.0 * num2), cancellationToken);
				await Task.Delay(300, cancellationToken);
				await AdbController.InputTextAsync(deviceSerial, proxyConfig.Username, cancellationToken);
				await Task.Delay(300, cancellationToken);
				if (!string.IsNullOrEmpty(proxyConfig.Password))
				{
					await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(1072.0 * num2), cancellationToken);
					await Task.Delay(300, cancellationToken);
					await AdbController.InputTextAsync(deviceSerial, proxyConfig.Password, cancellationToken);
					await Task.Delay(300, cancellationToken);
				}
			}
			await AdbController.TapAsync(deviceSerial, (int)(852.0 * num), (int)(104.0 * num2), cancellationToken);
			await Task.Delay(1200, cancellationToken);
			UiElement uiElement3 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ContentDesc.Equals("Start", StringComparison.OrdinalIgnoreCase));
			if (uiElement3 == null)
			{
				await AdbController.TapAsync(deviceSerial, (int)(450.0 * num), (int)(1298.0 * num2), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, (uiElement3.Left + uiElement3.Right) / 2, (uiElement3.Top + uiElement3.Bottom) / 2, cancellationToken);
			}
			await Task.Delay(1500, cancellationToken);
			UiElement uiElement4 = (await AdbController.DumpUiElementsAsync(deviceSerial, cancellationToken)).FirstOrDefault((UiElement P_0) => P_0.ResourceId.Contains("button1") || P_0.Text.Equals("OK", StringComparison.OrdinalIgnoreCase));
			if (uiElement4 == null)
			{
				await AdbController.TapAsync(deviceSerial, (int)(757.0 * num), (int)(1044.0 * num2), cancellationToken);
			}
			else
			{
				await AdbController.TapAsync(deviceSerial, (uiElement4.Left + uiElement4.Right) / 2, (uiElement4.Top + uiElement4.Bottom) / 2, cancellationToken);
				await Task.Delay(1200, cancellationToken);
			}
			await AdbController.RunShellAsync(deviceSerial, "input keyevent 3", cancellationToken);
			await Task.Delay(500, cancellationToken);
			logCallback?.Invoke($"[SuperProxy] ✓ Đã kết nối proxy {proxyConfig.Host}:{proxyConfig.Port} thành công trên máy {deviceSerial}.");
			return true;
		}
		catch (Exception ex)
		{
			logCallback?.Invoke("[SuperProxy] ✗ Lỗi thiết lập proxy trên máy " + deviceSerial + ": " + ex.Message);
			return false;
		}
	}

	public static async Task StopProxyAsync(string deviceSerial, Action<string>? logCallback = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		_ = 4;
		try
		{
			logCallback?.Invoke("[SuperProxy] Đang ngắt kết nối & reset sạch proxy trên máy " + deviceSerial + "...");
			try
			{
				await AdbController.RunShellAsync(deviceSerial, "am broadcast -a com.scheler.superproxy.STOP_PROXY", cancellationToken);
			}
			catch
			{
			}
			try
			{
				await AdbController.RunShellAsync(deviceSerial, "am force-stop com.scheler.superproxy", cancellationToken);
			}
			catch
			{
			}
			try
			{
				await AdbController.RunShellAsync(deviceSerial, "pm clear com.scheler.superproxy", cancellationToken);
			}
			catch
			{
			}
			try
			{
				await AdbController.RunShellAsync(deviceSerial, "input keyevent 3", cancellationToken);
			}
			catch
			{
			}
			await Task.Delay(400, cancellationToken);
			logCallback?.Invoke("[SuperProxy] ✓ Đã ngắt proxy & thoát app Super Proxy trên máy " + deviceSerial + ".");
		}
		catch (Exception ex)
		{
			logCallback?.Invoke("[SuperProxy] Lỗi ngắt proxy: " + ex.Message);
		}
	}
}
