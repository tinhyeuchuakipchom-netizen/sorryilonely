using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class OpenAiChatRequest
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private object[] m_2891 = Array.Empty<object>();

	[CompilerGenerated]
	private int m_2892;

	[CompilerGenerated]
	private bool m_2893;

	[JsonPropertyName("model")]
	public string Model
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("messages")]
	public object[] Messages
	{
		[CompilerGenerated]
		get
		{
			return m_2891;
		}
		[CompilerGenerated]
		set
		{
			m_2891 = value;
		}
	}

	[JsonPropertyName("max_tokens")]
	public int MaxTokens
	{
		[CompilerGenerated]
		get
		{
			return m_2892;
		}
		[CompilerGenerated]
		set
		{
			m_2892 = value;
		}
	}

	[JsonPropertyName("stream")]
	public bool Stream
	{
		[CompilerGenerated]
		get
		{
			return m_2893;
		}
		[CompilerGenerated]
		set
		{
			m_2893 = value;
		}
	}
}
