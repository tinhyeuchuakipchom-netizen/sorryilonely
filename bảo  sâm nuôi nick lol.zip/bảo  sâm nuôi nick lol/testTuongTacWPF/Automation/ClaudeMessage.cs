using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace testTuongTacWPF.Automation;

public class ClaudeMessage
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private object[] m_2870 = Array.Empty<object>();

	[JsonPropertyName("role")]
	public string Role
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	[JsonPropertyName("content")]
	public object[] Content
	{
		[CompilerGenerated]
		get
		{
			return m_2870;
		}
		[CompilerGenerated]
		set
		{
			m_2870 = value;
		}
	}
}
