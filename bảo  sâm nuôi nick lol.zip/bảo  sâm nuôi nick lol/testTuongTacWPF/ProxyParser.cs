using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;

namespace testTuongTacWPF;

public static class ProxyParser
{
	private static readonly Regex A = new Regex("^(https?|socks5|socks4)://", RegexOptions.IgnoreCase);

	private static readonly Regex a = new Regex("^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9_-]*[a-zA-Z0-9])(\\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9_-]*[a-zA-Z0-9]))*$", RegexOptions.Compiled);

	public static ProxyParseResult Parse(string line)
	{
		string text = line.Trim();
		if (text.Length == 0)
		{
			return m_2116(text, "Dòng rỗng");
		}
		string scheme = null;
		string text2 = text;
		Match match = A.Match(text);
		if (match.Success)
		{
			scheme = match.Groups[1].Value.ToLowerInvariant();
			text2 = text.Substring(match.Length);
		}
		ProxyParseResult proxyParseResult;
		if (text2.StartsWith("["))
		{
			proxyParseResult = b(text2);
		}
		else
		{
			proxyParseResult = ((!text2.Contains('@')) ? m_2113(text2) : m_2114(text2));
		}
		proxyParseResult.OriginalLine = text;
		proxyParseResult.Scheme = scheme;
		return proxyParseResult;
	}

	private static ProxyParseResult m_2113(string P_0)
	{
		string[] array = P_0.Split(':');
		if (array.Length != 2 && array.Length < 4)
		{
			return m_2116(P_0, "Sai cấu trúc - cần host:port hoặc host:port:user:pass");
		}
		string text = array[0].Trim();
		string text2 = array[1].Trim();
		string user = null;
		string pass = null;
		if (array.Length >= 4)
		{
			user = array[2];
			pass = ((array.Length == 4) ? array[3] : string.Join(":", array.Skip(3)));
		}
		return m_2115(P_0, text, text2, user, pass);
	}

	private static ProxyParseResult m_2114(string P_0)
	{
		string[] array = P_0.Split('@', 2);
		string text = array[0];
		string text2 = array[1];
		string pass = null;
		int num = text.IndexOf(':');
		string user;
		if (num >= 0)
		{
			user = text.Substring(0, num);
			pass = text.Substring(num + 1);
		}
		else
		{
			user = text;
		}
		if (text2.StartsWith('['))
		{
			ProxyParseResult proxyParseResult = b(text2);
			if (proxyParseResult.IsValid)
			{
				proxyParseResult.User = user;
				proxyParseResult.Pass = pass;
			}
			return proxyParseResult;
		}
		string[] array2 = text2.Split(':');
		if (array2.Length != 2)
		{
			return m_2116(P_0, "Sai cấu trúc host:port sau ký tự @");
		}
		string text3 = array2[0].Trim();
		string text4 = array2[1].Trim();
		return m_2115(P_0, text3, text4, user, pass);
	}

	private static ProxyParseResult m_2115(string P_0, string P_1, string P_2, string? user, string? pass)
	{
		if (string.IsNullOrWhiteSpace(P_1))
		{
			return m_2116(P_0, "Host/IP không được để trống");
		}
		ProxyKind kind;
		if (IPAddress.TryParse(P_1, out IPAddress address) && address.AddressFamily == AddressFamily.InterNetwork)
		{
			kind = ProxyKind.IPv4;
		}
		else
		{
			if (!B(P_1))
			{
				return m_2116(P_0, "\"" + P_1 + "\" không phải IPv4 hoặc tên miền hợp lệ");
			}
			kind = ProxyKind.Domain;
		}
		if (!C(P_2))
		{
			return m_2116(P_0, "\"" + P_2 + "\" không phải port hợp lệ (1-65535)");
		}
		return new ProxyParseResult
		{
			Kind = kind,
			Host = P_1,
			Port = P_2,
			User = user,
			Pass = pass
		};
	}

	private static bool B(string P_0)
	{
		if (string.IsNullOrWhiteSpace(P_0) || P_0.Length > 255)
		{
			return false;
		}
		if (Uri.CheckHostName(P_0) == UriHostNameType.Dns)
		{
			return true;
		}
		return a.IsMatch(P_0);
	}

	private static ProxyParseResult b(string P_0)
	{
		int num = P_0.IndexOf(']');
		if (num < 0)
		{
			return m_2116(P_0, "Thiếu dấu ] đóng địa chỉ IPv6");
		}
		string text = P_0.Substring(1, num - 1);
		string text2 = P_0.Substring(num + 1);
		if (!IPAddress.TryParse(text, out IPAddress address) || address.AddressFamily != AddressFamily.InterNetworkV6)
		{
			return m_2116(P_0, "\"" + text + "\" không phải IPv6 hợp lệ");
		}
		bool flag = text2.StartsWith("/");
		int result = 0;
		if (flag)
		{
			int num2 = text2.IndexOf(':');
			if (num2 < 0)
			{
				return m_2116(P_0, "Thiếu \":port\" sau dải IPv6");
			}
			if (!int.TryParse(text2.Substring(1, num2 - 1), out result) || result < 1 || result > 128)
			{
				return m_2116(P_0, "Prefix dải IPv6 phải trong khoảng /1 - /128 (vd [2001:db8::]/64)");
			}
			text2 = text2.Substring(num2);
		}
		if (!text2.StartsWith(":"))
		{
			return m_2116(P_0, "Thiếu \":port\" sau địa chỉ IPv6");
		}
		string[] array = text2.TrimStart(':').Split(':');
		if (array.Length != 1 && array.Length < 3)
		{
			return m_2116(P_0, "Sai cấu trúc - cần [ipv6]:port hoặc [ipv6]:port:user:pass");
		}
		if (!C(array[0]))
		{
			return m_2116(P_0, "\"" + array[0] + "\" không phải port hợp lệ (1-65535)");
		}
		string user = null;
		string pass = null;
		if (array.Length >= 3)
		{
			user = array[1];
			pass = ((array.Length == 3) ? array[2] : string.Join(":", array.Skip(2)));
		}
		return new ProxyParseResult
		{
			Kind = (flag ? ProxyKind.IPv6Range : ProxyKind.IPv6Single),
			Host = (flag ? $"[{text}]/{result}" : ("[" + text + "]")),
			Port = array[0],
			User = user,
			Pass = pass
		};
	}

	private static bool C(string P_0)
	{
		if (int.TryParse(P_0, out var result))
		{
			if (result > 0)
			{
				return result <= 65535;
			}
			return false;
		}
		return false;
	}

	private static ProxyParseResult m_2116(string P_0, string P_1)
	{
		return new ProxyParseResult
		{
			Kind = ProxyKind.Invalid,
			OriginalLine = P_0,
			Error = P_1
		};
	}
}
