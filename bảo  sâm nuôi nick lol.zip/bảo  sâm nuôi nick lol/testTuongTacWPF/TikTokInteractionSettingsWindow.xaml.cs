using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.Win32;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class TikTokInteractionSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private TikTokInteractionSettingsWindow(TikTokInteractionSettings P_0)
	{
		InitializeComponent();
		MinMinutesTextBox.Text = P_0.MinMinutes.ToString();
		MaxMinutesTextBox.Text = P_0.MaxMinutes.ToString();
		AutoLikeCheckBox.IsChecked = P_0.AutoLike;
		LikeChanceTextBox.Text = P_0.LikeChancePercent.ToString();
		AutoCommentCheckBox.IsChecked = P_0.AutoComment;
		CommentChanceTextBox.Text = P_0.CommentChancePercent.ToString();
		CommentTextsTextBox.Text = string.Join("\n", P_0.CommentTexts);
		AppendEmojiCheckBox.IsChecked = P_0.AppendEmoji;
		CommentEmojisTextBox.Text = string.Join("\n", P_0.CommentEmojis);
		CommentWithImageCheckBox.IsChecked = P_0.CommentWithImage;
		CommentImageFolderTextBox.Text = P_0.CommentImageFolder;
		AutoFollowCheckBox.IsChecked = P_0.AutoFollow;
		FollowChanceTextBox.Text = P_0.FollowChancePercent.ToString();
		AutoFavoriteCheckBox.IsChecked = P_0.AutoFavorite;
		FavoriteChanceTextBox.Text = P_0.FavoriteChancePercent.ToString();
		m_2195();
	}

	private void m_2192(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2193(object P_0, RoutedEventArgs P_1)
	{
		m_2195();
	}

	private void m_2194(object P_0, RoutedEventArgs P_1)
	{
		m_2195();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		m_2195();
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		m_2195();
	}

	private void C(object P_0, RoutedEventArgs P_1)
	{
		m_2195();
	}

	private void c(object P_0, RoutedEventArgs P_1)
	{
		m_2195();
	}

	private void D(object P_0, RoutedEventArgs P_1)
	{
		OpenFolderDialog openFolderDialog = new OpenFolderDialog
		{
			Title = "Chọn thư mục ảnh bình luận"
		};
		if (!string.IsNullOrWhiteSpace(CommentImageFolderTextBox.Text))
		{
			openFolderDialog.InitialDirectory = CommentImageFolderTextBox.Text;
		}
		if (openFolderDialog.ShowDialog(this) == true)
		{
			CommentImageFolderTextBox.Text = openFolderDialog.FolderName;
		}
	}

	private void m_2195()
	{
		if (LikeChancePanel != null)
		{
			LikeChancePanel.Visibility = ((AutoLikeCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			CommentOptionsPanel.Visibility = ((AutoCommentCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			EmojiOptionsPanel.Visibility = ((AppendEmojiCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			ImageOptionsPanel.Visibility = ((CommentWithImageCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			FollowChancePanel.Visibility = ((AutoFollowCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			FavoriteChancePanel.Visibility = ((AutoFavoriteCheckBox.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void d(object P_0, RoutedEventArgs P_1)
	{
		if (!m_2196(out TikTokInteractionSettings _, out string text))
		{
			ErrorText.Text = text;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void E(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private bool m_2196(out TikTokInteractionSettings P_0, out string P_1)
	{
		P_0 = new TikTokInteractionSettings();
		P_1 = "";
		if (!int.TryParse(MinMinutesTextBox.Text.Trim(), out var result) || result < 1)
		{
			P_1 = "\"Từ\" (phút) phải là 1 số nguyên dương.";
			return false;
		}
		if (!int.TryParse(MaxMinutesTextBox.Text.Trim(), out var result2) || result2 < result)
		{
			P_1 = "\"Đến\" (phút) phải là 1 số nguyên >= \"Từ\".";
			return false;
		}
		bool valueOrDefault = AutoLikeCheckBox.IsChecked == true;
		if (valueOrDefault && (!int.TryParse(LikeChanceTextBox.Text.Trim(), out var result3) || result3 < 0 || result3 > 100))
		{
			P_1 = "Tỉ lệ thả tim phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault2 = AutoCommentCheckBox.IsChecked == true;
		if (valueOrDefault2 && (!int.TryParse(CommentChanceTextBox.Text.Trim(), out var result4) || result4 < 0 || result4 > 100))
		{
			P_1 = "Tỉ lệ bình luận phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault3 = AutoFollowCheckBox.IsChecked == true;
		if (valueOrDefault3 && (!int.TryParse(FollowChanceTextBox.Text.Trim(), out var result5) || result5 < 0 || result5 > 100))
		{
			P_1 = "Tỉ lệ follow phải là 1 số từ 0 đến 100.";
			return false;
		}
		bool valueOrDefault4 = AutoFavoriteCheckBox.IsChecked == true;
		if (valueOrDefault4 && (!int.TryParse(FavoriteChanceTextBox.Text.Trim(), out var result6) || result6 < 0 || result6 > 100))
		{
			P_1 = "Tỉ lệ lưu / yêu thích phải là 1 số từ 0 đến 100.";
			return false;
		}
		P_0.MinMinutes = result;
		P_0.MaxMinutes = result2;
		P_0.AutoLike = valueOrDefault;
		P_0.LikeChancePercent = (valueOrDefault ? int.Parse(LikeChanceTextBox.Text.Trim()) : P_0.LikeChancePercent);
		P_0.AutoComment = valueOrDefault2;
		P_0.CommentChancePercent = (valueOrDefault2 ? int.Parse(CommentChanceTextBox.Text.Trim()) : P_0.CommentChancePercent);
		P_0.CommentTexts = CommentTextsTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		P_0.AppendEmoji = AppendEmojiCheckBox.IsChecked == true;
		P_0.CommentEmojis = CommentEmojisTextBox.Text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
		P_0.CommentWithImage = CommentWithImageCheckBox.IsChecked == true;
		P_0.CommentImageFolder = CommentImageFolderTextBox.Text.Trim();
		P_0.AutoFollow = valueOrDefault3;
		P_0.FollowChancePercent = (valueOrDefault3 ? int.Parse(FollowChanceTextBox.Text.Trim()) : P_0.FollowChancePercent);
		P_0.AutoFavorite = valueOrDefault4;
		P_0.FavoriteChancePercent = (valueOrDefault4 ? int.Parse(FavoriteChanceTextBox.Text.Trim()) : P_0.FavoriteChancePercent);
		return true;
	}

	public static TikTokInteractionSettings? Show(Window? owner, TikTokInteractionSettings initial)
	{
		TikTokInteractionSettingsWindow tikTokInteractionSettingsWindow = new TikTokInteractionSettingsWindow(initial);
		if (owner != null)
		{
			tikTokInteractionSettingsWindow.Owner = owner;
		}
		tikTokInteractionSettingsWindow.ShowDialog();
		if (!tikTokInteractionSettingsWindow.A)
		{
			return null;
		}
		tikTokInteractionSettingsWindow.m_2196(out TikTokInteractionSettings result, out string _);
		return result;
	}
}
