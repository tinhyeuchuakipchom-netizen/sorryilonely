using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class ImportFacebookWindow : Window, IComponentConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_412
	{
		public static readonly m_412 A = new m_412();

		public static Func<string, string> m_413;

		public static Func<string, bool> m_414;

		internal string m_415(string P_0)
		{
			return P_0.Trim(new char[2] { '\r', ' ' });
		}

		internal bool a(string P_0)
		{
			return P_0.Length > 0;
		}
	}

	[CompilerGenerated]
	private readonly List<FacebookAccountRow> A = new List<FacebookAccountRow>();

	private static readonly string[] m_398 = new string[10] { "Bỏ qua", "UID", "PASS", "MAIL", "PASS MAIL", "2FA", "TOKEN", "COOKIE", "PROXY", "GHI CHÚ" };

	private static readonly string[] a = new string[10] { "UID", "PASS", "MAIL", "PASS MAIL", "2FA", "TOKEN", "COOKIE", "Bỏ qua", "Bỏ qua", "Bỏ qua" };

	private readonly List<ComboBox> m_399 = new List<ComboBox>();

	private bool m_400;

	public List<FacebookAccountRow> ImportedAccounts
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
	}

	public ImportFacebookWindow()
	{
		InitializeComponent();
		m_401();
	}

	private void m_401()
	{
		for (int i = 0; i < a.Length; i++)
		{
			StackPanel stackPanel = new StackPanel
			{
				Orientation = Orientation.Vertical,
				Margin = new Thickness(0.0, 0.0, 10.0, 8.0)
			};
			stackPanel.Children.Add(new TextBlock
			{
				Text = $"Vị trí {i + 1}",
				FontSize = 11.0,
				Foreground = (Brush)FindResource("BrushTextSecondary"),
				Margin = new Thickness(2.0, 0.0, 0.0, 2.0)
			});
			ComboBox comboBox = new ComboBox
			{
				Width = 120.0,
				ItemsSource = m_398,
				SelectedItem = a[i]
			};
			comboBox.SelectionChanged += delegate
			{
				B();
			};
			stackPanel.Children.Add(comboBox);
			m_399.Add(comboBox);
			StructureSlotsPanel.Children.Add(stackPanel);
		}
	}

	private void m_402(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_403(object P_0, RoutedEventArgs P_1)
	{
		WindowState = WindowState.Minimized;
	}

	private void m_404(object P_0, RoutedEventArgs P_1)
	{
		if (StructurePanelBorder != null)
		{
			StructurePanelBorder.Visibility = ((StructureModeRadio.IsChecked != true) ? Visibility.Collapsed : Visibility.Visible);
			B();
		}
	}

	private List<string> m_405()
	{
		return (from P_0 in NickInputTextBox.Text.Split('\n')
			select P_0.Trim(new char[2] { '\r', ' ' }) into P_0
			where P_0.Length > 0
			select P_0).ToList();
	}

	private bool m_406(string P_0, out FacebookAccountRow P_1)
	{
		if (StructureModeRadio.IsChecked != true)
		{
			return B(P_0, out P_1);
		}
		return m_407(P_0, out P_1);
	}

	private bool m_407(string P_0, out FacebookAccountRow P_1)
	{
		P_1 = new FacebookAccountRow();
		string[] array = P_0.Split('|');
		for (int i = 0; i < array.Length && i < m_399.Count; i++)
		{
			string text = (m_399[i].SelectedItem as string) ?? "Bỏ qua";
			string text2 = array[i].Trim();
			switch (text)
			{
			case "UID":
				P_1.Uid = text2;
				break;
			case "PASS":
				P_1.Pass = text2;
				break;
			case "MAIL":
				P_1.Mail = text2;
				break;
			case "PASS MAIL":
				P_1.PassMail = text2;
				break;
			case "2FA":
				P_1.TwoFA = text2;
				break;
			case "TOKEN":
				P_1.Token = text2;
				break;
			case "COOKIE":
				P_1.Cookie = text2;
				break;
			case "PROXY":
				P_1.Proxy = text2;
				break;
			case "GHI CHÚ":
				P_1.GhiChu = text2;
				break;
			}
		}
		return !string.IsNullOrWhiteSpace(P_1.Uid);
	}

	private static string? m_408(string P_0)
	{
		Match match = Regex.Match(P_0, "c_user=(\\d+)");
		if (!match.Success)
		{
			return null;
		}
		return match.Groups[1].Value;
	}

	private bool B(string P_0, out FacebookAccountRow P_1)
	{
		P_1 = new FacebookAccountRow();
		string[] array = P_0.Split('|');
		string text = "";
		string pass = "";
		string token = "";
		string text2 = "";
		string mail = "";
		string passMail = "";
		string twoFA = "";
		string proxy = "";
		string ghiChu = "";
		try
		{
			string text3 = array[0].Trim();
			if (!text3.Contains("61") && (!text3.Contains("100") || text3.Contains("@")))
			{
				return false;
			}
			text = text3;
			if (array[1].Length <= 32)
			{
				pass = array[1];
			}
		}
		catch
		{
			return false;
		}
		bool flag = false;
		for (int i = 0; i < array.Length; i++)
		{
			string text4 = array[i].Trim().Replace(" ", "");
			if (text4.Length == 32 && !array[i].Contains("@") && !array[i].Contains(":") && !array[i].Contains("."))
			{
				twoFA = text4;
			}
			if (array[i].Contains("Trạng thái:"))
			{
				ghiChu = array[i];
			}
			if (array[i].Contains("datr="))
			{
				text2 = array[i];
				string text5 = m_408(text2);
				if (string.IsNullOrEmpty(text5))
				{
					flag = true;
					break;
				}
				text = text5;
			}
			if (array[i].Contains("EAA"))
			{
				if (array[i].Contains("Trạng thái: "))
				{
					string[] array2 = array[i].Split(':');
					token = ((array2.Length > 1) ? array2[1].Trim() : "");
				}
				else
				{
					token = array[i];
				}
			}
			try
			{
				string text6 = array[i];
				if (text6.Contains("@") && text6.Contains("."))
				{
					if (text6.Contains(":"))
					{
						mail = text6.Split(':')[1];
						passMail = ((array.Length > i + 1) ? array[i + 1].Split(':')[1] : "");
					}
					else
					{
						try
						{
							passMail = text6 + "|" + array[i + 1];
						}
						catch
						{
							passMail = array[i];
						}
						try
						{
							mail = array[i];
						}
						catch
						{
						}
						try
						{
							if (!array[i + 1].Contains(" "))
							{
								passMail = array[i + 1];
							}
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
			try
			{
				if (array[i].Contains(":"))
				{
					proxy = array[i];
				}
			}
			catch
			{
			}
		}
		if (flag)
		{
			return false;
		}
		P_1.Uid = text;
		P_1.Pass = pass;
		P_1.TwoFA = twoFA;
		P_1.Token = token;
		P_1.Cookie = text2;
		P_1.Mail = mail;
		P_1.PassMail = passMail;
		P_1.Proxy = proxy;
		P_1.GhiChu = ghiChu;
		return true;
	}

	private void m_409(object P_0, TextChangedEventArgs P_1)
	{
		B();
	}

	private void B()
	{
		if (TotalCountText == null)
		{
			return;
		}
		List<string> list = m_405();
		int num = 0;
		foreach (string item in list)
		{
			if (m_406(item, out FacebookAccountRow _))
			{
				num++;
			}
		}
		TotalCountText.Text = list.Count.ToString();
		SuccessCountText.Text = num.ToString();
		ErrorCountText.Text = (list.Count - num).ToString();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		ImportedAccounts.Clear();
		int num = 0;
		int num2 = 0;
		foreach (string item in m_405())
		{
			if (m_406(item, out FacebookAccountRow facebookAccountRow))
			{
				facebookAccountRow.TrangThai = "Chưa dùng";
				ImportedAccounts.Add(facebookAccountRow);
				num++;
			}
			else
			{
				num2++;
			}
		}
		CustomMessageBox.Show(this, $"Nhập thành công {num} nick, lỗi {num2} nick.", "Kết quả nhập nick", (num2 > 0) ? NotifyType.Warning : NotifyType.Success);
		DialogResult = true;
		Close();
	}

	[CompilerGenerated]
	private void m_411(object P_0, SelectionChangedEventArgs P_1)
	{
		B();
	}
}
