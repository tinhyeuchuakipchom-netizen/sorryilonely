using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Google.Apis.Sheets.v4;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Data;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class GoogleSheetsSyncWindow : Window, IComponentConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_368
	{
		public static readonly m_368 A = new m_368();

		public static Func<NickFolder, bool> m_373;

		public static Func<NickFolder, bool> a;

		internal bool m_374(NickFolder P_0)
		{
			return P_0.CanManage;
		}

		internal bool m_375(NickFolder P_0)
		{
			return P_0.CanManage;
		}
	}

	[CompilerGenerated]
	private sealed class m_369
	{
		public List<FacebookAccountRow> A;

		internal List<IList<object>> m_376(int P_0)
		{
			return GoogleSheetsSyncService.BuildRows(A.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.FolderId == P_0).ToList());
		}
	}

	[CompilerGenerated]
	private sealed class m_370
	{
		public int A;

		internal bool m_377(FacebookAccountRow P_0)
		{
			return P_0.FolderId == A;
		}
	}

	[CompilerGenerated]
	private sealed class m_371
	{
		public List<PlatformAccountRow> A;

		internal List<IList<object>> m_378(int P_0)
		{
			return GoogleSheetsSyncService.BuildRows(A.Where((PlatformAccountRow platformAccountRow) => platformAccountRow.FolderId == P_0).ToList());
		}
	}

	[CompilerGenerated]
	private sealed class m_372
	{
		public int A;

		internal bool m_379(PlatformAccountRow P_0)
		{
			return P_0.FolderId == A;
		}
	}

	private CancellationTokenSource? A;

	private readonly string m_359;

	private readonly string a;

	private bool m_360;

	public GoogleSheetsSyncWindow(string platformKey = "", string displayTitle = "Facebook")
	{
		InitializeComponent();
		m_359 = platformKey;
		a = displayTitle;
		Title = "Đồng bộ Google Trang tính - " + displayTitle;
		TitleText.Text = "Đồng bộ Google Trang tính - " + displayTitle;
		m_361();
	}

	private void m_361()
	{
		GoogleSheetsSyncSettings googleSheetsSyncSettings = GoogleSheetsSyncSettings.Load(m_359);
		EnabledCheck.IsChecked = googleSheetsSyncSettings.Enabled;
		ClientIdTextBox.Text = googleSheetsSyncSettings.ClientId;
		ClientSecretBox.Password = googleSheetsSyncSettings.ClientSecret;
		SpreadsheetTextBox.Text = googleSheetsSyncSettings.SpreadsheetId;
		m_362();
	}

	private void m_362()
	{
		bool isSignedIn = GoogleSheetsSyncService.IsSignedIn;
		SignInStatusText.Text = (isSignedIn ? "Đã đăng nhập Google." : "Chưa đăng nhập Google.");
		SignInButton.IsEnabled = !isSignedIn;
		SignOutButton.IsEnabled = isSignedIn;
	}

	private GoogleSheetsSyncSettings B()
	{
		return new GoogleSheetsSyncSettings
		{
			Enabled = (EnabledCheck.IsChecked == true),
			ClientId = ClientIdTextBox.Text.Trim(),
			ClientSecret = ClientSecretBox.Password.Trim(),
			SpreadsheetId = GoogleSheetsSyncService.ExtractSpreadsheetId(SpreadsheetTextBox.Text.Trim())
		};
	}

	private void m_363(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_364(object P_0, RoutedEventArgs P_1)
	{
		Close();
	}

	private void m_365(object P_0, RoutedEventArgs P_1)
	{
		B().Save(m_359);
		Close();
	}

	private async void B(object P_0, RoutedEventArgs P_1)
	{
		GoogleSheetsSyncSettings googleSheetsSyncSettings = B();
		if (string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientId) || string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientSecret))
		{
			m_366("Nhập Client ID và Client Secret trước khi đăng nhập.", true);
			return;
		}
		googleSheetsSyncSettings.Save(m_359);
		SignInButton.IsEnabled = false;
		m_366("Đang mở trình duyệt để đăng nhập Google...", false);
		A = new CancellationTokenSource();
		try
		{
			using (await GoogleSheetsSyncService.AuthorizeAsync(googleSheetsSyncSettings, A.Token))
			{
				m_366("Đăng nhập Google thành công.", false);
			}
		}
		catch (Exception ex)
		{
			m_366("Đăng nhập thất bại: " + ex.Message, true);
		}
		finally
		{
			A?.Dispose();
			A = null;
			m_362();
		}
	}

	private void b(object P_0, RoutedEventArgs P_1)
	{
		GoogleSheetsSyncService.SignOut();
		m_362();
		m_366("Đã đăng xuất Google.", false);
	}

	private async void C(object P_0, RoutedEventArgs P_1)
	{
		GoogleSheetsSyncSettings googleSheetsSyncSettings = B();
		googleSheetsSyncSettings.Save(m_359);
		if (string.IsNullOrWhiteSpace(googleSheetsSyncSettings.SpreadsheetId))
		{
			m_366("Chưa nhập Link/ID Google Sheet.", true);
			return;
		}
		if (!GoogleSheetsSyncService.IsSignedIn && string.IsNullOrWhiteSpace(googleSheetsSyncSettings.ClientId))
		{
			m_366("Chưa đăng nhập Google.", true);
			return;
		}
		SyncNowButton.IsEnabled = false;
		m_366("Đang đồng bộ toàn bộ thư mục...", false);
		this.A = new CancellationTokenSource();
		try
		{
			using SheetsService service = await GoogleSheetsSyncService.AuthorizeAsync(googleSheetsSyncSettings, this.A.Token);
			List<NickFolder> list;
			Func<int, List<IList<object>>> func;
			if (string.IsNullOrEmpty(m_359))
			{
				list = (from nickFolder in FacebookAccountDatabase.LoadFolders()
					where nickFolder.CanManage
					select nickFolder).ToList();
				List<FacebookAccountRow> A = FacebookAccountDatabase.LoadAll();
				func = (int num2) => GoogleSheetsSyncService.BuildRows(A.Where((FacebookAccountRow facebookAccountRow) => facebookAccountRow.FolderId == num2).ToList());
			}
			else
			{
				PlatformAccountDatabase platformAccountDatabase = new PlatformAccountDatabase(m_359);
				list = (from nickFolder in platformAccountDatabase.LoadFolders()
					where nickFolder.CanManage
					select nickFolder).ToList();
				List<PlatformAccountRow> A2 = platformAccountDatabase.LoadAll();
				func = (int num2) => GoogleSheetsSyncService.BuildRows(A2.Where((PlatformAccountRow platformAccountRow) => platformAccountRow.FolderId == num2).ToList());
			}
			int num = 0;
			foreach (NickFolder item in list)
			{
				this.A.Token.ThrowIfCancellationRequested();
				await GoogleSheetsSyncService.SyncFolderAsync(service, googleSheetsSyncSettings.SpreadsheetId, item.Name, func(item.Id), this.A.Token);
				num++;
				m_366($"Đang đồng bộ... ({num}/{list.Count} thư mục)", false);
			}
			m_366($"Đã đồng bộ xong {list.Count} thư mục lên Google Sheet.", false);
			m_362();
		}
		catch (OperationCanceledException)
		{
			m_366("Đã dừng đồng bộ.", true);
		}
		catch (Exception ex2)
		{
			m_366("Đồng bộ thất bại: " + ex2.Message, true);
		}
		finally
		{
			SyncNowButton.IsEnabled = true;
			this.A?.Dispose();
			this.A = null;
		}
	}

	private void m_366(string P_0, bool P_1)
	{
		StatusText.Text = P_0;
		StatusText.Foreground = (P_1 ? new SolidColorBrush(Color.FromRgb(239, 68, 68)) : ((Brush)FindResource("BrushGreen")));
		StatusText.Visibility = (string.IsNullOrWhiteSpace(P_0) ? Visibility.Collapsed : Visibility.Visible);
	}
}
