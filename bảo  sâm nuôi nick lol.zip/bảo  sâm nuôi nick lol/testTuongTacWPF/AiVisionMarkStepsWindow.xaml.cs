using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using testTuongTacWPF.Automation;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class AiVisionMarkStepsWindow : Window, IComponentConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_116
	{
		public static readonly m_116 A = new m_116();

		public static Func<UiElement, string> m_120;

		public static Func<string, bool> m_121;

		internal string m_122(UiElement P_0)
		{
			return P_0.Text;
		}

		internal bool m_123(string P_0)
		{
			return !string.IsNullOrWhiteSpace(P_0);
		}
	}

	private readonly AiVisionFlowStep m_76;

	private readonly IMarkStepsDeviceAdapter m_77;

	private readonly IReadOnlyList<AiVisionFlowStep> m_78;

	private List<UiElement> m_79 = new List<UiElement>();

	private BitmapImage? m_80;

	private bool m_81;

	private const int m_82 = 80;

	private const int a = 12;

	private const int B = 3;

	private bool m_83;

	private string? m_84;

	private string? m_85;

	private string? m_86;

	private List<string>? m_87;

	private int b;

	private int C;

	private int c;

	private int D;

	private string? m_88;

	private int d;

	private int E;

	private Point? m_89;

	private (int X, int Y)? m_90;

	private Line? m_91;

	private bool m_92;

	private string? A
	{
		get
		{
			if (string.IsNullOrWhiteSpace(m_86))
			{
				if (string.IsNullOrWhiteSpace(m_85))
				{
					if (string.IsNullOrWhiteSpace(m_84))
					{
						return null;
					}
					return m_84;
				}
				return m_85;
			}
			return m_86;
		}
	}

	public AiVisionMarkStepsWindow(AiVisionFlowStep step, IMarkStepsDeviceAdapter adapter, IReadOnlyList<AiVisionFlowStep> allSteps)
	{
		InitializeComponent();
		m_76 = step;
		m_77 = adapter;
		m_78 = allSteps;
		if (step.IsMarkedComplete)
		{
			m_83 = true;
			m_84 = step.ResourceId;
			m_85 = step.ContentDesc;
			m_86 = step.ElementText;
			m_87 = step.ScreenTexts;
			b = step.X;
			C = step.Y;
			c = step.X2;
			D = step.Y2;
			m_88 = step.DisambiguatorText;
			d = step.DisambiguatorX;
			E = step.DisambiguatorY;
		}
		switch (step.Type)
		{
		case AiVisionStepType.Tap:
			TitleText.Text = "Đánh dấu bước Nhấn";
			InstructionText.Text = "Bấm \"Chụp ảnh\", sau đó bấm thẳng vào ảnh tại chỗ cần chạm - hệ thống tự tìm phần tử gần điểm đó và tap THẬT trên máy/trang để thấy kết quả ngay.";
			break;
		case AiVisionStepType.Swipe:
			TitleText.Text = "Đánh dấu bước Kéo vuốt";
			InstructionText.Text = "Bấm \"Chụp ảnh\", sau đó bấm giữ tại điểm bắt đầu, kéo tới điểm kết thúc rồi thả ra - hệ thống swipe THẬT trên máy/trang để thấy kết quả ngay.";
			break;
		case AiVisionStepType.Text:
			TitleText.Text = "Đánh dấu bước Nhập văn bản";
			InstructionText.Text = "Chụp ảnh, có thể bấm vào ảnh tại đúng ô cần gõ để đánh dấu (sẽ tự tap ô đó trước khi gõ mỗi lần chạy) - nếu bỏ qua, bước này chỉ gõ vào ô đang được focus sẵn từ bước Nhấn ngay trước đó. Nhập nội dung cần gõ ở khung bên phải.";
			TextInputPanel.Visibility = Visibility.Visible;
			TextValueTextBox.Text = step.Text;
			break;
		}
		m_111();
	}

	private void m_93(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_94(object P_0, RoutedEventArgs P_1)
	{
		WindowState = WindowState.Minimized;
	}

	private async void m_95(object P_0, RoutedEventArgs P_1)
	{
		if (m_81)
		{
			return;
		}
		m_81 = true;
		m_112(true, "Đang chụp ảnh...");
		try
		{
			byte[] buffer = await m_77.CaptureScreenshotAsync(CancellationToken.None);
			m_79 = await m_77.DumpElementsAsync(CancellationToken.None);
			BitmapImage bitmapImage = new BitmapImage();
			using (MemoryStream streamSource = new MemoryStream(buffer))
			{
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = streamSource;
				bitmapImage.EndInit();
			}
			((Freezable)bitmapImage).Freeze();
			m_80 = bitmapImage;
			ScreenshotImage.Source = bitmapImage;
			NoImageHintText.Visibility = Visibility.Collapsed;
			MarkersCanvas.Children.Clear();
			string text = m_76.Type switch
			{
				AiVisionStepType.Tap => $"Đã chụp - phát hiện {m_79.Count} phần tử. Bấm vào ảnh tại chỗ cần tap.", 
				AiVisionStepType.Swipe => $"Đã chụp - phát hiện {m_79.Count} phần tử. Bấm giữ rồi kéo trên ảnh.", 
				AiVisionStepType.Text => $"Đã chụp - phát hiện {m_79.Count} phần tử. Bấm vào ảnh tại ô cần gõ để đánh dấu (không bắt buộc).", 
				_ => "Đã chụp ảnh để tham khảo.", 
			};
			MarkStatusText.Text = text;
		}
		catch (Exception ex)
		{
			MarkStatusText.Text = "Lỗi chụp ảnh: " + ex.Message;
		}
		finally
		{
			m_81 = false;
			m_112(false, null);
		}
	}

	private async void m_96(object P_0, MouseButtonEventArgs P_1)
	{
		if (m_81 || m_80 == null)
		{
			return;
		}
		Point position = P_1.GetPosition(MarkersCanvas);
		(int, int)? tuple = m_100(position, MarkersCanvas.ActualWidth, MarkersCanvas.ActualHeight, m_80.PixelWidth, m_80.PixelHeight);
		if (!tuple.HasValue)
		{
			return;
		}
		if (m_76.Type == AiVisionStepType.Swipe)
		{
			m_89 = position;
			m_90 = tuple.Value;
			MarkersCanvas.Children.Clear();
			return;
		}
		(int, int) value = tuple.Value;
		int item = value.Item1;
		int item2 = value.Item2;
		m_81 = true;
		m_112(true, "Đang tap...");
		try
		{
			(int, int) tuple2 = await m_77.ToDeviceCoordinatesAsync(item, item2, CancellationToken.None);
			int item3 = tuple2.Item1;
			int item4 = tuple2.Item2;
			UiElement uiElement = m_101(m_79, item3, item4);
			int num = uiElement?.CenterX ?? item3;
			int num2 = uiElement?.CenterY ?? item4;
			await m_77.TapAsync(num, num2, CancellationToken.None);
			m_83 = true;
			m_84 = uiElement?.ResourceId;
			m_85 = uiElement?.ContentDesc;
			m_86 = uiElement?.Text;
			m_87 = m_102(m_79);
			b = num;
			C = num2;
			(m_88, d, E) = m_103(uiElement?.Text);
			MarkersCanvas.Children.Clear();
			m_104(position);
			string text = ((!string.IsNullOrWhiteSpace(uiElement?.Label)) ? ("\"" + uiElement.Label + "\"") : $"({num},{num2})");
			MarkStatusText.Text = ((m_76.Type == AiVisionStepType.Text) ? ("Đã đánh dấu ô " + text + " - sẽ tap ô này trước khi gõ chữ. Bấm chỗ khác để đánh dấu lại.") : ("Đã tap " + text + ". Bấm chỗ khác để đánh dấu lại, hoặc Lưu để hoàn tất."));
			m_111();
		}
		catch (Exception ex)
		{
			MarkStatusText.Text = "Lỗi khi tap: " + ex.Message;
		}
		finally
		{
			m_81 = false;
			m_112(false, null);
		}
	}

	private void m_97(object P_0, MouseEventArgs P_1)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		if (m_76.Type == AiVisionStepType.Swipe && m_89.HasValue && P_1.LeftButton == MouseButtonState.Pressed)
		{
			Point position = P_1.GetPosition(MarkersCanvas);
			if (m_91 == null)
			{
				m_91 = new Line
				{
					Stroke = (Brush)FindResource("BrushAccent"),
					StrokeThickness = 3.0,
					StrokeDashArray = new DoubleCollection { 4.0, 3.0 },
					IsHitTestVisible = false
				};
				MarkersCanvas.Children.Add(m_91);
			}
			Line? line = m_91;
			Point value = m_89.Value;
			line.X1 = value.X;
			Line? line2 = m_91;
			value = m_89.Value;
			line2.Y1 = value.Y;
			m_91.X2 = position.X;
			m_91.Y2 = position.Y;
		}
	}

	private async void m_98(object P_0, MouseButtonEventArgs P_1)
	{
		if (m_81 || m_80 == null)
		{
			return;
		}
		if (m_76.Type != AiVisionStepType.Swipe || !m_89.HasValue || !m_90.HasValue)
		{
			m_89 = null;
			m_90 = null;
			return;
		}
		Point position = P_1.GetPosition(MarkersCanvas);
		(int, int)? tuple = m_100(position, MarkersCanvas.ActualWidth, MarkersCanvas.ActualHeight, m_80.PixelWidth, m_80.PixelHeight);
		Point value = m_89.Value;
		(int X, int Y) value2 = m_90.Value;
		int item = value2.X;
		int item2 = value2.Y;
		m_89 = null;
		m_90 = null;
		if (!tuple.HasValue)
		{
			m_99();
			return;
		}
		var (pixelX, pixelY) = tuple.Value;
		if (Math.Sqrt(Math.Pow(position.X - value.X, 2.0) + Math.Pow(position.Y - value.Y, 2.0)) < 12.0)
		{
			MarkStatusText.Text = "Kéo quá ngắn - bấm giữ và kéo dài hơn để đánh dấu điểm đầu/cuối.";
			m_99();
			return;
		}
		m_81 = true;
		m_112(true, "Đang swipe...");
		try
		{
			var (num, num2) = await m_77.ToDeviceCoordinatesAsync(item, item2, CancellationToken.None);
			var (num3, num4) = await m_77.ToDeviceCoordinatesAsync(pixelX, pixelY, CancellationToken.None);
			await m_77.SwipeAsync(num, num2, num3, num4, CancellationToken.None);
			m_83 = true;
			m_84 = null;
			m_85 = null;
			m_86 = null;
			m_87 = null;
			b = num;
			C = num2;
			c = num3;
			D = num4;
			(m_88, d, E) = m_103(null);
			MarkersCanvas.Children.Clear();
			m_105(value, position);
			MarkStatusText.Text = $"Đã swipe ({num},{num2}) → ({num3},{num4}). Kéo lại để đánh dấu lại, hoặc Lưu để hoàn tất.";
			m_111();
		}
		catch (Exception ex)
		{
			MarkStatusText.Text = "Lỗi khi swipe: " + ex.Message;
		}
		finally
		{
			m_81 = false;
			m_112(false, null);
		}
	}

	private void m_99()
	{
		MarkersCanvas.Children.Clear();
		m_91 = null;
	}

	private static (int X, int Y)? m_100(Point P_0, double P_1, double P_2, int P_3, int P_4)
	{
		if (P_1 <= 0.0 || P_2 <= 0.0 || P_3 <= 0 || P_4 <= 0)
		{
			return null;
		}
		double num = (double)P_3 / (double)P_4;
		double num2 = P_1 / P_2;
		double num3;
		double num4;
		double num5;
		double num6;
		if (num > num2)
		{
			num3 = P_1;
			num4 = num3 / num;
			num5 = 0.0;
			num6 = (P_2 - num4) / 2.0;
		}
		else
		{
			num4 = P_2;
			num3 = num4 * num;
			num6 = 0.0;
			num5 = (P_1 - num3) / 2.0;
		}
		double num7 = (P_0.X - num5) / num3;
		double num8 = (P_0.Y - num6) / num4;
		if (num7 < 0.0 || num7 > 1.0 || num8 < 0.0 || num8 > 1.0)
		{
			return null;
		}
		return ((int)(num7 * (double)P_3), (int)(num8 * (double)P_4));
	}

	private static UiElement? m_101(List<UiElement> P_0, int P_1, int P_2)
	{
		UiElement uiElement = null;
		long num = long.MaxValue;
		foreach (UiElement item in P_0)
		{
			if (P_1 >= item.Left && P_1 <= item.Right && P_2 >= item.Top && P_2 <= item.Bottom)
			{
				long num2 = (long)(item.Right - item.Left) * (long)(item.Bottom - item.Top);
				if (num2 < num)
				{
					num = num2;
					uiElement = item;
				}
			}
		}
		if (uiElement != null)
		{
			return uiElement;
		}
		UiElement result = null;
		double num3 = double.MaxValue;
		foreach (UiElement item2 in P_0)
		{
			double num4 = Math.Sqrt(Math.Pow(item2.CenterX - P_1, 2.0) + Math.Pow(item2.CenterY - P_2, 2.0));
			if (num4 < num3)
			{
				num3 = num4;
				result = item2;
			}
		}
		if (!(num3 <= 80.0))
		{
			return null;
		}
		return result;
	}

	private static List<string> m_102(List<UiElement> P_0)
	{
		return (from uiElement in P_0
			select uiElement.Text into value
			where !string.IsNullOrWhiteSpace(value)
			select value).Distinct().Take(3).ToList();
	}

	private (string? Text, int X, int Y) m_103(string? P_0)
	{
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (AiVisionFlowStep item in m_78)
		{
			if (item != m_76 && !string.IsNullOrWhiteSpace(item.DisambiguatorText))
			{
				hashSet.Add(item.DisambiguatorText);
			}
		}
		foreach (UiElement item2 in m_79)
		{
			if (!string.IsNullOrWhiteSpace(item2.Text) && !string.Equals(item2.Text, P_0, StringComparison.OrdinalIgnoreCase) && !hashSet.Contains(item2.Text))
			{
				return (Text: item2.Text, X: item2.CenterX, Y: item2.CenterY);
			}
		}
		return (Text: null, X: 0, Y: 0);
	}

	private void m_104(Point P_0)
	{
		Ellipse element = new Ellipse
		{
			Width = 20.0,
			Height = 20.0,
			Fill = (Brush)FindResource("BrushAccent"),
			Stroke = Brushes.White,
			StrokeThickness = 2.0,
			IsHitTestVisible = false
		};
		Canvas.SetLeft(element, P_0.X - 10.0);
		Canvas.SetTop(element, P_0.Y - 10.0);
		MarkersCanvas.Children.Add(element);
	}

	private void m_105(Point P_0, Point P_1)
	{
		Brush brush = (Brush)FindResource("BrushAccent");
		Line element = new Line
		{
			X1 = P_0.X,
			Y1 = P_0.Y,
			X2 = P_1.X,
			Y2 = P_1.Y,
			Stroke = brush,
			StrokeThickness = 3.0,
			IsHitTestVisible = false
		};
		MarkersCanvas.Children.Add(element);
		Ellipse element2 = new Ellipse
		{
			Width = 16.0,
			Height = 16.0,
			Fill = Brushes.White,
			Stroke = brush,
			StrokeThickness = 2.0,
			IsHitTestVisible = false
		};
		Canvas.SetLeft(element2, P_0.X - 8.0);
		Canvas.SetTop(element2, P_0.Y - 8.0);
		MarkersCanvas.Children.Add(element2);
		Ellipse element3 = new Ellipse
		{
			Width = 20.0,
			Height = 20.0,
			Fill = brush,
			Stroke = Brushes.White,
			StrokeThickness = 2.0,
			IsHitTestVisible = false
		};
		Canvas.SetLeft(element3, P_1.X - 10.0);
		Canvas.SetTop(element3, P_1.Y - 10.0);
		MarkersCanvas.Children.Add(element3);
	}

	private void m_106(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is Button { Tag: string tag })
		{
			TextValueTextBox.Text += tag;
			TextValueTextBox.CaretIndex = TextValueTextBox.Text.Length;
		}
	}

	private void m_107(object P_0, RoutedEventArgs P_1)
	{
		string text = AiVisionFileVariableWindow.Show(this);
		if (text != null)
		{
			TextValueTextBox.Text += text;
			TextValueTextBox.CaretIndex = TextValueTextBox.Text.Length;
		}
	}

	private void m_108(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 is Button { Tag: string tag })
		{
			string text = AiVisionRandomVariableWindow.Show(this, tag);
			if (text != null)
			{
				TextValueTextBox.Text += text;
				TextValueTextBox.CaretIndex = TextValueTextBox.Text.Length;
			}
		}
	}

	private void m_109(object P_0, TextChangedEventArgs P_1)
	{
		m_83 = !string.IsNullOrEmpty(TextValueTextBox.Text) || m_110();
		m_111();
	}

	private bool m_110()
	{
		if (string.IsNullOrWhiteSpace(m_84) && string.IsNullOrWhiteSpace(m_85) && string.IsNullOrWhiteSpace(m_86) && b == 0)
		{
			return C != 0;
		}
		return true;
	}

	private void m_111()
	{
		TextBlock markedSummaryText = MarkedSummaryText;
		markedSummaryText.Text = m_76.Type switch
		{
			AiVisionStepType.Tap => (!m_83) ? "(chưa đánh dấu)" : ((A != null) ? $"Nhấn \"{A}\" ({b},{C})" : $"Nhấn ({b},{C})"), 
			AiVisionStepType.Swipe => (!m_83) ? "(chưa đánh dấu)" : $"Kéo vuốt ({b},{C}) → ({c},{D})", 
			AiVisionStepType.Text => m_110() ? ("Nhấn ô rồi gõ chữ: \"" + TextValueTextBox.Text + "\"") : (string.IsNullOrEmpty(TextValueTextBox.Text) ? "(chưa nhập)" : ("Gõ chữ: \"" + TextValueTextBox.Text + "\"")), 
			_ => "", 
		};
		SaveButton.IsEnabled = m_83;
	}

	private void m_112(bool P_0, string? P_1)
	{
		CaptureButton.IsEnabled = !P_0;
		MarkersCanvas.IsEnabled = !P_0;
		if (P_1 != null)
		{
			MarkStatusText.Text = P_1;
		}
	}

	private void m_113(object P_0, RoutedEventArgs P_1)
	{
		if (m_83)
		{
			switch (m_76.Type)
			{
			case AiVisionStepType.Tap:
				m_76.ResourceId = m_84;
				m_76.ContentDesc = m_85;
				m_76.ElementText = m_86;
				m_76.ScreenTexts = m_87;
				m_76.X = b;
				m_76.Y = C;
				m_76.DisambiguatorText = m_88;
				m_76.DisambiguatorX = d;
				m_76.DisambiguatorY = E;
				break;
			case AiVisionStepType.Swipe:
				m_76.ScreenTexts = m_87;
				m_76.X = b;
				m_76.Y = C;
				m_76.X2 = c;
				m_76.Y2 = D;
				m_76.DisambiguatorText = m_88;
				m_76.DisambiguatorX = d;
				m_76.DisambiguatorY = E;
				break;
			case AiVisionStepType.Text:
				m_76.ResourceId = m_84;
				m_76.ContentDesc = m_85;
				m_76.ElementText = m_86;
				m_76.ScreenTexts = m_87;
				m_76.X = b;
				m_76.Y = C;
				m_76.Text = TextValueTextBox.Text;
				m_76.DisambiguatorText = m_88;
				m_76.DisambiguatorX = d;
				m_76.DisambiguatorY = E;
				break;
			}
			m_76.IsMarkedComplete = true;
			DialogResult = true;
			Close();
		}
	}

	private void m_114(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}
}
