using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF.Models;

public class PlatformAccountRow : INotifyPropertyChanged, IChromeAutomationAccount
{
	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	private bool m_2398;

	private int m_2399;

	private int a;

	private string m_2400 = "";

	private int B;

	private string m_2401 = "";

	private string m_2402 = "";

	private string b = "";

	private string C = "";

	private string c = "";

	private string D = "";

	private string d = "";

	private string E = "";

	private string e = "";

	private string F = "";

	private string f = "";

	private string G = "";

	private string g = "";

	private string H = "";

	private string h = "";

	private string I = "";

	private string i = "";

	private string J = "";

	private string j = "";

	public bool IsSelected
	{
		get
		{
			return m_2398;
		}
		set
		{
			m_2403(ref m_2398, value, "IsSelected");
		}
	}

	public int Index
	{
		get
		{
			return m_2399;
		}
		set
		{
			m_2403(ref m_2399, value, "Index");
		}
	}

	public int FolderId
	{
		get
		{
			return a;
		}
		set
		{
			m_2403(ref a, value, "FolderId");
		}
	}

	public string PhoneName
	{
		get
		{
			return m_2400;
		}
		set
		{
			m_2403(ref m_2400, value, "PhoneName");
			A?.Invoke(this, new PropertyChangedEventArgs("Platform"));
		}
	}

	public int ScriptId
	{
		get
		{
			return B;
		}
		set
		{
			m_2403(ref B, value, "ScriptId");
		}
	}

	public string ScriptName
	{
		get
		{
			return m_2401;
		}
		set
		{
			m_2403(ref m_2401, value, "ScriptName");
		}
	}

	public string TikTokInteractionSettingsJson
	{
		get
		{
			return m_2402;
		}
		set
		{
			m_2403(ref m_2402, value, "TikTokInteractionSettingsJson");
		}
	}

	public string Uid
	{
		get
		{
			return b;
		}
		set
		{
			m_2403(ref b, value, "Uid");
		}
	}

	public string Pass
	{
		get
		{
			return C;
		}
		set
		{
			m_2403(ref C, value, "Pass");
		}
	}

	public string TwoFA
	{
		get
		{
			return c;
		}
		set
		{
			m_2403(ref c, value, "TwoFA");
		}
	}

	public string Token
	{
		get
		{
			return D;
		}
		set
		{
			m_2403(ref D, value, "Token");
		}
	}

	public string Cookie
	{
		get
		{
			return d;
		}
		set
		{
			m_2403(ref d, value, "Cookie");
		}
	}

	public string Mail
	{
		get
		{
			return E;
		}
		set
		{
			m_2403(ref E, value, "Mail");
		}
	}

	public string PassMail
	{
		get
		{
			return e;
		}
		set
		{
			m_2403(ref e, value, "PassMail");
		}
	}

	public string MailKhoiPhuc
	{
		get
		{
			return F;
		}
		set
		{
			m_2403(ref F, value, "MailKhoiPhuc");
		}
	}

	public string ProfileChrome
	{
		get
		{
			return f;
		}
		set
		{
			m_2403(ref f, value, "ProfileChrome");
			A?.Invoke(this, new PropertyChangedEventArgs("Platform"));
		}
	}

	public string Platform
	{
		get
		{
			if (string.IsNullOrWhiteSpace(PhoneName))
			{
				if (string.IsNullOrWhiteSpace(ProfileChrome))
				{
					return "";
				}
				return "Chrome";
			}
			return "Phone";
		}
	}

	public string TenProfile
	{
		get
		{
			return G;
		}
		set
		{
			m_2403(ref G, value, "TenProfile");
		}
	}

	public string UserAgent
	{
		get
		{
			return g;
		}
		set
		{
			m_2403(ref g, value, "UserAgent");
		}
	}

	public string Proxy
	{
		get
		{
			return H;
		}
		set
		{
			m_2403(ref H, value, "Proxy");
		}
	}

	public string GhiChu
	{
		get
		{
			return h;
		}
		set
		{
			m_2403(ref h, value, "GhiChu");
		}
	}

	public string TrangThai
	{
		get
		{
			return I;
		}
		set
		{
			m_2403(ref I, value, "TrangThai");
			TrangThaiChiTiet = value;
		}
	}

	public string TrangThaiChiTiet
	{
		get
		{
			return i;
		}
		set
		{
			m_2403(ref i, value, "TrangThaiChiTiet");
		}
	}

	public string TinhTrang
	{
		get
		{
			return J;
		}
		set
		{
			m_2403(ref J, value, "TinhTrang");
		}
	}

	public string BrowserProfileId
	{
		get
		{
			return j;
		}
		set
		{
			m_2403(ref j, value, "BrowserProfileId");
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2403<gm_2373>(ref gm_2373 P_0, gm_2373 P_1, [CallerMemberName] string? propertyName = null)
	{
		if (!object.Equals(P_0, P_1))
		{
			P_0 = P_1;
			A?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
