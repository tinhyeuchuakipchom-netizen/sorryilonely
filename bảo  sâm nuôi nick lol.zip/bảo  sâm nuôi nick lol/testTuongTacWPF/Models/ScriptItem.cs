using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace testTuongTacWPF.Models;

public class ScriptItem : INotifyPropertyChanged
{
	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	[CompilerGenerated]
	private int m_2434;

	private int a;

	private string m_2435 = "";

	private string m_2436 = "Phone";

	private string B = "Facebook";

	private bool m_2437;

	private string b = "[]";

	[CompilerGenerated]
	private bool m_2438;

	public int Id
	{
		[CompilerGenerated]
		get
		{
			return m_2434;
		}
		[CompilerGenerated]
		set
		{
			m_2434 = value;
		}
	}

	public int Index
	{
		get
		{
			return a;
		}
		set
		{
			m_2439(ref a, value, "Index");
		}
	}

	public string Name
	{
		get
		{
			return m_2435;
		}
		set
		{
			m_2439(ref m_2435, value, "Name");
		}
	}

	public string Platform
	{
		get
		{
			return m_2436;
		}
		set
		{
			m_2439(ref m_2436, value, "Platform");
		}
	}

	public string ChuDe
	{
		get
		{
			return B;
		}
		set
		{
			m_2439(ref B, value, "ChuDe");
		}
	}

	public bool IsSelected
	{
		get
		{
			return m_2437;
		}
		set
		{
			m_2439(ref m_2437, value, "IsSelected");
		}
	}

	public string AiVisionFlowJson
	{
		get
		{
			return b;
		}
		set
		{
			m_2439(ref b, value, "AiVisionFlowJson");
		}
	}

	public bool IsSystem
	{
		[CompilerGenerated]
		get
		{
			return m_2438;
		}
		[CompilerGenerated]
		set
		{
			m_2438 = value;
		}
	}

	public bool CanManage => !IsSystem;

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2439<gm_2425>(ref gm_2425 P_0, gm_2425 P_1, [CallerMemberName] string? propertyName = null)
	{
		if (!object.Equals(P_0, P_1))
		{
			P_0 = P_1;
			A?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
