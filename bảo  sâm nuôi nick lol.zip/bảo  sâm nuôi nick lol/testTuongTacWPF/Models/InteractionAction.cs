using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace testTuongTacWPF.Models;

public class InteractionAction : INotifyPropertyChanged
{
	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	[CompilerGenerated]
	private int m_2354;

	private int a;

	[CompilerGenerated]
	private string m_2355 = "";

	[CompilerGenerated]
	private string m_2356 = "";

	[CompilerGenerated]
	private string B = "Phone";

	private bool m_2357;

	public int Id
	{
		[CompilerGenerated]
		get
		{
			return m_2354;
		}
		[CompilerGenerated]
		set
		{
			m_2354 = value;
		}
	}

	public int Index
	{
		get
		{
			return a;
		}
		set
		{
			m_2358(ref a, value, "Index");
		}
	}

	public string Name
	{
		[CompilerGenerated]
		get
		{
			return m_2355;
		}
		[CompilerGenerated]
		set
		{
			m_2355 = value;
		}
	}

	public string Category
	{
		[CompilerGenerated]
		get
		{
			return m_2356;
		}
		[CompilerGenerated]
		set
		{
			m_2356 = value;
		}
	}

	public string Platform
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public bool IsSelected
	{
		get
		{
			return m_2357;
		}
		set
		{
			m_2358(ref m_2357, value, "IsSelected");
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2358<gm_2347>(ref gm_2347 P_0, gm_2347 P_1, [CallerMemberName] string? propertyName = null)
	{
		if (!object.Equals(P_0, P_1))
		{
			P_0 = P_1;
			A?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
