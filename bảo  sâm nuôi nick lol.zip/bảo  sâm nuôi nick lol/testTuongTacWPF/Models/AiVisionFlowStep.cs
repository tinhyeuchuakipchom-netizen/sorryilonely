using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace testTuongTacWPF.Models;

public class AiVisionFlowStep : INotifyPropertyChanged
{
	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	private AiVisionStepType m_2250;

	private string m_2251 = "";

	private int m_2252 = 25;

	private int a = 1500;

	private int B = 1000;

	private int b = 3000;

	private string? m_2253;

	private string? m_2254;

	private string? m_2255;

	private List<string>? m_2256;

	private int C;

	private int c;

	private int D;

	private int d;

	private string m_2257 = "";

	private string m_2258 = "";

	private string? m_2259;

	private int E;

	private int e;

	private bool m_2260;

	public AiVisionStepType Type
	{
		get
		{
			return m_2250;
		}
		set
		{
			if (m_2250 != value)
			{
				m_2250 = value;
				m_2261("Type");
				m_2261("TypeLabel");
				m_2261("Summary");
				m_2261("IsAiGoal");
				m_2261("IsWait");
				m_2261("IsRandomWait");
				m_2261("IsTap");
				m_2261("IsSwipe");
				m_2261("IsText");
				m_2261("IsGoto");
				m_2261("IsMarked");
			}
		}
	}

	public string Goal
	{
		get
		{
			return m_2251;
		}
		set
		{
			if (!(m_2251 == value))
			{
				m_2251 = value;
				m_2261("Goal");
				m_2261("Summary");
			}
		}
	}

	public int MaxSteps
	{
		get
		{
			return m_2252;
		}
		set
		{
			if (m_2252 != value)
			{
				m_2252 = value;
				m_2261("MaxSteps");
			}
		}
	}

	public int WaitMs
	{
		get
		{
			return a;
		}
		set
		{
			if (a != value)
			{
				a = value;
				m_2261("WaitMs");
				m_2261("Summary");
			}
		}
	}

	public int RandomMinMs
	{
		get
		{
			return B;
		}
		set
		{
			if (B != value)
			{
				B = value;
				m_2261("RandomMinMs");
				m_2261("Summary");
			}
		}
	}

	public int RandomMaxMs
	{
		get
		{
			return b;
		}
		set
		{
			if (b != value)
			{
				b = value;
				m_2261("RandomMaxMs");
				m_2261("Summary");
			}
		}
	}

	public string? ResourceId
	{
		get
		{
			return m_2253;
		}
		set
		{
			if (!(m_2253 == value))
			{
				m_2253 = value;
				m_2261("ResourceId");
				m_2261("Summary");
			}
		}
	}

	public string? ContentDesc
	{
		get
		{
			return m_2254;
		}
		set
		{
			if (!(m_2254 == value))
			{
				m_2254 = value;
				m_2261("ContentDesc");
				m_2261("Summary");
			}
		}
	}

	public string? ElementText
	{
		get
		{
			return m_2255;
		}
		set
		{
			if (!(m_2255 == value))
			{
				m_2255 = value;
				m_2261("ElementText");
				m_2261("Summary");
			}
		}
	}

	public List<string>? ScreenTexts
	{
		get
		{
			return m_2256;
		}
		set
		{
			if (m_2256 != value)
			{
				m_2256 = value;
				m_2261("ScreenTexts");
				m_2261("Summary");
			}
		}
	}

	public int X
	{
		get
		{
			return C;
		}
		set
		{
			if (C != value)
			{
				C = value;
				m_2261("X");
				m_2261("Summary");
			}
		}
	}

	public int Y
	{
		get
		{
			return c;
		}
		set
		{
			if (c != value)
			{
				c = value;
				m_2261("Y");
				m_2261("Summary");
			}
		}
	}

	public int X2
	{
		get
		{
			return D;
		}
		set
		{
			if (D != value)
			{
				D = value;
				m_2261("X2");
				m_2261("Summary");
			}
		}
	}

	public int Y2
	{
		get
		{
			return d;
		}
		set
		{
			if (d != value)
			{
				d = value;
				m_2261("Y2");
				m_2261("Summary");
			}
		}
	}

	public string Text
	{
		get
		{
			return m_2257;
		}
		set
		{
			if (!(m_2257 == value))
			{
				m_2257 = value;
				m_2261("Text");
				m_2261("Summary");
			}
		}
	}

	public string Url
	{
		get
		{
			return m_2258;
		}
		set
		{
			if (!(m_2258 == value))
			{
				m_2258 = value;
				m_2261("Url");
				m_2261("Summary");
			}
		}
	}

	public string? DisambiguatorText
	{
		get
		{
			return m_2259;
		}
		set
		{
			if (!(m_2259 == value))
			{
				m_2259 = value;
				m_2261("DisambiguatorText");
			}
		}
	}

	public int DisambiguatorX
	{
		get
		{
			return E;
		}
		set
		{
			if (E != value)
			{
				E = value;
				m_2261("DisambiguatorX");
			}
		}
	}

	public int DisambiguatorY
	{
		get
		{
			return e;
		}
		set
		{
			if (e != value)
			{
				e = value;
				m_2261("DisambiguatorY");
			}
		}
	}

	public bool IsMarkedComplete
	{
		get
		{
			return m_2260;
		}
		set
		{
			if (m_2260 != value)
			{
				m_2260 = value;
				m_2261("IsMarkedComplete");
				m_2261("Summary");
			}
		}
	}

	public bool IsAiGoal => Type == AiVisionStepType.AiGoal;

	public bool IsWait => Type == AiVisionStepType.Wait;

	public bool IsRandomWait => Type == AiVisionStepType.RandomWait;

	public bool IsTap => Type == AiVisionStepType.Tap;

	public bool IsSwipe => Type == AiVisionStepType.Swipe;

	public bool IsText => Type == AiVisionStepType.Text;

	public bool IsGoto => Type == AiVisionStepType.Goto;

	public bool IsScroll => Type == AiVisionStepType.Scroll;

	public bool IsKeyPress => Type == AiVisionStepType.KeyPress;

	public bool IsMarked
	{
		get
		{
			if (!IsTap && !IsSwipe)
			{
				return IsText;
			}
			return true;
		}
	}

	public bool HasTapTarget
	{
		get
		{
			if (string.IsNullOrWhiteSpace(ResourceId) && string.IsNullOrWhiteSpace(ContentDesc) && string.IsNullOrWhiteSpace(ElementText) && X == 0)
			{
				return Y != 0;
			}
			return true;
		}
	}

	public string? IdentityLabel
	{
		get
		{
			if (string.IsNullOrWhiteSpace(ElementText))
			{
				if (string.IsNullOrWhiteSpace(ContentDesc))
				{
					if (string.IsNullOrWhiteSpace(ResourceId))
					{
						return null;
					}
					return ResourceId;
				}
				return ContentDesc;
			}
			return ElementText;
		}
	}

	public string TypeLabel => Type switch
	{
		AiVisionStepType.AiGoal => "AI", 
		AiVisionStepType.Wait => "CHỜ", 
		AiVisionStepType.RandomWait => "NGẪU NHIÊN", 
		AiVisionStepType.Tap => "NHẤN", 
		AiVisionStepType.Swipe => "KÉO VUỐT", 
		AiVisionStepType.Text => "VĂN BẢN", 
		AiVisionStepType.Goto => "MỞ TRANG", 
		AiVisionStepType.Scroll => "LĂN CHUỘT", 
		AiVisionStepType.KeyPress => "PHÍM", 
		_ => "", 
	};

	public string Summary => Type switch
	{
		AiVisionStepType.AiGoal => string.IsNullOrWhiteSpace(Goal) ? "(chưa nhập mục tiêu)" : Goal, 
		AiVisionStepType.Wait => $"Chờ {WaitMs} ms", 
		AiVisionStepType.RandomWait => $"Chờ ngẫu nhiên {RandomMinMs} - {RandomMaxMs} ms", 
		AiVisionStepType.Tap => (!IsMarkedComplete) ? "(chưa đánh dấu)" : ((IdentityLabel != null) ? $"Nhấn \"{IdentityLabel}\" ({X},{Y})" : $"Nhấn ({X},{Y})"), 
		AiVisionStepType.Swipe => (!IsMarkedComplete) ? "(chưa đánh dấu)" : $"Kéo vuốt ({X},{Y}) → ({X2},{Y2})", 
		AiVisionStepType.Text => (!IsMarkedComplete) ? "(chưa đánh dấu)" : (HasTapTarget ? ("Nhấn ô rồi gõ chữ: \"" + Text + "\"") : ("Gõ chữ: \"" + Text + "\"")), 
		AiVisionStepType.Goto => string.IsNullOrWhiteSpace(Url) ? "(chưa có URL)" : ("Mở trang: " + Url), 
		AiVisionStepType.Scroll => $"Lăn chuột tại ({X},{Y}) delta=({X2},{Y2})", 
		AiVisionStepType.KeyPress => "Phím: " + Text, 
		_ => "", 
	};

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2261(string P_0)
	{
		A?.Invoke(this, new PropertyChangedEventArgs(P_0));
	}
}
