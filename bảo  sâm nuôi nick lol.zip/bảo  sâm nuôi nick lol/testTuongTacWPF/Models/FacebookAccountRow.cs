using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF.Models;

public class FacebookAccountRow : INotifyPropertyChanged, IChromeAutomationAccount
{
	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	private bool m_2314;

	private int m_2315;

	private int a;

	private string m_2316 = "";

	private int B;

	private string m_2317 = "";

	private string m_2318 = "";

	private string b = "";

	private string C = "";

	private string c = "";

	private string D = "";

	private string d = "";

	private string E = "";

	private string e = "";

	private string F = "";

	private string f = "";

	private string G = "";

	private string g = "";

	private string H = "";

	private string h = "";

	private string I = "";

	private string i = "";

	private string J = "";

	private string j = "";

	private string K = "";

	private string k = "";

	private string L = "";

	private string l = "";

	private string M = "";

	private string m = "";

	private string N = "";

	private string n = "";

	private string O = "";

	private string o = "";

	private string P = "";

	private string p = "";

	private string Q = "";

	private string q = "";

	private string R = "";

	private string r = "";

	private string S = "";

	private string s = "";

	private string T = "";

	private string t = "";

	public bool IsSelected
	{
		get
		{
			return m_2314;
		}
		set
		{
			m_2319(ref m_2314, value, "IsSelected");
		}
	}

	public int Index
	{
		get
		{
			return m_2315;
		}
		set
		{
			m_2319(ref m_2315, value, "Index");
		}
	}

	public int FolderId
	{
		get
		{
			return a;
		}
		set
		{
			m_2319(ref a, value, "FolderId");
		}
	}

	public string PhoneName
	{
		get
		{
			return m_2316;
		}
		set
		{
			m_2319(ref m_2316, value, "PhoneName");
			A?.Invoke(this, new PropertyChangedEventArgs("Platform"));
		}
	}

	public int ScriptId
	{
		get
		{
			return B;
		}
		set
		{
			m_2319(ref B, value, "ScriptId");
		}
	}

	public string ScriptName
	{
		get
		{
			return m_2317;
		}
		set
		{
			m_2319(ref m_2317, value, "ScriptName");
		}
	}

	public string FeedBrowsingSettingsJson
	{
		get
		{
			return m_2318;
		}
		set
		{
			m_2319(ref m_2318, value, "FeedBrowsingSettingsJson");
		}
	}

	public string GroupSpamSettingsJson
	{
		get
		{
			return b;
		}
		set
		{
			m_2319(ref b, value, "GroupSpamSettingsJson");
		}
	}

	public string GroupSpamCommentedPostsJson
	{
		get
		{
			return C;
		}
		set
		{
			m_2319(ref C, value, "GroupSpamCommentedPostsJson");
		}
	}

	public string PostBoostSettingsJson
	{
		get
		{
			return c;
		}
		set
		{
			m_2319(ref c, value, "PostBoostSettingsJson");
		}
	}

	public string PostBoostDoneActionsJson
	{
		get
		{
			return D;
		}
		set
		{
			m_2319(ref D, value, "PostBoostDoneActionsJson");
		}
	}

	public string FriendRequestSettingsJson
	{
		get
		{
			return d;
		}
		set
		{
			m_2319(ref d, value, "FriendRequestSettingsJson");
		}
	}

	public string FriendRequestSentJson
	{
		get
		{
			return E;
		}
		set
		{
			m_2319(ref E, value, "FriendRequestSentJson");
		}
	}

	public string PageCreationSettingsJson
	{
		get
		{
			return e;
		}
		set
		{
			m_2319(ref e, value, "PageCreationSettingsJson");
		}
	}

	public string PostCreationSettingsJson
	{
		get
		{
			return F;
		}
		set
		{
			m_2319(ref F, value, "PostCreationSettingsJson");
		}
	}

	public string PagePostSettingsJson
	{
		get
		{
			return f;
		}
		set
		{
			m_2319(ref f, value, "PagePostSettingsJson");
		}
	}

	public string MessagingSettingsJson
	{
		get
		{
			return G;
		}
		set
		{
			m_2319(ref G, value, "MessagingSettingsJson");
		}
	}

	public string MessagingSentJson
	{
		get
		{
			return g;
		}
		set
		{
			m_2319(ref g, value, "MessagingSentJson");
		}
	}

	public string BmCreationSettingsJson
	{
		get
		{
			return H;
		}
		set
		{
			m_2319(ref H, value, "BmCreationSettingsJson");
		}
	}

	public string Uid
	{
		get
		{
			return h;
		}
		set
		{
			m_2319(ref h, value, "Uid");
		}
	}

	public string Pass
	{
		get
		{
			return I;
		}
		set
		{
			m_2319(ref I, value, "Pass");
		}
	}

	public string TwoFA
	{
		get
		{
			return i;
		}
		set
		{
			m_2319(ref i, value, "TwoFA");
		}
	}

	public string Token
	{
		get
		{
			return J;
		}
		set
		{
			m_2319(ref J, value, "Token");
		}
	}

	public string Cookie
	{
		get
		{
			return j;
		}
		set
		{
			m_2319(ref j, value, "Cookie");
		}
	}

	public string Mail
	{
		get
		{
			return K;
		}
		set
		{
			m_2319(ref K, value, "Mail");
		}
	}

	public string PassMail
	{
		get
		{
			return k;
		}
		set
		{
			m_2319(ref k, value, "PassMail");
		}
	}

	public string MailKhoiPhuc
	{
		get
		{
			return L;
		}
		set
		{
			m_2319(ref L, value, "MailKhoiPhuc");
		}
	}

	public string PassMailKhoiPhuc
	{
		get
		{
			return l;
		}
		set
		{
			m_2319(ref l, value, "PassMailKhoiPhuc");
		}
	}

	public string BanBe
	{
		get
		{
			return M;
		}
		set
		{
			m_2319(ref M, value, "BanBe");
		}
	}

	public string Nhom
	{
		get
		{
			return m;
		}
		set
		{
			m_2319(ref m, value, "Nhom");
		}
	}

	public string HoTen
	{
		get
		{
			return N;
		}
		set
		{
			m_2319(ref N, value, "HoTen");
		}
	}

	public string GioiTinh
	{
		get
		{
			return n;
		}
		set
		{
			m_2319(ref n, value, "GioiTinh");
		}
	}

	public string Avatar
	{
		get
		{
			return O;
		}
		set
		{
			m_2319(ref O, value, "Avatar");
		}
	}

	public string ProfileChrome
	{
		get
		{
			return o;
		}
		set
		{
			m_2319(ref o, value, "ProfileChrome");
			A?.Invoke(this, new PropertyChangedEventArgs("Platform"));
		}
	}

	public string Platform
	{
		get
		{
			if (string.IsNullOrWhiteSpace(PhoneName))
			{
				if (string.IsNullOrWhiteSpace(ProfileChrome))
				{
					return "";
				}
				return "Chrome";
			}
			return "Phone";
		}
	}

	public string TenProfile
	{
		get
		{
			return P;
		}
		set
		{
			m_2319(ref P, value, "TenProfile");
		}
	}

	public string UserAgent
	{
		get
		{
			return p;
		}
		set
		{
			m_2319(ref p, value, "UserAgent");
		}
	}

	public string Proxy
	{
		get
		{
			return Q;
		}
		set
		{
			m_2319(ref Q, value, "Proxy");
		}
	}

	public string TepCu
	{
		get
		{
			return q;
		}
		set
		{
			m_2319(ref q, value, "TepCu");
		}
	}

	public string GhiChu
	{
		get
		{
			return R;
		}
		set
		{
			m_2319(ref R, value, "GhiChu");
		}
	}

	public string TuongTacCuoi
	{
		get
		{
			return r;
		}
		set
		{
			m_2319(ref r, value, "TuongTacCuoi");
		}
	}

	public string TrangThai
	{
		get
		{
			return S;
		}
		set
		{
			m_2319(ref S, value, "TrangThai");
			TrangThaiChiTiet = value;
		}
	}

	public string TrangThaiChiTiet
	{
		get
		{
			return s;
		}
		set
		{
			m_2319(ref s, value, "TrangThaiChiTiet");
		}
	}

	public string TinhTrang
	{
		get
		{
			return T;
		}
		set
		{
			m_2319(ref T, value, "TinhTrang");
		}
	}

	public string BrowserProfileId
	{
		get
		{
			return t;
		}
		set
		{
			m_2319(ref t, value, "BrowserProfileId");
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2319<gm_2269>(ref gm_2269 P_0, gm_2269 P_1, [CallerMemberName] string? propertyName = null)
	{
		if (!object.Equals(P_0, P_1))
		{
			P_0 = P_1;
			A?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
