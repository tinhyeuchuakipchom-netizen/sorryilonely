using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Models;

public class FacebookExportItem
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string C = "";

	[CompilerGenerated]
	private string c = "";

	[CompilerGenerated]
	private string D = "";

	[CompilerGenerated]
	private string d = "";

	[CompilerGenerated]
	private string E = "";

	[CompilerGenerated]
	private string e = "";

	[CompilerGenerated]
	private string F = "";

	[CompilerGenerated]
	private string f = "";

	[CompilerGenerated]
	private string G = "";

	[CompilerGenerated]
	private string g = "";

	[CompilerGenerated]
	private string H = "";

	[CompilerGenerated]
	private string h = "";

	[CompilerGenerated]
	private string I = "";

	[CompilerGenerated]
	private string i = "";

	[CompilerGenerated]
	private string J = "";

	[CompilerGenerated]
	private string j = "";

	[CompilerGenerated]
	private string K = "";

	[CompilerGenerated]
	private string k = "";

	[CompilerGenerated]
	private string L = "";

	[CompilerGenerated]
	private string l = "";

	[CompilerGenerated]
	private string M = "";

	public string FolderName
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string PhoneName
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string ScriptFolderName
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string Uid
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string Pass
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}

	public string TwoFA
	{
		[CompilerGenerated]
		get
		{
			return c;
		}
		[CompilerGenerated]
		set
		{
			c = value;
		}
	}

	public string Token
	{
		[CompilerGenerated]
		get
		{
			return D;
		}
		[CompilerGenerated]
		set
		{
			D = value;
		}
	}

	public string Cookie
	{
		[CompilerGenerated]
		get
		{
			return d;
		}
		[CompilerGenerated]
		set
		{
			d = value;
		}
	}

	public string Mail
	{
		[CompilerGenerated]
		get
		{
			return E;
		}
		[CompilerGenerated]
		set
		{
			E = value;
		}
	}

	public string PassMail
	{
		[CompilerGenerated]
		get
		{
			return e;
		}
		[CompilerGenerated]
		set
		{
			e = value;
		}
	}

	public string MailKhoiPhuc
	{
		[CompilerGenerated]
		get
		{
			return F;
		}
		[CompilerGenerated]
		set
		{
			F = value;
		}
	}

	public string PassMailKhoiPhuc
	{
		[CompilerGenerated]
		get
		{
			return f;
		}
		[CompilerGenerated]
		set
		{
			f = value;
		}
	}

	public string BanBe
	{
		[CompilerGenerated]
		get
		{
			return G;
		}
		[CompilerGenerated]
		set
		{
			G = value;
		}
	}

	public string Nhom
	{
		[CompilerGenerated]
		get
		{
			return g;
		}
		[CompilerGenerated]
		set
		{
			g = value;
		}
	}

	public string GioiTinh
	{
		[CompilerGenerated]
		get
		{
			return H;
		}
		[CompilerGenerated]
		set
		{
			H = value;
		}
	}

	public string Avatar
	{
		[CompilerGenerated]
		get
		{
			return h;
		}
		[CompilerGenerated]
		set
		{
			h = value;
		}
	}

	public string ProfileChrome
	{
		[CompilerGenerated]
		get
		{
			return I;
		}
		[CompilerGenerated]
		set
		{
			I = value;
		}
	}

	public string TenProfile
	{
		[CompilerGenerated]
		get
		{
			return i;
		}
		[CompilerGenerated]
		set
		{
			i = value;
		}
	}

	public string UserAgent
	{
		[CompilerGenerated]
		get
		{
			return J;
		}
		[CompilerGenerated]
		set
		{
			J = value;
		}
	}

	public string Proxy
	{
		[CompilerGenerated]
		get
		{
			return j;
		}
		[CompilerGenerated]
		set
		{
			j = value;
		}
	}

	public string TepCu
	{
		[CompilerGenerated]
		get
		{
			return K;
		}
		[CompilerGenerated]
		set
		{
			K = value;
		}
	}

	public string GhiChu
	{
		[CompilerGenerated]
		get
		{
			return k;
		}
		[CompilerGenerated]
		set
		{
			k = value;
		}
	}

	public string TuongTacCuoi
	{
		[CompilerGenerated]
		get
		{
			return L;
		}
		[CompilerGenerated]
		set
		{
			L = value;
		}
	}

	public string TrangThai
	{
		[CompilerGenerated]
		get
		{
			return l;
		}
		[CompilerGenerated]
		set
		{
			l = value;
		}
	}

	public string TinhTrang
	{
		[CompilerGenerated]
		get
		{
			return M;
		}
		[CompilerGenerated]
		set
		{
			M = value;
		}
	}
}
