using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace testTuongTacWPF.Models;

public class NickFolder : INotifyPropertyChanged
{
	public const int AllFolderId = -1;

	public const int TrashFolderId = -2;

	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	private int m_2366;

	private string m_2367 = "";

	private bool m_2368;

	private int a;

	private static readonly string[] m_2369 = new string[10] { "#38BDF8", "#A78BFA", "#10B981", "#FB923C", "#6366F1", "#F472B6", "#14B8A6", "#FACC15", "#818CF8", "#EC4899" };

	public int Id
	{
		get
		{
			return m_2366;
		}
		set
		{
			if (m_2366 != value)
			{
				m_2366 = value;
				A?.Invoke(this, new PropertyChangedEventArgs("Id"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconGlyph"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconColor"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconBgColor"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconBorderColor"));
			}
		}
	}

	public string Name
	{
		get
		{
			return m_2367;
		}
		set
		{
			if (m_2367 != value)
			{
				m_2367 = value;
				A?.Invoke(this, new PropertyChangedEventArgs("Name"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconColor"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconBgColor"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconBorderColor"));
			}
		}
	}

	public bool IsSystem
	{
		get
		{
			return m_2368;
		}
		set
		{
			if (m_2368 != value)
			{
				m_2368 = value;
				A?.Invoke(this, new PropertyChangedEventArgs("IsSystem"));
				A?.Invoke(this, new PropertyChangedEventArgs("CanManage"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconColor"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconBgColor"));
				A?.Invoke(this, new PropertyChangedEventArgs("IconBorderColor"));
			}
		}
	}

	public bool CanManage => !IsSystem;

	public int Count
	{
		get
		{
			return a;
		}
		set
		{
			m_2370(ref a, value, "Count");
		}
	}

	public string IconGlyph
	{
		get
		{
			if (Id == -1)
			{
				return "\ue8ec";
			}
			if (Id == -2)
			{
				return "\ue74d";
			}
			return "\ue8b7";
		}
	}

	public string IconColor
	{
		get
		{
			if (Id == -1)
			{
				return "#38BDF8";
			}
			if (Id == -2)
			{
				return "#F87171";
			}
			if (IsSystem || Name == "Mặc định")
			{
				return "#F59E0B";
			}
			int num = Math.Abs(Id) % m_2369.Length;
			return m_2369[num];
		}
	}

	public string IconBgColor
	{
		get
		{
			string text = IconColor.TrimStart('#');
			return "#1F" + text;
		}
	}

	public string IconBorderColor
	{
		get
		{
			string text = IconColor.TrimStart('#');
			return "#40" + text;
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2370<gm_2361>(ref gm_2361 P_0, gm_2361 P_1, [CallerMemberName] string? propertyName = null)
	{
		if (!object.Equals(P_0, P_1))
		{
			P_0 = P_1;
			A?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
