using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace testTuongTacWPF.Models;

public class ProfileRow : INotifyPropertyChanged
{
	[CompilerGenerated]
	private PropertyChangedEventHandler? A;

	private bool m_2419;

	private int m_2420;

	private string m_2421 = "";

	private string a = "";

	private string B = "";

	private string b = "";

	private string C = "";

	private string c = "";

	private string D = "";

	private string d = "";

	private string E = "";

	private string e = "";

	public bool IsSelected
	{
		get
		{
			return m_2419;
		}
		set
		{
			m_2422(ref m_2419, value, "IsSelected");
		}
	}

	public int Index
	{
		get
		{
			return m_2420;
		}
		set
		{
			m_2422(ref m_2420, value, "Index");
		}
	}

	public string Name
	{
		get
		{
			return m_2421;
		}
		set
		{
			m_2422(ref m_2421, value, "Name");
		}
	}

	public string ProfileGroup
	{
		get
		{
			return a;
		}
		set
		{
			m_2422(ref a, value, "ProfileGroup");
		}
	}

	public string OS
	{
		get
		{
			return B;
		}
		set
		{
			m_2422(ref B, value, "OS");
		}
	}

	public string Browser
	{
		get
		{
			return b;
		}
		set
		{
			m_2422(ref b, value, "Browser");
		}
	}

	public string BrowserVersion
	{
		get
		{
			return C;
		}
		set
		{
			m_2422(ref C, value, "BrowserVersion");
		}
	}

	public string Proxy
	{
		get
		{
			return c;
		}
		set
		{
			m_2422(ref c, value, "Proxy");
		}
	}

	public string Note
	{
		get
		{
			return D;
		}
		set
		{
			m_2422(ref D, value, "Note");
		}
	}

	public string Status
	{
		get
		{
			return d;
		}
		set
		{
			m_2422(ref d, value, "Status");
		}
	}

	public string LastOpened
	{
		get
		{
			return E;
		}
		set
		{
			m_2422(ref E, value, "LastOpened");
		}
	}

	public string Tags
	{
		get
		{
			return e;
		}
		set
		{
			m_2422(ref e, value, "Tags");
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged
	{
		[CompilerGenerated]
		add
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			PropertyChangedEventHandler propertyChangedEventHandler = A;
			PropertyChangedEventHandler propertyChangedEventHandler2;
			do
			{
				propertyChangedEventHandler2 = propertyChangedEventHandler;
				PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
				propertyChangedEventHandler = Interlocked.CompareExchange(ref A, value2, propertyChangedEventHandler2);
			}
			while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
		}
	}

	private void m_2422<gm_2406>(ref gm_2406 P_0, gm_2406 P_1, [CallerMemberName] string? propertyName = null)
	{
		if (!object.Equals(P_0, P_1))
		{
			P_0 = P_1;
			A?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
