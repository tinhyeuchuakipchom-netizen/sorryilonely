namespace testTuongTacWPF.Models;

public enum AiVisionStepType
{
	AiGoal,
	Wait,
	RandomWait,
	Tap,
	Swipe,
	Text,
	Goto,
	Scroll,
	KeyPress
}
