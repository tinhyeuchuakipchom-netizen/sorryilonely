using System.Runtime.CompilerServices;

namespace testTuongTacWPF.Models;

public class CustomAiProvider
{
	[CompilerGenerated]
	private string A = "";

	[CompilerGenerated]
	private string a = "";

	[CompilerGenerated]
	private string B = "";

	[CompilerGenerated]
	private string b = "";

	[CompilerGenerated]
	private string C = "OpenAI";

	public string Name
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		set
		{
			A = value;
		}
	}

	public string ApiUrl
	{
		[CompilerGenerated]
		get
		{
			return a;
		}
		[CompilerGenerated]
		set
		{
			a = value;
		}
	}

	public string ApiKey
	{
		[CompilerGenerated]
		get
		{
			return B;
		}
		[CompilerGenerated]
		set
		{
			B = value;
		}
	}

	public string Model
	{
		[CompilerGenerated]
		get
		{
			return b;
		}
		[CompilerGenerated]
		set
		{
			b = value;
		}
	}

	public string Format
	{
		[CompilerGenerated]
		get
		{
			return C;
		}
		[CompilerGenerated]
		set
		{
			C = value;
		}
	}
}
