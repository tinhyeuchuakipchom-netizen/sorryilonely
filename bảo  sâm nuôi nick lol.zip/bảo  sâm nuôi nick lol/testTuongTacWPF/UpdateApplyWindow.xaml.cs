using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using testTuongTacWPF.Licensing;

namespace testTuongTacWPF;

public partial class UpdateApplyWindow : Window, IComponentConnector
{
	private readonly string A;

	private CancellationTokenSource? m_2204;

	private bool m_2205;

	public UpdateApplyWindow(string installDir)
	{
		InitializeComponent();
		A = installDir;
		Loaded += async delegate
		{
			await m_2206();
		};
	}

	private async Task m_2206()
	{
		ErrorButtonsPanel.Visibility = Visibility.Collapsed;
		m_2210(false);
		m_2204 = new CancellationTokenSource();
		IProgress<UpdateProgress> progress = new Progress<UpdateProgress>(m_2207);
		try
		{
			await SelfUpdateService.RunAsync(A, progress, m_2204.Token);
			Environment.Exit(0);
		}
		catch (OperationCanceledException)
		{
			Environment.Exit(0);
		}
		catch (Exception ex2)
		{
			m_2209(ex2.Message);
		}
	}

	private void m_2207(UpdateProgress P_0)
	{
		StatusText.Text = P_0.Message;
		double num = P_0.PercentComplete ?? m_2208(P_0.Phase);
		double actualWidth = ((FrameworkElement)(object)ProgressFill.Parent).ActualWidth;
		ProgressFill.Width = Math.Max(0.0, Math.Min(actualWidth, actualWidth * num / 100.0));
	}

	private static double m_2208(UpdatePhase P_0)
	{
		return P_0 switch
		{
			UpdatePhase.CheckingVersion => 5, 
			UpdatePhase.Verifying => 8, 
			UpdatePhase.Downloading => 10, 
			UpdatePhase.Installing => 90, 
			UpdatePhase.RelaunchingApp => 98, 
			UpdatePhase.Done => 100, 
			_ => 0, 
		};
	}

	private void m_2209(string P_0)
	{
		StatusText.Text = "Lỗi: " + P_0;
		m_2210(true);
		ErrorButtonsPanel.Visibility = Visibility.Visible;
	}

	private void m_2210(bool P_0)
	{
		ProgressFill.Background = new SolidColorBrush(P_0 ? Color.FromRgb(239, 68, 68) : Color.FromRgb(140, 111, 247));
	}

	private async void m_2211(object P_0, RoutedEventArgs P_1)
	{
		await m_2206();
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		m_2204?.Cancel();
		Environment.Exit(0);
	}

	[CompilerGenerated]
	private async void B(object P_0, RoutedEventArgs P_1)
	{
		await m_2206();
	}
}
