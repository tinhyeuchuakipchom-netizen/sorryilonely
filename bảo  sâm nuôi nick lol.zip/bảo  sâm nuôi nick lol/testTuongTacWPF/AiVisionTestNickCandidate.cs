using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace testTuongTacWPF;

public sealed class AiVisionTestNickCandidate
{
	[CompilerGenerated]
	private readonly string A;

	[CompilerGenerated]
	private readonly int m_146;

	[CompilerGenerated]
	private readonly IReadOnlyDictionary<string, string> m_147;

	public required string Uid
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		init
		{
			A = value;
		}
	}

	public required int FolderId
	{
		[CompilerGenerated]
		get
		{
			return m_146;
		}
		[CompilerGenerated]
		init
		{
			m_146 = value;
		}
	}

	public required IReadOnlyDictionary<string, string> Variables
	{
		[CompilerGenerated]
		get
		{
			return m_147;
		}
		[CompilerGenerated]
		init
		{
			m_147 = value;
		}
	}
}
