using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace testTuongTacWPF;

public static class ThemeManager
{
	public static readonly string[] ThemeOrder = new string[2] { "Neon", "Dark" };

	private const string A = "Neon";

	private static readonly Dictionary<string, Dictionary<string, Color>> m_2169 = new Dictionary<string, Dictionary<string, Color>>
	{
		["Dark"] = new Dictionary<string, Color>
		{
			["BrushWindowBg"] = Color.FromRgb(11, 9, 16),
			["BrushTitleBar"] = Color.FromRgb(11, 9, 16),
			["BrushSidebar"] = Color.FromRgb(11, 9, 16),
			["BrushContent"] = Color.FromRgb(16, 13, 21),
			["BrushCard"] = Color.FromRgb(28, 23, 38),
			["BrushBorder"] = Color.FromRgb(36, 32, 48),
			["BrushBorderLight"] = Color.FromRgb(51, 44, 70),
			["BrushAccent"] = Color.FromRgb(140, 111, 247),
			["BrushAccentSoft"] = Color.FromRgb(43, 32, 73),
			["BrushTextPrimary"] = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue),
			["BrushTextSecondary"] = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue),
			["BrushTextMuted"] = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue),
			["BrushGreen"] = Color.FromRgb(34, 197, 94),
			["BrushYellow"] = Color.FromRgb(251, 191, 36),
			["BrushHover"] = Color.FromRgb(32, 26, 44)
		},
		["Neon"] = new Dictionary<string, Color>
		{
			["BrushWindowBg"] = Color.FromRgb(9, 4, 20),
			["BrushTitleBar"] = Color.FromRgb(18, 7, 38),
			["BrushSidebar"] = Color.FromRgb(13, 5, 28),
			["BrushContent"] = Color.FromRgb(11, 5, 23),
			["BrushCard"] = Color.FromRgb(23, 11, 51),
			["BrushBorder"] = Color.FromRgb(88, 28, 135),
			["BrushBorderLight"] = Color.FromRgb(126, 34, 206),
			["BrushAccent"] = Color.FromRgb(192, 38, 211),
			["BrushAccentSoft"] = Color.FromRgb(46, 16, 101),
			["BrushTextPrimary"] = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue),
			["BrushTextSecondary"] = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue),
			["BrushTextMuted"] = Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue),
			["BrushGreen"] = Color.FromRgb(74, 222, 128),
			["BrushYellow"] = Color.FromRgb(234, 179, 8),
			["BrushHover"] = Color.FromRgb(31, 14, 61)
		}
	};

	private static readonly Dictionary<string, (Color Start, Color Mid, Color End)> m_2170 = new Dictionary<string, (Color, Color, Color)>
	{
		["Dark"] = (Color.FromRgb(192, 97, 240), Color.FromRgb(139, 79, 232), Color.FromRgb(91, 61, 235)),
		["Neon"] = (Color.FromRgb(139, 92, 246), Color.FromRgb(192, 38, 211), Color.FromRgb(236, 72, 153))
	};

	public static bool IsKnownTheme(string? theme)
	{
		if (theme != null)
		{
			return m_2169.ContainsKey(theme);
		}
		return false;
	}

	public static void Apply(string theme)
	{
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		if (!m_2169.TryGetValue(theme, out Dictionary<string, Color> value))
		{
			value = m_2169["Neon"];
		}
		ResourceDictionary resources = Application.Current.Resources;
		foreach (var (key, color2) in value)
		{
			resources[key] = new SolidColorBrush(color2);
		}
		if (!m_2170.TryGetValue(theme, out (Color, Color, Color) value2))
		{
			value2 = m_2170["Neon"];
		}
		resources["BrushPrimaryGradient"] = new LinearGradientBrush
		{
			StartPoint = new Point(0.0, 0.0),
			EndPoint = new Point(1.0, 1.0),
			GradientStops = new GradientStopCollection
			{
				new GradientStop(value2.Item1, 0.0),
				new GradientStop(value2.Item2, 0.5),
				new GradientStop(value2.Item3, 1.0)
			}
		};
		resources["ColorAccentGlow"] = value2.Item2;
	}

	public static string NextTheme(string current)
	{
		int num = Array.IndexOf(ThemeOrder, current);
		return ThemeOrder[(num + 1) % ThemeOrder.Length];
	}
}
