using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class AiVisionPickTestNickWindow : Window, IComponentConnector, IStyleConnector
{
	[Serializable]
	[CompilerGenerated]
	private sealed class m_166
	{
		public static readonly m_166 A = new m_166();

		public static Func<AiVisionTestNickCandidate, bool> m_168;

		internal bool m_169(AiVisionTestNickCandidate P_0)
		{
			return P_0.FolderId != -2;
		}
	}

	[CompilerGenerated]
	private sealed class m_167
	{
		public AiVisionPickTestNickWindow A;

		public string m_170;

		internal bool m_171(AiVisionTestNickCandidate P_0)
		{
			return P_0.FolderId == A.m_157.Id;
		}

		internal bool a(AiVisionTestNickCandidate P_0)
		{
			return P_0.Uid.Contains(m_170, StringComparison.OrdinalIgnoreCase);
		}
	}

	private readonly List<AiVisionTestNickPlatform> A;

	private AiVisionTestNickPlatform? m_156;

	private NickFolder? m_157;

	private AiVisionTestNickSelection? m_158;

	private bool m_159;

	private AiVisionPickTestNickWindow(List<AiVisionTestNickPlatform> P_0)
	{
		InitializeComponent();
		A = P_0;
		PlatformItemsControl.ItemsSource = A;
	}

	private void m_160(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_161(object P_0, RoutedEventArgs P_1)
	{
		m_158 = null;
		Close();
	}

	private void a(object P_0, RoutedEventArgs P_1)
	{
		if ((P_0 as Button)?.Tag is AiVisionTestNickPlatform aiVisionTestNickPlatform)
		{
			m_156 = aiVisionTestNickPlatform;
			FolderListBox.ItemsSource = aiVisionTestNickPlatform.Folders;
			PlatformPanel.Visibility = Visibility.Collapsed;
			FolderListBox.Visibility = Visibility.Visible;
			TitleText.Text = "Chọn thư mục - " + aiVisionTestNickPlatform.Label;
			BackButton.Visibility = Visibility.Visible;
		}
	}

	private void m_162(object P_0, SelectionChangedEventArgs P_1)
	{
		if (FolderListBox.SelectedItem is NickFolder nickFolder && m_156 != null)
		{
			m_157 = nickFolder;
			m_163();
		}
	}

	private void m_163()
	{
		if (m_156 != null && m_157 != null)
		{
			NickSearchBox.Text = "";
			a();
			FolderListBox.Visibility = Visibility.Collapsed;
			NickPanel.Visibility = Visibility.Visible;
			TitleText.Text = "Chọn nick - " + m_156.Label + " / " + m_157.Name;
		}
	}

	private void a()
	{
		if (m_156 == null || m_157 == null)
		{
			return;
		}
		IEnumerable<AiVisionTestNickCandidate> source = ((m_157.Id == -1) ? m_156.Nicks.Where((AiVisionTestNickCandidate P_0) => P_0.FolderId != -2) : m_156.Nicks.Where((AiVisionTestNickCandidate P_0) => P_0.FolderId == m_157.Id));
		string m_170 = NickSearchBox.Text.Trim();
		if (!string.IsNullOrEmpty(m_170))
		{
			source = source.Where((AiVisionTestNickCandidate P_0) => P_0.Uid.Contains(m_170, StringComparison.OrdinalIgnoreCase));
		}
		List<AiVisionTestNickCandidate> list = source.ToList();
		NickListBox.ItemsSource = list;
		NickEmptyText.Visibility = ((list.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void m_164(object P_0, TextChangedEventArgs P_1)
	{
		a();
	}

	private void a(object P_0, SelectionChangedEventArgs P_1)
	{
		if (NickListBox.SelectedItem is AiVisionTestNickCandidate aiVisionTestNickCandidate && m_156 != null)
		{
			m_158 = new AiVisionTestNickSelection
			{
				Label = m_156.Label + "/" + aiVisionTestNickCandidate.Uid,
				Variables = aiVisionTestNickCandidate.Variables
			};
			Close();
		}
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		if (NickPanel.Visibility == Visibility.Visible)
		{
			NickPanel.Visibility = Visibility.Collapsed;
			FolderListBox.Visibility = Visibility.Visible;
			TitleText.Text = ((m_156 != null) ? ("Chọn thư mục - " + m_156.Label) : "Chọn thư mục");
		}
		else if (FolderListBox.Visibility == Visibility.Visible)
		{
			FolderListBox.Visibility = Visibility.Collapsed;
			PlatformPanel.Visibility = Visibility.Visible;
			TitleText.Text = "Chọn nền tảng";
			BackButton.Visibility = Visibility.Collapsed;
		}
	}

	public static AiVisionTestNickSelection? Show(Window? owner, List<AiVisionTestNickPlatform> platforms)
	{
		AiVisionPickTestNickWindow aiVisionPickTestNickWindow = new AiVisionPickTestNickWindow(platforms);
		if (owner != null)
		{
			aiVisionPickTestNickWindow.Owner = owner;
		}
		aiVisionPickTestNickWindow.ShowDialog();
		return aiVisionPickTestNickWindow.m_158;
	}
}
