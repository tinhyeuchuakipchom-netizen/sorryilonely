using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;

namespace testTuongTacWPF;

public partial class PromptDialog : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private PromptDialog()
	{
		InitializeComponent();
	}

	private void m_2099(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_2100(object P_0, KeyEventArgs P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)P_1.Key == 6)
		{
			m_2101(P_0, P_1);
		}
	}

	private void m_2101(object P_0, RoutedEventArgs P_1)
	{
		A = true;
		Close();
	}

	private void m_2102(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	public static string? Show(Window? owner, string title, string message, string defaultValue = "")
	{
		PromptDialog promptDialog = new PromptDialog();
		if (owner != null)
		{
			promptDialog.Owner = owner;
		}
		promptDialog.TitleText.Text = title;
		promptDialog.MessageText.Text = message;
		promptDialog.InputTextBox.Text = defaultValue;
		promptDialog.InputTextBox.Focus();
		promptDialog.InputTextBox.SelectAll();
		promptDialog.ShowDialog();
		if (!promptDialog.A)
		{
			return null;
		}
		return promptDialog.InputTextBox.Text.Trim();
	}
}
