using System;
using System.Globalization;
using System.Windows.Controls;
using System.Windows.Data;

namespace testTuongTacWPF.Converters;

public class RowPositionConverter : IMultiValueConverter
{
	public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
	{
		if (values.Length < 2 || values[0] == null || !(values[1] is DataGrid dataGrid))
		{
			return "";
		}
		int num = dataGrid.Items.IndexOf(values[0]);
		if (num < 0)
		{
			return "";
		}
		return (num + 1).ToString();
	}

	public object[] ConvertBack(object P_2671, Type[] targetTypes, object parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}
