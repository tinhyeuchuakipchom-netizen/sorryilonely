using System;
using System.Globalization;
using System.Windows.Data;

namespace testTuongTacWPF.Converters;

public class WidthToFontSizeConverter : IMultiValueConverter
{
	public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
	{
		if (values.Length < 1 || !(values[0] is double num) || double.IsNaN(num) || num <= 0.0)
		{
			return 14.0;
		}
		return Math.Clamp(8.0 + num * 0.006, 11.0, 18.0);
	}

	public object[] ConvertBack(object P_2672, Type[] targetTypes, object parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}
