using System;
using System.Globalization;
using System.Windows.Data;

namespace testTuongTacWPF.Converters;

public class IndexPlusOneConverter : IValueConverter
{
	public object Convert(object P_2669, Type targetType, object parameter, CultureInfo culture)
	{
		if (P_2669 is int num)
		{
			return (num + 1).ToString();
		}
		return P_2669 ?? "";
	}

	public object ConvertBack(object P_2670, Type targetType, object parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}
