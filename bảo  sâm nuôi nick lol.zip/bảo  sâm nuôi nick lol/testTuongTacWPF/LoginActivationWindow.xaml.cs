using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Licensing;

namespace testTuongTacWPF;

public partial class LoginActivationWindow : Window, IComponentConnector
{
	[CompilerGenerated]
	private string A = "";

	private bool m_473;

	public string LoggedInUsername
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		private set
		{
			A = value;
		}
	}

	public LoginActivationWindow()
	{
		InitializeComponent();
		LicenseSettings licenseSettings = LicenseSettings.Load();
		UsernameTextBox.Text = licenseSettings.Username;
	}

	private void m_474(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_475(object P_0, RoutedEventArgs P_1)
	{
		DialogResult = false;
		Close();
	}

	private void m_476(object P_0, KeyEventArgs P_1)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)P_1.Key == 6)
		{
			a(P_0, P_1);
		}
	}

	private async void a(object P_0, RoutedEventArgs P_1)
	{
		string text = UsernameTextBox.Text.Trim();
		string password = PasswordBox.Password;
		if (string.IsNullOrWhiteSpace(text) || string.IsNullOrWhiteSpace(password))
		{
			m_477("Vui lòng nhập đầy đủ tài khoản và mật khẩu.");
			return;
		}
		LoginButton.IsEnabled = false;
		LoginButton.Content = "Đang đăng nhập...";
		m_477("");
		LicenseLoginResult licenseLoginResult = await LicenseClient.LoginAsync(text, password);
		LoginButton.IsEnabled = true;
		LoginButton.Content = "Đăng nhập";
		if (licenseLoginResult.Success)
		{
			LicenseSettings licenseSettings = new LicenseSettings();
			licenseSettings.Username = text;
			licenseSettings.Password = password;
			licenseSettings.LoggedInBefore = true;
			licenseSettings.Save();
			LoggedInUsername = text;
			DialogResult = true;
			Close();
		}
		else
		{
			m_477(licenseLoginResult.Message);
		}
	}

	private void m_477(string P_0)
	{
		StatusText.Text = P_0;
		StatusText.Visibility = (string.IsNullOrWhiteSpace(P_0) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		RegisterWindow registerWindow = new RegisterWindow
		{
			Owner = this
		};
		if (registerWindow.ShowDialog() == true)
		{
			UsernameTextBox.Text = registerWindow.RegisteredUsername;
			PasswordBox.Focus();
		}
	}
}
