using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace testTuongTacWPF;

public partial class CustomMessageBox : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private CustomMessageBox()
	{
		InitializeComponent();
	}

	private void m_337(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_338(object P_0, RoutedEventArgs P_1)
	{
		A = true;
		Close();
	}

	private void m_339(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private void B(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	private static CustomMessageBox m_340(Window? owner, string P_1, string P_2, NotifyType P_3)
	{
		CustomMessageBox customMessageBox = new CustomMessageBox();
		if (owner != null)
		{
			customMessageBox.Owner = owner;
		}
		customMessageBox.TitleText.Text = P_2;
		customMessageBox.MessageText.Text = P_1;
		if (P_3 == NotifyType.Warning)
		{
			customMessageBox.IconBorder.Background = (Brush)customMessageBox.FindResource("BrushYellow");
			customMessageBox.IconText.Text = "!";
			customMessageBox.IconText.Foreground = new SolidColorBrush(Color.FromRgb(36, 28, 0));
		}
		else
		{
			customMessageBox.IconBorder.Background = (Brush)customMessageBox.FindResource("BrushGreen");
			customMessageBox.IconText.Text = "✓";
			customMessageBox.IconText.Foreground = Brushes.White;
		}
		return customMessageBox;
	}

	public static void Show(Window? owner, string message, string title, NotifyType type = NotifyType.Success)
	{
		m_340(owner, message, title, type).ShowDialog();
	}

	public static bool Confirm(Window? owner, string message, string title, string okText = "Đồng ý")
	{
		CustomMessageBox customMessageBox = m_340(owner, message, title, NotifyType.Warning);
		customMessageBox.CancelButton.Visibility = Visibility.Visible;
		customMessageBox.OkButton.Content = okText;
		customMessageBox.ShowDialog();
		return customMessageBox.A;
	}
}
