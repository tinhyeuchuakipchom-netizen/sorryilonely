using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using testTuongTacWPF.Automation;

namespace testTuongTacWPF;

public partial class FriendRequestSettingsWindow : Window, IComponentConnector
{
	private bool A;

	private bool a;

	private FriendRequestSettingsWindow(FriendRequestSettings P_0)
	{
		InitializeComponent();
		FriendOptions.Load(P_0);
	}

	private void m_355(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_356(object P_0, RoutedEventArgs P_1)
	{
		if (!FriendOptions.TryRead(out FriendRequestSettings _, out string error))
		{
			ErrorText.Text = error;
			ErrorText.Visibility = Visibility.Visible;
		}
		else
		{
			A = true;
			Close();
		}
	}

	private void m_357(object P_0, RoutedEventArgs P_1)
	{
		A = false;
		Close();
	}

	public static FriendRequestSettings? Show(Window? owner, FriendRequestSettings initial)
	{
		FriendRequestSettingsWindow friendRequestSettingsWindow = new FriendRequestSettingsWindow(initial);
		if (owner != null)
		{
			friendRequestSettingsWindow.Owner = owner;
		}
		friendRequestSettingsWindow.ShowDialog();
		if (!friendRequestSettingsWindow.A)
		{
			return null;
		}
		friendRequestSettingsWindow.FriendOptions.TryRead(out FriendRequestSettings settings, out string _);
		return settings;
	}
}
