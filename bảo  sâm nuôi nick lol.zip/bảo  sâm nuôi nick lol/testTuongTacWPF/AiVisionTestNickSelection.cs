using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace testTuongTacWPF;

public sealed class AiVisionTestNickSelection
{
	[CompilerGenerated]
	private readonly string A;

	[CompilerGenerated]
	private readonly IReadOnlyDictionary<string, string> m_155;

	public required string Label
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		init
		{
			A = value;
		}
	}

	public required IReadOnlyDictionary<string, string> Variables
	{
		[CompilerGenerated]
		get
		{
			return m_155;
		}
		[CompilerGenerated]
		init
		{
			m_155 = value;
		}
	}
}
