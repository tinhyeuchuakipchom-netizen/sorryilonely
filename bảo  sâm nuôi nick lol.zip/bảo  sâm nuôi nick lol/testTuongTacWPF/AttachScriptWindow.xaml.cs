using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using testTuongTacWPF.Models;

namespace testTuongTacWPF;

public partial class AttachScriptWindow : Window, IComponentConnector
{
	[CompilerGenerated]
	private sealed class m_304
	{
		public ScriptItem A;

		public AttachScriptWindow m_305;

		internal void m_306(object P_0, RoutedEventArgs P_1)
		{
			m_305.SelectedScript = A;
			m_305.Close();
		}
	}

	[CompilerGenerated]
	private ScriptItem? A;

	private List<ScriptItem> m_292 = new List<ScriptItem>();

	private string m_293 = "Chrome";

	private int m_294 = 1;

	private string a = "Facebook";

	private const string B = "\ue7c3";

	private bool m_295;

	public ScriptItem? SelectedScript
	{
		[CompilerGenerated]
		get
		{
			return A;
		}
		[CompilerGenerated]
		private set
		{
			A = value;
		}
	}

	internal static (string Glyph, string Accent, string Subtitle) m_296(ScriptItem P_0)
	{
		return P_0.Name switch
		{
			"Đăng nhập" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: (P_0.Platform == "Chrome") ? "Đăng nhập Cookie / UID-Pass / Mail-Pass" : "Đăng nhập FB Katana / App trên thiết bị"), 
			"Tạo Page" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: "Tạo Page mới"), 
			"Nuôi nick" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: "Nuôi nick - lướt bảng tin, tương tác"), 
			"Spam nhóm" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: "Spam nhóm - đăng/bình luận vào nhóm"), 
			"Nuôi bài viết" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: "Nuôi bài viết - like/comment/share"), 
			"Kết bạn" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: "Kết bạn - gợi ý / UID / từ khóa"), 
			"Nhắn tin" => (Glyph: "\ue72e", Accent: "#22C55E", Subtitle: "Nhắn tin - tương tác tin nhắn"), 
			"Đăng bài viết" => (Glyph: "\ue70f", Accent: "#22C55E", Subtitle: "Đăng bài viết - nội dung + ảnh/video ngẫu nhiên"), 
			"Đăng bài trên page" => (Glyph: "\ue774", Accent: "#EC4899", Subtitle: "Đăng bài trên Page - tự động đổi Page & đăng bài"), 
			"Tạo BM" => (Glyph: "\ue774", Accent: "#3B82F6", Subtitle: "Tạo BM - Business Manager Facebook tự động"), 
			"Tương tác" => (Glyph: "\ue72e", Accent: "#3DDC84", Subtitle: "Lướt xem video & tương tác tự động"), 
			"Thả tim" => (Glyph: "\ueb51", Accent: "#EF4444", Subtitle: "Thả tim video tự động"), 
			"Bình luận" => (Glyph: "\ue90a", Accent: "#3B82F6", Subtitle: "Bình luận video - văn bản & hình ảnh"), 
			"Follow (Sub)" => (Glyph: "\ue8fa", Accent: "#8B5CF6", Subtitle: "Follow kênh / tác giả / gợi ý"), 
			"Chia sẻ" => (Glyph: "\ue72d", Accent: "#F59E0B", Subtitle: "Chia sẻ video - repost / copy link"), 
			"Cập nhật Avatar" => (Glyph: "\ueb9f", Accent: "#10B981", Subtitle: "Cập nhật ảnh đại diện TikTok từ máy tính"), 
			_ => (Glyph: "\ue7c3", Accent: "#22C55E", Subtitle: "Kịch bản (" + P_0.Platform + ")"), 
		};
	}

	private AttachScriptWindow()
	{
		InitializeComponent();
	}

	private void m_297(object P_0, MouseButtonEventArgs P_1)
	{
		if (P_1.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private void m_298(object P_0, RoutedEventArgs P_1)
	{
		Close();
	}

	private void m_299(object P_0, RoutedEventArgs P_1)
	{
		if (P_0 == TabChromeRadio)
		{
			m_293 = "Chrome";
		}
		else if (P_0 == TabAndroidRadio)
		{
			m_293 = "Android";
		}
		else if (P_0 == TabIPhoneRadio)
		{
			m_293 = "iPhone";
		}
		m_300();
	}

	private void m_300()
	{
		string text = m_293;
		string text2;
		if (text == "Android")
		{
			text2 = "Phone Android";
		}
		else
		{
			text2 = ((!(text == "iPhone")) ? "Chrome" : "Phone iOS (iPhone)");
		}
		string value = text2;
		if (SubtitleText != null)
		{
			SubtitleText.Text = $"{m_294} nick đã chọn · nền tảng {value} · chọn 1 kịch bản để gắn";
		}
		List<ScriptItem> list = m_292.Where((ScriptItem P_0) =>
		{
			if (!(m_293 == "Chrome"))
			{
				if (!(m_293 == "Android"))
				{
					if (!P_0.Platform.Equals("iPhone", StringComparison.OrdinalIgnoreCase))
					{
						return P_0.Platform.Equals("iOS", StringComparison.OrdinalIgnoreCase);
					}
					return true;
				}
				if (!P_0.Platform.Equals("Android", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Platform.Equals("Phone", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			return P_0.Platform.Equals("Chrome", StringComparison.OrdinalIgnoreCase);
		}).ToList();
		m_301(list);
	}

	private void m_301(IEnumerable<ScriptItem> P_0)
	{
		ScriptCardsPanel.Children.Clear();
		List<ScriptItem> list = P_0.ToList();
		if (list.Count == 0)
		{
			ScriptCardsPanel.Visibility = Visibility.Collapsed;
			EmptyStatePanel.Visibility = Visibility.Visible;
			string text = m_293;
			string text2;
			if (text == "Android")
			{
				text2 = "Android";
			}
			else
			{
				text2 = ((!(text == "iPhone")) ? "Chrome" : "iPhone");
			}
			string text3 = text2;
			EmptyStateTitle.Text = "Chưa có kịch bản nào cho nền tảng " + text3;
			return;
		}
		ScriptCardsPanel.Visibility = Visibility.Visible;
		EmptyStatePanel.Visibility = Visibility.Collapsed;
		FontFamily fontFamily = (FontFamily)Application.Current.FindResource("IconFont");
		Style style = (Style)Application.Current.FindResource("ScriptCardButtonStyle");
		Brush foreground = (Brush)Application.Current.FindResource("BrushTextMuted");
		foreach (ScriptItem A in list)
		{
			(string Glyph, string Accent, string Subtitle) tuple = m_296(A);
			string item = tuple.Glyph;
			string item2 = tuple.Accent;
			string item3 = tuple.Subtitle;
			Color color = (Color)ColorConverter.ConvertFromString(item2);
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = GridLength.Auto
			});
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(1.0, GridUnitType.Star)
			});
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = GridLength.Auto
			});
			Border element = new Border
			{
				Width = 42.0,
				Height = 42.0,
				CornerRadius = new CornerRadius(11.0),
				Background = new SolidColorBrush(color)
				{
					Opacity = 0.16
				},
				VerticalAlignment = VerticalAlignment.Center,
				Child = new TextBlock
				{
					Text = item,
					FontFamily = fontFamily,
					FontSize = 20.0,
					Foreground = new SolidColorBrush(color),
					HorizontalAlignment = HorizontalAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center
				}
			};
			Grid.SetColumn(element, 0);
			grid.Children.Add(element);
			StackPanel stackPanel = new StackPanel
			{
				Margin = new Thickness(12.0, 0.0, 8.0, 0.0),
				VerticalAlignment = VerticalAlignment.Center
			};
			stackPanel.Children.Add(new TextBlock
			{
				Text = A.Name,
				FontSize = 13.5,
				FontWeight = FontWeights.SemiBold,
				TextTrimming = TextTrimming.CharacterEllipsis
			});
			stackPanel.Children.Add(new TextBlock
			{
				Text = item3,
				FontSize = 11.5,
				Foreground = foreground,
				TextTrimming = TextTrimming.CharacterEllipsis,
				Margin = new Thickness(0.0, 2.0, 0.0, 0.0)
			});
			Grid.SetColumn(stackPanel, 1);
			grid.Children.Add(stackPanel);
			string text4 = ((!string.IsNullOrEmpty(A.ChuDe)) ? A.ChuDe : "Facebook");
			string value;
			if (m_293 == "Android")
			{
				value = "#3DDC84";
			}
			else
			{
				value = ((m_293 == "iPhone") ? "#A1A1AA" : "#1877F2");
			}
			Color color2 = (Color)ColorConverter.ConvertFromString(value);
			Border element2 = new Border
			{
				Background = new SolidColorBrush(color2)
				{
					Opacity = 0.18
				},
				BorderBrush = new SolidColorBrush(color2),
				BorderThickness = new Thickness(1.0),
				CornerRadius = new CornerRadius(10.0),
				Padding = new Thickness(9.0, 3.0, 9.0, 3.0),
				VerticalAlignment = VerticalAlignment.Center,
				Child = new TextBlock
				{
					Text = text4,
					FontSize = 10.5,
					FontWeight = FontWeights.Bold,
					Foreground = new SolidColorBrush(color2)
				}
			};
			Grid.SetColumn(element2, 2);
			grid.Children.Add(element2);
			Button button = new Button
			{
				Style = style,
				Content = grid,
				Width = 352.0,
				Margin = new Thickness(0.0, 0.0, 14.0, 14.0)
			};
			button.Click += delegate
			{
				SelectedScript = A;
				Close();
			};
			ScriptCardsPanel.Children.Add(button);
		}
	}

	public static ScriptItem? ShowFor(Window? owner, IEnumerable<ScriptItem> scripts, string platform, int selectedCount, string chuDe = "Facebook")
	{
		AttachScriptWindow attachScriptWindow = new AttachScriptWindow();
		if (owner != null)
		{
			attachScriptWindow.Owner = owner;
		}
		attachScriptWindow.m_292 = scripts.ToList();
		attachScriptWindow.m_294 = selectedCount;
		attachScriptWindow.a = chuDe;
		if (chuDe != "Facebook" && !string.IsNullOrWhiteSpace(chuDe))
		{
			attachScriptWindow.HeaderTitleText.Text = "Danh sách nick " + chuDe;
		}
		if (platform.Equals("Phone", StringComparison.OrdinalIgnoreCase) || platform.Equals("Android", StringComparison.OrdinalIgnoreCase) || platform.Equals("BoxPhone", StringComparison.OrdinalIgnoreCase))
		{
			attachScriptWindow.TabAndroidRadio.IsChecked = true;
		}
		else if (platform.Equals("iPhone", StringComparison.OrdinalIgnoreCase) || platform.Equals("iOS", StringComparison.OrdinalIgnoreCase))
		{
			attachScriptWindow.TabIPhoneRadio.IsChecked = true;
		}
		else
		{
			attachScriptWindow.TabChromeRadio.IsChecked = true;
		}
		attachScriptWindow.m_300();
		attachScriptWindow.ShowDialog();
		return attachScriptWindow.SelectedScript;
	}

	[CompilerGenerated]
	private bool m_303(ScriptItem P_0)
	{
		if (!(m_293 == "Chrome"))
		{
			if (!(m_293 == "Android"))
			{
				if (!P_0.Platform.Equals("iPhone", StringComparison.OrdinalIgnoreCase))
				{
					return P_0.Platform.Equals("iOS", StringComparison.OrdinalIgnoreCase);
				}
				return true;
			}
			if (!P_0.Platform.Equals("Android", StringComparison.OrdinalIgnoreCase))
			{
				return P_0.Platform.Equals("Phone", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
		return P_0.Platform.Equals("Chrome", StringComparison.OrdinalIgnoreCase);
	}
}
